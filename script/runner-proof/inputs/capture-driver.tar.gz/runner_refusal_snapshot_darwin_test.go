package integration

import (
	"context"
	"fmt"
	"sort"
	"sync"
	"time"
)

type runnerDiagnosticOwner struct {
	PID               int                    `json:"pid"`
	Before            *runnerBSDReceipt      `json:"before"`
	After             *runnerBSDReceipt      `json:"after"`
	Kernel            *runnerKernelCode      `json:"kernel"`
	Information       *runnerCodeInformation `json:"information"`
	AppleAnchorStatus *int32                 `json:"appleAnchorStatus"`
	BundleID          *string                `json:"bundleID"`
	BundleUnavailable string                 `json:"bundleUnavailable"`
	Stable            bool                   `json:"stable"`
	Errors            map[string]string      `json:"errors"`
}

type runnerDiagnosticOwnerOps struct {
	BSD  func(context.Context, *runnerNativeTrace, int) (runnerBSDReceipt, error)
	Code func(context.Context, *runnerNativeTrace, int) (*runnerKernelCode, *runnerCodeInformation, *int32, error)
}

func runnerObserveDiagnosticOwner(ctx context.Context, trace *runnerNativeTrace, pid int, ops runnerDiagnosticOwnerOps) runnerDiagnosticOwner {
	out := runnerDiagnosticOwner{PID: pid, BundleUnavailable: "live bundle identifier not queried", Errors: map[string]string{}}
	if ctx == nil || trace == nil || pid < 1 || ops.BSD == nil || ops.Code == nil {
		out.Errors["boundary"] = "diagnostic owner boundary unavailable"
		return out
	}
	before, err := ops.BSD(ctx, trace, pid)
	out.Before = &before
	if err != nil {
		out.Errors["bsd-before"] = runnerSanitizeDiagnostic(err.Error(), nil)
	}
	out.Kernel, out.Information, out.AppleAnchorStatus, err = ops.Code(ctx, trace, pid)
	if err != nil {
		out.Errors["code"] = runnerSanitizeDiagnostic(err.Error(), nil)
	}
	after, err := ops.BSD(ctx, trace, pid)
	out.After = &after
	if err != nil {
		out.Errors["bsd-after"] = runnerSanitizeDiagnostic(err.Error(), nil)
	}
	out.Stable = before.Accepted && after.Accepted && before.Selected != nil && before.Selected.PID == int64(pid) && runnerBSDEqual(before.Selected, after.Selected)
	return out
}

func runnerDiagnosticCode(ctx context.Context, trace *runnerNativeTrace, pid int) (kernel *runnerKernelCode, info *runnerCodeInformation, anchor *int32, err error) {
	c, err := openRunnerSecurityContext(ctx, trace, pid)
	if err != nil {
		return nil, nil, nil, err
	}
	defer c.close()
	k, e := c.kernel()
	kernel = &k
	if e != nil {
		return kernel, nil, nil, e
	}
	object, e := c.guestStatic()
	if e != nil {
		return kernel, nil, nil, e
	}
	defer c.release(object)
	i, e := c.readInformation(object)
	info = &i
	if e != nil {
		return kernel, info, nil, e
	}
	rule, e := c.rule("anchor apple")
	if e != nil {
		return kernel, info, nil, e
	}
	guest, e := c.ensureGuest()
	if e != nil {
		return kernel, info, nil, e
	}
	if e = c.begin("diagnostic-apple-anchor", 16); e != nil {
		return kernel, info, nil, e
	}
	status := c.guestCheck(guest, 16, rule)
	c.record("diagnostic-apple-anchor", 16, status, true)
	anchor = &status
	if c.lost || ctx.Err() != nil {
		return kernel, info, anchor, fmt.Errorf("diagnostic code observation incomplete")
	}
	return kernel, info, anchor, nil
}

type runnerDiagnosticSnapshot struct {
	Sequence    int                     `json:"sequence"`
	Trigger     string                  `json:"trigger"`
	RequestedMS float64                 `json:"requestedMs"`
	StartedMS   *float64                `json:"startedMs"`
	WindowsMS   *float64                `json:"windowsMs"`
	FinishedMS  *float64                `json:"finishedMs"`
	Windows     []independentWindow     `json:"windows"`
	Owners      []runnerDiagnosticOwner `json:"owners"`
	Error       string                  `json:"error"`
	Complete    bool                    `json:"complete"`
}

type runnerSnapshotJournal struct {
	mu             sync.Mutex
	began          time.Time
	rows           []runnerDiagnosticSnapshot
	nextCadence    time.Time
	cadenceSkipped int
	refusal        bool
	finalRefusal   bool
}

func newRunnerSnapshotJournal(began time.Time) *runnerSnapshotJournal {
	return &runnerSnapshotJournal{began: began, nextCadence: began}
}

func (s *runnerSnapshotJournal) request(trigger string, at time.Time) (int, bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if trigger != "cadence" && trigger != "refusal" && trigger != "final-refusal" {
		return 0, false
	}
	if trigger == "refusal" {
		if s.refusal {
			return 0, false
		}
		s.refusal = true
	} else if trigger == "final-refusal" {
		if s.finalRefusal {
			return 0, false
		}
		s.finalRefusal = true
	} else {
		if at.Before(s.nextCadence) {
			return 0, false
		}
		s.nextCadence = at.Add(2 * time.Second)
		for _, r := range s.rows {
			if !r.Complete && r.Trigger == "cadence" {
				s.cadenceSkipped++
				return 0, false
			}
		}
	}
	if len(s.rows) >= 78 {
		return 0, false
	}
	id := len(s.rows) + 1
	s.rows = append(s.rows, runnerDiagnosticSnapshot{Sequence: id, Trigger: trigger, RequestedMS: float64(at.Sub(s.began)) / float64(time.Millisecond)})
	return id, true
}

func (s *runnerSnapshotJournal) update(id int, body func(*runnerDiagnosticSnapshot)) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if id > 0 && id <= len(s.rows) {
		body(&s.rows[id-1])
	}
}

func (s *runnerSnapshotJournal) observe(ctx context.Context, trace *runnerNativeTrace, id int, windows func() ([]independentWindow, error), owner func(int) runnerDiagnosticOwner) {
	now := float64(time.Since(s.began)) / float64(time.Millisecond)
	s.update(id, func(r *runnerDiagnosticSnapshot) { r.StartedMS = &now })
	defer func() {
		at := float64(time.Since(s.began)) / float64(time.Millisecond)
		s.update(id, func(r *runnerDiagnosticSnapshot) { r.FinishedMS = &at; r.Complete = true })
	}()
	actual, err := runnerTracedQuery(ctx, trace, "CGWindowListCopyWindowInfo-diagnostic", windows)
	at := float64(time.Since(s.began)) / float64(time.Millisecond)
	if err != nil {
		s.update(id, func(r *runnerDiagnosticSnapshot) { r.Error = runnerSanitizeDiagnostic(err.Error(), nil) })
		return
	}
	if len(actual) > 512 {
		s.update(id, func(r *runnerDiagnosticSnapshot) { r.Error = "diagnostic window count exceeded" })
		return
	}
	s.update(id, func(r *runnerDiagnosticSnapshot) {
		r.Windows = append([]independentWindow(nil), actual...)
		r.WindowsMS = &at
	})
	pids := map[int]bool{}
	for _, w := range actual {
		if w.PID > 0 {
			pids[w.PID] = true
		}
	}
	if len(pids) > 128 {
		s.update(id, func(r *runnerDiagnosticSnapshot) { r.Error = "diagnostic owner count exceeded" })
		return
	}
	ordered := make([]int, 0, len(pids))
	for pid := range pids {
		ordered = append(ordered, pid)
	}
	sort.Ints(ordered)
	for _, pid := range ordered {
		if ctx.Err() != nil {
			s.update(id, func(r *runnerDiagnosticSnapshot) { r.Error = "diagnostic owner deadline exhausted" })
			return
		}
		fact := owner(pid)
		s.update(id, func(r *runnerDiagnosticSnapshot) { r.Owners = append(r.Owners, fact) })
	}
}

func (s *runnerSnapshotJournal) freeze() ([]runnerDiagnosticSnapshot, int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	out := append([]runnerDiagnosticSnapshot(nil), s.rows...)
	for i := range out {
		out[i].Windows = append([]independentWindow(nil), out[i].Windows...)
		out[i].Owners = append([]runnerDiagnosticOwner(nil), out[i].Owners...)
	}
	return out, s.cadenceSkipped
}

func (s *runnerSnapshotJournal) submit(o *runnerControllerObserver, trigger string, at time.Time) {
	id, ok := s.request(trigger, at)
	if !ok {
		return
	}
	key := fmt.Sprintf("diagnostic-snapshot:%d", id)
	err := o.Submit(key, func(ctx context.Context, trace *runnerNativeTrace) (any, error) {
		s.observe(ctx, trace, id, func() ([]independentWindow, error) { return runnerDiagnosticWindows(readRunnerWindows) }, func(pid int) runnerDiagnosticOwner {
			return runnerObserveDiagnosticOwner(ctx, trace, pid, runnerDiagnosticOwnerOps{BSD: runnerObserveBSDContext, Code: runnerDiagnosticCode})
		})
		return id, nil
	})
	if err != nil {
		s.update(id, func(r *runnerDiagnosticSnapshot) {
			r.Error = runnerSanitizeDiagnostic(err.Error(), nil)
			r.Complete = true
		})
	}
}

func runnerDiagnosticWindows(read func(bool) ([]independentWindow, error)) ([]independentWindow, error) {
	rows, err := read(true)
	if err != nil {
		return nil, err
	}
	rows = append([]independentWindow(nil), rows...)
	for i := range rows {
		rows[i].Title = ""
		rows[i].TitleVisible = false
	}
	return rows, nil
}
