package integration

import (
	"encoding/json"
	"fmt"
	"math"
	"strings"
	"testing"
	"unicode/utf8"
)

type runnerCaptureRow struct {
	Schema  int                        `json:"schema"`
	Case    string                     `json:"case"`
	Capture *bool                      `json:"capture"`
	Stage   string                     `json:"stage"`
	Elapsed float64                    `json:"elapsedMs"`
	Event   float64                    `json:"eventElapsedMs"`
	Fields  map[string]json.RawMessage `json:"-"`
	Timing  *captureTimingRow          `json:"-"`
}

func runnerExactFields(fields map[string]json.RawMessage, keys []string) error {
	if len(fields) != len(keys) {
		return fmt.Errorf("wrong runner field set")
	}
	for _, key := range keys {
		value, ok := fields[key]
		if !ok || strings.TrimSpace(string(value)) == "null" {
			return fmt.Errorf("missing/null runner field")
		}
	}
	return nil
}
func runnerInt(fields map[string]json.RawMessage, key string, low, high int64) (int64, error) {
	var n int64
	if json.Unmarshal(fields[key], &n) != nil || n < low || n > high {
		return 0, fmt.Errorf("runner integer outside bounds")
	}
	return n, nil
}
func runnerText(fields map[string]json.RawMessage, key string) (string, error) {
	var s string
	if json.Unmarshal(fields[key], &s) != nil || s == "" || len(s) > 256 || !utf8.ValidString(s) || strings.ContainsAny(s, "\x00\r\n") {
		return "", fmt.Errorf("invalid runner text")
	}
	return s, nil
}
func runnerBool(fields map[string]json.RawMessage, key string) (bool, error) {
	var b bool
	if json.Unmarshal(fields[key], &b) != nil || strings.TrimSpace(string(fields[key])) == "null" {
		return false, fmt.Errorf("invalid runner boolean")
	}
	return b, nil
}
func runnerOneOf(value string, options string) bool {
	return strings.Contains(" "+options+" ", " "+value+" ") && value != ""
}
func runnerGeometry(raw []byte) (independentRect, error) {
	var rect independentRect
	var fields map[string]json.RawMessage
	if runnerStrict(raw, &rect, 512) != nil || json.Unmarshal(raw, &fields) != nil || runnerExactFields(fields, strings.Fields("x y width height")) != nil {
		return rect, fmt.Errorf("invalid geometry fields")
	}
	if !finiteNonnegative(rect.Width) || !finiteNonnegative(rect.Height) || rect.Width <= 0 || rect.Height <= 0 || rect.Width > 32768 || rect.Height > 32768 || math.IsNaN(rect.X) || math.IsNaN(rect.Y) || math.IsInf(rect.X, 0) || math.IsInf(rect.Y, 0) || math.Abs(rect.X) > 65536 || math.Abs(rect.Y) > 65536 {
		return rect, fmt.Errorf("geometry outside bounds")
	}
	return rect, nil
}
func decodeRunnerCaptureRow(raw []byte) (runnerCaptureRow, error) {
	var row runnerCaptureRow
	var fields map[string]json.RawMessage
	if runnerStrict(raw, &fields, 4096) != nil || json.Unmarshal(raw, &row) != nil || row.Schema != 3 || row.Capture == nil || !*row.Capture || !finiteNonnegative(row.Elapsed) || !finiteNonnegative(row.Event) || row.Event > row.Elapsed {
		return row, fmt.Errorf("invalid runner capture envelope")
	}
	switch row.Case {
	case "selected-window", "display-exclusion", "authorization-exclusion", "reciprocal-revoke", "active-stop", "hotkey-stop":
	default:
		return row, fmt.Errorf("unknown runner capture case")
	}
	row.Fields = fields
	keys := strings.Fields("schema case capture stage elapsedMs eventElapsedMs")
	timingStages := "stop-requested stop-handler-entered local-gate-invalidated revoke-queued native-ack source-admitted native-admitted reverse-revoke-received reverse-reply-enqueued reverse-reply-written reverse-ledger-closed receiver-reset-confirmed capture-stopped"
	if runnerOneOf(row.Stage, timingStages) {
		value, e := decodeCaptureTiming(raw)
		if e != nil {
			return row, e
		}
		row.Timing = &value
		return row, nil
	}
	switch row.Stage {
	case "runner-preflight":
		keys = append(keys, strings.Fields("screenCapture listenEvent postEvent hosted osMajor architecture")...)
	case "surface-launcher-started", "surface-child-reaped":
		keys = append(keys, "label", "pid")
	case "surface-process":
		keys = append(keys, "label", "pid", "bundleIdentifier")
	case "surface-window":
		keys = append(keys, strings.Fields("label pid windowID rect layer profile")...)
	case "surface-unavailable":
		keys = append(keys, "label", "reason")
	case "surfaces-ready":
		keys = append(keys, "counts")
	case "protected-selection-refused":
		keys = append(keys, strings.Fields("label type pid predicateEvidence")...)
		kind, e := runnerText(fields, "type")
		if e != nil {
			return row, e
		}
		if kind == "window" {
			keys = append(keys, "windowID")
		} else if kind != "display" {
			return row, fmt.Errorf("unknown protected probe")
		}
	case "source-validated":
		keys = append(keys, strings.Fields("scope allowedWindowCount protectedWindowCount emptyExceptions")...)
	case "child-started", "child-exit-reaped":
		keys = append(keys, "pid")
	case "surfaces-confirmed", "lanes-authenticated", "heartbeat-ready", "synthetic-link-observed", "grant-requested", "native-granted", "capture-started", "baseline-confirmed":
	case "terminal":
		keys = append(keys, "outcome", "reason")
	default:
		return row, fmt.Errorf("unknown runner capture stage")
	}
	if e := runnerExactFields(fields, keys); e != nil {
		return row, e
	}
	if _, ok := fields["pid"]; ok {
		if _, e := runnerInt(fields, "pid", 1, math.MaxInt32); e != nil {
			return row, e
		}
	}
	if _, ok := fields["windowID"]; ok {
		if _, e := runnerInt(fields, "windowID", 1, math.MaxUint32); e != nil {
			return row, e
		}
	}
	text := func(key string) string { s, _ := runnerText(fields, key); return s }
	label := text("label")
	if _, ok := fields["label"]; ok {
		allowed := "allowed app chrome-a chrome-b authorization"
		if row.Stage == "surface-launcher-started" {
			allowed = "chrome-a chrome-b authorization-requester"
		}
		if row.Stage == "surface-child-reaped" {
			allowed = "allowed chrome-a chrome-b authorization-requester"
		}
		if row.Stage == "surface-unavailable" {
			allowed = "inventory"
		}
		if !runnerOneOf(label, allowed) {
			return row, fmt.Errorf("unknown runner surface label")
		}
	}
	switch row.Stage {
	case "runner-preflight":
		for _, key := range []string{"screenCapture", "listenEvent", "postEvent", "hosted"} {
			if _, e := runnerBool(fields, key); e != nil {
				return row, e
			}
		}
		if _, e := runnerInt(fields, "osMajor", 27, 27); e != nil || text("architecture") != "arm64" {
			return row, fmt.Errorf("unexpected runner platform")
		}
	case "surface-process":
		bundle := text("bundleIdentifier")
		expected := map[string]string{"allowed": "ai.sliccy.proof-helper", "app": "ai.sliccy.mac", "chrome-a": "com.google.Chrome", "chrome-b": "com.google.Chrome"}
		if label == "authorization" {
			if !runnerOneOf(bundle, "com.apple.SecurityAgent com.apple.securityagent com.apple.AuthorizationHost com.apple.authorizationhost") {
				return row, fmt.Errorf("unknown authorization role")
			}
		} else if bundle != expected[label] {
			return row, fmt.Errorf("surface role mismatch")
		}
	case "surface-window":
		if _, e := runnerGeometry(fields["rect"]); e != nil {
			return row, e
		}
		if _, e := runnerInt(fields, "layer", math.MinInt32, math.MaxInt32); e != nil {
			return row, e
		}
		profile := "none"
		if label == "chrome-a" {
			profile = "a"
		}
		if label == "chrome-b" {
			profile = "b"
		}
		if text("profile") != profile {
			return row, fmt.Errorf("wrong surface profile")
		}
	case "surface-unavailable":
		if text("reason") != "unresolved-owner" {
			return row, fmt.Errorf("unknown surface refusal")
		}
	case "surfaces-ready":
		var counts map[string]json.RawMessage
		if json.Unmarshal(fields["counts"], &counts) != nil || runnerExactFields(counts, strings.Fields("processes windows")) != nil {
			return row, fmt.Errorf("invalid counts fields")
		}
		if _, e := runnerInt(counts, "processes", 1, 5); e != nil {
			return row, e
		}
		if _, e := runnerInt(counts, "windows", 1, 128); e != nil {
			return row, e
		}
	case "protected-selection-refused":
		predicate, e := runnerBool(fields, "predicateEvidence")
		if e != nil {
			return row, e
		}
		if label == "allowed" || text("type") == "display" && !predicate {
			return row, fmt.Errorf("confounded/allowed protected display probe")
		}
	case "source-validated":
		scope := "window"
		if row.Case == "display-exclusion" || row.Case == "authorization-exclusion" {
			scope = "display"
		}
		if text("scope") != scope {
			return row, fmt.Errorf("wrong source scope")
		}
		if _, e := runnerInt(fields, "allowedWindowCount", 1, 1); e != nil {
			return row, e
		}
		if _, e := runnerInt(fields, "protectedWindowCount", 0, 127); e != nil {
			return row, e
		}
		if empty, e := runnerBool(fields, "emptyExceptions"); e != nil || !empty {
			return row, fmt.Errorf("nonempty source exceptions")
		}
	case "terminal":
		outcome, reason := text("outcome"), text("reason")
		if !runnerOneOf(outcome, "complete failed failed-to-demonstrate") || !runnerOneOf(reason, "complete fixed-failure permission-unavailable authorization-preexisting surface-unavailable interrupted cleanup-failed diagnostic-loss reverse-incomplete") || (outcome == "complete") != (reason == "complete") {
			return row, fmt.Errorf("invalid terminal disposition")
		}
	}
	return row, nil
}
func TestRunnerCaptureSchemaRejectsUnknownAndMalformedOwnershipMetadata(t *testing.T) {
	base := `{"schema":3,"case":"display-exclusion","capture":true,"elapsedMs":10,"eventElapsedMs":9,`
	examples := []string{
		`"stage":"runner-preflight","screenCapture":true,"listenEvent":false,"postEvent":false,"hosted":true,"osMajor":27,"architecture":"arm64"}`,
		`"stage":"surface-launcher-started","label":"chrome-a","pid":12}`,
		`"stage":"surface-process","label":"chrome-a","pid":12,"bundleIdentifier":"com.google.Chrome"}`,
		`"stage":"surface-window","label":"chrome-a","pid":12,"windowID":7,"rect":{"x":416,"y":64,"width":288,"height":224},"layer":0,"profile":"a"}`,
		`"stage":"surface-unavailable","label":"inventory","reason":"unresolved-owner"}`,
		`"stage":"surfaces-ready","counts":{"processes":4,"windows":6}}`,
		`"stage":"protected-selection-refused","label":"app","type":"window","pid":11,"windowID":2,"predicateEvidence":false}`,
		`"stage":"source-validated","scope":"display","allowedWindowCount":1,"protectedWindowCount":5,"emptyExceptions":true}`,
		`"stage":"child-started","pid":42}`,
		`"stage":"surface-child-reaped","pid":12,"label":"chrome-a"}`,
		`"stage":"terminal","outcome":"failed-to-demonstrate","reason":"surface-unavailable"}`,
	}
	for _, example := range examples {
		if _, e := decodeRunnerCaptureRow([]byte(base + example)); e != nil {
			t.Fatal(example, e)
		}
	}
	for _, stage := range strings.Fields("surfaces-confirmed lanes-authenticated heartbeat-ready synthetic-link-observed grant-requested native-granted capture-started baseline-confirmed") {
		if _, e := decodeRunnerCaptureRow([]byte(base + `"stage":"` + stage + `"}`)); e != nil {
			t.Fatal(e)
		}
	}
	window := base + examples[3]
	for _, bad := range []string{
		strings.Replace(window, `"windowID":7`, `"windowID":0`, 1),
		strings.Replace(window, `"windowID":7`, `"windowID":7,"windowID":8`, 1),
		strings.Replace(window, `"pid":12`, `"pid":12.0`, 1),
		strings.Replace(window, `"profile":"a"`, `"profile":"b"`, 1),
		strings.Replace(window, `"width":288`, `"width":null`, 1),
		strings.Replace(window, `"width":288`, `"width":-1`, 1),
		strings.Replace(window, `"height":224`, `"height":224,"other":1`, 1),
		strings.Replace(window, `"stage":"surface-window"`, `"stage":"unknown"`, 1),
		strings.Replace(window, `"eventElapsedMs":9`, `"eventElapsedMs":null`, 1),
		strings.Replace(window, `"label":"chrome-a"`, `"label":"unknown"`, 1),
		strings.Replace(base+examples[2], `"bundleIdentifier":"com.google.Chrome"`, `"bundleIdentifier":"ai.sliccy.mac"`, 1),
		strings.Replace(base+examples[7], `"emptyExceptions":true`, `"emptyExceptions":false`, 1),
		strings.Replace(base+examples[5], `"processes":4`, `"processes":4,"unknown":false`, 1),
		strings.Replace(base+examples[10], `"outcome":"failed-to-demonstrate"`, `"outcome":"complete"`, 1),
		window + " {}",
	} {
		if _, e := decodeRunnerCaptureRow([]byte(bad)); e == nil {
			t.Fatal("invalid runner row accepted")
		}
	}
}
