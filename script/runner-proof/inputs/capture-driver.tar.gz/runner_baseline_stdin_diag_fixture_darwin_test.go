package integration

import (
	"bytes"
	"errors"
	"testing"
	"time"
)

func TestRunnerChromeIdentityReasonBounds(t *testing.T) {
	cases := []struct {
		identity, strict, guest int64
		accepted                bool
		reason                  string
	}{
		{0, 0, 0, true, "accepted"},
		{0, -66999, 0, true, "accepted-detritus-tolerated"},
		{1, 0, 0, false, "identity-failed"},
		{0, 0, 1, false, "guest-failed"},
		{0, 2, 0, false, "strict-failed"},
		{1, 2, 3, false, "identity-guest-strict-failed"},
	}
	for _, c := range cases {
		ok, reason := runnerChromeIdentityReason(c.identity, c.strict, c.guest)
		if ok != c.accepted || reason != c.reason {
			t.Fatalf("ASSERTION:chrome-identity-reason %v => %v %q want %v %q", c, ok, reason, c.accepted, c.reason)
		}
	}
}

func TestRunnerBaselineMarkerWithholdAndSentStamps(t *testing.T) {
	began := time.Now().Add(-time.Second)
	var diag *runnerBaselineMarkerDiag
	runnerRecordBaselineWithheld(&diag, began, "full CG window universe changed before baseline marker")
	if diag == nil || diag.Decision != "withheld" || diag.Reason == "" || diag.DecisionStamp.MonotonicMS < 0 || diag.Write != nil {
		t.Fatal("ASSERTION:baseline-withheld-stamp")
	}
	runnerRecordBaselineSent(&diag, began, "runner-baseline", nil)
	if diag.Decision != "sent" || diag.Write == nil || diag.Write.Marker != "runner-baseline" || diag.Write.FirstByte != 'r' {
		t.Fatal("ASSERTION:baseline-sent-stamp")
	}
}

func TestRunnerStdinCloserStampsOnce(t *testing.T) {
	began := time.Now().Add(-500 * time.Millisecond)
	buf := &closeBuffer{}
	var closes []runnerStdinCloseStamp
	stdin := &runnerStdinCloser{w: buf, began: began, out: &closes}
	if err := stdin.CloseWithCause("abort-failures"); err != nil {
		t.Fatal(err)
	}
	_ = stdin.CloseWithCause("defer")
	if len(closes) != 1 || closes[0].Cause != "abort-failures" || closes[0].Stamp.MonotonicMS < 0 || !buf.closed {
		t.Fatalf("ASSERTION:stdin-close-stamp %#v closed=%v", closes, buf.closed)
	}
}

func TestRunnerChromeIdentityLiveCap(t *testing.T) {
	began := time.Now()
	counts := map[string]int{}
	var live []runnerChromeIdentityIter
	for i := 0; i < runnerChromeIdentityLiveCap+4; i++ {
		live = runnerAppendChromeIdentityLive(live, began, "chrome-a-1", "live", 0, 0, 0, counts)
	}
	if len(live) != runnerChromeIdentityLiveCap || live[0].Reason != "accepted" || live[0].Iteration != 1 {
		t.Fatal("ASSERTION:chrome-identity-live-cap")
	}
}

type closeBuffer struct {
	bytes.Buffer
	closed bool
}

func (c *closeBuffer) Close() error {
	if c.closed {
		return errors.New("double close")
	}
	c.closed = true
	return nil
}
