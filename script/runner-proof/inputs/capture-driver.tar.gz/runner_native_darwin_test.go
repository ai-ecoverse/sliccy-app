package integration

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"unsafe"

	"github.com/ebitengine/purego"
	"golang.org/x/sys/unix"
)

type runnerProcessFact struct {
	Label   string                 `json:"label"`
	Bundle  string                 `json:"bundle"`
	Path    string                 `json:"path"`
	Kernel  kernelImageObservation `json:"kernel"`
	Root    string                 `json:"ownedRoot,omitempty"`
	Profile string                 `json:"profile,omitempty"`
}

func runnerPlacement() error {
	env := map[string]string{}
	for _, key := range []string{"GITHUB_ACTIONS", "GITHUB_REPOSITORY", "GITHUB_EVENT_NAME", "GITHUB_REF", "SLICCY_RUNNER_ENVIRONMENT"} {
		env[key] = os.Getenv(key)
	}
	version := os.Getenv("SLICCY_RUNNER_OS_VERSION")
	if e := hostedPIDPlacement(env, version, runtime.GOARCH); e != nil {
		return e
	}
	if os.Getenv("RUNNER_ENVIRONMENT") != "github-hosted" {
		return fmt.Errorf("real hosted placement required")
	}
	return nil
}
func runnerProcessPath(pid int) (string, error) {
	lib, e := purego.Dlopen("/usr/lib/libproc.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return "", e
	}
	defer purego.Dlclose(lib)
	var path func(int32, *byte, uint32) int32
	purego.RegisterLibFunc(&path, lib, "proc_pidpath")
	var buf [4096]byte
	n := path(int32(pid), &buf[0], 4096)
	if n <= 0 || n >= 4096 {
		return "", fmt.Errorf("process path unavailable")
	}
	end := bytes.IndexByte(buf[:], 0)
	if end < 1 {
		return "", fmt.Errorf("process path not bounded")
	}
	p, e := filepath.EvalSymlinks(string(buf[:end]))
	if e != nil || !filepath.IsAbs(p) {
		return "", fmt.Errorf("process path unresolved")
	}
	return p, nil
}
func runnerProcArguments(pid int) ([]string, string, error) {
	var size uintptr
	mib := []int32{1, 49, int32(pid)}
	_, _, errno := syscall.Syscall6(syscall.SYS___SYSCTL, uintptr(unsafe.Pointer(&mib[0])), 3, 0, uintptr(unsafe.Pointer(&size)), 0, 0)
	if errno != 0 || size < 8 || size > 262144 {
		return nil, "", fmt.Errorf("bounded process arguments unavailable")
	}
	data := make([]byte, size)
	_, _, errno = syscall.Syscall6(syscall.SYS___SYSCTL, uintptr(unsafe.Pointer(&mib[0])), 3, uintptr(unsafe.Pointer(&data[0])), uintptr(unsafe.Pointer(&size)), 0, 0)
	runtime.KeepAlive(mib)
	if errno != 0 || size > uintptr(len(data)) {
		return nil, "", fmt.Errorf("process arguments query failed")
	}
	return parseRunnerArguments(data[:size])
}
func parseRunnerArguments(data []byte) ([]string, string, error) {
	if len(data) < 8 || len(data) > 262144 {
		return nil, "", fmt.Errorf("argument buffer outside bounds")
	}
	count := int(binary.LittleEndian.Uint32(data[:4]))
	if count < 1 || count > 64 {
		return nil, "", fmt.Errorf("argument count outside bounds")
	}
	rest := data[4:]
	end := bytes.IndexByte(rest, 0)
	if end < 1 {
		return nil, "", fmt.Errorf("missing executable argument")
	}
	rest = rest[end+1:]
	for len(rest) > 0 && rest[0] == 0 {
		rest = rest[1:]
	}
	var args []string
	total := 0
	for i := 0; i < count; i++ {
		end = bytes.IndexByte(rest, 0)
		if end < 0 {
			return nil, "", fmt.Errorf("partial argv")
		}
		total += end
		if total > 16384 {
			return nil, "", fmt.Errorf("argv outside budget")
		}
		args = append(args, string(rest[:end]))
		rest = rest[end+1:]
	}
	tmp := ""
	for len(rest) > 0 {
		end = bytes.IndexByte(rest, 0)
		if end < 0 {
			return nil, "", fmt.Errorf("partial environment")
		}
		if end == 0 {
			break
		}
		item := rest[:end]
		if bytes.HasPrefix(item, []byte("TMPDIR=")) {
			if tmp != "" {
				return nil, "", fmt.Errorf("duplicate temporary root")
			}
			tmp = string(item[7:])
		}
		rest = rest[end+1:]
	}
	return args, tmp, nil
}
func runnerOwnedRoot(tmp string) (string, error) {
	root := filepath.Dir(filepath.Clean(tmp))
	if filepath.Dir(root) != "/private/tmp" || !strings.HasPrefix(filepath.Base(root), "sliccy-runner.") || len(filepath.Base(root)) != len("sliccy-runner.")+8 || filepath.Base(filepath.Clean(tmp)) != "tmp" {
		return "", fmt.Errorf("unexpected owned root")
	}
	for _, path := range []string{root, filepath.Join(root, "tmp"), filepath.Join(root, "config")} {
		s, e := os.Lstat(path)
		if e != nil || !s.IsDir() || s.Mode()&os.ModeSymlink != 0 || s.Mode().Perm()&0077 != 0 {
			return "", fmt.Errorf("unsafe owned directory")
		}
		st, ok := s.Sys().(*syscall.Stat_t)
		if !ok || st.Uid != uint32(os.Getuid()) {
			return "", fmt.Errorf("owned directory UID mismatch")
		}
	}
	return root, nil
}
func runnerChromeArguments(args []string, tmp, label, origin string) (string, error) {
	root, e := runnerOwnedRoot(tmp)
	if e != nil {
		return "", e
	}
	profile := strings.TrimPrefix(label, "chrome-")
	if profile != "a" && profile != "b" {
		return "", fmt.Errorf("unknown browser profile")
	}
	var page fixedProofPage
	if profile == "a" {
		page = fixedProofPageCatalog[0]
	} else {
		page = fixedProofPageCatalog[2]
	}
	want := []string{"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "--user-data-dir=" + filepath.Join(root, "config/chrome-"+profile), "--no-first-run", "--no-default-browser-check", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--disable-default-apps", fmt.Sprintf("--window-position=%d,%d", int(page.Rect.X), int(page.Rect.Y)), "--window-size=288,224", "--app=" + origin + page.Path}
	if len(args) != len(want) {
		return "", fmt.Errorf("unexpected browser argv")
	}
	for i := range want {
		if args[i] != want[i] {
			return "", fmt.Errorf("browser argv differs from fixed profile")
		}
	}
	return root, nil
}
func observeRunnerProcess(label, bundle string, pid, parent int, app, origin string) (runnerProcessFact, error) {
	fact := runnerProcessFact{Label: label, Bundle: bundle}
	before, e := inspectRunnerKernelImage(pid)
	if e != nil {
		return fact, e
	}
	if label != "authorization" && (before.Identity.Parent != parent || before.Identity.UID != uint32(os.Getuid())) {
		return fact, fmt.Errorf("process is not the claimed owned child")
	}
	path, e := runnerProcessPath(pid)
	if e != nil {
		return fact, e
	}
	expected, hash, rule := "", "", ""
	switch label {
	case "app":
		expected = app
		hash = "10212be1ab512e3f25c9ce58c24f0c607e0f3b95"
		rule = runnerDeveloperRule("ai.sliccy.mac", "S8LB56P782")
	case "allowed":
		expected = filepath.Join(filepath.Dir(filepath.Dir(app)), "Helpers/ScreenProofSurface.app/Contents/MacOS/ScreenProofSurface")
		hash = "115b9b7fdbd85445f55f8d9c1a4f6359013f9f20"
		rule = runnerDeveloperRule("ai.sliccy.proof-helper", "S8LB56P782")
	case "cli":
		expected = filepath.Join(filepath.Dir(filepath.Dir(app)), "Resources/slicc")
		hash = "5da1a3199bd3f895bce2e53023c28ca1c33d249e"
		rule = runnerDeveloperRule("ai.sliccy.slicc", "S8LB56P782")
	case "chrome-a", "chrome-b":
		expected = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
		rule = runnerDeveloperRule("com.google.Chrome", "EQHXZ8M8AV")
	case "authorization":
		if !runnerOneOf(bundle, "com.apple.SecurityAgent com.apple.securityagent com.apple.AuthorizationHost com.apple.authorizationhost") || !strings.HasPrefix(path, "/System/Library/") {
			return fact, fmt.Errorf("unattributed Apple authorization service")
		}
		expected = path
		rule = `anchor apple and identifier "` + bundle + `"`
	default:
		return fact, fmt.Errorf("unknown process role")
	}
	resolved, e := filepath.EvalSymlinks(expected)
	if e != nil || path != resolved || before.CPU != 0x0100000c {
		return fact, fmt.Errorf("fixed native process image mismatch")
	}
	if hash != "" && before.CDHash != hash {
		return fact, fmt.Errorf("pinned process code changed")
	}
	if _, e := inspectRunnerImageRules(pid, path, before.CDHash, rule, runnerDeveloperRule("ai.sliccy.invalid-proof-role", "S8LB56P782"), before.CPU); e != nil {
		return fact, e
	}
	if label == "chrome-a" || label == "chrome-b" {
		args, tmp, e := runnerProcArguments(pid)
		if e != nil {
			return fact, e
		}
		root, e := runnerChromeArguments(args, tmp, label, origin)
		if e != nil {
			return fact, e
		}
		fact.Root = root
		fact.Profile = strings.TrimPrefix(label, "chrome-")
	}
	if label == "allowed" {
		_, tmp, e := runnerProcArguments(pid)
		if e != nil {
			return fact, e
		}
		fact.Root, e = runnerOwnedRoot(tmp)
		if e != nil {
			return fact, e
		}
	}
	after, e := inspectRunnerKernelImage(pid)
	if e != nil || after != before {
		return fact, fmt.Errorf("process incarnation/image changed during observation")
	}
	fact.Kernel = before
	fact.Path = path
	return fact, nil
}
func readRunnerMainDisplay() (result independentRect, err error) {
	if runnerPlacement() != nil {
		return result, fmt.Errorf("hosted display observation required")
	}
	defer func() {
		if recover() != nil {
			err = fmt.Errorf("display ABI unavailable")
		}
	}()
	lib, e := purego.Dlopen("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return result, e
	}
	defer purego.Dlclose(lib)
	var main func() uint32
	var bounds func(uint32) independentRect
	purego.RegisterLibFunc(&main, lib, "CGMainDisplayID")
	purego.RegisterLibFunc(&bounds, lib, "CGDisplayBounds")
	result = bounds(main())
	if result.X != 0 || result.Y != 0 || result.Width < 1024 || result.Height < 768 || result.Width > 2560 || result.Height > 2560 || result.Width*result.Height > 4000000 {
		return result, fmt.Errorf("unsupported independent display geometry")
	}
	return result, nil
}
func runnerProcessGone(pid int, identity ownedIncarnation) bool {
	current, e := inspectRunnerIncarnation(pid)
	if e != nil {
		return runnerPIDAbsent(pid)
	}
	return current.Unique != identity.Unique || current.Version != identity.Version
}
func runnerKillOwned(pid int, identity ownedIncarnation, signal unix.Signal) error {
	current, e := inspectOwnedIncarnation(pid, identity.Parent)
	if e != nil || current != identity {
		return fmt.Errorf("refuse signal without exact owned incarnation")
	}
	return unix.Kill(pid, signal)
}

func runnerRootAssociated(args []string, tmp string, roots map[string]bool) bool {
	for root := range roots {
		if filepath.Clean(tmp) == filepath.Join(root, "tmp") {
			return true
		}
		for _, arg := range args {
			if strings.HasPrefix(arg, "--user-data-dir="+filepath.Join(root, "config")+"/") {
				return true
			}
		}
	}
	return false
}
func runnerRootProcesses(roots map[string]bool, app string) ([]int, error) {
	if len(roots) == 0 {
		return nil, nil
	}
	if runnerPlacement() != nil {
		return nil, fmt.Errorf("hosted cleanup inventory required")
	}
	lib, e := purego.Dlopen("/usr/lib/libproc.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return nil, e
	}
	defer purego.Dlclose(lib)
	var all func(*int32, int32) int32
	purego.RegisterLibFunc(&all, lib, "proc_listallpids")
	pids := make([]int32, 4096)
	n := all(&pids[0], int32(len(pids)*4))
	if n < 1 || n >= int32(len(pids)) {
		return nil, fmt.Errorf("cleanup process inventory outside bound")
	}
	var found []int
	for _, pid := range pids[:n] {
		if pid < 1 {
			continue
		}
		identity, e := inspectRunnerIncarnation(int(pid))
		if e != nil || identity.UID != uint32(os.Getuid()) {
			continue
		}
		path, e := runnerProcessPath(int(pid))
		if e != nil {
			if current, check := inspectRunnerIncarnation(int(pid)); check == nil && current == identity {
				return found, fmt.Errorf("live process path unavailable during cleanup")
			}
			continue
		}
		if !runnerCleanupCandidate(path, app) {
			continue
		}
		args, tmp, e := runnerProcArguments(int(pid))
		if e != nil {
			if current, check := inspectRunnerIncarnation(int(pid)); check == nil && current == identity {
				return found, fmt.Errorf("live same-UID process arguments unavailable")
			}
			continue
		}
		if runnerRootAssociated(args, tmp, roots) {
			found = append(found, int(pid))
		}
	}
	return found, nil
}

func runnerCleanupCandidate(path, app string) bool {
	contents := filepath.Dir(filepath.Dir(app))
	return path == app || path == filepath.Join(contents, "Resources/slicc") || path == filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/MacOS/ScreenProofSurface") || strings.HasPrefix(path, "/Applications/Google Chrome.app/")
}

func runnerPIDAbsent(pid int) bool { return pid > 0 && unix.Kill(pid, 0) == unix.ESRCH }

type runnerObserverAccess struct {
	PID                            int   `json:"pid"`
	ScreenCapturePreflight         *bool `json:"screenCapturePreflight"`
	ResponsiblePID                 *int  `json:"responsiblePID"`
	ResponsibilityEstablished      bool  `json:"responsibilityEstablished"`
	PermissionInferredFromAncestry bool  `json:"permissionInferredFromAncestry"`
}

func readRunnerObserverAccess() (result runnerObserverAccess) {
	result.PID = os.Getpid()
	if runnerPlacement() != nil {
		return result
	}
	defer func() {
		if recover() != nil {
			result.ScreenCapturePreflight = nil
		}
	}()
	lib, e := purego.Dlopen("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return result
	}
	defer purego.Dlclose(lib)
	var preflight func() bool
	purego.RegisterLibFunc(&preflight, lib, "CGPreflightScreenCaptureAccess")
	value := preflight()
	result.ScreenCapturePreflight = &value
	return result
}
