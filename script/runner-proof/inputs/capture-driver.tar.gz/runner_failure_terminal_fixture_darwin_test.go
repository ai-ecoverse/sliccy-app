package integration

import (
 "bytes"
 "encoding/json"
 "errors"
 "fmt"
 "io"
 "os"
 "path/filepath"
 "strings"
 "syscall"
 "testing"
 "time"
)

func runnerEmergencyFixtureCase()runnerCaseResult {
 result:=runnerNormalizationCase("selected-window");result.Result="PASS"
 result.AppPID=42;result.AppReaped=true;result.DirectChildrenGone=true;result.RootsRemoved=true;result.OwnedWindowsGone=true;result.ProtocolWorkersSettled=true;result.MetadataReaderSettled=true
 result.AppOutput=runnerCaseOutput{StdoutTail:"first retained output",StderrTail:"retained error",Exit:runnerProcessExit{Observed:true,Exited:true,Code:1}}
 result.Failures=[]string{"first concrete case failure"}
 result.RootObservations=[]runnerRootObservation{{Path:"/private/tmp/fabricated-owned-root",State:"absent",Absent:true}}
 result.SpawnedChildren=map[int]runnerSpawnObservation{43:{Original:runnerSpawnIdentity{PID:43,Parent:42,Role:"surface",Seconds:10,Microseconds:20},IndependentlyBound:true,Settlement:&runnerSpawnSettlement{State:"pid-absent",OriginalGone:true}}}
 return result
}

func TestRunnerV84ReservedFailedTerminalRoundTrip(t *testing.T) {
 for _,kind:=range []string{"type","storage","partial-job"}{t.Run(kind,func(t *testing.T){
  dir:=t.TempDir();budget:=&runnerNormalizationBudget{};w,e:=newRunnerCaseEvidenceWriter(dir,"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,budget);if e!=nil{t.Fatal(e)}
  result:=runnerEmergencyFixtureCase()
  switch kind {
  case "type":result.NativeEvidence.Observations=[]runnerObservation[any]{{Value:make(chan int)}}
  case "storage":budget.Bytes=runnerNormalizationStorageLimit
  case "partial-job":w.mu.Lock();e=w.record("job-begin",map[string]any{"key":"partial","class":"ordinary","rows":2,"lost":false,"pending":0,"rowsNil":false,"snapshotSequence":0});w.problem=runnerNormalizationError("job-write","deadline",nil,1,0);w.mu.Unlock();if e!=nil{t.Fatal(e)}
  }
  index,e:=w.Commit(result)
  if e==nil||index.NormalizationFailure==nil||index.Critical==nil||index.Result!="FAIL"||index.EvidenceComplete||!index.BlockLaterCases{t.Fatal("ASSERTION:v84-failure-terminal-fail-closed",e,index)}
  raw,e:=os.ReadFile(filepath.Join(dir,"driver-evidence.v3.ndjson"));if e!=nil{t.Fatal(e)}
  decoded,e:=readRunnerNormalized(bytes.NewReader(raw),"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,nil,nil)
  if e!=nil||decoded.Index.Critical==nil||decoded.Index.NormalizationFailure==nil||decoded.Index.Result!="FAIL"||decoded.Index.EvidenceComplete||!decoded.Index.BlockLaterCases{t.Fatal("ASSERTION:v84-failure-terminal-roundtrip",e)}
  if decoded.Index.Critical.Output.Exit.Code!=1||decoded.Index.Critical.FirstCaseFailure!="first concrete case failure"||len(decoded.Index.Critical.Children)!=1||!decoded.Index.Critical.Children[0].OriginalGone||!decoded.Index.Critical.Roots[0].Observation.Absent{t.Fatal("ASSERTION:v84-critical-cleanup-exit-retained")}
  if budget.Memory!=0||!bytes.Contains(raw,[]byte(`"tag":"failed-footer"`)){t.Fatal("ASSERTION:v84-emergency-reservation-released")}
  if kind=="type"&&decoded.Index.NormalizationFailure.Reason!="type"{t.Fatal("ASSERTION:v84-first-normalization-predicate")}
  for _,changed:=range [][]byte{bytes.Replace(raw,[]byte(`"evidenceComplete":false`),[]byte(`"evidenceComplete":true`),1),bytes.Replace(raw,[]byte(`"outcome":"FAIL"`),[]byte(`"outcome":"PASS"`),1),raw[:len(raw)-1]}{
   if _,e:=readRunnerNormalized(bytes.NewReader(changed),"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,nil,nil);e==nil{t.Fatal("ASSERTION:v84-failure-terminal-integrity")}
  }
 })}
}

type runnerEmergencySink struct {io.WriteCloser;short bool;failure error;writes int}
func (s *runnerEmergencySink)Write(p []byte)(int,error){s.writes++;if s.short{return s.WriteCloser.Write(p[:len(p)/2])};if s.failure!=nil{return 0,s.failure};return s.WriteCloser.Write(p)}
func TestRunnerV84BusyAndBrokenSinksNeverClaimFooter(t *testing.T) {
 for _,kind:=range []string{"busy","short","error"}{t.Run(kind,func(t *testing.T){
  dir:=t.TempDir();w,e:=newRunnerCaseEvidenceWriter(dir,"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,&runnerNormalizationBudget{});if e!=nil{t.Fatal(e)}
  sink:=&runnerEmergencySink{WriteCloser:w.file,short:kind=="short"};if kind=="error"{sink.failure=syscall.ENOSPC};w.file=sink
  if kind=="busy"{w.mu.Lock()}
  index,e:=w.Commit(runnerEmergencyFixtureCase())
  if kind=="busy"{w.mu.Unlock();w.file.Close();w.budget.releaseMemory((128<<10)+runnerEmergencyMemory)}
  if e==nil||index.NormalizationFailure==nil||index.Critical==nil||index.EvidenceComplete||!index.BlockLaterCases{t.Fatal("ASSERTION:v84-broken-sink-failure-retained")}
  if kind=="busy"&&sink.writes!=0||kind!="busy"&&sink.writes!=1{t.Fatal("ASSERTION:v84-no-concurrent-or-repair-write",sink.writes)}
  raw,e:=os.ReadFile(filepath.Join(dir,"driver-evidence.v3.ndjson"));if e!=nil{t.Fatal(e)}
  if bytes.Contains(raw,[]byte(`"tag":"failed-footer"`)){t.Fatal("ASSERTION:v84-no-false-footer")}
  if kind=="error"&&(index.NormalizationFailure.Errno==nil||*index.NormalizationFailure.Errno!=int64(syscall.ENOSPC)){t.Fatal("ASSERTION:v84-sink-errno-retained")}
 })}
}

func runnerV84EmergencyWorstPayload()(map[string]any,runnerCriticalEvidence){
 result:=runnerEmergencyFixtureCase();escaped:=func(n int)string{return strings.Repeat("\x00",n)}
 result.AppOutput.StdoutTail=escaped(4096);result.AppOutput.StderrTail=escaped(4096);result.Failures=[]string{escaped(512)}
 result.Diagnostics=map[string]runnerDiagnosticPath{"first":{Records:[]runnerDiagnosticRecord{{Order:1,Step:escaped(128),ErrorType:escaped(128),Tail:escaped(1024)}}}}
 result.SpawnedChildren=map[int]runnerSpawnObservation{};result.RootObservations=nil
 for i:=0;i<8;i++{
  result.SpawnedChildren[100+i]=runnerSpawnObservation{Original:runnerSpawnIdentity{PID:100+i,Role:escaped(32),CDHash:escaped(64)},Settlement:&runnerSpawnSettlement{State:escaped(64),Error:escaped(512)}}
  result.RootObservations=append(result.RootObservations,runnerRootObservation{Path:escaped(1024),Error:escaped(512),ErrorType:escaped(128),State:escaped(64),Type:escaped(32)})
 }
 critical:=runnerCriticalSummary(result);cause:=runnerNormalizationError("result-encode","type",errors.New("fixed error"),0,0)
 payload:=map[string]any{"case":"selected-window","critical":&critical,"failure":cause,"prefixSHA256":strings.Repeat("f",64),"prefixBytes":int64(runnerNormalizationStorageLimit),"prefixRecords":uint64(32768),"evidenceComplete":false,"outcome":"FAIL","blockLaterCases":true,"tag":"failed-terminal","sequence":32768}
 return payload,critical
}

func TestRunnerV84EmergencyWorstEscapedBounds(t *testing.T) {
 payload,critical:=runnerV84EmergencyWorstPayload()
 if e:=runnerNormalizationJSONReservationWithin(payload,runnerEmergencyPayloadLimit-1);e!=nil{t.Fatal("ASSERTION:v84-emergency-escaped-reservation",e)}
 raw,e:=json.Marshal(payload);if e!=nil||len(raw)+1>runnerEmergencyPayloadLimit{t.Fatal("ASSERTION:v84-emergency-escaped-encoding",len(raw),e)}
 if int64(len(raw))>runnerEmergencyPayloadLimit-1{t.Fatal("ASSERTION:v84-emergency-escaped-reservation-vs-marshal",len(raw))}
 criticalRaw,e:=json.Marshal(critical);if e!=nil{t.Fatal(e)};if _,e=runnerDecodeCritical(criticalRaw);e!=nil{t.Fatal("ASSERTION:v84-critical-max-roundtrip",e)}
 result:=runnerEmergencyFixtureCase();result.SpawnedChildren=map[int]runnerSpawnObservation{};result.RootObservations=nil
 for i:=0;i<8;i++{
  result.SpawnedChildren[100+i]=runnerSpawnObservation{Original:runnerSpawnIdentity{PID:100+i}}
  result.RootObservations=append(result.RootObservations,runnerRootObservation{Path:"root"})
 }
 result.SpawnedChildren[999]=runnerSpawnObservation{};result.RootObservations=append(result.RootObservations,runnerRootObservation{Path:"ninth"})
 limited:=runnerCriticalSummary(result);if !limited.Limited||limited.DirectChildrenGone||limited.RootsRemoved||len(limited.Children)!=8||len(limited.Roots)!=8{t.Fatal("ASSERTION:v84-critical-overflow-explicit")}
 t.Logf("EMERGENCY_METRICS payload=%d reserve=%d memoryReservation=%d",len(raw)+1,runnerEmergencyReserve,runnerEmergencyMemory)
}

func runnerNormalizationJSONReservationCharge(value any)(int64,error){
 raw,e:=json.Marshal(value);if e!=nil{return 0,e}
 lo,hi:=int64(0),int64(len(raw))+1<<20
 for lo<hi{mid:=(lo+hi)/2;if runnerNormalizationJSONReservationWithin(value,mid)==nil{hi=mid}else{lo=mid+1}}
 if runnerNormalizationJSONReservationWithin(value,lo)!=nil{return 0,fmt.Errorf("reservation charge not found")}
 return lo,nil
}

func TestRunnerV84JSONReservationTightUpperBound(t *testing.T) {
 check:=func(label string,value any){
  t.Helper()
  raw,e:=json.Marshal(value);if e!=nil{t.Fatal(label,e)}
  charge,e:=runnerNormalizationJSONReservationCharge(value);if e!=nil{t.Fatal(label,e)}
  if charge<int64(len(raw)){t.Fatal("ASSERTION:v84-reservation-under-count",label,charge,len(raw))}
 }
 for b:=0;b<256;b++{check(fmt.Sprintf("byte-%02x",b),map[string]any{"s":string([]byte{byte(b)})})}
 check("u2028",map[string]any{"s":"\u2028"});check("u2029",map[string]any{"s":"\u2029"})
 check("html",map[string]any{"s":"<>&\"\\"});check("short-escapes",map[string]any{"s":"\b\t\n\f\r"})
 mixed:=make([]byte,64);for i:=range mixed{mixed[i]=byte(i*37+9)};check("mixed",map[string]any{"s":string(mixed)})
 payload,_:=runnerV84EmergencyWorstPayload()
 raw,e:=json.Marshal(payload);if e!=nil{t.Fatal(e)}
 charge,e:=runnerNormalizationJSONReservationCharge(payload);if e!=nil{t.Fatal(e)}
 if charge<int64(len(raw)){t.Fatal("ASSERTION:v84-reservation-under-count-emergency",charge,len(raw))}
 if charge>runnerEmergencyPayloadLimit-1{t.Fatal("ASSERTION:v84-emergency-ledger-after-tight-bound",charge)}
 if e:=runnerNormalizationJSONReservationWithin(payload,runnerEmergencyPayloadLimit-1);e!=nil{t.Fatal("ASSERTION:v84-emergency-escaped-reservation",e)}
 if runnerNormalizationJSONReservation(map[string]any{"value":strings.Repeat("x",1<<20)})==nil{t.Fatal("ASSERTION:v84-preallocation-still-refused")}
 t.Logf("TIGHT_BOUND marshal=%d charge=%d gate=%d",len(raw),charge,runnerEmergencyPayloadLimit-1)
}

func TestRunnerV84FinalizerRetainsFirstErrorAndDeadline(t *testing.T) {
 began:=time.Unix(1,0);now:=began;result:=runnerEmergencyFixtureCase()
 first:=runnerNormalizationError("result-encode","type",fmt.Errorf("fixed error"),0,0)
 runnerFinalizeNormalizedCase(&result,began,func(runnerCaseResult)(runnerCaseEvidenceIndex,error){return runnerCaseEvidenceIndex{Case:result.Case},first},func(runnerCaseEvidenceIndex)error{now=began.Add(runnerCaseAbsoluteBudget+time.Nanosecond);return syscall.ENOSPC},func()time.Time{return now})
 index:=result.normalizationIndex
 if index==nil||index.NormalizationFailure!=first||index.SecondaryFailure==nil||index.SecondaryFailure.Stage!="index-write"||index.Critical==nil||!result.NormalizationFailed||result.Result!="FAIL"||!index.BlockLaterCases{t.Fatal("ASSERTION:v84-finalizer-first-error-retained")}
}
