package integration

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"testing"
	"time"
)

func TestRunnerV8IdentityBudgetsAndHardClip(t *testing.T) {
	if runnerCaseExecutionBudget != 120*time.Second || runnerCaseAbsoluteBudget != 150*time.Second || runnerIdentityObservationBudget("com.google.Chrome") != 30*time.Second || runnerIdentityObservationBudget("ai.sliccy.mac") != 5*time.Second {
		t.Fatal("ASSERTION:v8-role-scoped-budgets")
	}
	for _, role := range []string{"com.google.Chrome", "ai.sliccy.mac"} {
		hard := time.Now().Add(time.Second)
		o := newRunnerControllerObserver(context.Background(), hard)
		if err := o.SubmitIdentity("budget", role, func(ctx context.Context, _ *runnerNativeTrace) (any, error) {
			deadline, ok := ctx.Deadline()
			if !ok || deadline.After(hard) {
				return nil, fmt.Errorf("unclipped")
			}
			return true, nil
		}); err != nil {
			t.Fatal(err)
		}
		rows, err := o.Wait([]string{"budget"}, time.Second)
		if err != nil || rows["budget"].Value != true {
			t.Fatal("ASSERTION:v8-observer-hard-clip", err)
		}
		o.Finish()
	}
}

func TestRunnerV8EarlyClockAndBaselineIntersection(t *testing.T) {
	epoch := time.Unix(100, 0)
	exchange := runnerClockExchange{Before: epoch.Add(time.Second), After: epoch.Add(1100 * time.Millisecond), Received: epoch.Add(1050 * time.Millisecond), EventMS: 1000}
	early, err := exchange.Bound()
	if err != nil || early.Lower != epoch || early.Upper != epoch.Add(50*time.Millisecond) {
		t.Fatal("ASSERTION:v8-write-before-clock", early, err)
	}
	next := runnerClockBound{Lower: epoch.Add(20 * time.Millisecond), Upper: epoch.Add(40 * time.Millisecond), Valid: true}
	combined, err := intersectRunnerClocks(early, next)
	if err != nil || combined.Lower != next.Lower || combined.Upper != next.Upper {
		t.Fatal("ASSERTION:v8-clock-intersection")
	}
	next.Lower = epoch.Add(time.Second)
	next.Upper = next.Lower
	if _, err = intersectRunnerClocks(early, next); err == nil {
		t.Fatal("ASSERTION:v8-clock-inconsistent-refused")
	}
	exchange.After = exchange.Before.Add(-time.Nanosecond)
	if _, err = exchange.Bound(); err == nil {
		t.Fatal("ASSERTION:v8-clock-write-refused")
	}
}

func TestRunnerV8SnapshotPreservesWindowsBeforeHeldOwner(t *testing.T) {
	journal := newRunnerSnapshotJournal(time.Now())
	id, ok := journal.request("cadence", time.Now())
	if !ok {
		t.Fatal("admission")
	}
	held, release, done := make(chan struct{}), make(chan struct{}), make(chan struct{})
	defer close(release)
	go func() {
		defer close(done)
		journal.observe(context.Background(), newRunnerNativeTrace(), id, func() ([]independentWindow, error) {
			return []independentWindow{{ID: 7, PID: 42, Layer: 0, Rect: independentRect{1, 2, 3, 4}, OnScreen: true}}, nil
		}, func(pid int) runnerDiagnosticOwner { close(held); <-release; return runnerDiagnosticOwner{PID: pid} })
	}()
	select {
	case <-held:
	case <-time.After(time.Second):
		t.Fatal("owner never entered")
	}
	rows, _ := journal.freeze()
	if len(rows) != 1 || len(rows[0].Windows) != 1 || rows[0].Windows[0].PID != 42 || rows[0].WindowsMS == nil || rows[0].Complete {
		t.Fatal("ASSERTION:v8-partial-snapshot-retained")
	}
	if _, ok := journal.request("cadence", time.Now().Add(3*time.Second)); ok {
		t.Fatal("ASSERTION:v8-cadence-no-overlap")
	}
	if _, ok := journal.request("refusal", time.Now()); !ok {
		t.Fatal("ASSERTION:v8-refusal-priority")
	}
	if _, ok := journal.request("refusal", time.Now()); ok {
		t.Fatal("ASSERTION:v8-refusal-bounded")
	}
	rows[0].Windows[0].PID = 999
	again, _ := journal.freeze()
	if again[0].Windows[0].PID != 42 {
		t.Fatal("ASSERTION:v8-snapshot-copy")
	}
}

func TestRunnerV8DiagnosticOwnerRetainsFailuresWithoutAuthority(t *testing.T) {
	sample := runnerBSDValue{PID: 42, Parent: 1, Effective: 501, Real: 501, Saved: 501, Seconds: 1, Microseconds: 2}
	bsd := func(context.Context, *runnerNativeTrace, int) (runnerBSDReceipt, error) {
		return runnerFakeBSD(sample, "diagnostic", "before"), nil
	}
	negative := int32(-67050)
	fact := runnerObserveDiagnosticOwner(context.Background(), newRunnerNativeTrace(), 42, runnerDiagnosticOwnerOps{BSD: bsd, Code: func(context.Context, *runnerNativeTrace, int) (*runnerKernelCode, *runnerCodeInformation, *int32, error) {
		return &runnerKernelCode{Flags: 0x04000000}, &runnerCodeInformation{Identifier: "unknown.role"}, &negative, fmt.Errorf("fixed error")
	}})
	if fact.Information == nil || fact.Information.Identifier != "unknown.role" || fact.AppleAnchorStatus == nil || *fact.AppleAnchorStatus != negative || fact.Errors["code"] == "" || !fact.Stable || fact.BundleID != nil {
		t.Fatal("ASSERTION:v8-owner-failure-facts")
	}
}

func runnerV8BaselineFixture() (runnerProcessFact, runnerBaselineIdentityOps) {
	old := runnerProcessFact{Bundle: "com.google.Chrome", Path: "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", Identity: runnerBSDValue{PID: 42, Parent: 10, Effective: 501, Real: 501, Saved: 501, Seconds: 1, Microseconds: 2}}
	old.Code.Binding.Bound = true
	old.Code.Binding.Kernel = runnerKernelCode{Path: old.Path, Flags: 1}
	old.Code.Binding.Kernel.Hash[0] = 1
	old.Code.Binding.FileMetadata = []string{"1", "2", "100", "33261", "1", "0", "1", "0"}
	ops := runnerBaselineIdentityOps{BSD: func(context.Context, *runnerNativeTrace, int) (runnerBSDReceipt, error) {
		return runnerFakeBSD(old.Identity, "com.google.Chrome", "before"), nil
	}, Kernel: func() (runnerKernelCode, error) { return old.Code.Binding.Kernel, nil }, Dynamic: func(flags uint32, rule string) int32 {
		if flags != 0 {
			return -1
		}
		if rule == `identifier "ai.sliccy.invalid-proof-role"` {
			return -67050
		}
		return 0
	}, Stat: func(string) ([]string, error) { return append([]string(nil), old.Code.Binding.FileMetadata...), nil }}
	return old, ops
}

func TestRunnerV8BaselineCheapBoundaryAndBudget(t *testing.T) {
	old, ops := runnerV8BaselineFixture()
	out, err := runnerRecheckBaselineIdentity(context.Background(), newRunnerNativeTrace(), old, ops)
	if err != nil || !out.Complete {
		t.Fatal("ASSERTION:v8-baseline-positive", err)
	}
	for _, which := range []string{"dynamic", "negative", "bsd", "kernel", "file", "budget"} {
		old, ops := runnerV8BaselineFixture()
		ctx, cancel := context.WithCancel(context.Background())
		switch which {
		case "dynamic":
			ops.Dynamic = func(uint32, string) int32 { return -1 }
		case "negative":
			ops.Dynamic = func(uint32, string) int32 { return 0 }
		case "bsd":
			ops.BSD = func(context.Context, *runnerNativeTrace, int) (runnerBSDReceipt, error) {
				v := old.Identity
				v.Seconds++
				return runnerFakeBSD(v, "com.google.Chrome", "before"), nil
			}
		case "kernel":
			ops.Kernel = func() (runnerKernelCode, error) { k := old.Code.Binding.Kernel; k.Hash[0]++; return k, nil }
		case "file":
			ops.Stat = func(string) ([]string, error) {
				v := append([]string(nil), old.Code.Binding.FileMetadata...)
				v[1] = "3"
				return v, nil
			}
		case "budget":
			count := 0
			previous := ops.BSD
			ops.BSD = func(c context.Context, tr *runnerNativeTrace, pid int) (runnerBSDReceipt, error) {
				count++
				v, e := previous(c, tr, pid)
				if count == 2 {
					cancel()
				}
				return v, e
			}
		}
		out, err := runnerRecheckBaselineIdentity(ctx, newRunnerNativeTrace(), old, ops)
		cancel()
		if err == nil || out.Complete {
			t.Fatal("ASSERTION:v8-baseline-" + which + "-refused")
		}
	}
	now := time.Unix(100, 0)
	if runnerBaselineDeadline(now, now.Add(time.Minute)) != now.Add(2*time.Second) || runnerBaselineDeadline(now, now.Add(time.Second)) != now.Add(time.Second) {
		t.Fatal("ASSERTION:v8-baseline-total-two-seconds")
	}
}

func TestRunnerV8BaselineNativeRoutingAvoidsStaticValidation(t *testing.T) {
	rule, _ := runnerReceiptRequirement("com.google.Chrome")
	wrong := `identifier "ai.sliccy.invalid-proof-role"`
	calls := []string{}
	c := &runnerSecurityContext{guest: 1, bundle: 2, rules: map[string]uintptr{rule: 3, wrong: 4}, guestCheck: func(_ uintptr, flags uint32, r uintptr) int32 {
		calls = append(calls, "dynamic")
		if r == 4 {
			return -67050
		}
		return 0
	}, staticCheck: func(uintptr, uint32, uintptr) int32 { calls = append(calls, "static"); return 0 }}
	old, ops := runnerV8BaselineFixture()
	ops.Dynamic = runnerBaselineDynamic(c, old.Bundle, old.Path)
	out, err := runnerRecheckBaselineIdentity(context.Background(), newRunnerNativeTrace(), old, ops)
	if err != nil || !out.Complete || !reflect.DeepEqual(calls, []string{"dynamic", "dynamic"}) {
		t.Fatal("ASSERTION:v8-baseline-no-static-slow-path", calls, err)
	}
}

func TestRunnerV8EarlyClockFoundationEncoder(t *testing.T) {
	path := os.Getenv("SLICCY_CLOCK_FIXTURE")
	if path == "" {
		t.Fatal("Foundation clock fixture missing")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	row, err := decodeRunnerCaptureRow(bytes.TrimSpace(data))
	if err != nil || row.Stage != "clock-anchor" {
		t.Fatal("ASSERTION:v8-clock-foundation-parser", err)
	}
	var fields map[string]json.RawMessage
	_ = json.Unmarshal(data, &fields)
	fields["marker"] = json.RawMessage(`"wrong"`)
	bad, _ := json.Marshal(fields)
	if _, err = decodeRunnerCaptureRow(bad); err == nil {
		t.Fatal("ASSERTION:v8-clock-fixed-marker")
	}
}

func TestRunnerV8DiagnosticWindowRouteKeepsApprovalAndDropsTitles(t *testing.T) {
	rows, err := runnerDiagnosticWindows(func(approved bool) ([]independentWindow, error) {
		if !approved {
			return nil, fmt.Errorf("fixed context refused")
		}
		return []independentWindow{{ID: 7, PID: 42, Title: "not retained", TitleVisible: true, OnScreen: true}}, nil
	})
	if err != nil || len(rows) != 1 || rows[0].PID != 42 || rows[0].Title != "" || rows[0].TitleVisible {
		t.Fatal("ASSERTION:v8-window-approved-route", err)
	}
}

func TestRunnerV8ActualClockMarkerWrite(t *testing.T) {
	var buffer bytes.Buffer
	e, err := runnerWriteClockAnchor(&buffer)
	if err != nil || buffer.String() != "runner-clock-anchor\n" || e.Before.IsZero() || e.After.Before(e.Before) {
		t.Fatal("ASSERTION:v8-actual-clock-write")
	}
}

func TestRunnerV8BaselineActualDeadlineRefusesLateCallback(t *testing.T) {
	old, ops := runnerV8BaselineFixture()
	began := time.Now()
	until := runnerBaselineDeadline(began, began.Add(time.Minute))
	ctx, cancel := context.WithDeadline(context.Background(), until)
	defer cancel()
	count := 0
	previous := ops.BSD
	ops.BSD = func(ctx context.Context, trace *runnerNativeTrace, pid int) (runnerBSDReceipt, error) {
		count++
		sample, err := previous(ctx, trace, pid)
		if count == 2 {
			<-ctx.Done()
		}
		return sample, err
	}
	result, err := runnerRecheckBaselineIdentity(ctx, newRunnerNativeTrace(), old, ops)
	elapsed := time.Since(began)
	if elapsed < 1900*time.Millisecond || elapsed > 2600*time.Millisecond {
		t.Fatal("ASSERTION:v8-baseline-actual-two-second-window", elapsed)
	}
	if err == nil || result.Complete {
		t.Fatal("ASSERTION:v8-baseline-actual-deadline-refused", err)
	}
}
