package integration

import (
	"encoding/json"
	"fmt"
	"math"
	"sort"
	"strings"
)

const runnerStructuralReason = "verified-windowserver-empty-sck-bundle"

type runnerStructuralRefusal struct {
	PID                   int
	Kind                  string
	Seconds, Microseconds uint64
	WindowID              *uint32
	PairedWindowIDs       []uint32
}

type runnerProtectedCoverage struct {
	ProtectedTargetRefusalCoverage          string         `json:"protectedTargetRefusalCoverage"`
	AllOwnerProtectedPredicatesDemonstrated bool           `json:"allOwnerProtectedPredicatesDemonstrated"`
	StrongerEveryOwnerPredicateClaim        string         `json:"strongerEveryOwnerPredicateClaim"`
	OwnerEvidenceCategories                 map[int]string `json:"ownerEvidenceCategories"`
	WindowServerProtectedPredicateClaim     string         `json:"windowServerProtectedPredicateClaim"`
}

func decodeRunnerStructuralRefusal(row runnerCaptureRow) (value runnerStructuralRefusal, err error) {
	f := row.Fields
	value.Kind, err = runnerText(f, "type")
	if err != nil {
		return value, err
	}
	keys := "schema case capture stage elapsedMs eventElapsedMs reason role label type pid startSeconds startMicroseconds predicateEvidence rawSCKBundleEmpty"
	switch value.Kind {
	case "display":
		keys += " pairedWindowIDs"
	case "window":
		keys += " windowID"
	default:
		return value, fmt.Errorf("structural refusal type")
	}
	if runnerExactFields(f, strings.Fields(keys)) != nil {
		return value, fmt.Errorf("structural refusal field union")
	}
	for key, want := range map[string]string{"reason": runnerStructuralReason, "role": "com.apple.WindowServer", "label": "window-server"} {
		if text, e := runnerText(f, key); e != nil || text != want {
			return value, fmt.Errorf("structural refusal exact role/reason")
		}
	}
	predicate, e := runnerBool(f, "predicateEvidence")
	if e != nil || predicate {
		return value, fmt.Errorf("structural refusal is not predicate evidence")
	}
	empty, e := runnerBool(f, "rawSCKBundleEmpty")
	if e != nil || !empty {
		return value, fmt.Errorf("structural refusal lacks raw empty bundle claim")
	}
	pid, e := runnerInt(f, "pid", 1, math.MaxInt32)
	if e != nil {
		return value, e
	}
	value.PID = int(pid)
	value.Seconds, e = runnerReceiptCounter(f["startSeconds"])
	if e != nil || value.Seconds == 0 {
		return value, fmt.Errorf("structural start unavailable")
	}
	micro, e := runnerInt(f, "startMicroseconds", 0, 999999)
	if e != nil {
		return value, e
	}
	value.Microseconds = uint64(micro)
	if value.Kind == "display" {
		var ids []json.RawMessage
		if json.Unmarshal(f["pairedWindowIDs"], &ids) != nil || len(ids) < 1 || len(ids) > 64 {
			return value, fmt.Errorf("structural paired window bound")
		}
		var previous uint32
		for _, raw := range ids {
			id, e := runnerRawInteger(raw, 1, math.MaxUint32)
			if e != nil || uint32(id) <= previous {
				return value, fmt.Errorf("structural pair order/identity")
			}
			previous = uint32(id)
			value.PairedWindowIDs = append(value.PairedWindowIDs, previous)
		}
	} else {
		id, e := runnerInt(f, "windowID", 1, math.MaxUint32)
		if e != nil {
			return value, e
		}
		v := uint32(id)
		value.WindowID = &v
	}
	return value, nil
}

func matchRunnerProtectedCoverage(windows []runnerWindowClaim, ordinary []runnerRefusalClaim, structural []runnerStructuralRefusal,
	facts map[int]runnerProcessFact, union []runnerUnionWindowClaim, actual []independentWindow) (*runnerProtectedCoverage, error) {
	out := &runnerProtectedCoverage{ProtectedTargetRefusalCoverage: "complete", AllOwnerProtectedPredicatesDemonstrated: true,
		StrongerEveryOwnerPredicateClaim: "PASS", OwnerEvidenceCategories: map[int]string{}, WindowServerProtectedPredicateClaim: "NOT_OBSERVED"}
	for _, w := range windows {
		if w.Label != "allowed" {
			out.OwnerEvidenceCategories[w.PID] = "protected-owner-predicate"
		}
	}
	if len(structural) == 0 {
		if err := matchRunnerRefusals(windows, ordinary); err != nil {
			return nil, err
		}
		for pid := range out.OwnerEvidenceCategories {
			if facts[pid].Bundle == "com.apple.WindowServer" {
				out.WindowServerProtectedPredicateClaim = "PASS"
			}
		}
		return out, nil
	}
	if len(structural) > 65 {
		return nil, fmt.Errorf("structural receipt count exceeded")
	}
	pid := structural[0].PID
	fact, known := facts[pid]
	kind, e := runnerUnionKind(fact.Union())
	b := fact.Identity
	if !known || e != nil || kind != "system" || fact.Label != "window-server" || fact.Bundle != "com.apple.WindowServer" || !fact.Code.Binding.Bound || !fact.Union().Platform ||
		b.PID != int64(pid) || b.Parent != 1 || b.Effective != 88 || b.Real != 0 || b.Saved != 0 || b.Seconds == 0 {
		return nil, fmt.Errorf("structural owner not independently bound WindowServer")
	}
	expected := map[uint32]runnerWindowClaim{}
	remaining := []runnerWindowClaim{}
	for _, w := range windows {
		if w.PID != pid {
			remaining = append(remaining, w)
			continue
		}
		if w.Label != "window-server" || w.ID == 0 || expected[w.ID].ID != 0 {
			return nil, fmt.Errorf("structural target ambiguity")
		}
		expected[w.ID] = w
	}
	if len(expected) < 1 || len(expected) > 64 {
		return nil, fmt.Errorf("structural target set bound")
	}
	for _, r := range ordinary {
		if r.PID == pid {
			return nil, fmt.Errorf("mixed predicate and structural categories")
		}
	}
	if e := matchRunnerRefusals(remaining, ordinary); e != nil {
		return nil, e
	}
	for id, w := range expected {
		uc, ac := 0, 0
		for _, u := range union {
			if u.ID == id {
				if u.PID != pid || u.Identifier != "com.apple.WindowServer" || u.Kind != "system" || u.Selectable || !u.InCG || !u.InSCK || u.Rect != w.Rect || u.Layer != w.Layer {
					return nil, fmt.Errorf("structural union witness mismatch")
				}
				uc++
			}
		}
		for _, a := range actual {
			if a.ID == id {
				if a.PID != pid || a.Rect != w.Rect || a.Layer != w.Layer || !a.OnScreen {
					return nil, fmt.Errorf("structural independent CG mismatch")
				}
				ac++
			}
		}
		if uc != 1 || ac != 1 {
			return nil, fmt.Errorf("structural paired membership missing/duplicate")
		}
	}
	display := false
	seen := map[uint32]bool{}
	ids := make([]uint32, 0, len(expected))
	for id := range expected {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })
	for _, r := range structural {
		if r.PID != pid || r.Seconds != b.Seconds || r.Microseconds != b.Microseconds {
			return nil, fmt.Errorf("structural incarnation mismatch")
		}
		switch r.Kind {
		case "display":
			if display || r.WindowID != nil || len(r.PairedWindowIDs) != len(ids) {
				return nil, fmt.Errorf("structural display coverage")
			}
			for i, id := range ids {
				if r.PairedWindowIDs[i] != id {
					return nil, fmt.Errorf("structural display pair set")
				}
			}
			display = true
		case "window":
			if r.WindowID == nil || len(r.PairedWindowIDs) != 0 || expected[*r.WindowID].ID == 0 || seen[*r.WindowID] {
				return nil, fmt.Errorf("structural window coverage")
			}
			seen[*r.WindowID] = true
		default:
			return nil, fmt.Errorf("structural type unknown")
		}
	}
	if !display || len(seen) != len(expected) {
		return nil, fmt.Errorf("structural coverage incomplete")
	}
	out.OwnerEvidenceCategories[pid] = runnerStructuralReason
	out.AllOwnerProtectedPredicatesDemonstrated = false
	out.StrongerEveryOwnerPredicateClaim = "FAILED_TO_DEMONSTRATE"
	out.WindowServerProtectedPredicateClaim = "FAILED_TO_DEMONSTRATE"
	return out, nil
}
