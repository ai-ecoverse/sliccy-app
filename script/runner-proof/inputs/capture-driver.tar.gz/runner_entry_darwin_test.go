package integration

import (
	"bytes"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestSignedRunnerCapture(t *testing.T) {
	root, app, manifest := os.Getenv("SLICC_RUNNER_PROOF_ROOT"), os.Getenv("SLICCY_SIGNED_PROOF_APP"), os.Getenv("SLICCY_CAPTURE_MANIFEST")
	if root == "" || app == "" || manifest == "" {
		t.Fatal("fixed reviewed capture artifact and private evidence locators required")
	}
	if runnerPlacement() != nil || runnerRequireEvidenceRoot(root) != nil {
		t.Fatal("reviewed isolated hosted capture context required")
	}
	if os.Getenv("GH_TOKEN") != "" || os.Getenv("GITHUB_TOKEN") != "" {
		t.Fatal("artifact download credentials must not reach driver")
	}
	preflightCtx, preflightCancel := context.WithTimeout(context.Background(), 5*time.Second)
	preflightCmd := exec.CommandContext(preflightCtx, "/usr/bin/sw_vers", "-productVersion")
	preflightCmd.Env = proofEnvironment(t)
	var versionOut, versionErr proofRows
	preflightCmd.Stdout = &versionOut
	preflightCmd.Stderr = &versionErr
	preflightBegan := time.Now()
	e := preflightCmd.Run()
	preflightExpired := preflightCtx.Err() != nil
	preflightCancel()
	exit := -1
	if preflightCmd.ProcessState != nil {
		exit = preflightCmd.ProcessState.ExitCode()
	}
	diagnostic := map[string]any{"step": "driver-os-version", "tool": "/usr/bin/sw_vers", "arguments": []string{"-productVersion"}, "exitStatus": exit, "elapsedMs": float64(time.Since(preflightBegan)) / float64(time.Millisecond), "deadlineExpired": preflightExpired, "stdoutTail": string(runnerDiagnosticTail(versionOut.data)), "stderrTail": string(runnerDiagnosticTail(versionErr.data)), "outputOverflow": versionOut.overflow || versionErr.overflow}
	if runnerSaveJSON(filepath.Join(root, "driver-preflight.json"), diagnostic) != nil {
		t.Fatal("private preflight diagnostic write failed")
	}
	version := bytes.TrimSpace(versionOut.data)
	if versionOut.overflow || versionErr.overflow {
		t.Fatal("preflight output exceeded bounded evidence")
	}
	if e != nil || strings.TrimSpace(string(version)) != os.Getenv("SLICCY_RUNNER_OS_VERSION") || !strings.HasPrefix(strings.TrimSpace(string(version)), "27.") {
		t.Fatal("actual hosted macOS27 version not independently established")
	}
	if _, e := runnerArtifactHashes(app, manifest); e != nil {
		t.Fatal("fixed build17 immutable fixture mismatch")
	}
	suite, cancel := context.WithTimeout(context.Background(), 960*time.Second)
	defer cancel()
	budget := &runnerImageBudget{}
	evidenceBudget:=&runnerNormalizationBudget{}
 driverDigest,sourceErr:=runnerDriverInputDigest(".");if sourceErr!=nil{t.Fatal("exact driver source unavailable for evidence binding")}
 var results []runnerCaseEvidenceIndex
	dirty := false
	for _, selected := range []string{"selected-window", "authorization-exclusion", "reciprocal-revoke", "active-stop", "hotkey-stop", "display-exclusion"} {
		t.Run(selected, func(t *testing.T) {
			if suite.Err() != nil || dirty {
				result := runnerCaseResult{Schema: 1, Case: selected, Result: "FAILED_TO_DEMONSTRATE", Failures: []string{"suite deadline exhausted or prior cleanup unconfirmed; no launch"}}
				index,e:=runnerCommitUnlaunchedCase(root,result,evidenceBudget,driverDigest);if e!=nil{index.Result="FAIL";index.EvidenceComplete=false;index.BlockLaterCases=true;index.Failures=append(index.Failures,"unlaunched case evidence unavailable")}
                results = append(results,index)
				t.Error("runner case not demonstrated; private evidence retained")
				return
			}
			result := runRunnerCaptureCase(t, suite, selected, app, manifest, root, budget,evidenceBudget,driverDigest)
			if runnerBlocksLaterCases(result) {
				dirty = true
			}
			if result.normalizationIndex==nil{results=append(results,runnerIncompleteCaseIndex(result))}else{results=append(results,*result.normalizationIndex)}
			if result.Result != "PASS" {
				t.Error("runner case did not pass; inspect sealed private evidence")
			}
		})
	}
	summary := map[string]any{"schema": 2,"normalizationVersion":2,"driverSourceSHA256":driverDigest, "sourceCommit": "849b6057c522c932653c6b9fa84560879d7d4681", "signedRun": uint64(42217144755), "version": "0.1.0", "build": "17", "cliVersion": "1.59.0", "cases": results, "productionEnabled": false, "extraCaptureClasses": map[string]string{"System Settings": "UNTESTED", "TCC-specific prompts": "UNTESTED", "password-specific surfaces": "UNTESTED"}, "proofScope": "fixed synthetic hosted surfaces and explicitly observed classes only; WindowServer empty-bundle structural refusal is not protected-predicate evidence; stronger every-owner predicate claim remains FAILED_TO_DEMONSTRATE", "artifactUnchanged": true}
	if _, e := runnerArtifactHashes(app, manifest); e != nil {
		summary["artifactUnchanged"] = false
		t.Error("immutable fixture changed during suite")
	}
	if e := runnerSaveNormalizedIndex(filepath.Join(root, "capture-suite.json"), summary,evidenceBudget); e != nil {
		t.Fatal("private suite summary write failed")
	}
	if suite.Err() != nil {
		t.Error("capture suite exceeded fixed deadline")
	}
}
func TestRunnerEntryRejectsLocalBeforeAnyWindowOrAppOperation(t *testing.T) {
	if e := runnerPlacement(); e == nil && os.Getenv("GITHUB_ACTIONS") != "true" {
		t.Fatal("local placement accepted")
	}
	for _, path := range []string{"", "relative", "/private/tmp/../tmp/untrusted"} {
		if e := runnerRequireEvidenceRoot(path); e == nil {
			t.Fatal(fmt.Sprintf("invalid evidence root accepted: %q", path))
		}
	}
}

func runnerDiagnosticTail(data []byte) []byte {
	if len(data) > 4096 {
		data = data[len(data)-4096:]
	}
	return append([]byte(nil), data...)
}
