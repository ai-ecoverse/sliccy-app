package integration

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"reflect"
	"strconv"
	"strings"
	"time"
	"unicode/utf8"
)

func runnerNormalizedStrict(raw []byte, value any) error {
	if len(raw) > 1<<20 || !utf8.Valid(raw) {
		return fmt.Errorf("normalization line bound")
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	tokens := 0
	var walk func(int) error
	walk = func(depth int) error {
		tokens++
		if depth > 32 || tokens > 131072 {
			return fmt.Errorf("normalization parser bound")
		}
		token, e := decoder.Token()
		if e != nil {
			return e
		}
		d, container := token.(json.Delim)
		if !container {
			return nil
		}
		if d != '[' && d != '{' {
			return fmt.Errorf("normalization delimiter")
		}
		seen := map[string]bool{}
		for decoder.More() {
			if d == '{' {
				key, e := decoder.Token()
				if e != nil {
					return e
				}
				s, ok := key.(string)
				if !ok || seen[s] {
					return fmt.Errorf("normalization duplicate key")
				}
				seen[s] = true
			}
			if e := walk(depth + 1); e != nil {
				return e
			}
		}
		end, e := decoder.Token()
		if e != nil || d == '[' && end != json.Delim(']') || d == '{' && end != json.Delim('}') {
			return fmt.Errorf("normalization unclosed object")
		}
		return nil
	}
	if e := walk(0); e != nil {
		return e
	}
	if _, e := decoder.Token(); e != io.EOF {
		return fmt.Errorf("normalization trailing data")
	}
	decoder = json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	return decoder.Decode(value)
}

func runnerPhaseTuple(row runnerNativePhase, operation int) ([]any, error) {
	phase, ok := map[string]int{"entered": 0, "completed": 1, "not-executed": 2}[row.Phase]
	if !ok || operation < 1 || operation > 4096 || !finiteNonnegative(row.ElapsedMS) {
		return nil, fmt.Errorf("normalization phase fields")
	}
	bits := fmt.Sprintf("%016x", math.Float64bits(row.ElapsedMS))
	return []any{row.Ordinal, operation, row.PID, row.Flags, phase, bits, row.ReturnValue, row.ValuePresent, row.Errno}, nil
}

func runnerDecodePhase(raw json.RawMessage, operations []string) (row runnerNativePhase, err error) {
	fields, err := runnerRawArray(raw, 9)
	if err != nil {
		return row, err
	}
	ordinal, e := runnerRawInteger(fields[0], 1, runnerSnapshotTraceRows)
	if e != nil {
		return row, e
	}
	row.Ordinal = uint64(ordinal)
	op, e := runnerRawInteger(fields[1], 1, 4096)
	if e != nil || int(op) > len(operations) {
		return row, fmt.Errorf("normalization unknown operation reference")
	}
	row.Operation = operations[op-1]
	pid, e := runnerRawInteger(fields[2], 1, math.MaxInt32)
	if e != nil {
		return row, e
	}
	row.PID = int(pid)
	flags, e := runnerRawInteger(fields[3], 0, math.MaxUint32)
	if e != nil {
		return row, e
	}
	row.Flags = uint32(flags)
	phase, e := runnerRawInteger(fields[4], 0, 2)
	if e != nil {
		return row, e
	}
	row.Phase = []string{"entered", "completed", "not-executed"}[phase]
	var text string
	if json.Unmarshal(fields[5], &text) != nil || len(text) != 16 || strings.ToLower(text) != text {
		return row, fmt.Errorf("normalization exact float bits")
	}
	bits, e := strconv.ParseUint(text, 16, 64)
	if e != nil || fmt.Sprintf("%016x", bits) != text {
		return row, fmt.Errorf("normalization float encoding")
	}
	row.ElapsedMS = math.Float64frombits(bits)
	if !finiteNonnegative(row.ElapsedMS) {
		return row, fmt.Errorf("normalization nonfinite/negative elapsed")
	}
	for i, target := range map[int]**int32{6: &row.ReturnValue, 8: &row.Errno} {
		if string(fields[i]) != "null" {
			n, e := runnerRawInteger(fields[i], math.MinInt32, math.MaxInt32)
			if e != nil {
				return row, e
			}
			v := int32(n)
			*target = &v
		}
	}
	if string(fields[7]) != "null" {
		var b bool
		if json.Unmarshal(fields[7], &b) != nil {
			return row, fmt.Errorf("normalization present boolean")
		}
		row.ValuePresent = &b
	}
	if row.Phase == "entered" && (row.ReturnValue != nil || row.ValuePresent != nil || row.Errno != nil) || row.Phase == "not-executed" && (row.ReturnValue != nil || row.ValuePresent != nil || row.Errno != nil) || row.Phase == "completed" && row.ValuePresent == nil {
		return row, fmt.Errorf("normalization phase value shape")
	}
	return row, nil
}

type runnerInlineSchema struct{ keys, nullable string }

var runnerInlineSchemas = map[string]runnerInlineSchema{
	"owner":       {"pid before after kernel information appleAnchorStatus bundleID bundleUnavailable stable errors", "before after kernel information appleAnchorStatus bundleID errors"},
	"receipt":     {"Role Phase PID Status SelfPID ParentPID Controls Target Accepted UsedSysctl ControlsAgreed Selected", "UsedSysctl ControlsAgreed Selected"},
	"read":        {"Executed NativeReturn Errno Status Count Expected Value", "Value"},
	"bsd":         {"PID Parent Effective Real Saved Seconds Microseconds", ""},
	"kernel":      {"Path Hash Flags", ""},
	"information": {"Identifier Path Type Hash Full Offset", "Hash Full Offset"},
}

func runnerInlineTransform(kind string, raw json.RawMessage, encode bool) (json.RawMessage, error) {
	if string(raw) == "null" {
		return raw, nil
	}
	schema, ok := runnerInlineSchemas[kind]
	if !ok {
		return nil, fmt.Errorf("normalization codec kind")
	}
	keys := strings.Fields(schema.keys)
	fields := map[string]json.RawMessage{}
	if encode {
		if json.Unmarshal(raw, &fields) != nil || runnerExactNullableFields(fields, keys, schema.nullable) != nil {
			return nil, fmt.Errorf("normalization source field ledger")
		}
	} else {
		tuple, e := runnerRawArray(raw, len(keys))
		if e != nil {
			return nil, e
		}
		for i, key := range keys {
			fields[key] = tuple[i]
		}
		if runnerExactNullableFields(fields, keys, schema.nullable) != nil {
			return nil, fmt.Errorf("normalization tuple nullability")
		}
	}
	apply := func(key, child string) error {
		v, e := runnerInlineTransform(child, fields[key], encode)
		if e == nil {
			fields[key] = v
		}
		return e
	}
	switch kind {
	case "owner":
		for key, child := range map[string]string{"before": "receipt", "after": "receipt", "kernel": "kernel", "information": "information"} {
			if e := apply(key, child); e != nil {
				return nil, e
			}
		}
	case "receipt":
		var controls []json.RawMessage
		if json.Unmarshal(fields["Controls"], &controls) != nil || len(controls) != 2 {
			return nil, fmt.Errorf("normalization control pair")
		}
		for i := range controls {
			v, e := runnerInlineBracket(controls[i], encode)
			if e != nil {
				return nil, e
			}
			controls[i] = v
		}
		fields["Controls"], _ = json.Marshal(controls)
		target, e := runnerInlineBracket(fields["Target"], encode)
		if e != nil {
			return nil, e
		}
		fields["Target"] = target
		if e := apply("Selected", "bsd"); e != nil {
			return nil, e
		}
	case "read":
		if e := apply("Value", "bsd"); e != nil {
			return nil, e
		}
	case "bsd":
		if encode {
			var seconds uint64
			if json.Unmarshal(fields["Seconds"], &seconds) != nil {
				return nil, fmt.Errorf("normalization uint64 start")
			}
			fields["Seconds"], _ = json.Marshal(strconv.FormatUint(seconds, 10))
		} else {
			var text string
			if json.Unmarshal(fields["Seconds"], &text) != nil {
				return nil, fmt.Errorf("normalization start text")
			}
			seconds, e := strconv.ParseUint(text, 10, 64)
			if e != nil || strconv.FormatUint(seconds, 10) != text {
				return nil, fmt.Errorf("normalization canonical start")
			}
			fields["Seconds"], _ = json.Marshal(seconds)
		}
	}
	if encode {
		tuple := make([]json.RawMessage, len(keys))
		for i, key := range keys {
			tuple[i] = fields[key]
		}
		return json.Marshal(tuple)
	}
	object, e := json.Marshal(fields)
	if e != nil {
		return nil, e
	}
	var typed any
	switch kind {
	case "owner":
		typed = &runnerDiagnosticOwner{}
	case "receipt":
		typed = &runnerBSDReceipt{}
	case "read":
		typed = &runnerBSDRead{}
	case "bsd":
		typed = &runnerBSDValue{}
	case "kernel":
		typed = &runnerKernelCode{}
	case "information":
		typed = &runnerCodeInformation{}
	}
	if e = runnerNormalizedStrict(object, typed); e != nil {
		return nil, e
	}
	if e = runnerNormalizedTypedShape(object, reflect.TypeOf(typed).Elem()); e != nil {
		return nil, e
	}
	if kind == "kernel" {
		var hash []json.RawMessage
		if json.Unmarshal(fields["Hash"], &hash) != nil || len(hash) != 20 {
			return nil, fmt.Errorf("normalization kernel hash length")
		}
		for _, b := range hash {
			if _, e := runnerRawInteger(b, 0, 255); e != nil {
				return nil, e
			}
		}
	}
	return object, nil
}

func runnerInlineBracket(raw json.RawMessage, encode bool) (json.RawMessage, error) {
	values, e := runnerRawArray(raw, 3)
	if e != nil {
		return nil, e
	}
	for i := range values {
		if string(values[i]) == "null" {
			return nil, fmt.Errorf("normalization null read")
		}
		v, e := runnerInlineTransform("read", values[i], encode)
		if e != nil {
			return nil, e
		}
		values[i] = v
	}
	return json.Marshal(values)
}

func runnerEncodeInlineOwner(owner runnerDiagnosticOwner) (json.RawMessage, error) {
	raw, e := json.Marshal(owner)
	if e != nil {
		return nil, e
	}
	return runnerInlineTransform("owner", raw, true)
}
func runnerDecodeInlineOwner(raw json.RawMessage) (runnerDiagnosticOwner, error) {
	var value runnerDiagnosticOwner
	if string(raw) == "null" {
		return value, fmt.Errorf("normalization null owner")
	}
	object, e := runnerInlineTransform("owner", raw, false)
	if e != nil {
		return value, e
	}
	e = runnerNormalizedStrict(object, &value)
	return value, e
}

func runnerNormalizedTypedShape(raw json.RawMessage, kind reflect.Type) error {
	if string(raw) == "null" {
		switch kind.Kind() {
		case reflect.Pointer, reflect.Map, reflect.Slice, reflect.Interface:
			return nil
		}
		return fmt.Errorf("normalization null typed field")
	}
	if kind.Kind() == reflect.Pointer {
		return runnerNormalizedTypedShape(raw, kind.Elem())
	}
	if kind == reflect.TypeOf(json.RawMessage{}) || kind.Kind() == reflect.Interface {
		return nil
	}
	if reflect.PointerTo(kind).Implements(reflect.TypeOf((*json.Unmarshaler)(nil)).Elem()) {
		value := reflect.New(kind).Interface()
		return runnerNormalizedStrict(raw, value)
	}
	switch kind.Kind() {
	case reflect.Struct:
		var fields map[string]json.RawMessage
		if json.Unmarshal(raw, &fields) != nil {
			return fmt.Errorf("normalization typed object")
		}
		expected := map[string]bool{}
		for i := 0; i < kind.NumField(); i++ {
			field := kind.Field(i)
			if field.PkgPath != "" {
				continue
			}
			tag := strings.Split(field.Tag.Get("json"), ",")
			name := tag[0]
			if name == "-" {
				continue
			}
			if name == "" {
				name = field.Name
			}
			expected[name] = true
			value, exists := fields[name]
			optional := len(tag) > 1 && tag[1] == "omitempty"
			if !exists {
				if optional {
					continue
				}
				return fmt.Errorf("normalization missing typed field %s", name)
			}
			if e := runnerNormalizedTypedShape(value, field.Type); e != nil {
				return e
			}
		}
		for name := range fields {
			if !expected[name] {
				return fmt.Errorf("normalization unknown typed field %s", name)
			}
		}
	case reflect.Slice, reflect.Array:
		if kind.Elem().Kind() == reflect.Uint8 && kind.Kind() == reflect.Slice {
			var value []byte
			return json.Unmarshal(raw, &value)
		}
		var values []json.RawMessage
		if json.Unmarshal(raw, &values) != nil {
			return fmt.Errorf("normalization typed array")
		}
		if kind.Kind() == reflect.Array && len(values) != kind.Len() {
			return fmt.Errorf("normalization fixed typed array")
		}
		for _, value := range values {
			if e := runnerNormalizedTypedShape(value, kind.Elem()); e != nil {
				return e
			}
		}
	case reflect.Map:
		var values map[string]json.RawMessage
		if json.Unmarshal(raw, &values) != nil {
			return fmt.Errorf("normalization typed map")
		}
		for _, value := range values {
			if e := runnerNormalizedTypedShape(value, kind.Elem()); e != nil {
				return e
			}
		}
	default:
		value := reflect.New(kind).Interface()
		return runnerNormalizedStrict(raw, value)
	}
	return nil
}

func runnerNormalizationJSONReservation(value any) error {
	remaining := int64(1 << 20)
	take := func(n int64) error {
		if n < 0 || n > remaining {
			return fmt.Errorf("normalization JSON preallocation bound")
		}
		remaining -= n
		return nil
	}
	text := func(s string) error { return take(2 + int64(len(s))*6) }
	var walk func(reflect.Value, int) error
	walk = func(v reflect.Value, depth int) error {
		if depth > 32 {
			return fmt.Errorf("normalization JSON depth bound")
		}
		if !v.IsValid() {
			return take(4)
		}
		if v.Kind() == reflect.Interface || v.Kind() == reflect.Pointer {
			if v.IsNil() {
				return take(4)
			}
			return walk(v.Elem(), depth+1)
		}
		if v.Type() == reflect.TypeOf(json.RawMessage{}) {
			if v.IsNil() {
				return take(4)
			}
			return take(int64(v.Len()) * 6)
		}
		if v.Type() == reflect.TypeOf(time.Time{}) {
			return take(64)
		}
		if observation, ok := v.Interface().(runnerObservation[any]); ok {
			problem := ""
			if observation.Error != nil {
				problem = observation.Error.Error()
			}
			return walk(reflect.ValueOf(map[string]any{"key": observation.Key, "value": observation.Value, "error": problem, "Submitted": observation.Submitted, "Started": observation.Started, "Finished": observation.Finished, "cancelledBeforeStart": observation.CancelledBeforeStart}), depth+1)
		}
		switch v.Kind() {
		case reflect.String:
			return text(v.String())
		case reflect.Bool:
			return take(5)
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr, reflect.Float32, reflect.Float64:
			return take(32)
		case reflect.Slice, reflect.Array:
			if v.Kind() == reflect.Slice && v.IsNil() {
				return take(4)
			}
			if v.Kind() == reflect.Slice && v.Type().Elem().Kind() == reflect.Uint8 {
				return take(2 + 4*((int64(v.Len())+2)/3))
			}
			if e := take(2 + int64(v.Len())); e != nil {
				return e
			}
			for i := 0; i < v.Len(); i++ {
				if e := walk(v.Index(i), depth+1); e != nil {
					return e
				}
			}
		case reflect.Map:
			if v.IsNil() {
				return take(4)
			}
			if e := take(2 + int64(v.Len())*2); e != nil {
				return e
			}
			iterator := v.MapRange()
			for iterator.Next() {
				key := iterator.Key()
				if key.Kind() == reflect.String {
					if e := text(key.String()); e != nil {
						return e
					}
				} else {
					if e := take(34); e != nil {
						return e
					}
				}
				if e := walk(iterator.Value(), depth+1); e != nil {
					return e
				}
			}
		case reflect.Struct:
			if e := take(2); e != nil {
				return e
			}
			for i := 0; i < v.NumField(); i++ {
				field := v.Type().Field(i)
				if field.PkgPath != "" {
					continue
				}
				tag := strings.Split(field.Tag.Get("json"), ",")
				if tag[0] == "-" {
					continue
				}
				name := tag[0]
				if name == "" {
					name = field.Name
				}
				if e := take(2); e != nil {
					return e
				}
				if e := text(name); e != nil {
					return e
				}
				if e := walk(v.Field(i), depth+1); e != nil {
					return e
				}
			}
		default:
			return fmt.Errorf("normalization JSON unsupported type")
		}
		return nil
	}
	return walk(reflect.ValueOf(value), 0)
}
