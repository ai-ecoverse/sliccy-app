package integration

import (
	"os"
	"path/filepath"
	"syscall"
	"testing"
	"time"
)

func TestRunnerRootObservationDistinguishesPresentAbsentAndStatError(t *testing.T) {
	root := t.TempDir()
	present := observeRunnerRootRemoval(root, time.Now(), os.Lstat)
	if present.State != "present" || present.Type != "directory" || present.Device == nil || present.Inode == nil || present.UID == nil || present.Mode == nil || present.Absent {
		t.Fatal("ASSERTION:root-present-record")
	}
	absent := observeRunnerRootRemoval(filepath.Join(root, "missing"), time.Now(), os.Lstat)
	if absent.State != "absent" || !absent.Absent || absent.Errno == nil || *absent.Errno != int64(syscall.ENOENT) {
		t.Fatal("ASSERTION:root-absent-record")
	}
	denied := observeRunnerRootRemoval(root, time.Now(), func(path string) (os.FileInfo, error) {
		return nil, &os.PathError{Op: "lstat", Path: path, Err: syscall.EACCES}
	})
	if denied.State != "stat-error" || denied.Absent || denied.Errno == nil || *denied.Errno != int64(syscall.EACCES) || denied.ErrorType == "" {
		t.Fatal("ASSERTION:root-stat-error-not-absence")
	}
}
