package integration

import (
	"encoding/json"
	"github.com/pion/webrtc/v4"
)

type proofSignallingReporter interface{ Error(...any) }
type proofSignallingOps struct {
	Answer    func(webrtc.SessionDescription) error
	Candidate func(webrtc.ICECandidateInit) error
}

func proofApplySignalling(t proofSignallingReporter, action string, body map[string]any, d *runnerDiagnostics, ops proofSignallingOps) {
	switch action {
	case "answer":
		answer, _ := body["answer"].(map[string]any)
		sdp, _ := answer["sdp"].(string)
		if err := ops.Answer(webrtc.SessionDescription{Type: webrtc.SDPTypeAnswer, SDP: sdp}); err != nil {
			d.Record("fixture.answer", err)
			t.Error("fixture answer rejected")
		}
	case "ice-candidate":
		raw, err := json.Marshal(body["candidate"])
		if err != nil {
			d.Record("fixture.candidate-marshal", err)
			t.Error("fixture candidate rejected")
			return
		}
		var candidate webrtc.ICECandidateInit
		if err = json.Unmarshal(raw, &candidate); err != nil {
			d.Record("fixture.candidate-decode", err)
			t.Error("fixture candidate rejected")
			return
		}
		if err = ops.Candidate(candidate); err != nil {
			d.Record("fixture.candidate-add", err)
			t.Error("fixture candidate rejected")
		}
	}
}
