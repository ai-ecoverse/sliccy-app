package integration

import (
	"fmt"
	"io"
	"time"
)

// Bounded diagnostics for selected-window baseline-marker / stdin causality.
// No behavior change to marker gating: stamps only.

type runnerDriverTimedStamp struct {
	MonotonicMS float64   `json:"monotonicMs"`
	At          time.Time `json:"at"`
}

type runnerStdinWriteStamp struct {
	Marker    string                `json:"marker"`
	FirstByte uint8                 `json:"firstByte"`
	Stamp     runnerDriverTimedStamp `json:"stamp"`
}

type runnerBaselineMarkerDiag struct {
	Decision      string                 `json:"decision"` // sent | withheld | not-attempted
	Reason        string                 `json:"reason,omitempty"`
	DecisionStamp runnerDriverTimedStamp `json:"decisionStamp"`
	Write         *runnerStdinWriteStamp `json:"write,omitempty"`
}

type runnerStdinCloseStamp struct {
	Cause string                 `json:"cause"`
	Stamp runnerDriverTimedStamp `json:"stamp"`
}

type runnerChromeIdentityIter struct {
	Label          string                 `json:"label"`
	Phase          string                 `json:"phase"`
	Iteration      int                    `json:"iteration"`
	Accepted       bool                   `json:"accepted"`
	Reason         string                 `json:"reason"`
	IdentityStatus int64                  `json:"identityStatus"`
	StrictStatus   int64                  `json:"strictStatus"`
	GuestStatus    int64                  `json:"guestStatus"`
	Stamp          runnerDriverTimedStamp `json:"stamp"`
}

func runnerStampSince(began time.Time) runnerDriverTimedStamp {
	now := time.Now()
	return runnerDriverTimedStamp{MonotonicMS: float64(now.Sub(began)) / float64(time.Millisecond), At: now}
}

func runnerChromeIdentityReason(identity, strict, guest int64) (accepted bool, reason string) {
	identityOK := identity == 0
	guestOK := guest == 0
	strictOK := strict == 0 || strict == -66999
	accepted = identityOK && guestOK && strictOK
	switch {
	case accepted && strict == -66999:
		return true, "accepted-detritus-tolerated"
	case accepted:
		return true, "accepted"
	case !identityOK && !guestOK && !strictOK:
		return false, "identity-guest-strict-failed"
	case !identityOK && !guestOK:
		return false, "identity-guest-failed"
	case !identityOK && !strictOK:
		return false, "identity-strict-failed"
	case !guestOK && !strictOK:
		return false, "guest-strict-failed"
	case !identityOK:
		return false, "identity-failed"
	case !guestOK:
		return false, "guest-failed"
	default:
		return false, "strict-failed"
	}
}

const runnerChromeIdentityLiveCap = 64

func runnerAppendChromeIdentityLive(dst []runnerChromeIdentityIter, began time.Time, label, phase string, identity, strict, guest int64, counts map[string]int) []runnerChromeIdentityIter {
	if len(dst) >= runnerChromeIdentityLiveCap {
		return dst
	}
	key := label + "/" + phase
	counts[key]++
	accepted, reason := runnerChromeIdentityReason(identity, strict, guest)
	return append(dst, runnerChromeIdentityIter{
		Label: label, Phase: phase, Iteration: counts[key], Accepted: accepted, Reason: reason,
		IdentityStatus: identity, StrictStatus: strict, GuestStatus: guest, Stamp: runnerStampSince(began),
	})
}

type runnerStdinCloser struct {
	w     io.WriteCloser
	began time.Time
	out   *[]runnerStdinCloseStamp
	closed bool
}

func (c *runnerStdinCloser) Write(p []byte) (int, error) { return c.w.Write(p) }

func (c *runnerStdinCloser) CloseWithCause(cause string) error {
	if c == nil || c.w == nil {
		return nil
	}
	if !c.closed {
		c.closed = true
		if c.out != nil && len(*c.out) < 8 {
			*c.out = append(*c.out, runnerStdinCloseStamp{Cause: cause, Stamp: runnerStampSince(c.began)})
		}
	}
	return c.w.Close()
}

func (c *runnerStdinCloser) Close() error { return c.CloseWithCause("defer") }

func runnerRecordBaselineWithheld(diag **runnerBaselineMarkerDiag, began time.Time, reason string) {
	*diag = &runnerBaselineMarkerDiag{
		Decision: "withheld", Reason: reason, DecisionStamp: runnerStampSince(began),
	}
}

func runnerRecordBaselineSent(diag **runnerBaselineMarkerDiag, began time.Time, marker string, writeErr error) {
	stamp := runnerStampSince(began)
	first := byte(0)
	if len(marker) > 0 {
		first = marker[0]
	}
	entry := &runnerBaselineMarkerDiag{
		Decision: "sent", DecisionStamp: stamp,
		Write: &runnerStdinWriteStamp{Marker: marker, FirstByte: first, Stamp: stamp},
	}
	if writeErr != nil {
		entry.Reason = fmt.Sprintf("write-failed:%v", writeErr)
	}
	*diag = entry
}
