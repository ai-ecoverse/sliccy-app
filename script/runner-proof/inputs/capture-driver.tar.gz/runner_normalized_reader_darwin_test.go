package integration

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"reflect"
	"strings"
)

type runnerNormalizedRead struct {
	Index                   runnerCaseEvidenceIndex
	Fields                  map[string]json.RawMessage
	SnapshotRecords         []uint64
	SnapshotsNil, PhasesNil bool
	Jobs                    map[string]runnerTraceReceipt
}

type runnerNormalizedJobRead struct {
	key, class        string
	first             uint64
	expected, pending int
	lost, rowsNil     bool
	rows              []runnerNativePhase
	entered           map[uint64]runnerNativePhase
	chunk             int
	lastOrdinal       uint64
	snapshotID        int
}

func readRunnerNormalized(input io.Reader, selected, manifest, driver string, onJob func(string, []runnerNativePhase) error, onSnapshot func(runnerDiagnosticSnapshot) error) (out runnerNormalizedRead, err error) {
	reader := bufio.NewReaderSize(input, 128<<10)
	digest := sha256.New()
	sequence := uint64(0)
	bytesRead := int64(0)
	operations := []string{}
	opSeen := map[string]bool{}
	operationBytes := 0
	jobs := map[string]runnerTraceReceipt{}
	snapshots := map[int]uint64{}
	snapshotOwners := []runnerDiagnosticOwner{}
	ownerSnapshot, ownerNext, ownerCount, phaseCount := 0, 0, 0, 0
	ownerFirst := uint64(0)
	var job *runnerNormalizedJobRead
	resultSeen, footerSeen := false, false
	closeJob := func() error {
		if job == nil {
			return nil
		}
		if len(job.rows) != job.expected || len(job.entered) != job.pending {
			return fmt.Errorf("normalization job phase/pending count mismatch")
		}
		if job.rowsNil && len(job.rows) != 0 {
			return fmt.Errorf("normalization nil phase shape")
		}
		if !job.rowsNil && job.rows == nil {
			job.rows = []runnerNativePhase{}
		}
		jobs[job.key] = runnerTraceReceipt{FirstRecord: job.first, LastRecord: sequence, Rows: len(job.rows), Lost: job.lost, Pending: job.pending, PrefixSHA256: hex.EncodeToString(digest.Sum(nil))}
		if onJob != nil {
			if e := onJob(job.key, job.rows); e != nil {
				return e
			}
		}
		job = nil
		return nil
	}
	for {
		raw, e := runnerNormalizedReadLine(reader)
		if e == io.EOF {
			if len(raw) != 0 {
				return out, fmt.Errorf("normalization unterminated record")
			}
			break
		}
		if e != nil {
			return out, e
		}
		if footerSeen || len(raw) > 1<<20 || bytesRead+int64(len(raw)) > runnerNormalizationStorageLimit {
			return out, fmt.Errorf("normalization stream bounds/after footer")
		}
		var f map[string]json.RawMessage
		if runnerNormalizedStrict(raw, &f) != nil {
			return out, fmt.Errorf("normalization strict record JSON")
		}
		tag, e := runnerText(f, "tag")
		if e != nil {
			return out, e
		}
		n, e := runnerInt(f, "sequence", 1, 32768)
		if e != nil || uint64(n) != sequence+1 {
			return out, fmt.Errorf("normalization record order")
		}
		if tag == "job-begin" || tag == "result" {
			if e = closeJob(); e != nil {
				return out, e
			}
		}
		if (sequence == 0) != (tag == "header") || resultSeen && tag != "footer" {
			return out, fmt.Errorf("normalization record grammar")
		}
		if ownerNext > 0 && tag != "owner" && tag != "snapshot" {
			return out, fmt.Errorf("normalization owner span interrupted")
		}
		prefix := hex.EncodeToString(digest.Sum(nil))
		next := sequence + 1
		exact := func(keys, nullable string) error {
			return runnerExactNullableFields(f, strings.Fields("tag sequence "+keys), nullable)
		}
		switch tag {
		case "header":
			if sequence != 0 || exact("case version manifestSHA256 driverSourceSHA256", "") != nil {
				return out, fmt.Errorf("normalization header")
			}
			name, e := runnerText(f, "case")
			if e != nil || name != selected {
				return out, fmt.Errorf("normalization case binding")
			}
			pin, e := runnerText(f, "manifestSHA256")
			if e != nil || pin != manifest {
				return out, fmt.Errorf("normalization manifest binding")
			}
			source, e := runnerText(f, "driverSourceSHA256")
			if e != nil || source != driver {
				return out, fmt.Errorf("normalization driver source binding")
			}
			if _, e = runnerInt(f, "version", 2, 2); e != nil {
				return out, e
			}
		case "operation":
			if sequence == 0 || resultSeen || job == nil || exact("id value", "") != nil {
				return out, fmt.Errorf("normalization operation position")
			}
			id, e := runnerInt(f, "id", 1, 4096)
			if e != nil || int(id) != len(operations)+1 {
				return out, fmt.Errorf("normalization operation IDs")
			}
			var value string
			if json.Unmarshal(f["value"], &value) != nil || value == "" || len(value) > 256 || opSeen[value] || operationBytes+len(value) > 1<<20 {
				return out, fmt.Errorf("normalization operation definition")
			}
			opSeen[value] = true
			operationBytes += len(value)
			operations = append(operations, value)
		case "job-begin":
			if sequence == 0 || resultSeen || ownerNext != 0 || len(jobs) >= 256 || exact("key class rows lost pending rowsNil snapshotSequence", "") != nil {
				return out, fmt.Errorf("normalization job header")
			}
			key, e := runnerText(f, "key")
			if e != nil || jobs[key].FirstRecord != 0 {
				return out, fmt.Errorf("normalization duplicate job")
			}
			class, e := runnerText(f, "class")
			if e != nil {
				return out, e
			}
			limit := runnerOrdinaryTraceRows
			if class == "snapshot" {
				limit = runnerSnapshotTraceRows
				if !strings.HasPrefix(key, "diagnostic-snapshot:") {
					return out, fmt.Errorf("normalization snapshot class key")
				}
			} else if class != "ordinary" {
				return out, fmt.Errorf("normalization class")
			}
			rows, e := runnerInt(f, "rows", 0, int64(limit))
			if e != nil {
				return out, e
			}
			pending, e := runnerInt(f, "pending", 0, int64(limit))
			if e != nil {
				return out, e
			}
			lost, e := runnerBool(f, "lost")
			if e != nil {
				return out, e
			}
			nilRows, e := runnerBool(f, "rowsNil")
			if e != nil {
				return out, e
			}
			snapshotID, e := runnerInt(f, "snapshotSequence", 0, 78)
			if e != nil {
				return out, e
			}
			if snapshotID > 0 && (class != "snapshot" || key != fmt.Sprintf("diagnostic-snapshot:%d", snapshotID)) {
				return out, fmt.Errorf("normalization paired snapshot job")
			}
			if class == "ordinary" && strings.HasPrefix(key, "diagnostic-snapshot:") {
				return out, fmt.Errorf("normalization ordinary snapshot key")
			}
			job = &runnerNormalizedJobRead{snapshotID: int(snapshotID), key: key, class: class, first: next, expected: int(rows), pending: int(pending), lost: lost, rowsNil: nilRows, entered: map[uint64]runnerNativePhase{}}
		case "phase-chunk":
			if job == nil || resultSeen || exact("key chunk firstRow rowCount rows", "") != nil {
				return out, fmt.Errorf("normalization phase chunk fields")
			}
			key, e := runnerText(f, "key")
			if e != nil || key != job.key {
				return out, fmt.Errorf("normalization chunk job")
			}
			chunk, e := runnerInt(f, "chunk", 0, runnerSnapshotTraceRows)
			if e != nil || int(chunk) != job.chunk {
				return out, fmt.Errorf("normalization chunk order")
			}
			first, e := runnerInt(f, "firstRow", 0, runnerSnapshotTraceRows)
			if e != nil || int(first) != len(job.rows) {
				return out, fmt.Errorf("normalization row offset")
			}
			count, e := runnerInt(f, "rowCount", 1, 256)
			if e != nil || len(job.rows)+int(count) > job.expected {
				return out, fmt.Errorf("normalization chunk count")
			}
			rows, e := runnerRawArray(f["rows"], int(count))
			if e != nil {
				return out, e
			}
			for _, raw := range rows {
				row, e := runnerDecodePhase(raw, operations)
				if e != nil {
					return out, e
				}
				if len(job.rows) > 0 && row.ElapsedMS < job.rows[len(job.rows)-1].ElapsedMS {
					return out, fmt.Errorf("normalization phase time order")
				}
				if row.Phase == "entered" {
					if row.Ordinal != job.lastOrdinal+1 {
						return out, fmt.Errorf("normalization ordinal order/reuse")
					}
					job.lastOrdinal = row.Ordinal
					job.entered[row.Ordinal] = row
				} else {
					old, exists := job.entered[row.Ordinal]
					if !exists || old.Operation != row.Operation || old.PID != row.PID || old.Flags != row.Flags {
						return out, fmt.Errorf("normalization completion mismatch")
					}
					delete(job.entered, row.Ordinal)
				}
				job.rows = append(job.rows, row)
				phaseCount++
			}
			job.chunk++
		case "owner":
			if resultSeen || job != nil && (len(job.rows) != job.expected || job.snapshotID == 0) || exact("snapshot index value", "") != nil {
				return out, fmt.Errorf("normalization inline owner fields")
			}
			id, e := runnerInt(f, "snapshot", 1, 78)
			if e != nil || snapshots[int(id)] != 0 {
				return out, fmt.Errorf("normalization owner snapshot")
			}
			if job != nil && job.snapshotID != int(id) {
				return out, fmt.Errorf("normalization owner job reference")
			}
			index, e := runnerInt(f, "index", 0, 127)
			if e != nil || int(index) != ownerNext {
				return out, fmt.Errorf("normalization owner order")
			}
			if ownerNext == 0 {
				ownerSnapshot = int(id)
				ownerFirst = next
			} else if ownerSnapshot != int(id) {
				return out, fmt.Errorf("normalization interleaved owner set")
			}
			owner, e := runnerDecodeInlineOwner(f["value"])
			if e != nil {
				return out, e
			}
			snapshotOwners = append(snapshotOwners, owner)
			ownerNext++
			ownerCount++
		case "snapshot":
			if resultSeen || job != nil && (len(job.rows) != job.expected || job.snapshotID == 0) || exact("snapshot ownerFirstRecord ownerCount ownersNil value", "") != nil {
				return out, fmt.Errorf("normalization snapshot fields")
			}
			id, e := runnerInt(f, "snapshot", 1, 78)
			if e != nil || snapshots[int(id)] != 0 {
				return out, fmt.Errorf("normalization snapshot ID")
			}
			if job != nil && job.snapshotID != int(id) {
				return out, fmt.Errorf("normalization snapshot job reference")
			}
			count, e := runnerInt(f, "ownerCount", 0, 128)
			if e != nil || int(count) != ownerNext || ownerNext > 0 && ownerSnapshot != int(id) {
				return out, fmt.Errorf("normalization owner count")
			}
			first, e := runnerInt(f, "ownerFirstRecord", 1, 32768)
			if e != nil || ownerNext > 0 && uint64(first) != ownerFirst || ownerNext == 0 && uint64(first) != next {
				return out, fmt.Errorf("normalization owner span")
			}
			nilOwners, e := runnerBool(f, "ownersNil")
			if e != nil || nilOwners && count != 0 {
				return out, fmt.Errorf("normalization nil owners")
			}
			var snapshot runnerDiagnosticSnapshot
			value, e := runnerDiagnosticObject(f["value"], "sequence trigger requestedMs startedMs windowsMs finishedMs windows owners error complete", "startedMs windowsMs finishedMs windows owners")
			if e != nil {
				return out, e
			}
			if string(value["owners"]) != "null" || runnerNormalizedStrict(f["value"], &snapshot) != nil || runnerNormalizedTypedShape(f["value"], reflect.TypeOf(snapshot)) != nil || snapshot.Sequence != int(id) || len(snapshot.Windows) > 512 {
				return out, fmt.Errorf("normalization snapshot metadata")
			}
			if !finiteNonnegative(snapshot.RequestedMS) {
				return out, fmt.Errorf("normalization snapshot request time")
			}
			for _, at := range []*float64{snapshot.StartedMS, snapshot.WindowsMS, snapshot.FinishedMS} {
				if at != nil && (!finiteNonnegative(*at) || *at < snapshot.RequestedMS) {
					return out, fmt.Errorf("normalization snapshot time")
				}
			}
			if !runnerDiagnosticEnum(snapshot.Trigger, "cadence refusal final-refusal") {
				return out, fmt.Errorf("normalization snapshot trigger")
			}
			snapshot.Owners = snapshotOwners
			if !nilOwners && snapshot.Owners == nil {
				snapshot.Owners = []runnerDiagnosticOwner{}
			}
			if onSnapshot != nil {
				if e = onSnapshot(snapshot); e != nil {
					return out, e
				}
			}
			snapshots[int(id)] = next
			snapshotOwners = nil
			ownerNext = 0
			ownerSnapshot = 0
		case "result":
			if resultSeen || ownerNext != 0 || exact("case value snapshotRecords snapshotsNil phaseJobs phasesNil", "") != nil {
				return out, fmt.Errorf("normalization result fields")
			}
			name, e := runnerText(f, "case")
			if e != nil || name != selected {
				return out, fmt.Errorf("normalization result case")
			}
			if runnerNormalizedStrict(f["value"], &out.Fields) != nil {
				return out, fmt.Errorf("normalization case value")
			}
			if _, exists := out.Fields["diagnosticSnapshots"]; exists {
				return out, fmt.Errorf("normalization duplicate snapshots")
			}
			if e = runnerValidateNormalizedCaseFields(out.Fields); e != nil {
				return out, e
			}
			var native map[string]json.RawMessage
			if json.Unmarshal(out.Fields["nativeEvidence"], &native) != nil {
				return out, fmt.Errorf("normalization native object")
			}
			if _, exists := native["phases"]; exists {
				return out, fmt.Errorf("normalization duplicate phases")
			}
			if runnerNormalizedStrict(f["phaseJobs"], &out.Jobs) != nil || len(out.Jobs) != len(jobs) {
				return out, fmt.Errorf("normalization phase references")
			}
			for key, want := range jobs {
				if out.Jobs[key] != want {
					return out, fmt.Errorf("normalization job span/digest mismatch")
				}
			}
			var lost map[string]bool
			var pending map[string]int
			json.Unmarshal(native["diagnosticLoss"], &lost)
			json.Unmarshal(native["pendingNativeCalls"], &pending)
			if len(lost) != len(jobs) || len(pending) != len(jobs) {
				return out, fmt.Errorf("normalization native trace reference count")
			}
			for key, want := range jobs {
				l, ok := lost[key]
				p, has := pending[key]
				if !ok || !has || l != want.Lost || p != want.Pending {
					return out, fmt.Errorf("normalization native trace loss mismatch")
				}
			}
			if json.Unmarshal(f["snapshotRecords"], &out.SnapshotRecords) != nil || len(out.SnapshotRecords) != len(snapshots) {
				return out, fmt.Errorf("normalization snapshot references")
			}
			for i, record := range out.SnapshotRecords {
				if snapshots[i+1] != record {
					return out, fmt.Errorf("normalization snapshot reference order")
				}
			}
			out.SnapshotsNil, e = runnerBool(f, "snapshotsNil")
			if e != nil || out.SnapshotsNil && len(snapshots) != 0 {
				return out, fmt.Errorf("normalization nil snapshots")
			}
			out.PhasesNil, e = runnerBool(f, "phasesNil")
			if e != nil || out.PhasesNil && len(jobs) != 0 {
				return out, fmt.Errorf("normalization nil phases")
			}
			resultSeen = true
		case "footer":
			if !resultSeen || exact("prefixSHA256 records operations jobs snapshots owners phases evidenceComplete outcome", "") != nil {
				return out, fmt.Errorf("normalization footer fields")
			}
			pin, e := runnerText(f, "prefixSHA256")
			if e != nil {
				return out, e
			}
			valid := pin == prefix
			for key, want := range map[string]int64{"records": int64(sequence), "operations": int64(len(operations)), "jobs": int64(len(jobs)), "snapshots": int64(len(snapshots)), "owners": int64(ownerCount), "phases": int64(phaseCount)} {
				n, e := runnerInt(f, key, 0, math.MaxInt64)
				valid = valid && e == nil && n == want
			}
			if !valid {
				return out, fmt.Errorf("normalization footer integrity")
			}
			complete, e := runnerBool(f, "evidenceComplete")
			if e != nil {
				return out, e
			}
			var native map[string]json.RawMessage
			json.Unmarshal(out.Fields["nativeEvidence"], &native)
			settled, e := runnerBool(out.Fields, "nativeObservationSettled")
			if e != nil {
				return out, e
			}
			expected := settled
			for _, r := range jobs {
				if r.Lost || r.Pending != 0 {
					expected = false
				}
			}
			if complete != expected {
				return out, fmt.Errorf("normalization completeness claim")
			}
			outcome, e := runnerText(f, "outcome")
			if e != nil {
				return out, e
			}
			var result string
			if json.Unmarshal(out.Fields["result"], &result) != nil || result != outcome {
				return out, fmt.Errorf("normalization outcome mismatch")
			}
			out.Index = runnerCaseEvidenceIndex{Schema: 2, NormalizationVersion: 2, Case: selected, Path: selected + "/driver-evidence.v2.ndjson", Jobs: len(jobs), Snapshots: len(snapshots), Owners: ownerCount, Phases: phaseCount, EvidenceComplete: complete, Result: result}
			footerSeen = true
		default:
			return out, fmt.Errorf("normalization record tag")
		}
		sequence = next
		bytesRead += int64(len(raw))
		digest.Write(raw)
		if job != nil && len(job.rows) == job.expected && ownerNext == 0 && (job.snapshotID == 0 || snapshots[job.snapshotID] != 0) {
			if e := closeJob(); e != nil {
				return out, e
			}
		}
	}
	if !footerSeen {
		return out, fmt.Errorf("normalization footer unavailable")
	}
	out.Index.NativeObservationSettled, _ = runnerBool(out.Fields, "nativeObservationSettled")
	out.Index.DirectChildrenGone, _ = runnerBool(out.Fields, "directChildrenGone")
	out.Index.RootsRemoved, _ = runnerBool(out.Fields, "rootsRemoved")
	out.Index.ProtocolWorkersSettled, _ = runnerBool(out.Fields, "protocolWorkersSettled")
	json.Unmarshal(out.Fields["failures"], &out.Index.Failures)
	json.Unmarshal(out.Fields["evidenceUnavailable"], &out.Index.EvidenceUnavailable)
	json.Unmarshal(out.Fields["unavailableReasons"], &out.Index.UnavailableReasons)
	out.Index.BlockLaterCases = runnerBlocksLaterCases(runnerNormalizedCaseSummary(out.Fields))
	out.Index.Bytes = bytesRead
	out.Index.Records = sequence
	out.Index.SHA256 = hex.EncodeToString(digest.Sum(nil))
	return out, nil
}

func runnerNormalizedReadLine(reader *bufio.Reader) ([]byte, error) {
	var line []byte
	for {
		part, e := reader.ReadSlice('\n')
		if len(part) > 1<<20-len(line) {
			return nil, fmt.Errorf("normalization record bound before allocation")
		}
		line = append(line, part...)
		if e == bufio.ErrBufferFull {
			continue
		}
		return line, e
	}
}
