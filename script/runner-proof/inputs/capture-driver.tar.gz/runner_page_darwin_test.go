package integration

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"image"
	"io"
	"net"
	"sync"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
	"github.com/ai-ecoverse/slicc-cli/internal/link"
)

type runnerWireFact struct {
	Kind       string        `json:"kind"`
	At         time.Time     `json:"at"`
	Started    time.Time     `json:"recordStarted,omitempty"`
	AdmittedAt *time.Time    `json:"admittedAt,omitempty"`
	DecodedAt  *time.Time    `json:"decodedAt,omitempty"`
	State      *screen.State `json:"state,omitempty"`
	Frame      *screen.Frame `json:"frame,omitempty"`
	Admitted   bool          `json:"admitted"`
	Pulse      *bool         `json:"pulse,omitempty"`
	Reason     string        `json:"reason,omitempty"`
	Bytes      int           `json:"bytes,omitempty"`
}
type runnerCapturePage struct {
	Diagnostics   *runnerDiagnostics
	Page          *link.Link
	Join          string
	Origin        string
	Pages         *fixedProofPages
	Receiver      runnerReceiver
	mu            sync.Mutex
	facts         []runnerWireFact
	problem       string
	reading       bool
	LinkDone      chan struct{}
	closing       bool
	stateWorkers  sync.WaitGroup
	closeOnce     sync.Once
	TransportDone chan struct{}
	Wake          chan struct{}
	Done          chan struct{}
	inspect       func(screen.Frame, image.Image) (bool, error)
	save          func(screen.Frame, []byte) error
}

func (p *runnerCapturePage) fact(f runnerWireFact) {
	p.mu.Lock()
	if len(p.facts) >= 512 {
		p.problem = "wire fact budget exceeded"
	} else {
		p.facts = append(p.facts, f)
	}
	p.mu.Unlock()
	select {
	case p.Wake <- struct{}{}:
	default:
	}
}
func (p *runnerCapturePage) fail(reason string) {
	p.Diagnostics.Record("page.problem", errors.New(reason))
	p.Receiver.clear()
	if p.Page != nil {
		p.stopLink()
	}
	p.mu.Lock()
	if p.problem == "" {
		p.problem = reason
	}
	p.mu.Unlock()
	select {
	case p.Wake <- struct{}{}:
	default:
	}
}
func (p *runnerCapturePage) snapshot() ([]runnerWireFact, string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	return append([]runnerWireFact(nil), p.facts...), p.problem
}
func (p *runnerCapturePage) handleState(s *link.Stream) {
	p.mu.Lock()
	if p.closing {
		p.mu.Unlock()
		_ = s.Reset("EACCES")
		return
	}
	p.stateWorkers.Add(1)
	p.mu.Unlock()
	defer p.stateWorkers.Done()
	scope := p.Receiver.scope

	hello, ok := s.Link().PeerHello()
	raw, e := json.Marshal(hello.Screen)
	var support screen.Support
	supportErr := runnerStrict(raw, &support, 4096)
	if !ok || e != nil || hello.Role != link.RoleNode || hello.HasCap("screen") || supportErr != nil || support.V != 1 || support.Codec != "jpeg" || !runnerLimitsValid(support.Limits) {
		p.Diagnostics.Record("protocol.worker", e)
		p.Diagnostics.Record("protocol.worker", supportErr)
		p.fail("invalid screen HELLO support")
		_ = s.Reset("EPROTO")
		return
	}
	scopes := map[string]bool{}
	for _, value := range support.Scopes {
		if (value != "window" && value != "display") || scopes[value] {
			p.fail("invalid HELLO scope catalog")
			_ = s.Reset("EPROTO")
			return
		}
		scopes[value] = true
	}
	if !scopes[scope] {
		p.fail("missing fixed screen scope")
		_ = s.Reset("EACCES")
		return
	}
	p.Receiver.mu.Lock()
	p.Receiver.ceiling = support.Limits
	p.Receiver.mu.Unlock()
	state, active, e := p.Receiver.apply(s.OpenPayload())
	if e != nil {
		p.Diagnostics.Record("protocol.worker", e)
		p.fail("invalid effective screen-state")
		_ = s.Reset("EPROTO")
		return
	}
	p.Receiver.mu.Lock()
	appliedAt := p.Receiver.stateAt
	p.Receiver.mu.Unlock()
	p.fact(runnerWireFact{Kind: "state", At: appliedAt, State: &state})
	if err := s.Accept(struct{}{}); err != nil {
		p.Diagnostics.Record("protocol.worker", err)
		p.fail("screen-state acknowledgement failed")
		return
	}
	_ = s.CloseWrite()
	if active {
		p.mu.Lock()
		p.reading = true
		p.mu.Unlock()
		go p.consume(s.Link(), *state.Binding, *state.Limits)
	}
	_ = s.SetReadDeadline(time.Now().Add(time.Second))
	var extra [1]byte
	n, readErr := s.Read(extra[:])
	if n != 0 {
		p.fail("screen-state carried DATA")
	} else if !errors.Is(readErr, io.EOF) {
		p.Diagnostics.Record("protocol.worker", readErr)
		p.Receiver.mu.Lock()
		cleared := p.Receiver.reset
		p.Receiver.mu.Unlock()
		select {
		case <-s.Link().Done():
			if !cleared {
				p.fail("state link ended while granted")
			}
		default:
			p.fail("screen-state did not end within deadline")
		}
	}

}

func newRunnerCapturePage(t *testing.T, scope string, inspect func(screen.Frame, image.Image) (bool, error), save func(screen.Frame, []byte) error) *runnerCapturePage {
	return newRunnerCapturePageDiagnostics(t, scope, inspect, save, nil)
}
func newRunnerCapturePageDiagnostics(t *testing.T, scope string, inspect func(screen.Frame, image.Image) (bool, error), save func(screen.Frame, []byte) error, d *runnerDiagnostics) *runnerCapturePage {
	t.Helper()
	p := &runnerCapturePage{Diagnostics: d, Wake: make(chan struct{}, 1), Done: make(chan struct{}), LinkDone: make(chan struct{}), TransportDone: make(chan struct{}), inspect: inspect, save: save, Receiver: runnerReceiver{ceiling: screen.DefaultLimits(), scope: scope}}
	handler := p.handleState
	p.Page, p.Join, _ = proofPageUsingHubDiagnostics(t, nil, handler, func(h *fakeHub) {
		var e error
		p.Pages, e = h.enableFixedProofPages()
		if e != nil {
			t.Fatal("static fixture pages unavailable")
		}
		p.Origin = h.srv.URL
	}, d)
	d.AddSecret(p.Join)
	go p.observeLinkClosure()
	return p
}

type runnerReadWitness struct {
	net.Conn
	Started time.Time
	Bytes   int
}

func (c *runnerReadWitness) Read(data []byte) (int, error) {
	n, e := c.Conn.Read(data)
	if n > 0 {
		if c.Started.IsZero() {
			c.Started = time.Now()
		}
		c.Bytes += n
	}
	return n, e
}
func (p *runnerCapturePage) consume(page *link.Link, binding screen.Binding, limits screen.Limits) {
	defer close(p.Done)
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	s, e := page.Open(ctx, screen.Open{Kind: "screen", V: 1, Binding: binding, MaxFPS: 5, MaxWidth: 2560, MaxHeight: 2560}, link.OpenOptions{})
	if e != nil {
		p.Diagnostics.Record("protocol.worker", e)
		p.fail("screen OPEN failed")
		return
	}
	var opened struct {
		V       int            `json:"v"`
		Binding screen.Binding `json:"binding"`
		Codec   string         `json:"codec"`
		Width   int            `json:"maxWidth"`
		Height  int            `json:"maxHeight"`
		FPS     int            `json:"maxFps"`
	}
	openedErr := runnerStrict(s.OpenedPayload(), &opened, 4096)
	if openedErr != nil || opened.V != 1 || opened.Binding != binding || opened.Codec != "jpeg" || opened.Width < 1 || opened.Height < 1 || opened.Width > limits.LongEdge || opened.Height > limits.LongEdge || opened.FPS < 1 || opened.FPS > 5 {
		p.Diagnostics.Record("protocol.worker", openedErr)
		p.fail("invalid screen OPENED")
		_ = s.Reset("EPROTO")
		return
	}
	_ = s.CloseWrite()
	p.fact(runnerWireFact{Kind: "opened", At: time.Now()})
	for {
		observed := &runnerReadWitness{Conn: s.Conn()}
		wire := runnerWireFrame{WidthCap: opened.Width, HeightCap: opened.Height, Limits: limits}
		body, e := readRunnerRecord(observed, &wire, limits.FrameBytes)
		frame := wire.Frame
		at := time.Now()
		if e != nil {
			var reset *link.ResetError
			if errors.As(e, &reset) && reset.Remote && reset.Code == "EACCES" {
				p.Receiver.clear()
				p.fact(runnerWireFact{Kind: "reset", At: at, Started: observed.Started, Reason: "EACCES", Bytes: observed.Bytes})
				return
			}
			p.Receiver.mu.Lock()
			cleared := p.Receiver.reset
			p.Receiver.mu.Unlock()
			if !cleared || !errors.Is(e, io.EOF) {
				p.Diagnostics.Record("protocol.worker", e)
				p.fail("unexpected screen record end")
			}
			p.fact(runnerWireFact{Kind: "stream-end", At: at, Started: observed.Started, Reason: "ended", Bytes: observed.Bytes})
			return
		}
		if !runnerJPEGMetadataFree(body) {
			p.fail("JPEG metadata or malformed envelope admitted")
			_ = s.Reset("EPROTO")
			return
		}
		generation, current, e := p.Receiver.beginFrame(frame, body, opened.Width, opened.Height)
		if e != nil {
			p.Diagnostics.Record("protocol.worker", e)
			p.fail("invalid screen frame")
			_ = s.Reset("EPROTO")
			return
		}
		var saveErr error
		if p.save != nil {
			saveErr = p.save(frame, body)
		}
		if saveErr != nil {
			p.Diagnostics.Record("protocol.worker", saveErr)
			p.fail("sealed frame evidence budget/write failed")
			_ = s.Reset("EBUSY")
			return
		}
		fact := runnerWireFact{Kind: "frame", At: at, Started: observed.Started, Frame: &frame, Bytes: len(body)}
		if current {
			img, e := checkRunnerJPEG(frame, body)
			if e != nil {
				p.Diagnostics.Record("protocol.worker", e)
				p.fail("invalid JPEG decode")
				_ = s.Reset("EPROTO")
				return
			}
			pulse, e := p.inspect(frame, img)
			if e != nil {
				p.Diagnostics.Record("protocol.worker", e)
				p.fail("synthetic pixel/exclusion assertion failed")
				_ = s.Reset("EPROTO")
				return
			}
			decodedAt := time.Now()
			fact.DecodedAt = &decodedAt
			p.Receiver.mu.Lock()
			if p.Receiver.granted && p.Receiver.binding != nil && p.Receiver.generation == generation {
				fact.Admitted = true
				admittedAt := time.Now()
				fact.AdmittedAt = &admittedAt
				fact.Pulse = &pulse
			}
			p.Receiver.mu.Unlock()
		}
		p.fact(fact)
	}
}
func (p *runnerCapturePage) stop(ctx context.Context) error {
	p.Receiver.mu.Lock()
	if p.Receiver.link == "" {
		p.Receiver.mu.Unlock()
		return fmt.Errorf("no accepted state to stop")
	}
	id := p.Receiver.link
	var session *string
	if p.Receiver.session != nil {
		v := *p.Receiver.session
		session = &v
	}
	p.Receiver.mu.Unlock()
	clearedAt := p.Receiver.clear()
	p.fact(runnerWireFact{Kind: "viewer-stop", At: clearedAt})
	s, e := p.Page.Open(ctx, screen.Stop{Kind: "screen-stop", V: 1, Link: id, Session: session}, link.OpenOptions{})
	if e != nil {
		p.Diagnostics.Record("protocol.worker", e)
		return fmt.Errorf("remote stop was refused")
	}
	var opened struct {
		V       int   `json:"v"`
		Stopped *bool `json:"stopped"`
	}
	stopOpenedErr := runnerStrict(s.OpenedPayload(), &opened, 4096)
	if stopOpenedErr != nil || opened.V != 1 || opened.Stopped == nil || !*opened.Stopped {
		p.Diagnostics.Record("protocol.worker", stopOpenedErr)
		return fmt.Errorf("remote stop not acknowledged")
	}
	_ = s.CloseWrite()
	until, ok := ctx.Deadline()
	if !ok {
		return fmt.Errorf("bounded Stop context required")
	}
	_ = s.SetReadDeadline(until)
	var extra [1]byte
	n, err := s.Read(extra[:])
	if n != 0 || !errors.Is(err, io.EOF) {
		p.Diagnostics.Record("protocol.worker", err)
		return fmt.Errorf("Stop carried DATA or did not end")
	}
	p.fact(runnerWireFact{Kind: "stop-opened", At: time.Now()})
	return nil
}

func (p *runnerCapturePage) stopLink() {
	p.closeOnce.Do(func() { go func() { _ = p.Page.Close(); close(p.TransportDone) }() })
}
func (p *runnerCapturePage) closeAndWait(until time.Time) bool {
	p.mu.Lock()
	p.closing = true
	p.mu.Unlock()
	p.stopLink()
	statesDone := make(chan struct{})
	go func() { p.stateWorkers.Wait(); close(statesDone) }()
	remaining := time.Until(until)
	if remaining <= 0 {
		return false
	}
	timer := time.NewTimer(remaining)
	select {
	case <-statesDone:
		if !timer.Stop() {
			select {
			case <-timer.C:
			default:
			}
		}
	case <-timer.C:
		p.fact(runnerWireFact{Kind: "unsettled", At: time.Now(), Reason: "state-readers"})
		return false
	}
	p.mu.Lock()
	reading := p.reading
	p.mu.Unlock()
	for index, done := range []<-chan struct{}{p.LinkDone, p.Done, p.TransportDone} {
		if done == p.Done && !reading {
			continue
		}
		remaining := time.Until(until)
		if remaining <= 0 {
			return false
		}
		timer := time.NewTimer(remaining)
		select {
		case <-done:
			if !timer.Stop() {
				select {
				case <-timer.C:
				default:
				}
			}
		case <-timer.C:
			reason := "link-watcher"
			if index == 1 {
				reason = "frame-reader"
			}
			if index == 2 {
				reason = "Pion-transport"
			}
			p.fact(runnerWireFact{Kind: "unsettled", At: time.Now(), Reason: reason})
			return false
		}
	}
	return true
}

func (p *runnerCapturePage) observeLinkClosure() {
	defer close(p.LinkDone)
	<-p.Page.Done()
	p.Receiver.clear()
	cause := p.Page.Err()
	if cause == nil {
		cause = errors.New("peer link closed with nil reported error")
	}
	p.Diagnostics.Record("link.lost", cause)
	reason := runnerSanitizeDiagnostic(cause.Error(), p.Diagnostics.SecretSnapshot())
	p.fact(runnerWireFact{Kind: "link-lost", At: time.Now(), Reason: reason})
}
