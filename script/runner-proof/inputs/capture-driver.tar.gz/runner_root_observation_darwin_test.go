package integration

import (
	"errors"
	"fmt"
	"os"
	"syscall"
	"time"
)

type runnerRootObservation struct {
	Path      string  `json:"path"`
	AtMS      float64 `json:"atMs"`
	State     string  `json:"state"`
	Type      string  `json:"type"`
	Device    *uint64 `json:"device"`
	Inode     *uint64 `json:"inode"`
	UID       *uint32 `json:"uid"`
	Mode      *uint32 `json:"mode"`
	ErrorType string  `json:"errorType,omitempty"`
	Error     string  `json:"error,omitempty"`
	Errno     *int64  `json:"errno"`
	Absent    bool    `json:"absent"`
}

func observeRunnerRootRemoval(path string, began time.Time, lstat func(string) (os.FileInfo, error)) runnerRootObservation {
	r := runnerRootObservation{Path: path, AtMS: float64(time.Since(began)) / float64(time.Millisecond), State: "unavailable"}
	info, err := lstat(path)
	if err != nil {
		r.ErrorType = fmt.Sprintf("%T", err)
		r.Error = runnerSanitizeDiagnostic(err.Error(), nil)
		var errno syscall.Errno
		if errors.As(err, &errno) {
			value := int64(errno)
			r.Errno = &value
		}
		if os.IsNotExist(err) {
			r.Absent = true
			r.State = "absent"
		} else {
			r.State = "stat-error"
		}
		return r
	}
	if info == nil {
		r.Error = "lstat returned no file metadata"
		return r
	}
	r.State = "present"
	r.Type = "other"
	if info.Mode()&os.ModeSymlink != 0 {
		r.Type = "symlink"
	} else if info.IsDir() {
		r.Type = "directory"
	} else if info.Mode().IsRegular() {
		r.Type = "regular"
	}
	if st, ok := info.Sys().(*syscall.Stat_t); ok {
		dev, ino, uid, mode := uint64(st.Dev), uint64(st.Ino), st.Uid, uint32(st.Mode)
		r.Device = &dev
		r.Inode = &ino
		r.UID = &uid
		r.Mode = &mode
	}
	return r
}
