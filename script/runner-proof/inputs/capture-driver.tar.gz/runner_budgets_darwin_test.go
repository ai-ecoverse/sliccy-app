package integration

import "time"

const (
	runnerCaseExecutionBudget        = 120 * time.Second
	runnerCaseAbsoluteBudget         = 150 * time.Second
	runnerChromeStaticIdentityBudget = 30 * time.Second
	runnerOrdinaryObservationBudget  = 5 * time.Second
)

func runnerIdentityObservationBudget(role string) time.Duration {
	if role == "com.google.Chrome" {
		return runnerChromeStaticIdentityBudget
	}
	return runnerOrdinaryObservationBudget
}
