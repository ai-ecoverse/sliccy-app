package integration

import (
	"bufio"
	"bytes"
	"encoding/json"
	"math"
	"os"
	"strings"
	"testing"
)

func runnerRefusalFixtureRows(t *testing.T) [][]byte {
	t.Helper()
	path := os.Getenv("SLICCY_REFUSAL_FIXTURE")
	if path == "" {
		t.Fatal("actual Foundation refusal fixture unavailable")
	}
	data, err := os.ReadFile(path)
	if err != nil || len(data) > 32768 {
		t.Fatal("refusal fixture", err)
	}
	scanner := bufio.NewScanner(bytes.NewReader(data))
	scanner.Buffer(make([]byte, 4096), 4096)
	var rows [][]byte
	for scanner.Scan() {
		rows = append(rows, append([]byte(nil), scanner.Bytes()...))
	}
	if scanner.Err() != nil || len(rows) != 3 {
		t.Fatal("actual refusal row count", scanner.Err(), len(rows))
	}
	return rows
}

func runnerRefusalReplace(raw []byte, path []string, value any) []byte {
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var root any
	if decoder.Decode(&root) != nil {
		panic("fixture decode")
	}
	current := root
	for _, key := range path[:len(path)-1] {
		if key == "0" {
			current = current.([]any)[0]
		} else {
			current = current.(map[string]any)[key]
		}
	}
	current.(map[string]any)[path[len(path)-1]] = value
	out, err := json.Marshal(root)
	if err != nil {
		panic(err)
	}
	return out
}

func TestRunnerV8ActualRefusalEncoderAndNoAuthority(t *testing.T) {
	rows := runnerRefusalFixtureRows(t)
	var ledger runnerCaseMetadataLedger
	for i, raw := range rows {
		row, err := decodeRunnerCaptureRow(raw)
		if err != nil || row.Refusal == nil || ledger.Add(row) != nil {
			t.Fatal("ASSERTION:v8-refusal-actual-encoder", i, err)
		}
		result := runnerCaseResult{}
		runnerObserveCaseAvailability(&result, row)
		if result.EvidenceUnavailable || len(result.Failures) != 0 {
			t.Fatal("ASSERTION:v8-refusal-no-verdict-authority")
		}
		if i == 0 && (row.Refusal.Owner == nil || row.Refusal.Owner.StartSeconds != math.MaxUint64 || row.Refusal.Owner.SavedUID != nil || row.Refusal.SigningIdentifierSource != "verified") {
			t.Fatal("ASSERTION:v8-refusal-owner-wide-types")
		}
		if i == 1 && (row.Refusal.SCK[0].PID != nil || row.Refusal.SCK[0].Rect.X != nil || row.Refusal.SCK[0].Rect.Height == nil || *row.Refusal.SCK[0].Rect.Height != -1) {
			t.Fatal("ASSERTION:v8-refusal-negative-facts-retained")
		}
		if i == 2 && (row.Refusal.SigningIdentifier.Status != "invalid-identifier" || row.Refusal.SigningIdentifier.Value != nil || row.Refusal.PID == nil || *row.Refusal.PID != -1) {
			t.Fatal("ASSERTION:v8-refusal-invalid-id-retained")
		}
	}
}

func TestRunnerV8RefusalStrictTypesAndEnums(t *testing.T) {
	raw := runnerRefusalFixtureRows(t)[0]
	paths := []string{"attempt", "site", "issue", "branch", "comparison", "pid", "windowID", "signingIdentifier.status", "signingIdentifier.value", "signingIdentifier.bytes", "signingIdentifierSource", "owner.pid", "owner.parent", "owner.effectiveUID", "owner.realUID", "owner.savedUID", "owner.startSeconds", "owner.startMicroseconds", "owner.verified", "owner.appleAnchored", "owner.sysctlBound", "owner.hashBytes", "cgCount", "sckCount", "cg.0.windowID", "cg.0.pid", "cg.0.layer", "cg.0.rect.x", "cg.0.rect.y", "cg.0.rect.width", "cg.0.rect.height", "sck.0.windowID", "sck.0.pid", "sck.0.ownerPresent", "sck.0.bundle.status", "sck.0.bundle.value", "sck.0.bundle.bytes", "sck.0.layer", "sck.0.rect.x", "sck.0.rect.y", "sck.0.rect.width", "sck.0.rect.height"}
	for _, path := range paths {
		if _, err := decodeRunnerCaptureRow(runnerRefusalReplace(raw, strings.Split(path, "."), []any{})); err == nil {
			t.Fatal("ASSERTION:v8-refusal-type-" + path)
		}
	}
	for _, path := range []string{"site", "issue", "branch", "comparison"} {
		if _, err := decodeRunnerCaptureRow(runnerRefusalReplace(raw, []string{path}, "__unapproved__")); err == nil {
			t.Fatal("ASSERTION:v8-refusal-enum-" + path)
		}
	}
	for _, path := range []string{"owner.verified", "owner.appleAnchored", "owner.sysctlBound", "sck.0.ownerPresent"} {
		if _, err := decodeRunnerCaptureRow(runnerRefusalReplace(raw, strings.Split(path, "."), 0)); err == nil {
			t.Fatal("ASSERTION:v8-refusal-bool-" + path)
		}
	}
	tests := []struct {
		name  string
		path  []string
		value any
	}{
		{"owner-presence", []string{"sck", "0", "ownerPresent"}, false},
		{"truncation", []string{"cgCount"}, 3},
		{"provenance", []string{"owner"}, nil},
		{"identifier-value", []string{"signingIdentifier", "value"}, "com.bad\nName"},
		{"negative-count", []string{"sckCount"}, -1},
		{"numeric-id", []string{"windowID"}, json.Number("4294967296")},
		{"negative-start", []string{"owner", "startSeconds"}, -1},
	}
	for _, test := range tests {
		bad := runnerRefusalReplace(raw, test.path, test.value)
		if test.name == "identifier-value" {
			bad = runnerRefusalReplace(bad, []string{"signingIdentifier", "bytes"}, len(test.value.(string)))
		}
		if _, err := decodeRunnerCaptureRow(bad); err == nil {
			t.Fatal("ASSERTION:v8-refusal-" + test.name)
		}
	}
}

func TestRunnerV8RefusalAttemptLedgerAllowsGapsButNotDuplicates(t *testing.T) {
	rows := runnerRefusalFixtureRows(t)
	var ledger runnerCaseMetadataLedger
	for _, raw := range rows {
		row, err := decodeRunnerCaptureRow(raw)
		if err != nil {
			t.Fatal(err)
		}
		if err = ledger.Add(row); err != nil {
			t.Fatal("ASSERTION:v8-refusal-attempt-gap", err)
		}
	}
	row, err := decodeRunnerCaptureRow(rows[0])
	if err != nil {
		t.Fatal(err)
	}
	if ledger.Add(row) == nil {
		t.Fatal("ASSERTION:v8-refusal-duplicate-attempt")
	}
}

func TestRunnerV82ActualSurfaceRefusalEncoderStrictFields(t *testing.T) {
	path := os.Getenv("SLICCY_SURFACE_REFUSAL_FIXTURE")
	if path == "" {
		t.Fatal("actual surface producer fixture missing")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	scanner := bufio.NewScanner(bytes.NewReader(data))
	scanner.Buffer(make([]byte, 4096), 4096)
	var rows [][]byte
	for scanner.Scan() {
		rows = append(rows, append([]byte(nil), scanner.Bytes()...))
	}
	if scanner.Err() != nil || len(rows) != 21 {
		t.Fatal("ASSERTION:v82-surface-actual-row-count", scanner.Err(), len(rows))
	}
	seenPredicate, seenOperation := map[string]bool{}, map[string]bool{}
	for _, raw := range rows {
		row, err := decodeRunnerCaptureRow(raw)
		if err != nil || row.SurfaceRefusal == nil || row.Refusal != nil {
			t.Fatal("ASSERTION:v82-surface-actual-encoder", err)
		}
		seenPredicate[row.SurfaceRefusal.Predicate] = true
		seenOperation[row.SurfaceRefusal.Operation] = true
		result := runnerCaseResult{Result: "PASS"}
		runnerObserveCaseAvailability(&result, row)
		if result.Result != "PASS" || result.EvidenceUnavailable {
			t.Fatal("ASSERTION:v82-surface-no-authority")
		}
	}
	if len(seenPredicate) != 7 || len(seenOperation) != 10 {
		t.Fatal("ASSERTION:v82-surface-enum-coverage")
	}
	for index, want := range []int32{-2147483648, 0, 2147483647} {
		row, err := decodeRunnerCaptureRow(rows[17+index])
		if err != nil || row.SurfaceRefusal == nil || row.SurfaceRefusal.Status == nil || *row.SurfaceRefusal.Status != want {
			t.Fatal("ASSERTION:v82-surface-status-roundtrip", index, err)
		}
	}
	for _, change := range []struct {
		field string
		value any
	}{{"predicate", "new"}, {"operation", "new"}, {"status", false}, {"status", true}, {"status", "0"}, {"status", json.Number("0.5")}, {"status", json.Number("2147483648")}, {"status", json.Number("-2147483649")}, {"predicate", nil}, {"operation", nil}, {"path", "unexpected"}} {
		bad := runnerRefusalReplace(rows[0], []string{change.field}, change.value)
		if _, err := decodeRunnerCaptureRow(bad); err == nil {
			t.Fatal("ASSERTION:v82-surface-invalid-field", change.field, change.value)
		}
	}
	for _, field := range []string{"predicate", "operation", "status"} {
		var fields map[string]json.RawMessage
		_ = json.Unmarshal(rows[0], &fields)
		delete(fields, field)
		bad, _ := json.Marshal(fields)
		if _, err := decodeRunnerCaptureRow(bad); err == nil {
			t.Fatal("ASSERTION:v82-surface-missing-field", field)
		}
	}
}

func TestRunnerV82SurfaceExactDiagnosticEnums(t *testing.T) {
	path := os.Getenv("SLICCY_SURFACE_REFUSAL_FIXTURE")
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	raw := bytes.Split(data, []byte("\n"))[0]
	for _, field := range []struct{ name, valid, composite string }{{"predicate", "host", "host identifier"}, {"operation", "host", "host executable-read"}} {
		if _, err := decodeRunnerCaptureRow(runnerRefusalReplace(raw, []string{field.name}, field.valid)); err != nil {
			t.Fatal("ASSERTION:v82-surface-exact-enum-control", err)
		}
		for _, value := range []string{field.composite, " " + field.valid, field.valid + " ", "\t" + field.valid, field.valid + "\n", ""} {
			if _, err := decodeRunnerCaptureRow(runnerRefusalReplace(raw, []string{field.name}, value)); err == nil {
				t.Fatal("ASSERTION:v82-surface-exact-enum", field.name, value)
			}
		}
	}
}
func TestRunnerV82InventoryExactDiagnosticEnums(t *testing.T) {
	raw := runnerRefusalFixtureRows(t)[0]
	for _, field := range []struct{ name, valid, composite string }{{"site", "initial", "initial refresh"}, {"issue", "permission", "permission surface-identity"}, {"branch", "operation", "operation host"}, {"comparison", "operation", "operation present"}, {"signingIdentifierSource", "verified", "tentative verified"}} {
		if _, err := decodeRunnerCaptureRow(runnerRefusalReplace(raw, []string{field.name}, field.valid)); err != nil {
			t.Fatal("ASSERTION:v82-inventory-exact-enum-control", field.name, err)
		}
		for _, value := range []string{field.composite, " " + field.valid, field.valid + " ", "\t" + field.valid, field.valid + "\n", ""} {
			if _, err := decodeRunnerCaptureRow(runnerRefusalReplace(raw, []string{field.name}, value)); err == nil {
				t.Fatal("ASSERTION:v82-inventory-exact-enum", field.name, value)
			}
		}
	}
}
