package integration

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"strings"
	"testing"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
)

type hostedPIDRow struct {
	identityRow
	Attempt          *int     `json:"attempt,omitempty"`
	Hosted           *bool    `json:"hosted,omitempty"`
	OSMajor          *int     `json:"osMajor,omitempty"`
	Architecture     string   `json:"architecture,omitempty"`
	Invalidated      *bool    `json:"invalidated,omitempty"`
	MaximumSeconds   *int     `json:"maximumSeconds,omitempty"`
	Count            *uint64  `json:"count,omitempty"`
	Spawned          *uint64  `json:"spawned,omitempty"`
	Reaped           *uint64  `json:"reaped,omitempty"`
	CPU              *float64 `json:"cpuMs,omitempty"`
	Wall             *float64 `json:"wallMs,omitempty"`
	MaximumDebt      *float64 `json:"maximumDebtMs,omitempty"`
	PrefixEqual      *bool    `json:"prefixEqual,omitempty"`
	VersionDifferent *bool    `json:"versionDifferent,omitempty"`
	Outcome          string   `json:"outcome,omitempty"`
}

func decodeHostedPIDRow(raw []byte) (hostedPIDRow, error) {
	var row hostedPIDRow
	if screen.Strict(raw, &row, 4096) != nil || row.Schema != 3 || row.Case != "pid-reuse-hosted" || row.Capture == nil || *row.Capture || !finiteNonnegative(row.Elapsed) {
		return row, fmt.Errorf("invalid hosted PID row")
	}
	keys := strings.Fields("schema case capture stage elapsedMs")
	switch row.Stage {
	case "runner-preflight":
		keys = append(keys, "hosted", "osMajor", "architecture", "pid")
	case "pid-reuse-original-started", "pid-reuse-attempt-started", "lanes-authenticated", "heartbeat-ready", "pid-reuse-original-live-positive", "pid-reuse-original-observed", "pid-reuse-candidate-live-positive", "pid-reuse-child-reaped", "pid-reuse-observed", "pid-reuse-current-token-positive", "pid-reuse-old-token-refused", "pid-reuse-current-token-rechecked", "pid-reuse-observation-ended", "pid-reuse-near-target-missed":
		keys = append(keys, "attempt", "pid")
	case "pid-reuse-gate-invalidated":
		keys = append(keys, "attempt", "pid", "invalidated")
	case "cycler-started":
		keys = append(keys, "maximumSeconds")
	case "cycler-progress", "cycler-ended":
		keys = append(keys, "count", "spawned", "reaped", "cpuMs", "wallMs", "maximumDebtMs")
		if row.Stage == "cycler-ended" {
			keys = append(keys, "reason")
		}
	case "cycler-failed":
		keys = append(keys, "reason", "spawned", "reaped")
	case "token-incarnation-compared":
		keys = append(keys, "attempt", "pid", "prefixEqual", "versionDifferent")
	case "owned-cleanup-complete":
		keys = append(keys, "spawned", "reaped")
	case "terminal":
		keys = append(keys, "outcome", "reason")
	default:
		return row, fmt.Errorf("unknown hosted PID stage")
	}
	var fields map[string]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil || len(fields) != len(keys) {
		return row, fmt.Errorf("wrong hosted stage field set")
	}
	for _, key := range keys {
		value, ok := fields[key]
		if !ok || bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			return row, fmt.Errorf("missing/null hosted field")
		}
	}
	if row.Attempt != nil && (*row.Attempt < 0 || *row.Attempt > 1) {
		return row, fmt.Errorf("attempt outside bound")
	}
	if row.PID != nil && *row.PID <= 0 {
		return row, fmt.Errorf("invalid owned PID")
	}
	for _, f := range []*float64{row.CPU, row.Wall, row.MaximumDebt} {
		if f != nil && !finiteNonnegative(*f) {
			return row, fmt.Errorf("invalid metric")
		}
	}
	allowedReason := ""
	switch row.Stage {
	case "cycler-ended":
		allowedReason = "near-target time-limit cpu-debt-at-deadline unsupported-target invalid-accounting invalid-lifecycle"
	case "cycler-failed":
		allowedReason = "cpu-accounting-failed spawn-failed reap-failed lifecycle-failed interrupted"
	case "terminal":
		allowedReason = "pid-reuse-confirmed pid-reuse-not-observed unsupported-target fixed-failure interrupted cleanup-failed time-budget-exceeded"
		if row.Outcome != "complete" && row.Outcome != "failed-to-demonstrate" && row.Outcome != "failed" {
			return row, fmt.Errorf("unknown terminal outcome")
		}
	}
	if allowedReason != "" && !strings.Contains(" "+allowedReason+" ", " "+row.Reason+" ") {
		return row, fmt.Errorf("unknown fixed reason")
	}
	return row, nil
}
func finiteNonnegative(v float64) bool { return v >= 0 && !math.IsNaN(v) && !math.IsInf(v, 0) }
func hostedPIDPlacement(env map[string]string, version, arch string) error {
	if arch != "arm64" || strings.Split(version, ".")[0] != "27" {
		return fmt.Errorf("hosted macOS27 arm64 required")
	}
	for key, value := range map[string]string{"GITHUB_ACTIONS": "true", "GITHUB_REPOSITORY": "ai-ecoverse/sliccy-app", "GITHUB_EVENT_NAME": "workflow_dispatch", "GITHUB_REF": "refs/heads/proof/runner-capture-v1", "SLICCY_RUNNER_ENVIRONMENT": "github-hosted"} {
		if env[key] != value {
			return fmt.Errorf("exact hosted placement required")
		}
	}
	return nil
}
func TestHostedPIDParserRefusesInvalidMetadata(t *testing.T) {
	good := `{"schema":3,"case":"pid-reuse-hosted","capture":false,"stage":"token-incarnation-compared","elapsedMs":1,"attempt":1,"pid":42,"prefixEqual":true,"versionDifferent":true}`
	if _, e := decodeHostedPIDRow([]byte(good)); e != nil {
		t.Fatal(e)
	}
	for _, bad := range []string{strings.Replace(good, `"attempt":1`, `"attempt":2`, 1), strings.Replace(good, `"pid":42`, `"pid":null`, 1), strings.Replace(good, `"pid":42`, `"pid":42,"pid":43`, 1), strings.Replace(good, `"capture":false`, `"capture":true`, 1), strings.Replace(good, `"prefixEqual":true`, `"prefixEqual":true,"extra":false`, 1), strings.Replace(good, `"stage":"token-incarnation-compared"`, `"stage":"pid-reuse-observed"`, 1), good + " {}"} {
		if _, e := decodeHostedPIDRow([]byte(bad)); e == nil {
			t.Fatal("invalid hosted row accepted")
		}
	}
}
func TestHostedPIDPlacementRejectsLocalAndOverrides(t *testing.T) {
	env := map[string]string{"GITHUB_ACTIONS": "true", "GITHUB_REPOSITORY": "ai-ecoverse/sliccy-app", "GITHUB_EVENT_NAME": "workflow_dispatch", "GITHUB_REF": "refs/heads/proof/runner-capture-v1", "SLICCY_RUNNER_ENVIRONMENT": "github-hosted"}
	if e := hostedPIDPlacement(env, "27.0", "arm64"); e != nil {
		t.Fatal(e)
	}
	if hostedPIDPlacement(nil, "27.0", "arm64") == nil || hostedPIDPlacement(env, "26.0", "arm64") == nil || hostedPIDPlacement(env, "27.0", "amd64") == nil {
		t.Fatal("invalid host allowed")
	}
	for key, value := range env {
		env[key] = "unapproved"
		if hostedPIDPlacement(env, "27.0", "arm64") == nil {
			t.Fatal("bad host field allowed")
		}
		env[key] = value
	}
}
