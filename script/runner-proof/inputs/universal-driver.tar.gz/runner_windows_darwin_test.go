package integration

import (
	"fmt"
	"math"
	"os"
	"testing"
	"unsafe"

	"github.com/ebitengine/purego"
)

type independentRect struct {
	X      float64 `json:"x"`
	Y      float64 `json:"y"`
	Width  float64 `json:"width"`
	Height float64 `json:"height"`
}
type independentWindow struct {
	ID    uint32          `json:"windowID"`
	PID   int             `json:"pid"`
	Layer int64           `json:"layer"`
	Rect  independentRect `json:"rect"`
	Order int             `json:"order"`
}
type windowCF struct {
	list         func(uint32, uint32) uintptr
	release      func(uintptr)
	typeID       func(uintptr) uint64
	arrayType    func() uint64
	dictType     func() uint64
	numberType   func() uint64
	arrayCount   func(uintptr) int64
	arrayAt      func(uintptr, int64) uintptr
	dictGet      func(uintptr, uintptr) uintptr
	numberGet    func(uintptr, int32, unsafe.Pointer) bool
	stringCreate func(uintptr, *byte, uint32) uintptr
}

func readRunnerWindows(approved bool) (result []independentWindow, err error) {
	if !approved || os.Getenv("RUNNER_ENVIRONMENT") != "github-hosted" || os.Getenv("GITHUB_REPOSITORY") != "ai-ecoverse/sliccy-app" || os.Getenv("GITHUB_REF") != "refs/heads/proof/runner-capture-v1" {
		return nil, fmt.Errorf("isolated runner context required")
	}
	defer func() {
		if recover() != nil {
			err = fmt.Errorf("independent window API unavailable")
		}
	}()
	cf, e := purego.Dlopen("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return nil, e
	}
	defer purego.Dlclose(cf)
	cg, e := purego.Dlopen("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return nil, e
	}
	defer purego.Dlclose(cg)
	var a windowCF
	purego.RegisterLibFunc(&a.list, cg, "CGWindowListCopyWindowInfo")
	for _, v := range []struct {
		name   string
		target any
	}{{"CFRelease", &a.release}, {"CFGetTypeID", &a.typeID}, {"CFArrayGetTypeID", &a.arrayType}, {"CFDictionaryGetTypeID", &a.dictType}, {"CFNumberGetTypeID", &a.numberType}, {"CFArrayGetCount", &a.arrayCount}, {"CFArrayGetValueAtIndex", &a.arrayAt}, {"CFDictionaryGetValue", &a.dictGet}, {"CFNumberGetValue", &a.numberGet}, {"CFStringCreateWithCString", &a.stringCreate}} {
		purego.RegisterLibFunc(v.target, cf, v.name)
	}
	array := a.list(1|16, 0)
	if array == 0 {
		return nil, fmt.Errorf("window enumeration unavailable")
	}
	defer a.release(array)
	if a.typeID(array) != a.arrayType() {
		return nil, fmt.Errorf("window list type invalid")
	}
	count := a.arrayCount(array)
	if count < 1 || count > 512 {
		return nil, fmt.Errorf("window enumeration outside bound")
	}
	lookup := func(dict uintptr, name string) uintptr {
		raw := append([]byte(name), 0)
		key := a.stringCreate(0, &raw[0], 0x08000100)
		if key == 0 {
			return 0
		}
		defer a.release(key)
		return a.dictGet(dict, key)
	}
	integer := func(dict uintptr, key string) (int64, error) {
		value := lookup(dict, key)
		var n int64
		if value == 0 || a.typeID(value) != a.numberType() || !a.numberGet(value, 4, unsafe.Pointer(&n)) {
			return 0, fmt.Errorf("window integer unavailable")
		}
		return n, nil
	}
	real := func(dict uintptr, key string) (float64, error) {
		value := lookup(dict, key)
		var n float64
		if value == 0 || a.typeID(value) != a.numberType() || !a.numberGet(value, 13, unsafe.Pointer(&n)) || math.IsNaN(n) || math.IsInf(n, 0) {
			return 0, fmt.Errorf("window geometry unavailable")
		}
		return n, nil
	}
	seen := map[uint32]bool{}
	for i := int64(0); i < count; i++ {
		dict := a.arrayAt(array, i)
		if dict == 0 || a.typeID(dict) != a.dictType() {
			return nil, fmt.Errorf("window dictionary unavailable")
		}
		id, e := integer(dict, "kCGWindowNumber")
		if e != nil || id < 1 || id > math.MaxUint32 {
			return nil, fmt.Errorf("window ID invalid")
		}
		pid, e := integer(dict, "kCGWindowOwnerPID")
		if e != nil || pid < 1 || pid > math.MaxInt32 {
			return nil, fmt.Errorf("window owner unavailable")
		}
		layer, e := integer(dict, "kCGWindowLayer")
		if e != nil || layer < math.MinInt32 || layer > math.MaxInt32 {
			return nil, fmt.Errorf("window layer unavailable")
		}
		bounds := lookup(dict, "kCGWindowBounds")
		if bounds == 0 || a.typeID(bounds) != a.dictType() {
			return nil, fmt.Errorf("window bounds unavailable")
		}
		x, e := real(bounds, "X")
		if e != nil {
			return nil, e
		}
		y, e := real(bounds, "Y")
		if e != nil {
			return nil, e
		}
		w, e := real(bounds, "Width")
		if e != nil {
			return nil, e
		}
		h, e := real(bounds, "Height")
		if e != nil {
			return nil, e
		}
		if w <= 0 || h <= 0 || w > 32768 || h > 32768 || math.Abs(x) > 65536 || math.Abs(y) > 65536 || seen[uint32(id)] {
			return nil, fmt.Errorf("ambiguous/unsupported window geometry")
		}
		seen[uint32(id)] = true
		result = append(result, independentWindow{uint32(id), int(pid), layer, independentRect{x, y, w, h}, int(i)})
	}
	return result, nil
}

func TestRunnerWindowObserverRequiresExplicitGate(t *testing.T) {
	if _, e := readRunnerWindows(false); e == nil {
		t.Fatal("window enumeration without reviewed runner gate")
	}
}
