package integration

import (
	"os"
	"testing"
)

func TestSignedRunnerCapture(t *testing.T) {
	if os.Getenv("SLICC_RUNNER_PROOF_ROOT") == "" {
		t.Skip("reviewed isolated runner manifest required")
	}
	t.Fatal("runner case implementation/source/artifact freeze incomplete; dispatch is blocked")
}
