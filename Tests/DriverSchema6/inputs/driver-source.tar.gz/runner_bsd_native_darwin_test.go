package integration

import (
	"encoding/binary"
	"context"
	"fmt"
	"math"
	"os"
	"runtime"
	"syscall"
	"unsafe"

	"github.com/ebitengine/purego"
	"golang.org/x/sys/unix"
)

func runnerBSDSystemRead(pid int64) runnerBSDRead {
	var value unix.KinfoProc
	size := uintptr(unsafe.Sizeof(value))
	r := runnerBSDRead{Expected: int64(size), Count: int64(size)}
	if pid < 1 || pid > math.MaxInt32 || size != 648 {
		r.Status = int64(syscall.EINVAL)
		return r
	}
	mib := [4]int32{1, 14, 1, int32(pid)}
	r.Executed = true
	returned, _, errno := syscall.Syscall6(syscall.SYS___SYSCTL, uintptr(unsafe.Pointer(&mib[0])), 4, uintptr(unsafe.Pointer(&value)), uintptr(unsafe.Pointer(&size)), 0, 0)
	runtime.KeepAlive(mib)
	r.NativeReturn = int32(returned); r.Errno = int32(errno)
	r.Count = int64(size)
	if errno != 0 {
		r.Status = int64(errno)
		return r
	}
	if size != unsafe.Sizeof(value) {
		r.Status = int64(syscall.EINVAL)
		return r
	}
	v := &runnerBSDValue{}
	if value.Proc.P_starttime.Sec > 0 && value.Proc.P_starttime.Usec >= 0 {
		*v = runnerBSDValue{PID: int64(value.Proc.P_pid), Parent: int64(value.Eproc.Ppid), Effective: value.Eproc.Ucred.Uid, Real: value.Eproc.Pcred.P_ruid, Saved: value.Eproc.Pcred.P_svuid, Seconds: uint64(value.Proc.P_starttime.Sec), Microseconds: uint64(value.Proc.P_starttime.Usec)}
	}
	r.Value = v
	return r
}

func runnerBSDProcRead(pid int64) (r runnerBSDRead) {
	r.Expected = 136
	if pid < 1 || pid > math.MaxInt32 {
		r.Status = int64(syscall.EINVAL)
		return r
	}
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	lib, e := purego.Dlopen("/usr/lib/libproc.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		r.Status = int64(syscall.EIO)
		return r
	}
	defer purego.Dlclose(lib)
	system, e := purego.Dlopen("/usr/lib/libSystem.B.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		r.Status = int64(syscall.EIO)
		return r
	}
	defer purego.Dlclose(system)
	var info func(int32, int32, uint64, *byte, int32) int32
	var errorPointer func() *int32
	purego.RegisterLibFunc(&info, lib, "proc_pidinfo")
	purego.RegisterLibFunc(&errorPointer, system, "__error")
	pointer := errorPointer()
	if pointer == nil {
		r.Status = int64(syscall.EIO)
		return r
	}
	*pointer = 0
	var raw [136]byte
	r.Executed = true
	n := info(int32(pid), 3, 0, &raw[0], 136)
	errno := *pointer
	r.NativeReturn = n; r.Errno = errno
	if n > 0 {
		r.Count = int64(n)
	}
	if n != 136 {
		r.Status = int64(errno)
		if r.Status == 0 {
			r.Status = int64(syscall.EINVAL)
		}
		return r
	}
	v := &runnerBSDValue{}
	u32 := func(at int) uint32 { return binary.LittleEndian.Uint32(raw[at : at+4]) }
	if u32(12) <= math.MaxInt32 && u32(16) <= math.MaxInt32 {
		*v = runnerBSDValue{PID: int64(u32(12)), Parent: int64(u32(16)), Effective: u32(20), Real: u32(28), Saved: u32(36), Seconds: binary.LittleEndian.Uint64(raw[120:128]), Microseconds: binary.LittleEndian.Uint64(raw[128:136])}
	}
	r.Value = v
	return r
}

func runnerObserveBSDWith(pid int64, self, parent func() int, sysctl, proc func(int64) runnerBSDRead) (runnerBSDReceipt, error) {
	r := runnerBSDReceipt{PID: pid, SelfPID: int64(self()), ParentPID: int64(parent())}
	bracket := func(pid int64) runnerBSDBracket { return runnerBSDBracket{sysctl(pid), proc(pid), sysctl(pid)} }
	r.Controls[0] = bracket(r.SelfPID)
	r.Controls[1] = bracket(r.ParentPID)
	r.Target = bracket(pid)
	if int64(self()) != r.SelfPID || int64(parent()) != r.ParentPID {
		r.Status = int64(syscall.EINVAL)
	}
	selected, used := runnerBSDSelect(r)
	r.Selected = selected
	r.Accepted = selected != nil
	if !r.Accepted {
		return r, fmt.Errorf("independent raw BSD identity could not bind")
	}
	controls := runnerBSDControls(r)
	r.UsedSysctl = &used
	r.ControlsAgreed = &controls
	return r, nil
}

func runnerObserveBSD(pid int) (r runnerBSDReceipt, err error) {
	if runnerPlacement() != nil || os.Geteuid() == 0 {
		return r, fmt.Errorf("hosted unprivileged BSD observation required")
	}
	defer func() {
		if recover() != nil {
			err = fmt.Errorf("independent BSD observation ABI unavailable")
		}
	}()
	return runnerObserveBSDWith(int64(pid), os.Getpid, os.Getppid, runnerBSDSystemRead, runnerBSDProcRead)
}

func runnerObserveBSDContext(ctx context.Context,trace *runnerNativeTrace,pid int)(r runnerBSDReceipt,err error){
	if ctx==nil||trace==nil||runnerPlacement()!=nil||os.Geteuid()==0{return r,fmt.Errorf("bounded hosted BSD observation context required")}
	r.PID=int64(pid);r.SelfPID=int64(os.Getpid());r.ParentPID=int64(os.Getppid())
	read:=func(target int64,operation string,flags uint32,query func(int64)runnerBSDRead)(runnerBSDRead,error){
		if ctx.Err()!=nil{return runnerBSDRead{},ctx.Err()}
		id,ok:=trace.Begin(operation,int(target),flags);if !ok{return runnerBSDRead{},fmt.Errorf("native BSD trace lost")}
		value:=query(target)
		if !value.Executed{trace.NotExecuted(id);return value,fmt.Errorf("native BSD precondition/ABI refused before call")}
		if !trace.EndDetailed(id,&value.NativeReturn,value.Value!=nil,&value.Errno){return value,fmt.Errorf("native BSD trace completion lost")}
		return value,nil
	}
	bracket:=func(target int64)(b runnerBSDBracket,e error){
		if b[0],e=read(target,"sysctl-KERN_PROC_PID",0,runnerBSDSystemRead);e!=nil{return b,e}
		if b[1],e=read(target,"proc_pidinfo-PROC_PIDTBSDINFO",3,runnerBSDProcRead);e!=nil{return b,e}
		if b[2],e=read(target,"sysctl-KERN_PROC_PID",0,runnerBSDSystemRead);e!=nil{return b,e}
		return b,nil
	}
	if r.Controls[0],err=bracket(r.SelfPID);err!=nil{return r,err}
	if r.Controls[1],err=bracket(r.ParentPID);err!=nil{return r,err}
	if r.Target,err=bracket(r.PID);err!=nil{return r,err}
	if int64(os.Getpid())!=r.SelfPID||int64(os.Getppid())!=r.ParentPID{r.Status=int64(syscall.EINVAL)}
	selected,used:=runnerBSDSelect(r);r.Selected=selected;r.Accepted=selected!=nil
	if !r.Accepted{return r,fmt.Errorf("independent BSD raw observations could not bind")}
	controls:=runnerBSDControls(r);r.UsedSysctl=&used;r.ControlsAgreed=&controls
	return r,nil
}
