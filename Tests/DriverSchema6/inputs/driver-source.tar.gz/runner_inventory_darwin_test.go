package integration

import (
	"fmt"
	"testing"
)

type runnerOwnerWitness struct {
	Label  string
	PID    int
	Bundle string
}
type runnerWindowClaim struct {
	Label   string
	PID     int
	ID      uint32
	Rect    independentRect
	Layer   int64
	Profile string
}
type runnerInventoryCounts struct{ Processes, Windows int }

func matchRunnerInventory(selected string, owners []runnerOwnerWitness, claims []runnerWindowClaim, actual []independentWindow, counts runnerInventoryCounts) error {
	display := selected == "display-exclusion" || selected == "authorization-exclusion"
	switch selected {
	case "selected-window", "display-exclusion", "authorization-exclusion", "reciprocal-revoke", "active-stop", "hotkey-stop":
	default:
		return fmt.Errorf("unknown inventory case")
	}
	want := map[string]string{"allowed": "ai.sliccy.proof-helper"}
	if display {
		want["app"] = "ai.sliccy.mac"
		want["chrome-a"] = "com.google.Chrome"
		want["chrome-b"] = "com.google.Chrome"
	}
	if selected == "authorization-exclusion" {
		want["authorization"] = "apple-authorization"
	}
	if len(owners) != len(want) || len(owners) > 5 || len(claims) > 128 || len(actual) > 512 {
		return fmt.Errorf("owner/window count mismatch")
	}
	byPID := map[int]runnerOwnerWitness{}
	byLabel := map[string]runnerOwnerWitness{}
	for _, owner := range owners {
		bundle, ok := want[owner.Label]
		if !ok || owner.PID < 1 {
			return fmt.Errorf("unknown owner")
		}
		if bundle == "apple-authorization" {
			switch owner.Bundle {
			case "com.apple.SecurityAgent", "com.apple.securityagent", "com.apple.AuthorizationHost", "com.apple.authorizationhost":
			default:
				return fmt.Errorf("unapproved authorization owner")
			}
		} else if owner.Bundle != bundle {
			return fmt.Errorf("owner bundle mismatch")
		}
		if _, ok := byPID[owner.PID]; ok {
			return fmt.Errorf("one PID substituted for multiple owners")
		}
		if _, ok := byLabel[owner.Label]; ok {
			return fmt.Errorf("duplicate owner label")
		}
		byPID[owner.PID] = owner
		byLabel[owner.Label] = owner
	}
	if counts.Processes != len(owners) || counts.Windows != len(claims) {
		return fmt.Errorf("inventory count claim mismatch")
	}
	windows := map[uint32]independentWindow{}
	for _, window := range actual {
		if window.ID == 0 || window.PID < 1 {
			return fmt.Errorf("invalid independent window")
		}
		if _, ok := windows[window.ID]; ok {
			return fmt.Errorf("duplicate independent window")
		}
		windows[window.ID] = window
	}
	identified := map[uint32]bool{}
	for _, owner := range owners {
		var frozen []independentRect
		switch owner.Label {
		case "allowed":
			frozen = []independentRect{{128, 128, 256, 256}}
		case "chrome-a", "chrome-b":
			profile := owner.Label[len("chrome-"):]
			for _, page := range fixedProofPageCatalog {
				if page.Profile == profile {
					frozen = append(frozen, page.Rect)
				}
			}
		case "app":
			if _, e := runnerUniqueWindow(actual, owner.PID, independentRect{64, 512, 320, 128}); e != nil {
				return e
			}
			fallthrough
		case "authorization":
			for _, window := range actual {
				if window.PID == owner.PID {
					frozen = append(frozen, window.Rect)
				}
			}
		}
		for _, bounds := range frozen {
			window, e := runnerUniqueWindow(actual, owner.PID, bounds)
			if e != nil {
				return e
			}
			identified[window.ID] = true
		}
	}
	seen := map[uint32]bool{}
	perOwner := map[string]int{}
	pages := map[string]bool{}
	indicator := false
	for _, claim := range claims {
		owner, ok := byPID[claim.PID]
		if !ok || owner.Label != claim.Label || seen[claim.ID] || !identified[claim.ID] {
			return fmt.Errorf("unknown/mislabeled/duplicate window claim")
		}
		window, uniqueError := runnerUniqueWindow(actual, owner.PID, claim.Rect)
		_, ok = windows[claim.ID]
		if uniqueError != nil || !ok || window.ID != claim.ID || window.PID != claim.PID || window.Rect != claim.Rect || window.Layer != claim.Layer {
			return fmt.Errorf("claim does not match independent window")
		}
		seen[claim.ID] = true
		perOwner[claim.Label]++
		profile := "none"
		switch claim.Label {
		case "allowed":
			if claim.Rect != (independentRect{128, 128, 256, 256}) || claim.Layer != 0 {
				return fmt.Errorf("allowed source geometry/layer mismatch")
			}
		case "chrome-a", "chrome-b":
			profile = claim.Label[len("chrome-"):]
			found := false
			for _, page := range fixedProofPageCatalog {
				if page.Profile == profile && page.Rect == claim.Rect && claim.Layer == 0 && !pages[page.Path] {
					pages[page.Path] = true
					found = true
					break
				}
			}
			if !found {
				return fmt.Errorf("Chrome profile/title/geometry mismatch")
			}
		case "app":
			if claim.Rect == (independentRect{64, 512, 320, 128}) {
				indicator = true
			}
		}
		if claim.Profile != profile {
			return fmt.Errorf("wrong window profile")
		}
	}
	for _, window := range actual {
		if _, ok := byPID[window.PID]; ok && !seen[window.ID] {
			return fmt.Errorf("independently visible owner window omitted")
		}
	}
	for label := range want {
		if perOwner[label] < 1 {
			return fmt.Errorf("required owner has no window")
		}
		if label == "allowed" && perOwner[label] != 1 {
			return fmt.Errorf("ambiguous allowed source")
		}
		if (label == "chrome-a" || label == "chrome-b") && perOwner[label] != 2 {
			return fmt.Errorf("missing browser profile window")
		}
	}
	if display && (!indicator || len(pages) != 4) {
		return fmt.Errorf("missing indicator/browser window")
	}
	return nil
}

func TestRunnerInventoryCannotTrustPartialOrMislabeledClaims(t *testing.T) {
	makeFixture := func() ([]runnerOwnerWitness, []runnerWindowClaim, []independentWindow, runnerInventoryCounts) {
		owners := []runnerOwnerWitness{{"allowed", 10, "ai.sliccy.proof-helper"}, {"app", 11, "ai.sliccy.mac"}, {"chrome-a", 12, "com.google.Chrome"}, {"chrome-b", 13, "com.google.Chrome"}, {"authorization", 14, "com.apple.SecurityAgent"}}
		actual := []independentWindow{{ID: 1, PID: 10, Rect: independentRect{128, 128, 256, 256}}, {ID: 2, PID: 11, Layer: 25, Rect: independentRect{64, 512, 320, 128}}, {ID: 7, PID: 14, Rect: independentRect{600, 200, 300, 200}}}
		for i, page := range fixedProofPageCatalog {
			pid := 12
			if page.Profile == "b" {
				pid = 13
			}
			actual = append(actual, independentWindow{ID: uint32(i + 3), PID: pid, Rect: page.Rect, Title: page.Title})
		}
		var claims []runnerWindowClaim
		for _, window := range actual {
			label := ""
			for _, owner := range owners {
				if owner.PID == window.PID {
					label = owner.Label
				}
			}
			profile := "none"
			if label == "chrome-a" {
				profile = "a"
			}
			if label == "chrome-b" {
				profile = "b"
			}
			claims = append(claims, runnerWindowClaim{label, window.PID, window.ID, window.Rect, window.Layer, profile})
		}
		return owners, claims, actual, runnerInventoryCounts{len(owners), len(claims)}
	}
	o, c, a, n := makeFixture()
	if e := matchRunnerInventory("authorization-exclusion", o, c, a, n); e != nil {
		t.Fatal(e)
	}
	for i := range a {
		a[i].Title = ""
		a[i].TitleVisible = false
	}
	if e := matchRunnerInventory("authorization-exclusion", o, c, a, n); e != nil {
		t.Fatal("absent browser titles changed ownership verdict", e)
	}
	for i := range a {
		a[i].Title = "conflicting diagnostic title"
		a[i].TitleVisible = true
	}
	if e := matchRunnerInventory("authorization-exclusion", o, c, a, n); e != nil {
		t.Fatal("conflicting browser titles changed ownership verdict", e)
	}

	for mode := 0; mode < 10; mode++ {
		o, c, a, n = makeFixture()
		switch mode {
		case 0:
			a = append(a, independentWindow{ID: 20, PID: 11, Layer: 100, Rect: independentRect{1, 1, 10, 10}})
		case 1:
			a = append(a, independentWindow{ID: 20, PID: 14, Rect: independentRect{1, 1, 10, 10}})
		case 2:
			c = c[:len(c)-1]
			n.Windows--
		case 3:
			c[3].Profile = "b"
		case 4:
			a[3].PID = 99
		case 5:
			o[2].PID = o[3].PID
		case 6:
			o[4].Bundle = "lookalike.prompt"
		case 7:
			c[0].Rect.X++
		case 8:
			c[3].ID = c[4].ID
		case 9:
			a[0].Layer = 10
			c[0].Layer = 10
		}
		if matchRunnerInventory("authorization-exclusion", o, c, a, n) == nil {
			t.Fatalf("bad inventory mutation %d passed", mode)
		}
	}
	o, c, a, n = makeFixture()
	a = append(a, independentWindow{ID: 20, PID: 99, Rect: independentRect{1, 1, 10, 10}})
	if e := matchRunnerInventory("authorization-exclusion", o, c, a, n); e != nil {
		t.Fatal("unrelated runner window treated as a declared owned window", e)
	}
}

type runnerRefusalClaim struct {
	Label     string
	PID       int
	Kind      string
	WindowID  *uint32
	Predicate bool
}

func matchRunnerRefusals(windows []runnerWindowClaim, refusals []runnerRefusalClaim) error {
	if len(windows) > 128 || len(refusals) > 256 {
		return fmt.Errorf("refusal inventory outside bounds")
	}
	owners := map[int]string{}
	expected := map[uint32]runnerWindowClaim{}
	for _, window := range windows {
		if window.Label == "allowed" {
			continue
		}
		if window.PID < 1 || window.ID == 0 {
			return fmt.Errorf("invalid protected window")
		}
		if label, ok := owners[window.PID]; ok && label != window.Label {
			return fmt.Errorf("ambiguous protected owner")
		}
		if _, ok := expected[window.ID]; ok {
			return fmt.Errorf("duplicate protected window")
		}
		owners[window.PID] = window.Label
		expected[window.ID] = window
	}
	displays, seen := map[int]bool{}, map[uint32]bool{}
	for _, claim := range refusals {
		label, ok := owners[claim.PID]
		if !ok || label != claim.Label {
			return fmt.Errorf("unattributed protected refusal")
		}
		switch claim.Kind {
		case "display":
			if claim.WindowID != nil || !claim.Predicate || displays[claim.PID] {
				return fmt.Errorf("missing unconfounded display refusal")
			}
			displays[claim.PID] = true
		case "window":
			if claim.WindowID == nil || seen[*claim.WindowID] {
				return fmt.Errorf("duplicate/missing refusal window")
			}
			window, ok := expected[*claim.WindowID]
			if !ok || window.PID != claim.PID || claim.Predicate != (window.Layer == 0) {
				return fmt.Errorf("window refusal does not match independently observed predicate")
			}
			seen[*claim.WindowID] = true
		default:
			return fmt.Errorf("unknown protected probe")
		}
	}
	if len(displays) != len(owners) || len(seen) != len(expected) {
		return fmt.Errorf("incomplete owner/window refusal coverage")
	}
	return nil
}
func TestRunnerRefusalsRequireEveryOwnerAndEveryActualWindow(t *testing.T) {
	app, chrome := uint32(7), uint32(8)
	windows := []runnerWindowClaim{{"app", 11, app, independentRect{64, 512, 320, 128}, 25, "none"}, {"chrome-a", 12, chrome, independentRect{416, 64, 288, 224}, 0, "a"}}
	claims := []runnerRefusalClaim{{"app", 11, "display", nil, true}, {"app", 11, "window", &app, false}, {"chrome-a", 12, "display", nil, true}, {"chrome-a", 12, "window", &chrome, true}}
	if e := matchRunnerRefusals(windows, claims); e != nil {
		t.Fatal("layer-confounded window allowed only with separate display predicate", e)
	}
	for mode := 0; mode < 6; mode++ {
		bad := append([]runnerRefusalClaim(nil), claims...)
		switch mode {
		case 0:
			bad = bad[1:]
		case 1:
			bad = bad[:3]
		case 2:
			bad[1].Predicate = true
		case 3:
			bad[2].PID = 11
		case 4:
			bad = append(bad, bad[0])
		case 5:
			bad[0].Predicate = false
		}
		if matchRunnerRefusals(windows, bad) == nil {
			t.Fatalf("bad protected coverage %d passed", mode)
		}
	}
	if e := matchRunnerRefusals(nil, nil); e != nil {
		t.Fatal("selected-window fixture invented protected coverage", e)
	}
}

func runnerUniqueWindow(actual []independentWindow, pid int, bounds independentRect) (independentWindow, error) {
	var found independentWindow
	count := 0
	for _, window := range actual {
		if window.PID == pid && window.Rect == bounds {
			found = window
			count++
		}
	}
	if count != 1 {
		return independentWindow{}, fmt.Errorf("missing/ambiguous independently observed owner and bounds")
	}
	return found, nil
}

type runnerTitleFact struct {
	Visible       bool  `json:"visible"`
	ExpectedMatch *bool `json:"expectedMatch"`
}

func runnerTitleDiagnostics(actual []independentWindow) map[uint32]runnerTitleFact {
	out := map[uint32]runnerTitleFact{}
	for _, window := range actual {
		fact := runnerTitleFact{Visible: window.TitleVisible}
		if window.TitleVisible {
			for _, page := range fixedProofPageCatalog {
				if window.Rect == page.Rect {
					matches := window.Title == page.Title
					fact.ExpectedMatch = &matches
				}
			}
		}
		out[window.ID] = fact
	}
	return out
}
func TestRunnerOwnerBoundsDoNotDependOnTitleVisibilityOrText(t *testing.T) {
	owner := runnerOwnerWitness{"allowed", 10, "ai.sliccy.proof-helper"}
	rect := independentRect{128, 128, 256, 256}
	claim := runnerWindowClaim{"allowed", 10, 7, rect, 0, "none"}
	window := independentWindow{ID: 7, PID: 10, Rect: rect}
	if e := matchRunnerInventory("selected-window", []runnerOwnerWitness{owner}, []runnerWindowClaim{claim}, []independentWindow{window}, runnerInventoryCounts{1, 1}); e != nil {
		t.Fatal("absent title gated owned window", e)
	}
	window.Title = "conflicting diagnostic only"
	window.TitleVisible = true
	if e := matchRunnerInventory("selected-window", []runnerOwnerWitness{owner}, []runnerWindowClaim{claim}, []independentWindow{window}, runnerInventoryCounts{1, 1}); e != nil {
		t.Fatal("diagnostic title gated verdict", e)
	}
	for _, bad := range []independentWindow{{ID: 7, PID: 11, Rect: rect}, {ID: 7, PID: 10, Rect: independentRect{129, 128, 256, 256}}} {
		if _, e := runnerUniqueWindow([]independentWindow{bad}, 10, rect); e == nil {
			t.Fatal("wrong PID/bounds identified source")
		}
	}
	duplicate := window
	duplicate.ID = 8
	if _, e := runnerUniqueWindow([]independentWindow{window, duplicate}, 10, rect); e == nil {
		t.Fatal("ambiguous owner/bounds picked one window")
	}
	chrome := independentWindow{ID: 9, PID: 12, Rect: fixedProofPageCatalog[0].Rect}
	if d := runnerTitleDiagnostics([]independentWindow{chrome})[9]; d.Visible || d.ExpectedMatch != nil {
		t.Fatal("missing title inferred as observation")
	}
	chrome.TitleVisible = true
	chrome.Title = "different"
	if d := runnerTitleDiagnostics([]independentWindow{chrome})[9]; !d.Visible || d.ExpectedMatch == nil || *d.ExpectedMatch {
		t.Fatal("conflicting diagnostic title not retained")
	}
}
