package integration

import (
	"fmt"
	"testing"
)

type runnerWindowClaim struct {
	Label   string
	PID     int
	ID      uint32
	Rect    independentRect
	Layer   int64
	Profile string
}
type runnerInventoryCounts struct{ Processes, Windows int }

type runnerRefusalClaim struct {
	Label     string
	PID       int
	Kind      string
	WindowID  *uint32
	Predicate bool
}

func matchRunnerRefusals(windows []runnerWindowClaim, refusals []runnerRefusalClaim) error {
	if len(windows) > 128 || len(refusals) > 256 {
		return fmt.Errorf("refusal inventory outside bounds")
	}
	owners := map[int]string{}
	expected := map[uint32]runnerWindowClaim{}
	for _, window := range windows {
		if window.Label == "allowed" {
			continue
		}
		if window.PID < 1 || window.ID == 0 {
			return fmt.Errorf("invalid protected window")
		}
		if label, ok := owners[window.PID]; ok && label != window.Label {
			return fmt.Errorf("ambiguous protected owner")
		}
		if _, ok := expected[window.ID]; ok {
			return fmt.Errorf("duplicate protected window")
		}
		owners[window.PID] = window.Label
		expected[window.ID] = window
	}
	displays, seen := map[int]bool{}, map[uint32]bool{}
	for _, claim := range refusals {
		label, ok := owners[claim.PID]
		if !ok || label != claim.Label {
			return fmt.Errorf("unattributed protected refusal")
		}
		switch claim.Kind {
		case "display":
			if claim.WindowID != nil || !claim.Predicate || displays[claim.PID] {
				return fmt.Errorf("missing unconfounded display refusal")
			}
			displays[claim.PID] = true
		case "window":
			if claim.WindowID == nil || seen[*claim.WindowID] {
				return fmt.Errorf("duplicate/missing refusal window")
			}
			window, ok := expected[*claim.WindowID]
			if !ok || window.PID != claim.PID || claim.Predicate != (window.Layer == 0) {
				return fmt.Errorf("window refusal does not match independently observed predicate")
			}
			seen[*claim.WindowID] = true
		default:
			return fmt.Errorf("unknown protected probe")
		}
	}
	if len(displays) != len(owners) || len(seen) != len(expected) {
		return fmt.Errorf("incomplete owner/window refusal coverage")
	}
	return nil
}
func TestRunnerRefusalsRequireEveryOwnerAndEveryActualWindow(t *testing.T) {
	app, chrome := uint32(7), uint32(8)
	windows := []runnerWindowClaim{{"app", 11, app, independentRect{64, 512, 320, 128}, 25, "none"}, {"chrome-a-1", 12, chrome, independentRect{416, 64, 288, 224}, 0, "a-1"}}
	claims := []runnerRefusalClaim{{"app", 11, "display", nil, true}, {"app", 11, "window", &app, false}, {"chrome-a-1", 12, "display", nil, true}, {"chrome-a-1", 12, "window", &chrome, true}}
	if e := matchRunnerRefusals(windows, claims); e != nil {
		t.Fatal("layer-confounded window allowed only with separate display predicate", e)
	}
	for mode := 0; mode < 6; mode++ {
		bad := append([]runnerRefusalClaim(nil), claims...)
		switch mode {
		case 0:
			bad = bad[1:]
		case 1:
			bad = bad[:3]
		case 2:
			bad[1].Predicate = true
		case 3:
			bad[2].PID = 11
		case 4:
			bad = append(bad, bad[0])
		case 5:
			bad[0].Predicate = false
		}
		if matchRunnerRefusals(windows, bad) == nil {
			t.Fatalf("bad protected coverage %d passed", mode)
		}
	}
	if e := matchRunnerRefusals(nil, nil); e != nil {
		t.Fatal("selected-window fixture invented protected coverage", e)
	}
}

func runnerUniqueWindow(actual []independentWindow, pid int, bounds independentRect) (independentWindow, error) {
	var found independentWindow
	count := 0
	for _, window := range actual {
		if window.PID == pid && window.Rect == bounds {
			found = window
			count++
		}
	}
	if count != 1 {
		return independentWindow{}, fmt.Errorf("missing/ambiguous independently observed owner and bounds")
	}
	return found, nil
}

type runnerTitleFact struct {
	Visible       bool  `json:"visible"`
	ExpectedMatch *bool `json:"expectedMatch"`
}

func runnerTitleDiagnostics(actual []independentWindow) map[uint32]runnerTitleFact {
	out := map[uint32]runnerTitleFact{}
	for _, window := range actual {
		fact := runnerTitleFact{Visible: window.TitleVisible}
		if window.TitleVisible {
			for _, page := range fixedProofPageCatalog {
				if window.Rect == page.Rect {
					matches := window.Title == page.Title
					fact.ExpectedMatch = &matches
				}
			}
		}
		out[window.ID] = fact
	}
	return out
}
func TestRunnerOwnerBoundsDoNotDependOnTitleVisibilityOrText(t *testing.T) {
	owner := runnerOwnerWitness{"allowed", 10, "ai.sliccy.proof-helper"}
	rect := independentRect{128, 128, 256, 256}
	claim := runnerWindowClaim{"allowed", 10, 7, rect, 0, "none"}
	window := independentWindow{ID: 7, PID: 10, Rect: rect}
	if e := matchRunnerInventory("selected-window", []runnerOwnerWitness{owner}, []runnerWindowClaim{claim}, []independentWindow{window}, runnerInventoryCounts{1, 1}); e != nil {
		t.Fatal("absent title gated owned window", e)
	}
	window.Title = "conflicting diagnostic only"
	window.TitleVisible = true
	if e := matchRunnerInventory("selected-window", []runnerOwnerWitness{owner}, []runnerWindowClaim{claim}, []independentWindow{window}, runnerInventoryCounts{1, 1}); e != nil {
		t.Fatal("diagnostic title gated verdict", e)
	}
	for _, bad := range []independentWindow{{ID: 7, PID: 11, Rect: rect}, {ID: 7, PID: 10, Rect: independentRect{129, 128, 256, 256}}} {
		if _, e := runnerUniqueWindow([]independentWindow{bad}, 10, rect); e == nil {
			t.Fatal("wrong PID/bounds identified source")
		}
	}
	duplicate := window
	duplicate.ID = 8
	if _, e := runnerUniqueWindow([]independentWindow{window, duplicate}, 10, rect); e == nil {
		t.Fatal("ambiguous owner/bounds picked one window")
	}
	chrome := independentWindow{ID: 9, PID: 12, Rect: fixedProofPageCatalog[0].Rect}
	if d := runnerTitleDiagnostics([]independentWindow{chrome})[9]; d.Visible || d.ExpectedMatch != nil {
		t.Fatal("missing title inferred as observation")
	}
	chrome.TitleVisible = true
	chrome.Title = "different"
	if d := runnerTitleDiagnostics([]independentWindow{chrome})[9]; !d.Visible || d.ExpectedMatch == nil || *d.ExpectedMatch {
		t.Fatal("conflicting diagnostic title not retained")
	}
}
