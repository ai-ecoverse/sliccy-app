package integration

import (
	"bytes"
	"context"
	"fmt"
	"image"
	"image/color"
	"image/jpeg"
	"sync"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
	"github.com/ai-ecoverse/slicc-cli/internal/link"
)

type generatedFrameFact struct {
	Sequence screen.Counter
	At       time.Time
	Width    int
	Height   int
}
type generatedStateFact struct {
	State screen.State
	At    time.Time
}
type generatedFramePage struct {
	Page      *link.Link
	Join      string
	States    chan generatedStateFact
	Frames    chan generatedFrameFact
	Errors    chan string
	Opened    chan time.Time
	Done      chan struct{}
	requested uint64
	mu        sync.Mutex
	seq       uint64
	active    *screen.Binding
	granted   bool
}

func checkGeneratedGray(body []byte) error {
	if len(body) < 4 || len(body) > 4096 {
		return fmt.Errorf("generated JPEG size invalid")
	}
	cfg, e := jpeg.DecodeConfig(bytes.NewReader(body))
	if e != nil || cfg.Width != 16 || cfg.Height != 16 {
		return fmt.Errorf("generated dimensions invalid")
	}
	img, e := jpeg.Decode(bytes.NewReader(body))
	if e != nil {
		return fmt.Errorf("generated JPEG invalid")
	}
	for y := 0; y < 16; y++ {
		for x := 0; x < 16; x++ {
			r, g, b, _ := img.At(x, y).RGBA()
			for _, v := range []uint32{r >> 8, g >> 8, b >> 8} {
				if v < 125 || v > 131 {
					return fmt.Errorf("generated pixel differs from fixed gray")
				}
			}
		}
	}
	return nil
}

func newGeneratedFramePage(t *testing.T, gate <-chan struct{}) *generatedFramePage {
	t.Helper()
	p := &generatedFramePage{States: make(chan generatedStateFact, 16), Frames: make(chan generatedFrameFact, 8), Errors: make(chan string, 16), Opened: make(chan time.Time, 1), Done: make(chan struct{})}
	reject := func(reason string) {
		select {
		case p.Errors <- reason:
		default:
			t.Error("frame fixture error queue overflow")
		}
	}
	handler := func(s *link.Stream) {
		var state screen.State
		if screen.Strict(s.OpenPayload(), &state, 65536) != nil {
			reject("invalid screen state")
			_ = s.Reset("EPROTO")
			return
		}
		seq, e := state.Seq.Value()
		p.mu.Lock()
		valid := e == nil && seq > p.seq && state.Kind == "screen-state" && state.V == 1
		first := false
		if len(state.Caps) > 0 {
			valid = valid && len(state.Caps) == 1 && state.Caps[0] == "screen" && state.Reason == "active" && state.Scope == "window" && state.Binding != nil && state.Binding.Valid() && state.Limits != nil && state.Limits.Valid() && !p.granted
			if valid {
				copy := *state.Binding
				p.active = &copy
				p.granted = true
				first = true
			}
		} else {
			valid = valid && state.Reason != "active" && state.Binding == nil
			if valid {
				p.active = nil
			}
		}
		if valid {
			p.seq = seq
		}
		p.mu.Unlock()
		if !valid {
			reject("invalid or repeated synthetic grant")
			_ = s.Reset("EPROTO")
			return
		}
		select {
		case p.States <- generatedStateFact{state, time.Now()}:
		default:
			reject("state budget exceeded")
		}
		if s.Accept(nil) != nil {
			reject("state acknowledgement failed")
			return
		}
		_ = s.CloseWrite()
		if first {
			go p.consume(t, s.Link(), *state.Binding, *state.Limits, reject)
		}
	}
	p.Page, p.Join, _ = proofPageUsing(t, gate, handler)
	return p
}

func (p *generatedFramePage) consume(t *testing.T, page *link.Link, binding screen.Binding, limits screen.Limits, reject func(string)) {
	defer close(p.Done)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	stream, e := page.Open(ctx, screen.Open{Kind: "screen", V: 1, Binding: binding, MaxFPS: 5, MaxWidth: 16, MaxHeight: 16}, link.OpenOptions{})
	if e != nil {
		reject("synthetic screen OPEN refused")
		return
	}
	var opened struct {
		V         int            `json:"v"`
		Binding   screen.Binding `json:"binding"`
		Codec     string         `json:"codec"`
		MaxWidth  int            `json:"maxWidth"`
		MaxHeight int            `json:"maxHeight"`
		MaxFPS    int            `json:"maxFps"`
	}
	if screen.Strict(stream.OpenedPayload(), &opened, 4096) != nil || opened.V != 1 || opened.Binding != binding || opened.Codec != "jpeg" || opened.MaxWidth != 16 || opened.MaxHeight != 16 || opened.MaxFPS < 1 || opened.MaxFPS > 5 {
		reject("invalid synthetic screen OPENED")
		_ = stream.Reset("EPROTO")
		return
	}
	_ = stream.CloseWrite()
	p.Opened <- time.Now()
	last := screen.Counter("0")
	for {
		var f screen.Frame
		body, e := screen.ReadRecord(stream.Conn(), &f, 4096, 2*time.Second)
		if e != nil {
			return
		}
		p.mu.Lock()
		current := p.active != nil && *p.active == binding
		requested := p.requested
		p.mu.Unlock()
		if !current {
			reject("frame arrived after grant invalidation")
			return
		}
		if screen.CheckFrame(f, body, binding, last, limits) != nil || f.Launch != "" || f.Connection != "" || checkGeneratedGray(body) != nil {
			reject("invalid generated baseline frame")
			_ = stream.Reset("EPROTO")
			return
		}
		seq, _ := f.Seq.Value()
		if seq == 0 || seq > requested {
			reject("transferred or extra frame reached Pion")
			_ = stream.Reset("EACCES")
			return
		}
		last = f.Seq
		select {
		case p.Frames <- generatedFrameFact{f.Seq, time.Now(), f.Width, f.Height}:
		default:
			reject("frame budget exceeded")
			return
		}
	}
}

func TestGeneratedGrayConsumer(t *testing.T) {
	for _, tc := range []struct {
		gray  uint8
		size  int
		valid bool
	}{{128, 16, true}, {0, 16, false}, {128, 32, false}} {
		img := image.NewRGBA(image.Rect(0, 0, tc.size, tc.size))
		for y := 0; y < tc.size; y++ {
			for x := 0; x < tc.size; x++ {
				img.SetRGBA(x, y, color.RGBA{tc.gray, tc.gray, tc.gray, 255})
			}
		}
		var body bytes.Buffer
		if jpeg.Encode(&body, img, &jpeg.Options{Quality: 90}) != nil {
			t.Fatal("generated JPEG setup failed")
		}
		if (checkGeneratedGray(body.Bytes()) == nil) != tc.valid {
			t.Fatal("generated-only consumer admitted wrong source")
		}
	}
	if checkGeneratedGray([]byte{0xff, 0xd8, 0xff, 0xd9}) == nil {
		t.Fatal("invalid JPEG accepted")
	}
}
