package integration

import (
	"encoding/json"
	"testing"
)

func TestRunnerNativeTraceKeepsEnteredCallWithoutInventingCompletion(t *testing.T){
	trace:=newRunnerNativeTrace();id,ok:=trace.Begin("SecCodeCopySigningInformation",42,3)
	if !ok||id==0{t.Fatal("trace begin")}
	rows,lost,pending:=trace.Snapshot()
	if lost||pending!=1||len(rows)!=1||rows[0].Phase!="entered"||rows[0].ReturnValue!=nil||rows[0].ValuePresent!=nil{t.Fatal("ASSERTION:trace-pending-not-complete")}
	status:=int32(-67050);if !trace.End(id,&status,false){t.Fatal("trace end")};status=0
	rows,lost,pending=trace.Snapshot()
	if lost||pending!=0||len(rows)!=2||rows[1].ReturnValue==nil||*rows[1].ReturnValue!=-67050||rows[1].ValuePresent==nil||*rows[1].ValuePresent||rows[1].ElapsedMS<rows[0].ElapsedMS{t.Fatal("ASSERTION:trace-exact-native-result")}
	raw,e:=json.Marshal(rows);if e!=nil{t.Fatal(e)};var actual []map[string]json.RawMessage;if json.Unmarshal(raw,&actual)!=nil||string(actual[0]["returnValue"])!="null"||string(actual[1]["valuePresent"])!="false"{t.Fatal("ASSERTION:trace-typed-json")}
	if trace.End(id,&status,true){t.Fatal("ASSERTION:trace-duplicate-completion")};_,lost,_=trace.Snapshot();if !lost{t.Fatal("trace loss not latched")}
}

func TestRunnerNativeTraceOverflowCannotResumeAfterDrain(t *testing.T){
	trace:=newRunnerNativeTrace();status:=int32(0)
	for i:=0;i<256;i++{id,ok:=trace.Begin("native-call",42,0);if !ok||!trace.End(id,&status,true){t.Fatal("trace nominal bound")}}
	if _,ok:=trace.Begin("overflow",42,0);ok{t.Fatal("ASSERTION:trace-overflow")}
	rows,lost,pending:=trace.Snapshot();if !lost||len(rows)!=512||pending!=0{t.Fatal("trace lost snapshot")}
	if _,ok:=trace.Begin("after-snapshot",42,0);ok{t.Fatal("ASSERTION:trace-retired")}
}
