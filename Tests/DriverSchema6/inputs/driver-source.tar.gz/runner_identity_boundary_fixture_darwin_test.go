package integration

import (
 "context"
 "fmt"
 "os"
 "strings"
 "testing"
)

func runnerFakeIdentityOps(spec runnerIdentitySpec)(runnerIdentityOps,*runnerBoundProcess){
 path,pin,owned,_:=runnerIdentityPolicy(spec)
 if path==""{path="/System/Library/Fixture/Executable"}
 identity:=runnerBSDValue{PID:int64(spec.PID),Parent:int64(spec.Parent),Effective:uint32(os.Getuid()),Real:uint32(os.Getuid()),Saved:uint32(os.Getuid()),Seconds:100,Microseconds:1}
 fact:=&runnerBoundProcess{Label:spec.Label,Bundle:spec.Role,Path:path,Identity:identity,Owned:owned}
 fact.Code.Binding=runnerIndependentCodeFact{PID:spec.PID,Identifier:spec.Role,Path:path,BSD:identity,Bound:true}
 if strings.HasPrefix(spec.Role,"com.apple."){fact.Code.Binding.Kernel.Flags=0x04000000}
 ops:=runnerIdentityOps{
  Bind:func(_ context.Context,_ *runnerNativeTrace,pid int,role,pathArg,pinArg string)(runnerNativeBindingObservation,error){
   if pid!=spec.PID||role!=spec.Role||pinArg!=pin||owned&&pathArg!=path{return runnerNativeBindingObservation{},fmt.Errorf("actual identity routing mismatch")};return fact.Code,nil
  },
  BSD:func(_ context.Context,_ *runnerNativeTrace,pid int)(runnerBSDReceipt,error){
   value:=fact.Code.Binding.BSD
   if spec.ParentIdentity!=nil&&pid==spec.Parent{value=*spec.ParentIdentity}
   return runnerFakeBSD(value,spec.Role,"before"),nil
  },
  Arguments:func(int)([]string,string,error){
   args:=[]string{path}
   if spec.Label=="authorization-requester"{args=append(args,"-e",`do shell script "/usr/bin/true" with administrator privileges`)}
   return args,"/private/tmp/sliccy-runner.ABCDEFGH/tmp",nil
  },
  Resolve:func(path string)(string,error){return path,nil},
  Root:func(string)(string,error){return "/private/tmp/sliccy-runner.ABCDEFGH",nil},
  Chrome:func(_ []string,_ string,label,origin string)(string,error){if label!=spec.Label||origin!=spec.Origin{return "",fmt.Errorf("profile routing")};return "/private/tmp/sliccy-runner.ABCDEFGH",nil},
 }
 return ops,fact
}

func TestRunnerIdentityBoundaryRoutesFixedRolesAndBracketsParent(t *testing.T){
 parent:=runnerBSDValue{PID:70,Parent:69,Effective:uint32(os.Getuid()),Real:uint32(os.Getuid()),Saved:uint32(os.Getuid()),Seconds:10,Microseconds:1}
 roles:=map[string]string{"app":"ai.sliccy.mac","allowed":"ai.sliccy.proof-helper","cli":"ai.sliccy.slicc","chrome-a-1":"com.google.Chrome","chrome-a-2":"com.google.Chrome","chrome-b-1":"com.google.Chrome","chrome-b-2":"com.google.Chrome","authorization-requester":"com.apple.osascript","authorization":"com.apple.SecurityAgent","window-manager":"com.apple.WindowManager","dock":"com.apple.dock","finder":"com.apple.finder","window-server":"com.apple.WindowServer"}
 for label,role:=range roles{t.Run(label,func(t *testing.T){
  spec:=runnerIdentitySpec{PID:42,Parent:70,Label:label,Role:role,App:"/fixture/Sliccy.app/Contents/MacOS/Sliccy",Origin:"http://127.0.0.1:1234",ParentIdentity:&parent}
  ops,_:=runnerFakeIdentityOps(spec)
  result,err:=observeRunnerIdentityWith(context.Background(),newRunnerNativeTrace(),spec,ops)
  if err!=nil||result.Label!=label||result.Bundle!=role||!result.Code.Binding.Bound{t.Fatalf("ASSERTION:identity-fixed-role-routing %s %v",label,err)}
 })}
}

func TestRunnerIdentityBoundaryRefusesLostOwnershipAndIncompleteBinding(t *testing.T){
 parent:=runnerBSDValue{PID:70,Parent:69,Effective:uint32(os.Getuid()),Real:uint32(os.Getuid()),Saved:uint32(os.Getuid()),Seconds:10,Microseconds:1}
 base:=runnerIdentitySpec{PID:42,Parent:70,Label:"allowed",Role:"ai.sliccy.proof-helper",App:"/fixture/Sliccy.app/Contents/MacOS/Sliccy",ParentIdentity:&parent}
 for _,name:=range []string{"parent-before","parent-after","child-after","child-parent","child-uid","child-real","child-saved","code-refused","wrong-pid","wrong-role","wrong-path","argv","cancelled","missing-parent","role-label"}{t.Run(name,func(t *testing.T){
  spec:=base;ops,fact:=runnerFakeIdentityOps(spec);calls:=0;bsd:=ops.BSD
  switch name{
  case "parent-before","parent-after","child-after":
   ops.BSD=func(ctx context.Context,trace *runnerNativeTrace,pid int)(runnerBSDReceipt,error){r,e:=bsd(ctx,trace,pid);calls++;if name=="parent-before"&&calls==1||name=="child-after"&&calls==2||name=="parent-after"&&calls==3{copy:=*r.Selected;copy.Seconds++;r.Selected=&copy};return r,e}
  case "child-parent":fact.Code.Binding.BSD.Parent++
  case "child-uid":fact.Code.Binding.BSD.Effective++
  case "child-real":fact.Code.Binding.BSD.Real++
  case "child-saved":fact.Code.Binding.BSD.Saved++
  case "code-refused":fact.Code.Binding.Bound=false
  case "wrong-pid":fact.Code.Binding.PID++
  case "wrong-role":fact.Code.Binding.Identifier="ai.sliccy.mac"
  case "wrong-path":fact.Code.Binding.Path+="-replacement"
  case "argv":ops.Arguments=func(int)([]string,string,error){return []string{"/unrelated"},"tmp",nil}
  case "missing-parent":spec.ParentIdentity=nil
  case "role-label":spec.Role="ai.sliccy.mac"
  }
  ctx,cancel:=context.WithCancel(context.Background());defer cancel();if name=="cancelled"{cancel()}
  if _,err:=observeRunnerIdentityWith(ctx,newRunnerNativeTrace(),spec,ops);err==nil{t.Fatalf("ASSERTION:identity-refuse-%s",name)}
 })}
}
