package integration

import (
	"context"
	"fmt"
	"os"
	"testing"
)

func TestRunnerResidualDiscoveryCannotInferAbsenceOrSignalFromPaths(t *testing.T) {
	app := "/fixture/Sliccy.app/Contents/MacOS/Sliccy"
	root := "/private/tmp/sliccy-runner.abcdefgh"
	for _, name := range []string{"clean", "residual", "unrelated", "other-uid", "identity-unavailable", "unrelated-identity-unavailable", "changed-incarnation", "argv-unavailable", "absent", "cancelled"} {
		t.Run(name, func(t *testing.T) {
			reads, argsReads, listCalls := 0, 0, 0
			ops := runnerRootDiscoveryOps{
				List: func() ([]int, error) { listCalls++; return []int{42}, nil },
				BSD: func(int) runnerBSDRead {
					reads++
					value := runnerBSDValue{PID: 42, Parent: 70, Effective: uint32(os.Getuid()), Seconds: 20, Microseconds: 1}
					if name == "other-uid" {
						value.Effective++
					}
					if name == "changed-incarnation" && reads == 2 {
						value.Seconds++
					}
					if name == "identity-unavailable" || name == "unrelated-identity-unavailable" || name == "absent" {
						return runnerBSDRead{Status: 1, Expected: 648}
					}
					return runnerBSDRead{Count: 648, Expected: 648, Value: &value}
				},
				Path: func(int) (string, error) {
					if name == "unrelated" || name == "unrelated-identity-unavailable" {
						return "/Applications/Other.app/Contents/MacOS/Other", nil
					}
					return app, nil
				},
				Arguments: func(int) ([]string, string, error) {
					argsReads++
					if name == "argv-unavailable" {
						return nil, "", fmt.Errorf("fixture-argv-refusal")
					}
					tmp := "/unrelated/tmp"
					if name == "residual" {
						tmp = root + "/tmp"
					}
					return []string{app}, tmp, nil
				},
				Absent: func(int) bool { return name == "absent" },
			}
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			if name == "cancelled" {
				cancel()
			}
			found, err := runnerRootProcessesWith(ctx, map[string]bool{root: true}, app, ops)
			refused := runnerOneOf(name, "identity-unavailable changed-incarnation argv-unavailable cancelled")
			if (err != nil) != refused {
				t.Fatalf("ASSERTION:residual-discovery-%s %v", name, err)
			}
			if name == "residual" {
				if len(found) != 1 || found[0] != 42 {
					t.Fatal("ASSERTION:residual-discovery-presence")
				}
			} else if len(found) != 0 {
				t.Fatal("unexpected residual claim")
			}
			if runnerOneOf(name, "unrelated other-uid unrelated-identity-unavailable identity-unavailable absent cancelled") && argsReads != 0 {
				t.Fatal("ASSERTION:residual-unrelated-argv")
			}
			if name == "cancelled" && listCalls != 0 {
				t.Fatal("expired discovery still queried process list")
			}
		})
	}
	result := runnerCaseResult{AppPID: 42, DirectChildrenGone: true, RootsRemoved: true, AppReaped: true, OwnedWindowsGone: true, MetadataReaderSettled: true, ProtocolWorkersSettled: true, RootAssociatedError: "residual-identity"}
	if !runnerBlocksLaterCases(result) {
		t.Fatal("ASSERTION:residual-unconfirmed-blocks-cases")
	}
	result.RootAssociatedError = ""
	if runnerBlocksLaterCases(result) {
		t.Fatal("clean independently scoped absence blocked later cases")
	}
}
