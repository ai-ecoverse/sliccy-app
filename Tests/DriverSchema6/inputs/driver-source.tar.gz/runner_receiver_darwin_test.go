package integration

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/jpeg"
	"sync"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
)

type runnerReceiver struct {
	mu            sync.Mutex
	ceiling       screen.Limits
	limits        screen.Limits
	scope         string
	link          string
	session       *string
	binding       *screen.Binding
	stateSeq      uint64
	frameSeq      screen.Counter
	generation    uint64
	granted       bool
	everGranted   bool
	invalidatedAt time.Time
	stateAt       time.Time
	reset         bool
}

func runnerWireID(s string) bool {
	p, e := base64.RawURLEncoding.Strict().DecodeString(s)
	return e == nil && len(p) == 16 && base64.RawURLEncoding.EncodeToString(p) == s
}
func runnerLimitsBelow(value, ceiling screen.Limits) bool {
	return runnerLimitsValid(value) && runnerLimitsValid(ceiling) && value.HeaderBytes <= ceiling.HeaderBytes && value.FrameBytes <= ceiling.FrameBytes && value.LongEdge <= ceiling.LongEdge && value.Pixels <= ceiling.Pixels && value.DefaultFPS <= ceiling.DefaultFPS && value.MaxFPS <= ceiling.MaxFPS && value.BytesPerSecond <= ceiling.BytesPerSecond
}
func (r *runnerReceiver) apply(raw []byte) (screen.State, bool, error) {
	var value screen.State
	if runnerStrict(raw, &value, 65536) != nil {
		return value, false, fmt.Errorf("invalid screen-state")
	}
	var fields map[string]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil {
		return value, false, fmt.Errorf("invalid screen-state fields")
	}
	seq, e := runnerCounter(value.Seq)
	if e != nil || value.Kind != "screen-state" || value.V != 1 || value.Caps == nil {
		return value, false, fmt.Errorf("invalid screen-state envelope")
	}
	active := len(value.Caps) == 1 && value.Caps[0] == "screen"
	if len(value.Caps) > 0 && !active || active != (value.Reason == "active") {
		return value, false, fmt.Errorf("invalid effective capability")
	}
	keys := []string{"kind", "v", "stateSeq", "caps", "binding", "scope", "reason", "limits"}
	if !active {
		keys = []string{"kind", "v", "stateSeq", "caps", "link", "lastSession", "reason"}
	}
	if len(fields) != len(keys) {
		return value, false, fmt.Errorf("wrong screen-state shape")
	}
	for _, key := range keys {
		v, ok := fields[key]
		if !ok || key != "lastSession" && bytes.Equal(bytes.TrimSpace(v), []byte("null")) {
			return value, false, fmt.Errorf("missing screen-state field")
		}
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if seq <= r.stateSeq {
		return value, false, fmt.Errorf("replayed screen-state")
	}
	newLink := value.Link
	if active {
		if value.Binding == nil || !runnerBindingValid(*value.Binding) || value.Limits == nil || !runnerLimitsBelow(*value.Limits, r.ceiling) || value.Scope != r.scope || r.everGranted || r.reset {
			return value, false, fmt.Errorf("unexpected fixture grant")
		}
		newLink = value.Binding.Link
	} else {
		if !runnerWireID(newLink) {
			return value, false, fmt.Errorf("invalid disabled link")
		}
		if r.session == nil && value.LastSession != nil || r.session != nil && (value.LastSession == nil || *value.LastSession != *r.session) {
			return value, false, fmt.Errorf("disabled last-session mismatch")
		}
	}
	if r.link != "" && newLink != r.link {
		return value, false, fmt.Errorf("cross-link state substitution")
	}
	r.link = newLink
	r.stateSeq = seq
	r.generation++
	r.stateAt = time.Now()
	if active {
		b := *value.Binding
		s := b.Session
		r.binding = &b
		r.session = &s
		r.limits = *value.Limits
		r.granted = true
		r.everGranted = true
		r.frameSeq = "0"
		r.invalidatedAt = time.Time{}
	} else {
		r.binding = nil
		r.granted = false
		if r.everGranted {
			r.reset = true
			if r.invalidatedAt.IsZero() {
				r.invalidatedAt = r.stateAt
			}
		}
	}
	return value, active, nil
}
func (r *runnerReceiver) clear() time.Time {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.granted = false
	r.binding = nil
	r.generation++
	r.reset = true
	if r.invalidatedAt.IsZero() {
		r.invalidatedAt = time.Now()
	}
	return r.invalidatedAt
}
func (r *runnerReceiver) beginFrame(f screen.Frame, body []byte, maxWidth, maxHeight int) (uint64, bool, error) {
	r.mu.Lock()
	limits := r.limits
	r.mu.Unlock()

	n, e := runnerCounter(f.Seq)
	if e != nil || n == 0 || f.Type != "frame" || f.V != 1 || f.Codec != "jpeg" || !runnerBindingValid(f.Binding) || f.Launch != "" || f.Connection != "" || f.Width < 1 || f.Height < 1 || f.Width > maxWidth || f.Height > maxHeight || f.Width > limits.LongEdge || f.Height > limits.LongEdge || int64(f.Width)*int64(f.Height) > int64(limits.Pixels) || len(body) > limits.FrameBytes || !runnerJPEGMetadataFree(body) {
		return 0, false, fmt.Errorf("invalid frame envelope")
	}
	if _, e := runnerCounter(f.Captured); e != nil {
		return 0, false, e
	}
	cfg, e := jpeg.DecodeConfig(bytes.NewReader(body))
	if e != nil || cfg.Width != f.Width || cfg.Height != f.Height {
		return 0, false, fmt.Errorf("JPEG/header dimensions differ")
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	current := r.granted && r.binding != nil && f.Binding == *r.binding
	old, oldError := runnerCounter(r.frameSeq)
	if r.frameSeq == "" {
		old = 0
		oldError = nil
	}
	if oldError != nil {
		return 0, false, oldError
	}
	if r.session != nil && f.Binding.Session == *r.session {
		if n <= old {
			return 0, false, fmt.Errorf("replayed session frame")
		}
		r.frameSeq = f.Seq
	}
	if !current {
		return r.generation, false, nil
	}

	return r.generation, true, nil
}
func (r *runnerReceiver) commitFrame(generation uint64) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.granted && r.binding != nil && r.generation == generation
}
func checkRunnerJPEG(f screen.Frame, body []byte) (image.Image, error) {
	if len(body) > screen.FrameBytes || f.Width < 1 || f.Height < 1 || f.Width > 2560 || f.Height > 2560 || int64(f.Width)*int64(f.Height) > 4000000 {
		return nil, fmt.Errorf("capture image outside budget")
	}
	config, e := jpeg.DecodeConfig(bytes.NewReader(body))
	if e != nil || config.Width != f.Width || config.Height != f.Height {
		return nil, fmt.Errorf("capture JPEG dimensions differ")
	}
	img, e := jpeg.Decode(bytes.NewReader(body))
	if e != nil || img.Bounds() != (image.Rect(0, 0, f.Width, f.Height)) {
		return nil, fmt.Errorf("capture JPEG decoding failed")
	}
	return img, nil
}
func TestRunnerReceiverClearsBeforeInflightArrivalAndDuringDecode(t *testing.T) {
	binding := screen.Binding{Link: screen.ID(16), Session: screen.ID(16), Source: screen.ID(16), GrantEpoch: "1", SourceEpoch: "1", ProtectionEpoch: "1"}
	limits := screen.DefaultLimits()
	initial := screen.State{Kind: "screen-state", V: 1, Seq: "1", Caps: []string{}, Link: binding.Link, Reason: "awaiting-consent"}
	active := screen.State{Kind: "screen-state", V: 1, Seq: "2", Caps: []string{"screen"}, Binding: &binding, Scope: "window", Reason: "active", Limits: &limits}
	session := binding.Session
	stopped := screen.State{Kind: "screen-state", V: 1, Seq: "3", Caps: []string{}, Link: binding.Link, LastSession: &session, Reason: "stopped"}
	raw := func(value screen.State) []byte {
		v, e := json.Marshal(value)
		if e != nil {
			t.Fatal(e)
		}
		return v
	}
	img := image.NewRGBA(image.Rect(0, 0, 16, 16))
	draw.Draw(img, img.Bounds(), image.NewUniform(color.RGBA{128, 128, 128, 255}), image.Point{}, draw.Src)
	var encoded bytes.Buffer
	if e := jpeg.Encode(&encoded, img, &jpeg.Options{Quality: 65}); e != nil {
		t.Fatal(e)
	}
	frame := screen.Frame{Type: "frame", V: 1, Binding: binding, Seq: "1", Captured: "1", Width: 16, Height: 16, Codec: "jpeg"}
	newReceiver := func() *runnerReceiver {
		r := &runnerReceiver{ceiling: limits, scope: "window"}
		if _, on, e := r.apply(raw(initial)); e != nil || on {
			t.Fatal(e)
		}
		if _, on, e := r.apply(raw(active)); e != nil || !on {
			t.Fatal(e)
		}
		return r
	}
	r := newReceiver()
	generation, on, e := r.beginFrame(frame, encoded.Bytes(), 16, 16)
	if e != nil || !on || !r.commitFrame(generation) {
		t.Fatal("valid baseline refused", e)
	}
	if _, _, e := r.beginFrame(frame, encoded.Bytes(), 16, 16); e == nil {
		t.Fatal("replayed frame admitted")
	}
	frame.Seq = "2"
	generation, on, e = r.beginFrame(frame, encoded.Bytes(), 16, 16)
	if e != nil || !on {
		t.Fatal(e)
	}
	r.clear()
	if r.commitFrame(generation) {
		t.Fatal("decode completing after reset admitted")
	}
	frame.Seq = "3"
	if _, on, e := r.beginFrame(frame, encoded.Bytes(), 16, 16); e != nil || on {
		t.Fatal("inflight arrival after reset was admitted or mistaken for producer violation", e)
	}
	if _, _, e := r.apply(raw(stopped)); e != nil {
		t.Fatal(e)
	}
	if _, _, e := r.apply(raw(active)); e == nil {
		t.Fatal("replayed grant reopened view")
	}
	r = newReceiver()
	mismatch := frame
	mismatch.Binding.ProtectionEpoch = "2"
	if _, on, e := r.beginFrame(mismatch, encoded.Bytes(), 16, 16); e != nil || on {
		t.Fatal("epoch mismatch was not safely dropped", e)
	}
	if _, _, e := r.beginFrame(frame, encoded.Bytes(), 15, 16); e == nil {
		t.Fatal("OPENED size ceiling bypassed")
	}
	if _, e := checkRunnerJPEG(frame, encoded.Bytes()); e != nil {
		t.Fatal(e)
	}
	frame.Width = 17
	if _, e := checkRunnerJPEG(frame, encoded.Bytes()); e == nil {
		t.Fatal("JPEG header mismatch accepted")
	}
}
func TestRunnerReceiverRejectsMalformedGrantAndDisabledState(t *testing.T) {
	b := screen.Binding{Link: screen.ID(16), Session: screen.ID(16), Source: screen.ID(16), GrantEpoch: "1", SourceEpoch: "1", ProtectionEpoch: "1"}
	limits := screen.DefaultLimits()
	active := screen.State{Kind: "screen-state", V: 1, Seq: "1", Caps: []string{"screen"}, Binding: &b, Scope: "window", Reason: "active", Limits: &limits}
	good, e := json.Marshal(active)
	if e != nil {
		t.Fatal(e)
	}
	for _, bad := range [][]byte{
		bytes.Replace(good, []byte(`"caps":["screen"]`), []byte(`"caps":["screen","screen"]`), 1),
		bytes.Replace(good, []byte(`"reason":"active"`), []byte(`"reason":"stopped"`), 1),
		bytes.Replace(good, []byte(`"v":1`), []byte(`"v":1,"v":1`), 1),
		bytes.Replace(good, []byte(`"scope":"window"`), []byte(`"scope":"display"`), 1),
		append(append([]byte(nil), good...), []byte(" {}")...),
	} {
		r := &runnerReceiver{ceiling: limits, scope: "window"}
		if _, _, e := r.apply(bad); e == nil {
			t.Fatal("invalid active state accepted")
		}
	}
	r := &runnerReceiver{ceiling: limits, scope: "window"}
	if _, _, e := r.apply(good); e != nil {
		t.Fatal(e)
	}
	wrong := screen.ID(16)
	disabled := screen.State{Kind: "screen-state", V: 1, Seq: "2", Caps: []string{}, Link: b.Link, LastSession: &wrong, Reason: "stopped"}
	bad, _ := json.Marshal(disabled)
	if _, _, e := r.apply(bad); e == nil {
		t.Fatal("wrong stopped session accepted")
	}
	session := b.Session
	disabled.LastSession = &session
	disabled.Link = screen.ID(16)
	bad, _ = json.Marshal(disabled)
	if _, _, e := r.apply(bad); e == nil {
		t.Fatal("cross-link disabled state accepted")
	}
}
