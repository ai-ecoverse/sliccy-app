package integration

import (
	"encoding/binary"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"syscall"

	"golang.org/x/sys/unix"
)

func runnerFileSlices(raw []byte) ([]runnerFileSlice, error) {
	if len(raw) < 28 || len(raw) > 128*1024*1024 {
		return nil, fmt.Errorf("bounded executable bytes unavailable")
	}
	magic := binary.BigEndian.Uint32(raw[:4])
	fat := magic == 0xcafebabe || magic == 0xcafebabf || magic == 0xbebafeca || magic == 0xbfbafeca
	wide := magic == 0xcafebabf || magic == 0xbfbafeca
	var order binary.ByteOrder = binary.BigEndian
	if magic == 0xbebafeca || magic == 0xbfbafeca {
		order = binary.LittleEndian
	}
	count, stride, tableEnd := 1, 20, 0
	if wide {
		stride = 32
	}
	if fat {
		count = int(order.Uint32(raw[4:8]))
		if count < 1 || count > 8 {
			return nil, fmt.Errorf("slice count outside bound")
		}
		tableEnd = 8 + count*stride
		if tableEnd > len(raw) {
			return nil, fmt.Errorf("truncated universal table")
		}
	}
	var result []runnerFileSlice
	for i := 0; i < count; i++ {
		v := runnerFileSlice{Size: uint64(len(raw))}
		if fat {
			e := raw[8+i*stride : 8+(i+1)*stride]
			v.CPU, v.Subtype = int32(order.Uint32(e[:4])), int32(order.Uint32(e[4:8]))
			var alignment uint32
			if wide {
				v.Offset, v.Size = order.Uint64(e[8:16]), order.Uint64(e[16:24])
				alignment = order.Uint32(e[24:28])
				if order.Uint32(e[28:32]) != 0 {
					return nil, fmt.Errorf("universal reserved field nonzero")
				}
			} else {
				v.Offset, v.Size = uint64(order.Uint32(e[8:12])), uint64(order.Uint32(e[12:16]))
				alignment = order.Uint32(e[16:20])
			}
			if alignment > 30 || v.Offset%(uint64(1)<<alignment) != 0 || v.Offset < uint64(tableEnd) {
				return nil, fmt.Errorf("universal alignment/header overlap")
			}
		}
		if v.Offset > uint64(len(raw)) || v.Size < 28 || v.Size > uint64(len(raw))-v.Offset {
			return nil, fmt.Errorf("slice range outside file")
		}
		body := raw[v.Offset : v.Offset+v.Size]
		thinMagic := binary.BigEndian.Uint32(body[:4])
		var thinOrder binary.ByteOrder
		switch thinMagic {
		case 0xfeedface, 0xfeedfacf:
			thinOrder = binary.BigEndian
		case 0xcefaedfe, 0xcffaedfe:
			thinOrder = binary.LittleEndian
		default:
			return nil, fmt.Errorf("unrecognized executable slice magic")
		}
		if (thinMagic == 0xfeedfacf || thinMagic == 0xcffaedfe) && v.Size < 32 {
			return nil, fmt.Errorf("truncated 64-bit header")
		}
		cpu, sub := int32(thinOrder.Uint32(body[4:8])), int32(thinOrder.Uint32(body[8:12]))
		if fat && (v.CPU != cpu || v.Subtype != sub) {
			return nil, fmt.Errorf("universal/thin architecture disagreement")
		}
		v.CPU, v.Subtype = cpu, sub
		for _, old := range result {
			if old.CPU == v.CPU && old.Subtype == v.Subtype || old.Offset < v.Offset+v.Size && v.Offset < old.Offset+old.Size {
				return nil, fmt.Errorf("duplicate/overlapping executable slices")
			}
		}
		result = append(result, v)
	}
	return result, nil
}

func runnerSameFile(a, b os.FileInfo) bool {
	x, xok := a.Sys().(*syscall.Stat_t)
	y, yok := b.Sys().(*syscall.Stat_t)
	return xok && yok && a.Mode().IsRegular() && b.Mode().IsRegular() && x.Dev == y.Dev && x.Ino == y.Ino && x.Size == y.Size && x.Mtimespec == y.Mtimespec && x.Ctimespec == y.Ctimespec
}

func runnerOpenFileSnapshot(path string) (*runnerFileSnapshot, error) {
	canonical, e := filepath.EvalSymlinks(path)
	if e != nil || !filepath.IsAbs(path) || filepath.Clean(path) != path || canonical != path {
		return nil, fmt.Errorf("file pathname is not canonical")
	}
	fd, e := unix.Open(path, unix.O_RDONLY|unix.O_CLOEXEC|unix.O_NOFOLLOW, 0)
	if e != nil {
		return nil, e
	}
	file := os.NewFile(uintptr(fd), path)
	if file == nil {
		unix.Close(fd)
		return nil, fmt.Errorf("retained file unavailable")
	}
	retained := false
	defer func() {
		if !retained {
			file.Close()
		}
	}()
	first, e := file.Stat()
	if e != nil {
		return nil, e
	}
	byName, e := os.Lstat(path)
	if e != nil || !runnerSameFile(first, byName) || first.Size() < 28 || first.Size() > 128*1024*1024 {
		return nil, fmt.Errorf("retained file/path identity invalid")
	}
	raw, e := io.ReadAll(io.LimitReader(file, first.Size()+1))
	if e != nil || int64(len(raw)) != first.Size() {
		return nil, fmt.Errorf("retained file read changed size")
	}
	slices, e := runnerFileSlices(raw)
	if e != nil {
		return nil, e
	}
	st := first.Sys().(*syscall.Stat_t)
	meta := []string{strconv.FormatInt(int64(st.Dev), 10), strconv.FormatUint(st.Ino, 10), strconv.FormatInt(st.Size, 10), strconv.FormatUint(uint64(st.Mode), 10), strconv.FormatInt(st.Mtimespec.Sec, 10), strconv.FormatInt(st.Mtimespec.Nsec, 10), strconv.FormatInt(st.Ctimespec.Sec, 10), strconv.FormatInt(st.Ctimespec.Nsec, 10)}
	check := func() error {
		current, e := file.Stat()
		if e != nil {
			return e
		}
		name, e := os.Lstat(path)
		if e != nil || !runnerSameFile(first, current) || !runnerSameFile(first, name) {
			return fmt.Errorf("retained file/path changed across observation")
		}
		return nil
	}
	if e := check(); e != nil {
		return nil, e
	}
	retained = true
	return &runnerFileSnapshot{Path: path, Slices: slices, Metadata: meta, Recheck: check, Close: func() { file.Close() }}, nil
}
