package integration

import (
 "context"
 "bytes"
 "encoding/hex"
 "fmt"
 "os"
 "sort"
 "time"
)

type runnerControllerObserver struct {
 pool *runnerObservationPool[any]
 traces map[string]*runnerNativeTrace
 deadline time.Time
 sequence uint64
}

type runnerControllerNativeEvidence struct {
 Observations []runnerObservation[any] `json:"observations"`
 Phases map[string][]runnerNativePhase `json:"phases"`
 Lost map[string]bool `json:"diagnosticLoss"`
 Pending map[string]int `json:"pendingNativeCalls"`
 Settled bool `json:"settled"`
}

func newRunnerControllerObserver(ctx context.Context,deadline time.Time)*runnerControllerObserver{
 return &runnerControllerObserver{pool:newRunnerObservationPool[any](ctx,deadline),traces:map[string]*runnerNativeTrace{},deadline:deadline}
}

func(o *runnerControllerObserver)Submit(key string,query func(context.Context,*runnerNativeTrace)(any,error))error{
 if o.traces[key]!=nil{return fmt.Errorf("duplicate controller native observation")}
 trace:=newRunnerNativeTrace();o.traces[key]=trace
 deadline:=time.Now().Add(5*time.Second);if deadline.After(o.deadline){deadline=o.deadline}
 queryCtx,cancel:=context.WithDeadline(o.pool.ctx,deadline)
 err:=o.pool.Submit(key,func(_ context.Context)(any,error){defer cancel();if queryCtx.Err()!=nil{return nil,queryCtx.Err()};return query(queryCtx,trace)})
 if err!=nil{cancel()};return err
}

func(o *runnerControllerObserver)Wait(keys []string,maximum time.Duration)(map[string]runnerObservation[any],error){
 deadline:=time.Now().Add(maximum);if deadline.After(o.deadline){deadline=o.deadline}
 return o.pool.Wait(keys,deadline)
}

func(o *runnerControllerObserver)Call(operation string,query func(context.Context,*runnerNativeTrace)(any,error))(any,error){
 o.sequence++;key:=fmt.Sprintf("call:%d:%s",o.sequence,operation)
 deadline:=time.Now().Add(5*time.Second);if deadline.After(o.deadline){deadline=o.deadline}
 queryCtx,cancel:=context.WithDeadline(o.pool.ctx,deadline);defer cancel()
 if err:=o.Submit(key,func(_ context.Context,trace *runnerNativeTrace)(any,error){return query(queryCtx,trace)});err!=nil{return nil,err}
 values,err:=o.Wait([]string{key},time.Until(deadline))
 return values[key].Value,err
}

func(o *runnerControllerObserver)Identity(key string,spec runnerIdentitySpec)error{
 deadline:=time.Now().Add(5*time.Second);if deadline.After(o.deadline){deadline=o.deadline}
 queryCtx,cancel:=context.WithDeadline(o.pool.ctx,deadline)
 err:=o.Submit(key,func(_ context.Context,trace *runnerNativeTrace)(any,error){defer cancel();return observeRunnerIdentity(queryCtx,trace,spec)})
 if err!=nil{cancel()};return err
}

func(o *runnerControllerObserver)Finish()runnerControllerNativeEvidence{
 o.pool.Close()
 wait:=runnerWaitBudget(time.Now(),o.deadline,25*time.Millisecond)
 if wait>0{timer:=time.NewTimer(wait);select{case<-o.pool.done:case<-timer.C:};if !timer.Stop(){select{case<-timer.C:default:}}}
 result:=runnerControllerNativeEvidence{Observations:o.pool.Snapshot(),Phases:map[string][]runnerNativePhase{},Lost:map[string]bool{},Pending:map[string]int{},Settled:o.pool.Settled()}
 for key,trace:=range o.traces{rows,lost,pending:=trace.Snapshot();result.Phases[key]=rows;result.Lost[key]=lost;result.Pending[key]=pending;if lost||pending!=0{result.Settled=false}}
 return result
}

func runnerTracedQuery[T any](ctx context.Context,trace *runnerNativeTrace,operation string,query func()(T,error))(value T,err error){
 if ctx.Err()!=nil{return value,ctx.Err()}
 id,ok:=trace.Begin(operation,os.Getpid(),0);if !ok{return value,fmt.Errorf("native observation trace retired")}
 value,err=query()
 if !trace.End(id,nil,err==nil){return value,fmt.Errorf("native observation completion lost")}
 if ctx.Err()!=nil{return value,ctx.Err()}
 return value,err
}

func runnerClaimedSystemLabel(role string)(string,bool){
 label,ok:=map[string]string{"com.apple.WindowManager":"window-manager","com.apple.dock":"dock","com.apple.finder":"finder","com.apple.WindowServer":"window-server","com.apple.SecurityAgent":"authorization"}[role]
 return label,ok
}

func runnerBoundFactsEqual(a,b runnerProcessFact)bool{return runnerBoundSame(a,b)}

func runnerFixturePresence(selected string,processes map[int]runnerProcessFact,actual []independentWindow)error{
 expected:=map[string]independentRect{"allowed":{128,128,256,256},"app":{64,512,320,128}}
 if selected=="display-exclusion"||selected=="authorization-exclusion"{for _,page:=range fixedProofPageCatalog{expected["chrome-"+page.Profile]=page.Rect}}
 labels:=map[string]int{}
 for pid,fact:=range processes{
  if _,needed:=expected[fact.Label];!needed{continue}
  if labels[fact.Label]!=0||!fact.Code.Binding.Bound||fact.Identity.PID!=int64(pid){return fmt.Errorf("missing/duplicate independent fixture role")}
  labels[fact.Label]=pid
 }
 ids:=map[uint32]bool{}
 for label,rect:=range expected{
  pid:=labels[label];if pid<1{return fmt.Errorf("required fixture owner absent")}
  window,err:=runnerUniqueWindow(actual,pid,rect)
  if err!=nil||window.Layer!=0||!window.OnScreen||ids[window.ID]{return fmt.Errorf("fixed fixture window presence missing/ambiguous")}
  if label!="app"{count:=0;for _,candidate:=range actual{if candidate.PID==pid{count++}};if count!=1{return fmt.Errorf("fixture owner has extra on-screen window")}}
  ids[window.ID]=true
 }
 return nil
}

func runnerProcessKeys(processes map[int]runnerProcessFact)[]int{
 pids:=make([]int,0,len(processes));for pid:=range processes{pids=append(pids,pid)};sort.Ints(pids);return pids
}

func matchRunnerOwnedRecord(row runnerCaptureRow,fact runnerProcessFact)error{
 if !fact.Owned||row.Stage!="owned-process-recorded"{return fmt.Errorf("original record is not owned")}
 want:=map[string]string{"allowed":"surface","cli":"cli","authorization-requester":"authorization-requester","chrome-a-1":"chrome","chrome-a-2":"chrome","chrome-b-1":"chrome","chrome-b-2":"chrome"}[fact.Label]
 role,e:=runnerText(row.Fields,"role");if e!=nil||want==""||role!=want{return fmt.Errorf("original record role mismatch")}
 b:=fact.Identity
 for key,want:=range map[string]int64{"pid":b.PID,"parent":b.Parent,"uid":int64(b.Effective),"startMicroseconds":int64(b.Microseconds)}{n,e:=runnerInt(row.Fields,key,0,4294967295);if e!=nil||n!=want{return fmt.Errorf("original owned identity field mismatch")}}
 seconds,e:=runnerReceiptCounter(row.Fields["startSeconds"]);if e!=nil||seconds!=b.Seconds{return fmt.Errorf("original owned start mismatch")}
 hash,e:=runnerText(row.Fields,"cdHash");if e!=nil||hash!=hex.EncodeToString(fact.Code.Binding.Kernel.Hash[:]){return fmt.Errorf("original owned image mismatch")}
 return nil
}

func runnerWindowSetsEqual(a,b []independentWindow)bool{
 if len(a)!=len(b){return false}
 byID:=map[uint32]independentWindow{}
 for _,window:=range a{if window.ID==0||byID[window.ID].ID!=0{return false};byID[window.ID]=window}
 seen:=map[uint32]bool{}
 for _,window:=range b{old,ok:=byID[window.ID];if !ok||seen[window.ID]||old.PID!=window.PID||old.Rect!=window.Rect||old.Layer!=window.Layer||old.OnScreen!=window.OnScreen{return false};seen[window.ID]=true}
 return true
}

func runnerValidateCaseReceipts(book runnerReceiptBook,processes map[int]runnerProcessFact)error{
 codeSites:=map[string]bool{}
 bsdPIDs:=map[string]bool{}
 for _,entry:=range book.Entries{
  receipt:=entry.Receipt
  if receipt.BSD!=nil{
   b:=receipt.BSD;fact,known:=processes[int(b.PID)]
   if !known||!b.Accepted||!runnerBSDEqual(b.Selected,&fact.Identity){return fmt.Errorf("BSD receipt not bound to independent retained incarnation")}
   bsdPIDs[fmt.Sprintf("%d:%s",b.PID,b.Phase)]=true
  }
  if receipt.Code==nil{continue}
  code:=receipt.Code
  if !code.Passed{return fmt.Errorf("refused code binding in complete case")}
  codeSites[fmt.Sprintf("%s:%d:%s",code.Role,code.PID,code.Site)]=true
  if code.Site=="preflight"{continue}
  fact,known:=processes[int(code.PID)];if !known||code.Role!=fact.Bundle{return fmt.Errorf("code receipt owner not independently bound")}
  if runnerOneOf(code.Site,"child-initial child-signal"){
   values,err:=runnerRawArray(code.Compared["incarnation"],5);if err!=nil{return err}
   b:=fact.Identity
   for index,want:=range []int64{b.PID,b.Parent,int64(b.Effective)}{n,err:=runnerRawInteger(values[index],0,4294967295);if err!=nil||n!=want{return fmt.Errorf("CLI boundary incarnation mismatch")}}
   sec,err:=runnerReceiptCounter(values[3]);if err!=nil||sec!=b.Seconds{return fmt.Errorf("CLI boundary start mismatch")};micros,err:=runnerReceiptCounter(values[4]);if err!=nil||micros!=b.Microseconds{return fmt.Errorf("CLI boundary start fraction mismatch")}
  }
  if code.Selected!=nil{
   observed:=fact.Code.Binding.Selected
   selected:=code.Selected
   if selected.CPU!=observed.CPU||selected.Subtype!=observed.Subtype||selected.Offset!=observed.Offset||selected.Size!=observed.Size||selected.Type!=observed.Type||!bytes.Equal(selected.Hash,observed.Hash)||!bytes.Equal(selected.Full,observed.Full){return fmt.Errorf("app selected slice differs from independent selection")}
   before,e:=runnerReceiptIncarnation(code.Compared["incarnationBefore"],code.PID);if e!=nil||!runnerBSDEqual(before,&fact.Identity){return fmt.Errorf("app code incarnation differs from retained observer")}
  }
 }
 cliSeen:=false
 for pid,fact:=range processes{
  if fact.Label=="cli"{
   cliSeen=true
   for _,site:=range []string{"initial-live","signal","child-initial","child-signal"}{if !codeSites[fmt.Sprintf("%s:%d:%s",fact.Bundle,pid,site)]{return fmt.Errorf("mandatory CLI receipt stream missing")}}
  }
  if _,e:=runnerUnionKind(fact.Union());e==nil{
   site:="live"
   if fact.Label=="app"{site="self"}else if !fact.Owned{site="system-owner";for _,phase:=range []string{"before","after"}{if !bsdPIDs[fmt.Sprintf("%d:%s",pid,phase)]{return fmt.Errorf("system BSD receipt coverage missing")}}}
   if !codeSites[fmt.Sprintf("%s:%d:%s",fact.Bundle,pid,site)]{return fmt.Errorf("inventory code receipt coverage missing")}
   if fact.Owned&&fact.Label!="app"{for _,site:=range []string{"initial-live","live-copy","signal"}{if !codeSites[fmt.Sprintf("%s:%d:%s",fact.Bundle,pid,site)]{return fmt.Errorf("owned inventory code receipt coverage missing")}}}
  }
 }
 if !cliSeen{return fmt.Errorf("independent CLI missing")}
 return nil
}

func runnerCollectIdentityResults(observer *runnerControllerObserver,identityJobs map[int]string,processes map[int]runnerProcessFact,roots map[string]bool,register func(runnerProcessFact)error)error{
  keys:=[]string{};for _,key:=range identityJobs{keys=append(keys,key)}
  _,firstErr:=observer.Wait(keys,5*time.Second)
  for pid,key:=range identityJobs{
   observation,settled:=observer.pool.Result(key)
   if !settled||observation.Error!=nil{if firstErr==nil{firstErr=fmt.Errorf("native identity missing/refused")};continue}
   fact,ok:=observation.Value.(runnerProcessFact);if !ok||!fact.Code.Binding.Bound||fact.Identity.PID!=int64(pid){if firstErr==nil{firstErr=fmt.Errorf("native identity result shape")};continue}
   if old,exists:=processes[pid];exists&&!runnerBoundFactsEqual(old,fact){if firstErr==nil{firstErr=fmt.Errorf("owner identity changed")};continue}
   processes[pid]=fact;if fact.Root!=""{roots[fact.Root]=true}
   if fact.Owned&&register(fact)!=nil&&firstErr==nil{firstErr=fmt.Errorf("owned process exec/exit monitor unavailable")}
  }
  return firstErr
 }

