package integration

import (
	"bytes"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/jpeg"
	"math"
	"testing"
)

var fixtureQuadrants = [4][3]int{{220, 48, 48}, {48, 180, 80}, {48, 96, 220}, {224, 192, 48}}

func mapFixtureWindow(window, source independentRect, width, height int) (independentRect, error) {
	for _, v := range []float64{window.X, window.Y, window.Width, window.Height, source.X, source.Y, source.Width, source.Height} {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return independentRect{}, fmt.Errorf("nonfinite source geometry")
		}
	}
	if width < 1 || height < 1 || width > 2560 || height > 2560 || width > 4_000_000/height || source.Width <= 0 || source.Height <= 0 || window.Width != 256 || window.Height != 256 || window.X < source.X || window.Y < source.Y || window.X+window.Width > source.X+source.Width || window.Y+window.Height > source.Y+source.Height {
		return independentRect{}, fmt.Errorf("source/allowed window geometry mismatch")
	}
	sx, sy := float64(width)/source.Width, float64(height)/source.Height
	r := independentRect{X: (window.X - source.X) * sx, Y: (window.Y - source.Y) * sy, Width: window.Width * sx, Height: window.Height * sy}
	if r.Width < 128 || r.Height < 128 {
		return independentRect{}, fmt.Errorf("allowed pattern has insufficient decoded resolution")
	}
	return r, nil
}
func inspectFixturePattern(img image.Image, r independentRect) (bool, error) {
	if img == nil {
		return false, fmt.Errorf("missing decoded frame")
	}
	for _, v := range []float64{r.X, r.Y, r.Width, r.Height} {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false, fmt.Errorf("nonfinite mapped geometry")
		}
	}
	bounds := img.Bounds()
	if r.X < 0 || r.Y < 0 || r.Width < 128 || r.Height < 128 || r.X+r.Width > float64(bounds.Dx()) || r.Y+r.Height > float64(bounds.Dy()) {
		return false, fmt.Errorf("mapped window outside decoded frame")
	}
	if bounds.Min != (image.Point{}) || bounds.Dx() < 1 || bounds.Dy() < 1 || bounds.Dx() > 2560 || bounds.Dy() > 2560 || bounds.Dx() > 4_000_000/bounds.Dy() {
		return false, fmt.Errorf("decoded dimensions outside bounds")
	}
	sample := func(x, y, w, h int, want [3]int, tolerance int) error {
		rect := image.Rect(int(math.Ceil(r.X+float64(x)*r.Width/256)), int(math.Ceil(r.Y+float64(y)*r.Height/256)), int(math.Floor(r.X+float64(x+w)*r.Width/256)), int(math.Floor(r.Y+float64(y+h)*r.Height/256)))
		if rect.Empty() || !rect.In(bounds) {
			return fmt.Errorf("sample outside independent geometry")
		}
		for py := rect.Min.Y; py < rect.Max.Y; py++ {
			for px := rect.Min.X; px < rect.Max.X; px++ {
				red, green, blue, alpha := img.At(px, py).RGBA()
				if alpha != 65535 {
					return fmt.Errorf("nonopaque allowed sample")
				}
				for i, v := range []uint32{red, green, blue} {
					delta := int(v>>8) - want[i]
					if delta < -tolerance || delta > tolerance {
						return fmt.Errorf("allowed synthetic pixels differ")
					}
				}
			}
		}
		return nil
	}
	for i, p := range [][2]int{{40, 40}, {168, 40}, {40, 168}, {168, 168}} {
		if e := sample(p[0], p[1], 48, 48, fixtureQuadrants[i], 8); e != nil {
			return false, e
		}
	}
	if sample(12, 12, 8, 8, [3]int{0, 0, 0}, 16) == nil {
		return false, nil
	}
	if sample(12, 12, 8, 8, [3]int{255, 255, 255}, 16) == nil {
		return true, nil
	}
	return false, fmt.Errorf("pulse is neither fixed black nor white")
}
func TestRunnerPatternRecognizesSyntheticJPEGInteriors(t *testing.T) {
	makeFrame := func(white bool) image.Image {
		img := image.NewRGBA(image.Rect(0, 0, 1024, 768))
		draw.Draw(img, img.Bounds(), image.NewUniform(color.RGBA{A: 255}), image.Point{}, draw.Src)
		for i, c := range fixtureQuadrants {
			x, y := 128+(i%2)*128, 128+(i/2)*128
			draw.Draw(img, image.Rect(x, y, x+128, y+128), image.NewUniform(color.RGBA{uint8(c[0]), uint8(c[1]), uint8(c[2]), 255}), image.Point{}, draw.Src)
		}
		v := uint8(0)
		if white {
			v = 255
		}
		draw.Draw(img, image.Rect(136, 136, 152, 152), image.NewUniform(color.RGBA{v, v, v, 255}), image.Point{}, draw.Src)
		var data bytes.Buffer
		if e := jpeg.Encode(&data, img, &jpeg.Options{Quality: 65}); e != nil {
			t.Fatal(e)
		}
		decoded, e := jpeg.Decode(bytes.NewReader(data.Bytes()))
		if e != nil {
			t.Fatal(e)
		}
		return decoded
	}
	r, e := mapFixtureWindow(independentRect{128, 128, 256, 256}, independentRect{0, 0, 1024, 768}, 1024, 768)
	if e != nil {
		t.Fatal(e)
	}
	for _, white := range []bool{false, true} {
		phase, e := inspectFixturePattern(makeFrame(white), r)
		if e != nil || phase != white {
			t.Fatal("fixed JPEG quadrants/pulse not recognized", e)
		}
	}
	for _, bad := range []independentRect{{math.NaN(), 128, 256, 256}, {128, 128, -256, 256}, {-128, 128, 256, 256}, {900, 128, 256, 256}} {
		if _, e := inspectFixturePattern(makeFrame(false), bad); e == nil {
			t.Fatal("invalid mapped geometry passed")
		}
	}
	if _, e := inspectFixturePattern(makeFrame(false), independentRect{384, 128, 256, 256}); e == nil {
		t.Fatal("wrong source geometry passed")
	}
	if _, e := mapFixtureWindow(independentRect{128, 128, 256, 256}, independentRect{0, 0, 1024, 768}, 256, 192); e == nil {
		t.Fatal("insufficient source resolution passed")
	}
	if _, e := mapFixtureWindow(independentRect{128, 128, 256, 256}, independentRect{0, 0, 1024, 768}, 4096, 3072); e == nil {
		t.Fatal("oversize decoded frame passed")
	}
}
