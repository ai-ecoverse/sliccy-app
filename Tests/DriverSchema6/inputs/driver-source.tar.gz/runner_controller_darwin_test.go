package integration

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"image"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
	"golang.org/x/sys/unix"
)

type runnerImageBudget struct {
	mu    sync.Mutex
	bytes int
}

func (b *runnerImageBudget) reserve(n int) bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	if n < 0 || n > screen.FrameBytes || b.bytes+n > 64<<20 {
		return false
	}
	b.bytes += n
	return true
}

type runnerCaseResult struct {
 normalizationIndex *runnerCaseEvidenceIndex
 NormalizationFailed bool `json:"normalizationFailed"`
 ProtectedCoverage *runnerProtectedCoverage `json:"protectedCoverage"`
 PageDeliveries []runnerPageDelivery `json:"pageDeliveries"`
 DiagnosticSnapshots []runnerDiagnosticSnapshot `json:"diagnosticSnapshots"`
 DiagnosticCadenceSkipped int `json:"diagnosticCadenceSkipped"`
 ClockAnchor runnerClockExchange `json:"clockAnchor"`
	Diagnostics map[string]runnerDiagnosticPath `json:"diagnostics"`
 AppOutput runnerCaseOutput `json:"appOutput"`
 SpawnedChildren map[int]runnerSpawnObservation `json:"spawnedChildren"`
 Schema                      int                            `json:"schema"`
	Case                        string                         `json:"case"`
	Result                      string                         `json:"result"`
	EvidenceUnavailable         bool                           `json:"evidenceUnavailable"`
	UnavailableReasons          []string                       `json:"unavailableReasons"`
	CaptureDurationBound        *runnerCaptureDurationEvidence `json:"captureDurationBound"`
	Limitations                 []string                       `json:"limitations,omitempty"`
	Failures                    []string                       `json:"failures"`
	AppPID                      int                            `json:"appPID"`
	ExitCode                    int                            `json:"exitCode"`
	CaseElapsedMS               float64                        `json:"caseElapsedMs"`
	Processes                   map[int]runnerProcessFact      `json:"processes"`
	Windows                     []independentWindow            `json:"independentWindows"`
	Wire                        []runnerWireFact               `json:"wire"`
	Clock                       runnerClockBound               `json:"clock"`
	ReceiverLatencyUpperMS      float64                        `json:"receiverLatencyUpperMs"`
	RemoteStopLatencyMS         float64                        `json:"remoteStopLatencyMs"`
	DirectChildrenGone          bool                           `json:"directChildrenGone"`
	AppReaped                   bool                           `json:"appReaped"`
	RootObservations []runnerRootObservation `json:"rootObservations"`
 RootsRemoved                bool                           `json:"rootsRemoved"`
	MonitorLoss                 bool                           `json:"monitorLoss"`
	AppClaimsOnlyReaps          []int                          `json:"appClaimsOnlySecondaryReaps"`
	RootAssociatedError         string                         `json:"rootAssociatedError,omitempty"`
	RootAssociatedProcesses     []int                          `json:"rootAssociatedProcesses"`
	OwnedWindowsGone            bool                           `json:"ownedWindowsGone"`
	TitleDiagnostics            map[uint32]runnerTitleFact     `json:"titleDiagnostics"`
	ObserverAccess              runnerObserverAccess           `json:"observerAccess"`
	ReceiverInvalidatedAt       time.Time                      `json:"receiverInvalidatedAt"`
	LoopDeadlineExceeded        bool                           `json:"loopDeadlineExceeded"`
	ProtocolPageCreated         bool                           `json:"protocolPageCreated"`
	ProtocolSettlementAttempted bool                           `json:"protocolSettlementAttempted"`
	ProtocolWorkersSettled      bool                           `json:"protocolWorkersSettled"`
	MetadataReaderSettled       bool                           `json:"metadataReaderSettled"`
	NativeObservationSettled    bool                           `json:"nativeObservationSettled"`
	NativeEvidence              runnerControllerNativeEvidence `json:"nativeEvidence"`
	Coverage                    map[string]string              `json:"coverage"`
}
type runnerIncoming struct {
	row runnerCaptureRow
	at  time.Time
}
type runnerReadResult struct {
	raw    []byte
	err    error
	runErr error
 exit runnerProcessExit
}
type runnerWatchEvent struct {
	pid   int
	event proofExecEvent
}
type runnerWatch struct {
	fact   runnerProcessFact
	stop   func()
	exited bool
}
type runnerMarkerGate struct {
	Surfaces, Started, BaselinePixels, Stop, Reset bool
	SurfacesSent, BaselineSent, ResetSent          bool
}

func (g *runnerMarkerGate) next() string {
	if g.Surfaces && !g.SurfacesSent {
		g.SurfacesSent = true
		return "runner-surfaces-observed"
	}
	if g.SurfacesSent && g.Started && g.BaselinePixels && !g.BaselineSent {
		g.BaselineSent = true
		return "runner-baseline"
	}
	if g.BaselineSent && g.Stop && g.Reset && !g.ResetSent {
		g.ResetSent = true
		return "runner-receiver-reset"
	}
	return ""
}
func runnerWriteNew(path string, data []byte) error {
	file, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	_, e = file.Write(data)
	closed := file.Close()
	if e != nil {
		return e
	}
	return closed
}
func runnerSaveJSON(path string, value any) error {
	raw, e := json.MarshalIndent(value, "", "  ")
	if e != nil {
		return e
	}
	return runnerWriteNew(path, append(raw, '\n'))
}
func runnerArtifactHashes(app, manifest string) (map[string]string, error) {
	contents := filepath.Dir(filepath.Dir(app))
	if filepath.Base(app) != "Sliccy" || filepath.Base(filepath.Dir(app)) != "MacOS" || filepath.Base(contents) != "Contents" || !strings.HasSuffix(filepath.Dir(contents), ".app") {
		return nil, fmt.Errorf("fixed app executable layout required")
	}
	pins := map[string]string{
		app:                                   "6b9c1845c5d1e1561a9b1a45c92ece2bb8efa77a2355eb61d808686a740d6a3d",
		filepath.Join(contents, "Info.plist"): "ebdc8c6b44f6f1ee08345fe9ed15b8d099221220ae3056cb955ea6b2accbb5b2",
		filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/MacOS/ScreenProofSurface"): "85ef7c16e6542d94b26051ba1e04e6df12da7317923726943e4ff292c75a1e89",
		filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/Info.plist"):               "14f7874c0fe98de803e48c3945067f11e66d7ef2054a94798b70f4a723c4aa29",
		filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/CodeResources"): "26ac87e435876410294563f19a3a0872668910af8c6640c7a03b8c61fb3f5188",
		filepath.Join(contents, "Resources/slicc"):                                                  "0055c051f48364dbf6d3744c637a06353305a392d06edbedd96bd6764adb5a73",
		manifest: runnerManifestSHA256,
		filepath.Join(contents, "_CodeSignature/CodeResources"):                                         "fe58cab087321a86bc2f9795ea1a1a28a82d70d5f4a1508488b92fdb335b215c",
		filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/_CodeSignature/CodeResources"): "6686de10a28a2fe11b36cbb86dcbacc827cfc4ea116b4dabf1845e5aee629e9b",
	}
	for path, want := range pins {
		info, e := os.Lstat(path)
		if e != nil || !info.Mode().IsRegular() || info.Size() > 134217728 {
			return nil, fmt.Errorf("immutable regular artifact missing")
		}
		raw, e := os.ReadFile(path)
		if e != nil {
			return nil, e
		}
		sum := sha256.Sum256(raw)
		if hex.EncodeToString(sum[:]) != want {
			return nil, fmt.Errorf("immutable fixture hash mismatch")
		}
	}
	return pins, nil
}
func runnerRequireEvidenceRoot(path string) error {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return fmt.Errorf("private absolute evidence root required")
	}
	info, e := os.Lstat(path)
	if e != nil || !info.IsDir() || info.Mode()&os.ModeSymlink != 0 || info.Mode().Perm()&0077 != 0 {
		return fmt.Errorf("private evidence root unavailable")
	}
	var st unix.Stat_t
	if unix.Lstat(path, &st) != nil || st.Uid != uint32(os.Getuid()) {
		return fmt.Errorf("evidence root UID mismatch")
	}
	return nil
}
func readRunnerRows(stdout io.Reader, cmd *exec.Cmd, selected string, incoming chan<- runnerIncoming, finished chan<- runnerReadResult, abort func(), diagnostics ...*runnerDiagnostics) {
 var d *runnerDiagnostics;if len(diagnostics)>0 {d=diagnostics[0]}
 readRunnerRowsWithWait(stdout,func()(error,runnerProcessExit){err:=cmd.Wait();return err,runnerCaptureProcessExit(cmd.ProcessState)},selected,incoming,finished,abort,d)
}
func readRunnerRowsWithWait(stdout io.Reader, wait func()(error,runnerProcessExit), selected string, incoming chan<- runnerIncoming, finished chan<- runnerReadResult, abort func(), d *runnerDiagnostics) {
	var abortOnce sync.Once
	reject := func() {
		abortOnce.Do(func() {
			if abort != nil {
				abort()
			}
		})
	}
	var raw []byte
	var problem error
	scanner := bufio.NewScanner(stdout)
	scanner.Buffer(make([]byte, 4096), 4096)
	last := 0.0
	terminal := false
	count := 0
	for scanner.Scan() {
		line := append([]byte(nil), scanner.Bytes()...)
		count++
		if len(raw)+len(line)+1 > 1048576 || count > 16384 {
			problem = fmt.Errorf("metadata admission bound exceeded");d.Record("metadata.queue",problem)
			reject()
			break
		}
		raw = append(raw, line...)
		raw = append(raw, '\n')
		row, e := decodeRunnerCaptureRow(line)
		if e != nil || row.Case != selected || row.Elapsed < last || terminal {
 if e!=nil {d.Record("metadata.decoder",e)} else {d.Record("metadata.envelope",fmt.Errorf("metadata envelope row=%d caseMatch=%t monotonic=%t afterTerminal=%t",count,row.Case==selected,row.Elapsed>=last,terminal))}
			problem = fmt.Errorf("invalid or incomplete case metadata")
			reject()
			continue
		}
		last = row.Elapsed
		if row.Stage == "terminal" {
			terminal = true
		}
		select {
		case incoming <- runnerIncoming{row, time.Now()}:
		default:
			problem = fmt.Errorf("metadata queue overflow");d.Record("metadata.queue",problem)
			reject()
		}
	}
	if scanner.Err() != nil {
 d.Record("metadata.pipe",scanner.Err())
		problem = fmt.Errorf("metadata pipe error")
		reject()
	}
	if !terminal {
		problem = fmt.Errorf("terminal metadata missing");d.Record("metadata.terminal",problem)
		reject()
	}
	d.Record("metadata.problem",problem)
 runErr,exit := wait()
 d.Record("metadata.wait",runErr)
	finished <- runnerReadResult{raw:raw,err:problem,runErr:runErr,exit:exit}
	close(incoming)
}
func runRunnerCaptureCase(t *testing.T, suite context.Context, selected, app, manifest, root string, budget *runnerImageBudget, evidenceBudget *runnerNormalizationBudget,driverDigest string) (result runnerCaseResult) {
	t.Helper()
	caseBegan := time.Now()
	ctx, cancel := context.WithDeadline(suite, caseBegan.Add(runnerCaseExecutionBudget))
	defer cancel()
	result = runnerCaseResult{Schema: 1, Case: selected, Result: "FAIL", Processes: map[int]runnerProcessFact{}, Coverage: map[string]string{"System Settings": "UNTESTED", "TCC-specific prompt": "UNTESTED", "password-specific surface": "UNTESTED"}}
	dir := filepath.Join(root, selected)
	if os.Mkdir(dir, 0700) != nil {
		result.NormalizationFailed=true
        result.Failures = append(result.Failures, "private fresh case directory unavailable")
		return result
	}
 evidence,writeErr:=newRunnerCaseEvidenceWriter(dir,selected,runnerManifestSHA256,driverDigest,evidenceBudget)
 if writeErr!=nil{result.Result="FAIL";result.NormalizationFailed=true;result.Failures=append(result.Failures,"private normalization stream unavailable");return result}
 defer func(){
  runnerApplyAuthorizationPurpose(&result)
  index,e:=evidence.Commit(result)
  if e!=nil||time.Since(caseBegan)>runnerCaseAbsoluteBudget{result.Result="FAIL";result.NormalizationFailed=true;result.Failures=append(result.Failures,"private normalization evidence incomplete or absolute deadline exceeded");index.Result="FAIL";index.EvidenceComplete=false;index.Failures=append([]string(nil),result.Failures...);index.BlockLaterCases=true}
  result.normalizationIndex=&index
  if e=runnerSaveNormalizedIndex(filepath.Join(dir,"driver-observations.json"),index,evidenceBudget);e!=nil{result.Result="FAIL";result.NormalizationFailed=true;result.Failures=append(result.Failures,"private evidence index write failed");index.Result="FAIL";index.EvidenceComplete=false;index.Failures=append([]string(nil),result.Failures...);index.BlockLaterCases=true}
 }()

	diagnostics:=newRunnerDiagnostics(caseBegan)
 var output runnerCaseOutput
 stdoutTail,stderrTail:=&runnerOutputTail{},&runnerOutputTail{}
 defer func(){
 output.StdoutTail,output.StdoutBytes=stdoutTail.Snapshot(diagnostics.SecretSnapshot())
 output.StderrTail,output.StderrBytes=stderrTail.Snapshot(diagnostics.SecretSnapshot())
 result.AppOutput=output
 result.Diagnostics=diagnostics.Snapshot()
 }()
 var snapshotJournal *runnerSnapshotJournal
 var snapshotObserver *runnerControllerObserver
 fail := func(reason string) {
 if snapshotJournal!=nil&&snapshotObserver!=nil {snapshotJournal.submit(snapshotObserver,"refusal",time.Now())}
 diagnostics.Record("controller.refusal",fmt.Errorf("%s",reason))
		if len(result.Failures) < 32 {
			result.Failures = append(result.Failures, reason)
		}
	}
	if _, e := runnerArtifactHashes(app, manifest); e != nil {
		fail("immutable fixture binding failed")
		return result
	}

	observer := newRunnerControllerObserver(suite, caseBegan.Add(runnerCaseAbsoluteBudget))
 snapshotJournal=newRunnerSnapshotJournal(caseBegan);snapshotObserver=observer
 observer.evidence=evidence;observer.snapshots=snapshotJournal
 snapshotJournal.submit(observer,"cadence",time.Now())
	defer func() {
		snapshotObserver=nil
  result.NativeEvidence = observer.Finish()
  result.DiagnosticSnapshots,result.DiagnosticCadenceSkipped=snapshotJournal.freeze()
		result.NativeObservationSettled = result.NativeEvidence.Settled && !result.MonitorLoss
		if !result.NativeObservationSettled {
			result.Result = "FAIL"
			fail("native observation incomplete/unsettled; later cases prohibited")
		}
		result.CaseElapsedMS = float64(time.Since(caseBegan)) / float64(time.Millisecond)
		if result.CaseElapsedMS > float64(runnerCaseAbsoluteBudget/time.Millisecond) {
			result.Result = "FAIL"
			fail("case including native settlement exceeded absolute bound")
		}
	}()
	display := selected == "display-exclusion" || selected == "authorization-exclusion"
	type initialFacility struct {
		Windows []independentWindow
		Source  independentRect
		Access  runnerObserverAccess
		Parent  runnerBSDValue
	}
	initialValue, e := observer.Call("initial-facilities", func(queryCtx context.Context, trace *runnerNativeTrace) (any, error) {
		value := initialFacility{Source: independentRect{128, 128, 256, 256}}
		value.Access = readRunnerObserverAccess()
		var err error
		value.Windows, err = runnerTracedQuery(queryCtx, trace, "CGWindowListCopyWindowInfo-initial", func() ([]independentWindow, error) { return readRunnerWindows(true) })
		if err != nil {
			return value, err
		}
		if display {
			value.Source, err = runnerTracedQuery(queryCtx, trace, "CGDisplayBounds-main", readRunnerMainDisplay)
			if err != nil {
				return value, err
			}
		}
		parent, err := runnerObserveBSDContext(queryCtx, trace, os.Getpid())
		if err != nil || parent.Selected == nil {
			return value, fmt.Errorf("observer parent incarnation unavailable")
		}
		value.Parent = *parent.Selected
		return value, nil
	})
	if e != nil {
		runnerMarkUnavailable(&result, "initial-facility")
		fail("independent initial facility unavailable")
		return result
	}
	initial, ok := initialValue.(initialFacility)
	if !ok {
		fail("initial facility result type invalid")
		return result
	}
	result.ObserverAccess = initial.Access
	source := initial.Source
	initialIDs := map[uint32]bool{}
	for _, window := range initial.Windows {
		initialIDs[window.ID] = true
	}
	queryWindows := func(operation string) ([]independentWindow, error) {
		value, err := observer.Call(operation, func(queryCtx context.Context, trace *runnerNativeTrace) (any, error) {
			return runnerTracedQuery(queryCtx, trace, operation, func() ([]independentWindow, error) { return readRunnerWindows(true) })
		})
		if err != nil {
			return nil, err
		}
		windows, ok := value.([]independentWindow)
		if !ok {
			return nil, fmt.Errorf("window result type invalid")
		}
		return windows, nil
	}
	var configMu sync.Mutex
	var claims []runnerWindowClaim
	configured := false
	var frameCount atomic.Uint32
	inspect := func(frame screen.Frame, img image.Image) (bool, error) {
		configMu.Lock()
		valid := configured
		windows := append([]runnerWindowClaim(nil), claims...)
		configMu.Unlock()
		if !valid {
			return false, fmt.Errorf("pixels arrived before independent source confirmation")
		}
		pulse, _, e := inspectRunnerCapturePixels(img, source, windows)
		return pulse, e
	}
	save := func(frame screen.Frame, body []byte) error {
		if !budget.reserve(len(body)) {
			return fmt.Errorf("suite image budget exceeded")
		}
		n := frameCount.Add(1)
		if n > 128 {
			return fmt.Errorf("case image count exceeded")
		}
		return runnerWriteNew(filepath.Join(dir, fmt.Sprintf("frame-%03d.jpeg", n)), body)
	}
	scope := "window"
	if display {
		scope = "display"
	}
	page := newRunnerCapturePageDiagnostics(t, scope, inspect, save,diagnostics)
 defer func(){result.PageDeliveries=page.Pages.deliverySnapshot()}()
	protocolLifecycle := ownRunnerCaseProtocol(&result, page, caseBegan.Add(runnerCaseAbsoluteBudget))
	defer protocolLifecycle.Finish()
	cmd := exec.Command(app, "--screen-runner-proof", "--case", selected)
	cmd.WaitDelay = time.Second
	cmd.Env = append(proofEnvironment(t), "GITHUB_ACTIONS=true", "GITHUB_REPOSITORY=ai-ecoverse/sliccy-app", "GITHUB_EVENT_NAME=workflow_dispatch", "GITHUB_REF=refs/heads/proof/runner-capture-v1", "SLICCY_RUNNER_ENVIRONMENT=github-hosted")
	input, e := cmd.StdinPipe()
	if e != nil {
		fail("fixed marker pipe unavailable")
		return result
	}
	defer input.Close()
	stdout, e := cmd.StdoutPipe()
	if e != nil {
		fail("metadata pipe unavailable")
		return result
	}
	stderr := &proofRows{}
	cmd.Stderr = io.MultiWriter(stderr,stderrTail)
	began := caseBegan
	if ctx.Err() != nil {
		runnerMarkUnavailable(&result, "setup-budget")
		fail("case setup exhausted execution budget; no launch")
		return result
	}
	if err:=cmd.Start(); err!=nil {
 diagnostics.Record("fixture.setup",err)
		fail("fixed signed app launch failed")
		return result
	}
	result.AppPID = cmd.Process.Pid
	incoming := make(chan runnerIncoming, 1024)
	finished := make(chan runnerReadResult, 1)
	go readRunnerRows(io.TeeReader(stdout,stdoutTail), cmd, selected, incoming, finished, func() { _ = input.Close(); page.fail("metadata observer loss"); page.stopLink() },diagnostics)
 var reader runnerReadResult
 readerDone := false
 defer func(){output.Exit=runnerSettledExit(reader,readerDone);if output.Exit.Observed {diagnostics.Record("app.exit",fmt.Errorf("exit code %d signal %d",output.Exit.Code,output.Exit.Signal))}}()
	watches := map[int]*runnerWatch{}
	watchEvents := make(chan runnerWatchEvent, 128)
	watchCtx, stopWatching := context.WithCancel(context.Background())
	var watchLoss atomic.Bool
	addWatch := func(fact runnerProcessFact) error {
		if old := watches[int(fact.Identity.PID)]; old != nil {
			if !runnerBoundFactsEqual(old.fact, fact) {
				return fmt.Errorf("watched incarnation changed")
			}
			return nil
		}
		events, stop, e := watchProofExec(int(fact.Identity.PID))
		if e != nil {
			return e
		}
		watches[int(fact.Identity.PID)] = &runnerWatch{fact: fact, stop: stop}
		go func(pid int) {
			for {
				select {
				case event := <-events:
					select {
					case watchEvents <- runnerWatchEvent{pid, event}:
					default:
						watchLoss.Store(true)
					}
					if event.Exit || event.Err != nil {
						return
					}
				case <-watchCtx.Done():
					return
				}
			}
		}(int(fact.Identity.PID))
		return nil
	}
	var stopWatchesOnce sync.Once
	stopWatches := func() {
		stopWatchesOnce.Do(func() {
			stopWatching()
			keys := []string{}
			for pid, watch := range watches {
				key := fmt.Sprintf("monitor-stop:%d", pid)
				keys = append(keys, key)
				if err := observer.Submit(key, func(queryCtx context.Context, trace *runnerNativeTrace) (any, error) {
					return runnerTracedQuery(queryCtx, trace, "owned-monitor-stop-settlement", func() (bool, error) { watch.stop(); return true, nil })
				}); err != nil {
					watchLoss.Store(true)
					result.MonitorLoss = true
				}
			}
			if len(keys) > 0 {
				if _, err := observer.Wait(keys, time.Until(caseBegan.Add(runnerCaseAbsoluteBudget))); err != nil {
					watchLoss.Store(true)
					result.MonitorLoss = true
				}
			}
		})
	}
	defer stopWatches()

	processGone := func(pid int, identity runnerBSDValue) bool {
		value, err := observer.Call("owned-process-gone", func(queryCtx context.Context, trace *runnerNativeTrace) (any, error) {
			return runnerTracedQuery(queryCtx, trace, "owned-incarnation-absence", func() (bool, error) { return runnerProcessGone(pid, identity), nil })
		})
		gone, ok := value.(bool)
		return err == nil && ok && gone
	}
	signalOwned := func(fact runnerProcessFact, signal unix.Signal) error {
		_, err := observer.Call("owned-signal", func(queryCtx context.Context, trace *runnerNativeTrace) (any, error) {
			return nil, runnerKillBoundOwned(queryCtx, trace, fact, signal)
		})
		return err
	}
	var settleSpawnedChildren func()
 defer func(){if settleSpawnedChildren!=nil {settleSpawnedChildren()}}()

	normalCleanup := false
	defer func() {
		if recover() != nil {
			result.Result = "FAIL"
			fail("driver observer panic; proof inconclusive")
		}
		if normalCleanup {
			return
		}
		result.Result = "FAIL"
		_ = input.Close()
		page.stopLink()
		waitReader := func(maximum time.Duration) {
			if readerDone {
				return
			}
			remaining := runnerWaitBudget(time.Now(), caseBegan.Add(runnerCaseAbsoluteBudget), maximum)
			if remaining <= 0 {
				return
			}
			timer := time.NewTimer(remaining)
			select {
			case reader = <-finished:
				readerDone = true
				result.AppReaped = true
			case <-timer.C:
			}
			if !timer.Stop() {
				select {
				case <-timer.C:
				default:
				}
			}
		}
		waitReader(2 * time.Second)
		if !readerDone {
			for pid, watch := range watches {
				if pid != cmd.Process.Pid && watch.fact.Label != "authorization" {
					_ = signalOwned(watch.fact, unix.SIGTERM)
				}
			}
			waitReader(time.Second)
		}
		if !readerDone {
			_ = cmd.Process.Kill()
			waitReader(time.Second)
		}
		if readerDone {
			_ = runnerWriteNew(filepath.Join(dir, "emergency-milestones.ndjson"), reader.raw)
		}
	}()

	appSpec := runnerIdentitySpec{PID: cmd.Process.Pid, Parent: os.Getpid(), Label: "app", Role: "ai.sliccy.mac", App: app, Origin: page.Origin, ParentIdentity: &initial.Parent}
	appValue, e := observer.Call("app-identity", func(queryCtx context.Context, trace *runnerNativeTrace) (any, error) {
		return observeRunnerIdentity(queryCtx, trace, appSpec)
	})
	appFact, appOK := appValue.(runnerProcessFact)
	if e != nil || !appOK || addWatch(appFact) != nil {
		fail("owned signed app observation unavailable")
	} else {
		result.Processes[cmd.Process.Pid] = appFact
	}
	if len(result.Failures) == 0 {
		if _, e := io.WriteString(input, page.Join+"\n"); e != nil {
			fail("synthetic join input failed")
		}
  anchor,clockErr:=runnerWriteClockAnchor(input)
  result.ClockAnchor=anchor
  if clockErr!=nil {diagnostics.Record("fixture.clock",clockErr);fail("early clock anchor delivery failed")}

	} else {
		_ = input.Close()
	}

	identityJobs := map[int]string{}
	requiredObserved := map[int]string{}
	identityLabels := map[int]string{cmd.Process.Pid: "app"}
	identityRoles := map[int]string{cmd.Process.Pid: "ai.sliccy.mac"}
	ownerClaims := []runnerUnionOwnerClaim{}
	unionClaims := []runnerUnionWindowClaim{}
	ownedClaims := map[int]runnerCaptureRow{}
 result.SpawnedChildren=map[int]runnerSpawnObservation{}
	rootPaths := map[string]bool{}
	book := runnerReceiptBook{}
	semantic := runnerCaseMetadataLedger{}
	submitIdentity := func(label, role string, pid int) error {
		if old := identityJobs[pid]; old != "" {
			if identityLabels[pid] != label || identityRoles[pid] != role {
				return fmt.Errorf("PID substituted for another identity role")
			}
			return nil
		}
		if pid == cmd.Process.Pid {
			if label != "app" || role != "ai.sliccy.mac" {
				return fmt.Errorf("app PID role substituted")
			}
			return nil
		}
		_, _, owned, err := runnerIdentityPolicy(runnerIdentitySpec{Label: label, Role: role, App: app})
		if err != nil {
			return err
		}
		if owned {
			requiredObserved[pid] = label
		}
		parent := cmd.Process.Pid
		parentIdentity := appFact.Identity
		spec := runnerIdentitySpec{PID: pid, Parent: parent, ParentIdentity: &parentIdentity, Label: label, Role: role, App: app, Origin: page.Origin}
		key := fmt.Sprintf("identity:%d", pid)
		if err := observer.Identity(key, spec); err != nil {
			return err
		}
		identityJobs[pid] = key
		identityLabels[pid] = label
		identityRoles[pid] = role
		return nil
	}
	collectIdentities := func() error {
		return runnerCollectIdentityResults(observer, identityJobs, result.Processes, rootPaths, addWatch)
	}

 settleSpawnedChildren=func(){
 for pid,spawned:=range result.SpawnedChildren {
 if spawned.Settlement!=nil {continue}
  if fact,ok:=result.Processes[pid];ok && runnerSpawnMatchesFact(spawned,fact) {spawned.IndependentlyBound=true}
  value,err:=observer.Call("spawned-incarnation-settlement",func(queryCtx context.Context,trace *runnerNativeTrace)(any,error){
   return runnerObserveSpawnSettlement(queryCtx,trace,spawned.Original,caseBegan,runnerObserveBSDContext,runnerPIDAbsent),nil
  })
  if err!=nil {diagnostics.Record("child.settlement",err);spawned.Settlement=&runnerSpawnSettlement{State:"unavailable",Error:runnerSanitizeDiagnostic(err.Error(),nil)}} else if settled,ok:=value.(runnerSpawnSettlement);ok {spawned.Settlement=&settled} else {diagnostics.Record("child.settlement",fmt.Errorf("settlement result type invalid"))}
  runnerStoreSpawnSettlement(result.SpawnedChildren,pid,spawned)
 }
 }

	refusals := []runnerRefusalClaim{}
 structuralRefusals := []runnerStructuralRefusal{}
	var counts runnerInventoryCounts
	launched := map[int]string{}
	reaped := map[int]string{}
	stages := map[string]runnerIncoming{}
	var timing []captureTimingRow
	var gate runnerMarkerGate
	var baselineSent time.Time
	var resetWire time.Time
	var remoteStopStarted bool
	var remoteStopSent time.Time
	type stopResult struct {
		err error
		at  time.Time
	}
	remoteStopDone := make(chan stopResult, 1)
	remoteStopReceived := false
	acceptRemoteStop := func(value stopResult) {
		remoteStopReceived = true
		if value.err != nil {
			fail("independent remote Stop did not complete")
		} else {
			result.RemoteStopLatencyMS = float64(value.at.Sub(remoteStopSent)) / float64(time.Millisecond)
			if result.RemoteStopLatencyMS > 1500 {
				fail("remote Stop exceeded original bound")
			}
		}
	}

	aborted := false
	var stopRow *runnerIncoming
	var terminal runnerIncoming
	var cleanupDeadline time.Time
	cleanupEscalated := false

 revalidateBeforeBaseline := func() error {
  until:=runnerBaselineDeadline(time.Now(),caseBegan.Add(runnerCaseAbsoluteBudget))
  keys:=[]string{}
  for _,pid:=range runnerProcessKeys(result.Processes) {
   old:=result.Processes[pid];key:=fmt.Sprintf("baseline-identity:%d",pid);keys=append(keys,key)
   if err:=observer.submitWithBudget(key,time.Until(until),func(queryCtx context.Context,trace *runnerNativeTrace)(any,error){return observeRunnerBaselineIdentity(queryCtx,trace,old)});err!=nil{return err}
  }
  values,err:=observer.Wait(keys,time.Until(until));if err!=nil{return err}
  for _,pid:=range runnerProcessKeys(result.Processes){value,ok:=values[fmt.Sprintf("baseline-identity:%d",pid)].Value.(runnerBaselineIdentityEvidence);if !ok||!value.Complete{return fmt.Errorf("baseline cheap identity incomplete")}}
  key:="baseline-windows"
  if err:=observer.submitWithBudget(key,time.Until(until),func(queryCtx context.Context,trace *runnerNativeTrace)(any,error){return runnerTracedQuery(queryCtx,trace,"CGWindowListCopyWindowInfo-before-baseline",func()([]independentWindow,error){return readRunnerWindows(true)})});err!=nil{return err}
  rows,err:=observer.Wait([]string{key},time.Until(until));if err!=nil{return err}
  actual,ok:=rows[key].Value.([]independentWindow)
  if !ok||!runnerWindowSetsEqual(result.Windows,actual){return fmt.Errorf("full CG window universe changed before baseline marker")}
  if time.Now().After(until){return fmt.Errorf("baseline total two-second budget exhausted")}
  return nil
 }

	sendMarker := func(marker string) {
		if marker == "runner-baseline" {
			if err := revalidateBeforeBaseline(); err != nil {
				fail("independent live/bounds baseline recheck unavailable")
				return
			}
		}
		if marker == "runner-baseline" {
			baselineSent = time.Now()
		}
		if _, e := io.WriteString(input, marker+"\n"); e != nil {
			fail("fixed driver marker delivery failed")
		}
	}
	handleWatch := func(event runnerWatchEvent) {
		watch := watches[event.pid]
		if watch == nil {
			fail("unknown kernel monitor event")
			return
		}
		if event.event.Err != nil || event.event.Exec {
			fail("owned process exec/monitor failure")
		}
		if event.event.Exit {
			watch.exited = true
			if gate.Started && !gate.Stop && terminal.row.Stage == "" && watch.fact.Label != "authorization" {
				fail("required owner exited before stop")
			}
		}
	}

	deadlineC := ctx.Done()
	ticker := time.NewTicker(10 * time.Millisecond)
	defer ticker.Stop()
	loopComplete := runRunnerControllerLoop(caseBegan.Add(runnerCaseAbsoluteBudget), func() bool { return !readerDone || incoming != nil }, func(hardDeadlineC <-chan time.Time) bool {
		if (len(result.Failures) > 0 || result.EvidenceUnavailable) && !aborted {
			aborted = true
			_ = input.Close()
			page.stopLink()
			cleanupDeadline = time.Now().Add(3 * time.Second)
		}
		if !cleanupEscalated && !cleanupDeadline.IsZero() && time.Now().After(cleanupDeadline) {
			cleanupEscalated = true
			for pid, watch := range watches {
				if pid != cmd.Process.Pid && watch.fact.Label != "authorization" && !processGone(pid, watch.fact.Identity) {
					_ = signalOwned(watch.fact, unix.SIGTERM)
				}
			}
			if watch := watches[cmd.Process.Pid]; watch != nil {
				_ = signalOwned(watch.fact, unix.SIGKILL)
			} else {
				_ = cmd.Process.Kill()
			}
		}
		select {
		case received, ok := <-incoming:
			if !ok {
				incoming = nil
				return true
			}
			row := received.row
 if row.Stage=="inventory-refusal" {snapshotJournal.submit(observer,"refusal",received.at)}
 if row.Stage=="surface-unavailable" {snapshotJournal.submit(observer,"final-refusal",received.at)}
			runnerObserveCaseAvailability(&result, row)
			if err := semantic.Add(row); err != nil {
				fail("case semantic metadata incomplete/duplicated")
			}
			if row.Elapsed > received.at.Sub(began).Seconds()*1000+1 {
				fail("app clock exceeds independent observation interval")
			}
			if row.Receipt != nil {
				if err := book.Add(*row.Receipt); err != nil {
					fail("incomplete/invalid receipt stream")
				}
			}
			if row.Timing != nil {
				timing = append(timing, *row.Timing)
			}
			repeated := row.Structural != nil || (row.DisplayDiagnostic != nil && runnerDiagnosticEnum(row.Stage,"display-observation display-observation-screen")) || row.Receipt != nil || runnerOneOf(row.Stage, "inventory-refusal inventory-owner inventory-window owned-process-recorded first-cause chrome-identity revoke-queued native-ack local-gate-invalidated stop-handler-entered authorization-observed") || row.Stage == "source-admitted" || row.Stage == "native-admitted" || strings.HasPrefix(row.Stage, "reverse-re") || row.Stage == "surface-process" || row.Stage == "surface-window" || row.Stage == "protected-selection-refused" || row.Stage == "surface-launcher-started" || row.Stage == "surface-child-reaped"
			if !repeated {
				if _, ok := stages[row.Stage]; ok {
					fail("duplicate mandatory case milestone")
				}
				stages[row.Stage] = received
			}
			text := func(key string) string { s, _ := runnerText(row.Fields, key); return s }
			integer := func(key string) int { n, _ := runnerInt(row.Fields, key, -2147483648, 4294967295); return int(n) }
			switch row.Stage {
			case "runner-preflight":
   case "clock-anchor":
    result.ClockAnchor.Received=received.at;result.ClockAnchor.EventMS=row.Event
    bound,err:=result.ClockAnchor.Bound()
    if err!=nil {fail("early causal clock unavailable")} else {result.Clock=bound}

			case "surface-launcher-started":
				pid := integer("pid")
				if _, ok := launched[pid]; ok {
					fail("duplicate owned launcher PID")
				}
				launched[pid] = text("label")
				if text("label") == "authorization-requester" {
					if err := submitIdentity("authorization-requester", "com.apple.osascript", pid); err != nil {
						fail("requester identity observation admission refused")
					}
				}

			case "owned-process-recorded":
				pid := integer("pid")
				if _, exists := ownedClaims[pid]; exists {
					fail("duplicate original owned process record")
				}
				ownedClaims[pid] = row
    spawned,spawnErr:=runnerRetainSpawnObservation(row,result.SpawnedChildren)
    if spawnErr!=nil {diagnostics.Record("child.spawn",spawnErr);fail("spawn identity record unavailable")} else {
     label,role:="",""
     switch spawned.Original.Role {case "surface":label,role="allowed","ai.sliccy.proof-helper";case "cli":label,role="cli","ai.sliccy.slicc";case "authorization-requester":label,role="authorization-requester","com.apple.osascript"}
     if label!="" {if err:=submitIdentity(label,role,pid);err!=nil {diagnostics.Record("child.spawn",err);fail("spawn identity observation admission refused")}}
    }
   case "inventory-owner":
				claim, err := runnerDecodeUnionOwner(row)
				if err != nil {
					fail("invalid union owner claim")
					break
				}
				ownerClaims = append(ownerClaims, claim)
				label := identityLabels[claim.PID]
				if label == "" {
					var known bool
					label, known = runnerClaimedSystemLabel(claim.Identifier)
					if !known {
						fail("unrecognized independent owner role")
						break
					}
				}
				if err := submitIdentity(label, claim.Identifier, claim.PID); err != nil {
					fail("independent owner observation admission refused")
				}
			case "inventory-window":
				claim, err := runnerDecodeUnionWindow(row)
				if err != nil {
					fail("invalid union window claim")
					break
				}
				unionClaims = append(unionClaims, claim)
			case "child-started", "surface-process":
				label, role := "cli", "ai.sliccy.slicc"
				if row.Stage == "surface-process" {
					label, role = text("label"), text("bundleIdentifier")
				}
				pid := integer("pid")
				if label == "allowed" {
					if _, exists := launched[pid]; exists {
						fail("duplicate allowed child")
					}
					launched[pid] = label
				}
				if label == "app" && pid != cmd.Process.Pid {
					fail("app owner substituted")
					break
				}
				if err := submitIdentity(label, role, pid); err != nil {
					fail("independent process observation admission refused")
				}
			case "surface-window":
				rect, _ := runnerGeometry(row.Fields["rect"])
				configMu.Lock()
				claims = append(claims, runnerWindowClaim{text("label"), integer("pid"), uint32(integer("windowID")), rect, int64(integer("layer")), text("profile")})
				configMu.Unlock()
			case "protected-structural-refused":
    structuralRefusals=append(structuralRefusals,*row.Structural)
   case "protected-selection-refused":
				predicate, _ := runnerBool(row.Fields, "predicateEvidence")
				claim := runnerRefusalClaim{Label: text("label"), PID: integer("pid"), Kind: text("type"), Predicate: predicate}
				if claim.Kind == "window" {
					id := uint32(integer("windowID"))
					claim.WindowID = &id
				}
				refusals = append(refusals, claim)

			case "surfaces-ready":
				var object map[string]json.RawMessage
				_ = json.Unmarshal(row.Fields["counts"], &object)
				n, _ := runnerInt(object, "processes", 1, 128)
				w, _ := runnerInt(object, "windows", 1, 128)
				counts = runnerInventoryCounts{int(n), int(w)}
				if err := collectIdentities(); err != nil {
					runnerMarkUnavailable(&result, "owner-observations")
					fail("complete independent owner observations unavailable")
					break
				}
				actual, err := queryWindows("CGWindowListCopyWindowInfo-surfaces")
				facts := map[int]runnerUnionOwnerFact{}
				for pid, fact := range result.Processes {
					facts[pid] = fact.Union()
					if fact.Root != "" {
						rootPaths[fact.Root] = true
					}
				}
				supplemental := map[uint32]independentWindow{}
				for _, claim := range unionClaims {
					if !claim.InCG {
						value, queryErr := observer.Call("CGWindowListCopyWindowInfo-fixed-ID", func(queryCtx context.Context, trace *runnerNativeTrace) (any, error) {
							return runnerTracedQuery(queryCtx, trace, "CGWindowListCopyWindowInfo-fixed-ID", func() (independentWindow, error) { return readRunnerWindowByID(true, claim.ID) })
						})
						window, ok := value.(independentWindow)
						if queryErr != nil || !ok {
							err = fmt.Errorf("SCK-only independent window metadata unavailable")
							break
						}
						supplemental[claim.ID] = window
					}
				}
				if err != nil || matchRunnerUnion(ownerClaims, unionClaims, facts, actual, supplemental, claims, counts) != nil || runnerFixturePresence(selected, result.Processes, actual) != nil {
					runnerMarkUnavailable(&result, "union-fixture")
					fail("independent full CG/SCK union or fixture presence unavailable")
					break
				}
				for pid, record := range ownedClaims {
					fact, known := result.Processes[pid]
					if !known || matchRunnerOwnedRecord(record, fact) != nil {
						fail("original owned process record does not match independent incarnation")
					}
				}
				for pid, fact := range result.Processes {
					if fact.Owned && fact.Label != "app" {
						if _, known := ownedClaims[pid]; !known {
							fail("original owned child record missing")
						}
					}
				}
				if selected == "authorization-exclusion" {
					for _, claim := range claims {
						if claim.Label == "authorization" && initialIDs[claim.ID] {
							fail("authorization window predates requester")
						}
					}
				}
				if display {
					page.Pages.mu.Lock()
					for _, spec := range fixedProofPageCatalog {
						if page.Pages.delivered[spec.Path] < 1 {
							fail("fixed browser page not delivered")
						}
					}
					page.Pages.mu.Unlock()
				}
				result.Windows = actual
				result.TitleDiagnostics = runnerTitleDiagnostics(actual)
				configMu.Lock()
				configured = true
				configMu.Unlock()
				gate.Surfaces = true
			case "source-validated":
				coverage,coverageError:=matchRunnerProtectedCoverage(claims,refusals,structuralRefusals,result.Processes,unionClaims,result.Windows)
    if coverageError != nil {
					fail("incomplete independently attributed protected builder coverage")
    } else {result.ProtectedCoverage=coverage}
				if integer("allowedWindowCount") != 1 || integer("protectedWindowCount") != len(claims)-1 {
					fail("validated source count differs from independent inventory")
				}
			case "capture-started":
				gate.Started = true
			case "baseline-confirmed":
				if !gate.BaselineSent {
					fail("baseline confirmed without independent pixels")
					break
				}
				bound, e := boundRunnerClock(baselineSent, received.at, row.Event)
				if e != nil {
					fail("causal marker clock unavailable")
				} else {
					result.Clock, e = intersectRunnerClocks(result.Clock,bound)
 if e!=nil {fail("baseline causal clock inconsistent")}
				}
				if selected == "reciprocal-revoke" && !remoteStopStarted {
					remoteStopStarted = true
					remoteStopSent = time.Now()
					gate.Stop = true
					go func() {
						stopCtx, cancel := context.WithDeadline(ctx, remoteStopSent.Add(1500*time.Millisecond))
						defer cancel()
						err := page.stop(stopCtx)
						remoteStopDone <- stopResult{err, time.Now()}
					}()
				}
			case "stop-requested":
				copy := received
				stopRow = &copy
				gate.Stop = true
			case "surface-unavailable":
			case "surface-child-reaped":
				pid, label := integer("pid"), text("label")
				if launched[pid] != label || reaped[pid] != "" {
					fail("unmatched/duplicate owned child reap")
				}
				reaped[pid] = label
			case "child-exit-reaped":
				pid := integer("pid")
				fact, ok := result.Processes[pid]
				if !ok || fact.Label != "cli" {
					fail("native reap PID differs from observed child")
				}
			case "terminal":
				terminal = received
			}
		case <-page.Wake:
			facts, problem := page.snapshot()
			if problem != "" {
 diagnostics.Record("protocol.worker",fmt.Errorf("%s",problem))
				fail("independent screen receiver rejected protocol/evidence")
			}
			black, white := false, false
			for _, fact := range facts {
				if fact.Kind == "frame" && fact.Admitted && fact.Pulse != nil {
					if *fact.Pulse {
						white = true
					} else {
						black = true
					}
				}
				invalidated := fact.Kind == "reset" || fact.Kind == "state" && fact.State != nil && len(fact.State.Caps) == 0 && fact.State.LastSession != nil
				if invalidated && resetWire.IsZero() {
					resetWire = fact.At
					gate.Reset = true
				}
			}
			gate.BaselinePixels = black && white
		case value := <-remoteStopDone:
			acceptRemoteStop(value)
		case event := <-watchEvents:
			handleWatch(event)
		case reader = <-finished:
			readerDone = true
			result.AppReaped = true
		case <-deadlineC:
			deadlineC = nil
			fail("fixed case execution deadline exceeded")
			if !aborted {
				aborted = true
				_ = input.Close()
				page.stopLink()
				cleanupDeadline = time.Now().Add(3 * time.Second)
			}
		case <-hardDeadlineC:
			return false
		case <-ticker.C:
 snapshotJournal.submit(observer,"cadence",time.Now())
  }
  for pid,key:=range identityJobs {
   if _,exists:=result.Processes[pid];exists {continue}
   observation,settled:=observer.pool.Result(key)
   if !settled {continue}
   spawned,known:=result.SpawnedChildren[pid]
   if observation.Error!=nil {if known {spawned.ObservationError=runnerSanitizeDiagnostic(observation.Error.Error(),nil);result.SpawnedChildren[pid]=spawned};diagnostics.Record("child.spawn",observation.Error);continue}
   fact,ok:=observation.Value.(runnerProcessFact)
   if !ok || !fact.Code.Binding.Bound {continue}
   if known && !runnerSpawnMatchesFact(spawned,fact) {diagnostics.Record("child.spawn",fmt.Errorf("spawn independent identity mismatch"));fail("spawn independent identity mismatch");continue}
   result.Processes[pid]=fact
   if known {spawned.IndependentlyBound=true;result.SpawnedChildren[pid]=spawned}
   if fact.Root!="" {rootPaths[fact.Root]=true}
   if fact.Owned {if err:=addWatch(fact);err!=nil {diagnostics.Record("child.spawn",err);fail("spawn monitor unavailable")}}
  }
		if !aborted && len(result.Failures) == 0 && !result.EvidenceUnavailable {
			for marker := gate.next(); marker != ""; marker = gate.next() {
				sendMarker(marker)
			}
		}
		return true
	})
	if !loopComplete {
		page.Receiver.clear()
		page.stopLink()
		_ = input.Close()
		_ = stdout.Close()
		if !readerDone {
			_ = cmd.Process.Kill()
		}
		markRunnerLoopDeadline(&result, readerDone)
		result.CaseElapsedMS = float64(time.Since(caseBegan)) / float64(time.Millisecond)
		result.Wire, _ = page.snapshot()
		normalCleanup = true
		return result
	}
	result.MetadataReaderSettled = readerDone

	if remoteStopStarted && !remoteStopReceived {
		remaining := time.Until(remoteStopSent.Add(1500 * time.Millisecond))
		if remaining <= 0 {
			fail("remote Stop completion deadline exhausted")
		} else {
			timer := time.NewTimer(remaining)
			select {
			case value := <-remoteStopDone:
				acceptRemoteStop(value)
			case <-timer.C:
				fail("remote Stop completion missing")
			}
			if !timer.Stop() {
				select {
				case <-timer.C:
				default:
				}
			}
		}
	}

	settleUntil := time.Now().Add(2 * time.Second)
	if hard := began.Add(runnerCaseAbsoluteBudget); settleUntil.After(hard) {
		settleUntil = hard
	}
	_ = closeRunnerCaseProtocol(&result, page, settleUntil)
 if err:=collectIdentities();err!=nil {diagnostics.Record("child.spawn",err)}
 settleSpawnedChildren()
	monitorDeadline := time.NewTimer(runnerWaitBudget(time.Now(), caseBegan.Add(runnerCaseAbsoluteBudget), 500*time.Millisecond))
	allExited := func() bool {
		for _, watch := range watches {
			if watch.fact.Label != "authorization" && !watch.exited {
				return false
			}
		}
		return true
	}
	for !allExited() {
		select {
		case event := <-watchEvents:
			handleWatch(event)
		case <-monitorDeadline.C:
			fail("owned process exit observation incomplete")
			goto monitorSettled
		}
	}
monitorSettled:
	if !monitorDeadline.Stop() {
		select {
		case <-monitorDeadline.C:
		default:
		}
	}
	stopWatches()
	for {
		select {
		case event := <-watchEvents:
			handleWatch(event)
		default:
			goto monitorDrained
		}
	}
monitorDrained:
	var finalProblem string
	result.Wire, finalProblem = page.snapshot()
	page.Receiver.mu.Lock()
	result.ReceiverInvalidatedAt = page.Receiver.invalidatedAt
	page.Receiver.mu.Unlock()
	for _, fact := range result.Wire {
		if fact.Kind == "frame" && fact.Admitted {
			if fact.AdmittedAt == nil || fact.AdmittedAt.Before(fact.At) || fact.DecodedAt == nil || fact.AdmittedAt.Before(*fact.DecodedAt) || !result.ReceiverInvalidatedAt.IsZero() && fact.AdmittedAt.After(result.ReceiverInvalidatedAt) {
				fail("receiver admitted pixels after reset or before decode")
			}
		}
	}
	if readerDone && reader.exit.Observed {
		result.ExitCode = reader.exit.Code
	} else {
		result.ExitCode = -1
	}
	if finalProblem != "" {
 diagnostics.Record("protocol.worker",fmt.Errorf("%s",finalProblem))
		fail("screen protocol worker failed before evidence closure")
	}
	diagnostics.Record("metadata.problem",reader.err)
 if reader.err != nil || stderr.overflow || (bytes.Contains(reader.raw, []byte(page.Join)) || bytes.Contains(stderr.data, []byte(page.Join))) {
		fail("metadata loss/overflow/secret disclosure")
	}
	if terminal.row.Stage == "" {
		fail("terminal case disposition missing")
	} else {
		outcome, _ := runnerText(terminal.row.Fields, "outcome")
		if outcome == "failed-to-demonstrate" {
			runnerMarkUnavailable(&result, "terminal-unavailable")
		}
		if outcome == "complete" {
			if err := semantic.CompleteChrome(display); err != nil {
				fail("mandatory Chrome identity phases missing")
			}
			if err := runnerValidateCaseReceipts(book, result.Processes); err != nil {
				fail("mandatory receipt coverage or independent binding correlation failed")
			}
			for _, stage := range strings.Fields("runner-preflight clock-anchor child-started lanes-authenticated heartbeat-ready synthetic-link-observed surfaces-ready surfaces-confirmed source-validated grant-requested native-granted capture-started baseline-confirmed receiver-reset-confirmed capture-stopped reverse-ledger-closed child-exit-reaped") {
				if stages[stage].row.Stage == "" {
					fail("required successful-case milestone missing")
				}
			}
			if validateCaptureTiming(timing) != nil {
				fail("actual stop/admission/reciprocal timing evidence failed")
			}
			bound, boundErr := runnerCaptureDurationBound(timing)
			if bound.Basis != "" {
				result.CaptureDurationBound = &bound
			}
			if boundErr != nil {
				fail("capture duration evidence missing or exceeds10seconds")
			}
			if matchRunnerWireAdmissions(timing, result.Wire) != nil {
				fail("wire/source/native frame correlation incomplete")
			}
			if stopRow == nil || resetWire.IsZero() {
				fail("independent wire invalidation missing")
			} else {
				upper, e := runnerWireStopLatency(selected, result.Clock, resetWire, stopRow.row.Event, remoteStopSent)
				if e != nil || upper > 1500*time.Millisecond {
					fail("independent wire invalidation exceeded causal 1500ms bound")
				} else {
					result.ReceiverLatencyUpperMS = float64(upper) / float64(time.Millisecond)
				}
			}
			if selected == "reciprocal-revoke" && (result.RemoteStopLatencyMS <= 0 || result.RemoteStopLatencyMS > 1500) {
				fail("reciprocal peer completion absent")
			}
			if !gate.SurfacesSent || !gate.BaselineSent || !gate.ResetSent {
				fail("independent required markers incomplete")
			}
			if reader.runErr != nil {
				fail("complete case returned nonzero")
			}
			_ = runnerFinalizeCasePass(&result)
		} else if outcome != "failed-to-demonstrate" {
			fail("signed fixture reported case failure")
		}
	}
	result.MonitorLoss = watchLoss.Load()
	if result.MonitorLoss {
		fail("kernel monitor delivery lost")
	}
	result.DirectChildrenGone = true
	for pid := range requiredObserved {
		if _, known := result.Processes[pid]; !known {
			result.DirectChildrenGone = false
		}
	}
	for pid, label := range launched {
		if reaped[pid] != label {
			result.DirectChildrenGone = false
		}
		if fact, ok := result.Processes[pid]; ok {
			if !processGone(pid, fact.Identity) {
				result.DirectChildrenGone = false
			}
		} else {
			result.DirectChildrenGone = false
			result.AppClaimsOnlyReaps = append(result.AppClaimsOnlyReaps, pid)
		}
	}
	for pid, fact := range result.Processes {
		if fact.Label == "cli" && !processGone(pid, fact.Identity) {
			result.DirectChildrenGone = false
		}
	}
	result.RootsRemoved = true
 for path:=range rootPaths {
  observation:=observeRunnerRootRemoval(path,caseBegan,os.Lstat)
  result.RootObservations=append(result.RootObservations,observation)
  if !observation.Absent {result.RootsRemoved=false}
 }
	postWindows, e := queryWindows("CGWindowListCopyWindowInfo-cleanup")
	result.OwnedWindowsGone = e == nil
	if result.OwnedWindowsGone {
		result.OwnedWindowsGone = runnerDirectOwnedWindowsGone(postWindows, result.Processes)
	}
	var rootScanError error
	scan, scanErr := observer.Call("root-associated-diagnostic", func(queryCtx context.Context, trace *runnerNativeTrace) (any, error) {
		return runnerTracedQuery(queryCtx, trace, "proc-list-owned-path-diagnostic", func() ([]int, error) { return runnerRootProcesses(queryCtx, rootPaths, app) })
	})
	rootScanError = scanErr
	if scanErr == nil {
		var ok bool
		result.RootAssociatedProcesses, ok = scan.([]int)
		if !ok {
			rootScanError = fmt.Errorf("residual diagnostic shape")
		}
	}
	if rootScanError != nil {
		result.RootAssociatedError = rootScanError.Error()
	}
	if !result.DirectChildrenGone || !result.RootsRemoved || !result.AppReaped || !result.OwnedWindowsGone || rootScanError != nil || len(result.RootAssociatedProcesses) > 0 {
		fail("bounded owned cleanup unconfirmed")
	}

	if _, e := runnerArtifactHashes(app, manifest); e != nil {
		fail("immutable fixture changed after case")
	}
	result.CaseElapsedMS = float64(time.Since(began)) / float64(time.Millisecond)
	if time.Since(began) > runnerCaseAbsoluteBudget {
		fail("case including cleanup exceeded150seconds")
	}
	if len(result.Failures) > 0 && result.Result == "PASS" {
		result.Result = "FAIL"
	}
	if result.Result == "PASS" {
		result.Coverage["selected owned window pixels"] = "PASS"
		if display {
			result.Coverage["hosting Chrome four independent profiles/all four owned windows"] = "PASS"
			result.Coverage["sliccy.app all independently visible windows"] = "PASS"
		}
		if selected == "authorization-exclusion" {
			result.Coverage["actually attributed authorization service/window"] = "PASS"
		}
		if selected == "active-stop" {
			result.Coverage["programmatic installed Stop button action"] = "PASS"
		}
		if selected == "hotkey-stop" {
			result.Coverage["fixed posted shortcut through actual Carbon handler"] = "PASS"
		}
		if selected == "reciprocal-revoke" {
			result.Coverage["remote Stop plus receive/enqueue/actual write/peer ACK"] = "PASS"
		}
	}
	if runnerWriteNew(filepath.Join(dir, "milestones.ndjson"), reader.raw) != nil || runnerWriteNew(filepath.Join(dir, "stderr.txt"), stderr.data) != nil {
		result.Result = "FAIL"
		fail("private row evidence write failed")
	}

	normalCleanup = true
	return result
}
func TestRunnerMarkerControllerCannotSubstituteSentFramesOrLocalClear(t *testing.T) {
	g := runnerMarkerGate{Started: true}
	if g.next() != "" {
		t.Fatal("capture-start alone permitted marker")
	}
	g.Surfaces = true
	if g.next() != "runner-surfaces-observed" {
		t.Fatal("verified surfaces marker missing")
	}
	if g.next() != "" {
		t.Fatal("sent-only frame treated as decoded baseline")
	}
	g.BaselinePixels = true
	if g.next() != "runner-baseline" {
		t.Fatal("actual decoded baseline did not permit marker")
	}
	g.Stop = true
	if g.next() != "" {
		t.Fatal("local viewer clear substituted for actual node invalidation")
	}
	g.Reset = true
	if g.next() != "runner-receiver-reset" || g.next() != "" {
		t.Fatal("real invalidation not acknowledged exactly once")
	}
}

func runnerWaitBudget(now, deadline time.Time, maximum time.Duration) time.Duration {
	remaining := deadline.Sub(now)
	if remaining <= 0 {
		return 0
	}
	if remaining < maximum {
		return remaining
	}
	return maximum
}
func TestRunnerCleanupWaitsDoNotRestartTheCaseDeadline(t *testing.T) {
	now := time.Unix(100, 0)
	if runnerWaitBudget(now, now.Add(20*time.Millisecond), time.Second) != 20*time.Millisecond || runnerWaitBudget(now, now.Add(time.Second), 20*time.Millisecond) != 20*time.Millisecond || runnerWaitBudget(now, now.Add(-time.Second), time.Second) != 0 {
		t.Fatal("cleanup extended the original deadline")
	}
}
