package integration

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"image"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
	"golang.org/x/sys/unix"
)

type runnerImageBudget struct {
	mu    sync.Mutex
	bytes int
}

func (b *runnerImageBudget) reserve(n int) bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	if n < 0 || n > screen.FrameBytes || b.bytes+n > 64<<20 {
		return false
	}
	b.bytes += n
	return true
}

type runnerCaseResult struct {
	Schema                  int                        `json:"schema"`
	Case                    string                     `json:"case"`
	Result                  string                     `json:"result"`
	Limitations             []string                   `json:"limitations,omitempty"`
	Failures                []string                   `json:"failures"`
	AppPID                  int                        `json:"appPID"`
	ExitCode                int                        `json:"exitCode"`
	CaseElapsedMS           float64                    `json:"caseElapsedMs"`
	Processes               map[int]runnerProcessFact  `json:"processes"`
	Windows                 []independentWindow        `json:"independentWindows"`
	Wire                    []runnerWireFact           `json:"wire"`
	Clock                   runnerClockBound           `json:"clock"`
	ReceiverLatencyUpperMS  float64                    `json:"receiverLatencyUpperMs"`
	RemoteStopLatencyMS     float64                    `json:"remoteStopLatencyMs"`
	DirectChildrenGone      bool                       `json:"directChildrenGone"`
	AppReaped               bool                       `json:"appReaped"`
	RootsRemoved            bool                       `json:"rootsRemoved"`
	MonitorLoss             bool                       `json:"monitorLoss"`
	AppClaimsOnlyReaps      []int                      `json:"appClaimsOnlySecondaryReaps"`
	RootAssociatedProcesses []int                      `json:"rootAssociatedProcesses"`
	OwnedWindowsGone        bool                       `json:"ownedWindowsGone"`
	TitleDiagnostics        map[uint32]runnerTitleFact `json:"titleDiagnostics"`
	ObserverAccess          runnerObserverAccess       `json:"observerAccess"`
	ReceiverInvalidatedAt   time.Time                  `json:"receiverInvalidatedAt"`
	LoopDeadlineExceeded    bool                       `json:"loopDeadlineExceeded"`
	MetadataReaderSettled   bool                       `json:"metadataReaderSettled"`
	Coverage                map[string]string          `json:"coverage"`
}
type runnerIncoming struct {
	row runnerCaptureRow
	at  time.Time
}
type runnerReadResult struct {
	raw    []byte
	err    error
	runErr error
}
type runnerWatchEvent struct {
	pid   int
	event proofExecEvent
}
type runnerWatch struct {
	fact   runnerProcessFact
	stop   func()
	exited bool
}
type runnerMarkerGate struct {
	Surfaces, Started, BaselinePixels, Stop, Reset bool
	SurfacesSent, BaselineSent, ResetSent          bool
}

func (g *runnerMarkerGate) next() string {
	if g.Surfaces && !g.SurfacesSent {
		g.SurfacesSent = true
		return "runner-surfaces-observed"
	}
	if g.SurfacesSent && g.Started && g.BaselinePixels && !g.BaselineSent {
		g.BaselineSent = true
		return "runner-baseline"
	}
	if g.BaselineSent && g.Stop && g.Reset && !g.ResetSent {
		g.ResetSent = true
		return "runner-receiver-reset"
	}
	return ""
}
func runnerWriteNew(path string, data []byte) error {
	file, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	_, e = file.Write(data)
	closed := file.Close()
	if e != nil {
		return e
	}
	return closed
}
func runnerSaveJSON(path string, value any) error {
	raw, e := json.MarshalIndent(value, "", "  ")
	if e != nil {
		return e
	}
	return runnerWriteNew(path, append(raw, '\n'))
}
func runnerArtifactHashes(app, manifest string) (map[string]string, error) {
	contents := filepath.Dir(filepath.Dir(app))
	if filepath.Base(app) != "Sliccy" || filepath.Base(filepath.Dir(app)) != "MacOS" || filepath.Base(contents) != "Contents" || !strings.HasSuffix(filepath.Dir(contents), ".app") {
		return nil, fmt.Errorf("fixed app executable layout required")
	}
	pins := map[string]string{
		app:                                   "008395610f729c8f819250992bdf8e833ed6dc53da069971b0d65ffc3448a5c0",
		filepath.Join(contents, "Info.plist"): "77dfc22d7e8f9baf316b9b46c84e28873693a2b29985b5c57a8e1b0157ad3cd7",
		filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/MacOS/ScreenProofSurface"): "baff7b8b21264018138c9f7e2e7f6b8052bdcaf6e10b8ffa06dde854ac2b20c9",
		filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/Info.plist"):               "11a51ca14176be56ce266330b5c15f8341301a5a9dab8f891765ac11b112e794",
		filepath.Join(contents, "Resources/slicc"):                                                  "0055c051f48364dbf6d3744c637a06353305a392d06edbedd96bd6764adb5a73",
		manifest: "815e3778b711bb0bff94d5bb5dbcc741acd1f4f6f202c0d5e5a76ce22e572842",
		filepath.Join(contents, "_CodeSignature/CodeResources"):                                         "6ede3fa929106f14e5d990d00130750887b84b95048d0013267ac371868425eb",
		filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/_CodeSignature/CodeResources"): "6686de10a28a2fe11b36cbb86dcbacc827cfc4ea116b4dabf1845e5aee629e9b",
	}
	for path, want := range pins {
		info, e := os.Lstat(path)
		if e != nil || !info.Mode().IsRegular() || info.Size() > 134217728 {
			return nil, fmt.Errorf("immutable regular artifact missing")
		}
		raw, e := os.ReadFile(path)
		if e != nil {
			return nil, e
		}
		sum := sha256.Sum256(raw)
		if hex.EncodeToString(sum[:]) != want {
			return nil, fmt.Errorf("immutable fixture hash mismatch")
		}
	}
	return pins, nil
}
func runnerRequireEvidenceRoot(path string) error {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return fmt.Errorf("private absolute evidence root required")
	}
	info, e := os.Lstat(path)
	if e != nil || !info.IsDir() || info.Mode()&os.ModeSymlink != 0 || info.Mode().Perm()&0077 != 0 {
		return fmt.Errorf("private evidence root unavailable")
	}
	var st unix.Stat_t
	if unix.Lstat(path, &st) != nil || st.Uid != uint32(os.Getuid()) {
		return fmt.Errorf("evidence root UID mismatch")
	}
	return nil
}
func readRunnerRows(stdout io.Reader, cmd *exec.Cmd, selected string, incoming chan<- runnerIncoming, finished chan<- runnerReadResult, abort func()) {
	var abortOnce sync.Once
	reject := func() {
		abortOnce.Do(func() {
			if abort != nil {
				abort()
			}
		})
	}
	var raw []byte
	var problem error
	scanner := bufio.NewScanner(stdout)
	scanner.Buffer(make([]byte, 4096), 4096)
	last := 0.0
	terminal := false
	count := 0
	for scanner.Scan() {
		line := append([]byte(nil), scanner.Bytes()...)
		count++
		if len(raw)+len(line)+1 > 1048576 || count > 16384 {
			problem = fmt.Errorf("metadata admission bound exceeded")
			reject()
			break
		}
		raw = append(raw, line...)
		raw = append(raw, '\n')
		row, e := decodeRunnerCaptureRow(line)
		if e != nil || row.Case != selected || row.Elapsed < last || terminal {
			problem = fmt.Errorf("invalid or incomplete case metadata")
			reject()
			continue
		}
		last = row.Elapsed
		if row.Stage == "terminal" {
			terminal = true
		}
		select {
		case incoming <- runnerIncoming{row, time.Now()}:
		default:
			problem = fmt.Errorf("metadata queue overflow")
			reject()
		}
	}
	if scanner.Err() != nil {
		problem = fmt.Errorf("metadata pipe error")
		reject()
	}
	if !terminal {
		problem = fmt.Errorf("terminal metadata missing")
		reject()
	}
	runErr := cmd.Wait()
	finished <- runnerReadResult{raw, problem, runErr}
	close(incoming)
}
func runRunnerCaptureCase(t *testing.T, suite context.Context, selected, app, manifest, root string, budget *runnerImageBudget) (result runnerCaseResult) {
	t.Helper()
	caseBegan := time.Now()
	result = runnerCaseResult{Schema: 1, Case: selected, Result: "FAIL", Processes: map[int]runnerProcessFact{}, Coverage: map[string]string{"System Settings": "UNTESTED", "TCC-specific prompt": "UNTESTED", "password-specific surface": "UNTESTED"}}
	dir := filepath.Join(root, selected)
	if os.Mkdir(dir, 0700) != nil {
		result.Failures = append(result.Failures, "private fresh case directory unavailable")
		return result
	}
	defer func() {
		runnerApplyAuthorizationPurpose(&result)
		if e := runnerSaveJSON(filepath.Join(dir, "driver-observations.json"), result); e != nil {
			result.Result = "FAIL"
			result.Failures = append(result.Failures, "private evidence write failed")
		}
	}()

	fail := func(reason string) {
		if len(result.Failures) < 32 {
			result.Failures = append(result.Failures, reason)
		}
	}
	if _, e := runnerArtifactHashes(app, manifest); e != nil {
		fail("immutable fixture binding failed")
		return result
	}
	result.ObserverAccess = readRunnerObserverAccess()
	initialWindows, e := readRunnerWindows(true)
	if e != nil {
		result.Result = "FAILED_TO_DEMONSTRATE"
		fail("independent initial window facility unavailable")
		return result
	}
	initialIDs := map[uint32]bool{}
	for _, window := range initialWindows {
		initialIDs[window.ID] = true
	}
	source := independentRect{128, 128, 256, 256}
	display := selected == "display-exclusion" || selected == "authorization-exclusion"
	if display {
		source, e = readRunnerMainDisplay()
		if e != nil {
			result.Result = "FAILED_TO_DEMONSTRATE"
			fail("independent main display facility unavailable")
			_ = runnerSaveJSON(filepath.Join(dir, "driver-observations.json"), result)
			return result
		}
	}
	var configMu sync.Mutex
	var claims []runnerWindowClaim
	configured := false
	var frameCount atomic.Uint32
	inspect := func(frame screen.Frame, img image.Image) (bool, error) {
		configMu.Lock()
		valid := configured
		windows := append([]runnerWindowClaim(nil), claims...)
		configMu.Unlock()
		if !valid {
			return false, fmt.Errorf("pixels arrived before independent source confirmation")
		}
		pulse, _, e := inspectRunnerCapturePixels(img, source, windows)
		return pulse, e
	}
	save := func(frame screen.Frame, body []byte) error {
		if !budget.reserve(len(body)) {
			return fmt.Errorf("suite image budget exceeded")
		}
		n := frameCount.Add(1)
		if n > 128 {
			return fmt.Errorf("case image count exceeded")
		}
		return runnerWriteNew(filepath.Join(dir, fmt.Sprintf("frame-%03d.jpeg", n)), body)
	}
	scope := "window"
	if display {
		scope = "display"
	}
	page := newRunnerCapturePage(t, scope, inspect, save)
	defer page.stopLink()
	ctx, cancel := context.WithDeadline(suite, caseBegan.Add(40*time.Second))
	defer cancel()
	cmd := exec.Command(app, "--screen-runner-proof", "--case", selected)
	cmd.WaitDelay = time.Second
	cmd.Env = append(proofEnvironment(t), "GITHUB_ACTIONS=true", "GITHUB_REPOSITORY=ai-ecoverse/sliccy-app", "GITHUB_EVENT_NAME=workflow_dispatch", "GITHUB_REF=refs/heads/proof/runner-capture-v1", "SLICCY_RUNNER_ENVIRONMENT=github-hosted")
	input, e := cmd.StdinPipe()
	if e != nil {
		fail("fixed marker pipe unavailable")
		return result
	}
	defer input.Close()
	stdout, e := cmd.StdoutPipe()
	if e != nil {
		fail("metadata pipe unavailable")
		return result
	}
	stderr := &proofRows{}
	cmd.Stderr = stderr
	began := caseBegan
	if ctx.Err() != nil {
		result.Result = "FAILED_TO_DEMONSTRATE"
		fail("case setup exhausted execution budget; no launch")
		return result
	}
	if cmd.Start() != nil {
		fail("fixed signed app launch failed")
		return result
	}
	result.AppPID = cmd.Process.Pid
	incoming := make(chan runnerIncoming, 1024)
	finished := make(chan runnerReadResult, 1)
	go readRunnerRows(stdout, cmd, selected, incoming, finished, func() { _ = input.Close(); page.fail("metadata observer loss"); page.stopLink() })
	watches := map[int]*runnerWatch{}
	watchEvents := make(chan runnerWatchEvent, 128)
	watchCtx, stopWatching := context.WithCancel(context.Background())
	var watchLoss atomic.Bool
	addWatch := func(fact runnerProcessFact) error {
		if old := watches[fact.Kernel.Identity.PID]; old != nil {
			if old.fact.Kernel != fact.Kernel {
				return fmt.Errorf("watched incarnation changed")
			}
			return nil
		}
		events, stop, e := watchProofExec(fact.Kernel.Identity.PID)
		if e != nil {
			return e
		}
		watches[fact.Kernel.Identity.PID] = &runnerWatch{fact: fact, stop: stop}
		go func(pid int) {
			for {
				select {
				case event := <-events:
					select {
					case watchEvents <- runnerWatchEvent{pid, event}:
					default:
						watchLoss.Store(true)
					}
					if event.Exit || event.Err != nil {
						return
					}
				case <-watchCtx.Done():
					return
				}
			}
		}(fact.Kernel.Identity.PID)
		return nil
	}
	var stopWatchesOnce sync.Once
	stopWatches := func() {
		stopWatchesOnce.Do(func() {
			stopWatching()
			for _, watch := range watches {
				watch.stop()
			}
		})
	}
	defer stopWatches()
	var reader runnerReadResult
	readerDone := false
	normalCleanup := false
	defer func() {
		if recover() != nil {
			result.Result = "FAIL"
			fail("driver observer panic; proof inconclusive")
		}
		if normalCleanup {
			return
		}
		result.Result = "FAIL"
		_ = input.Close()
		page.stopLink()
		waitReader := func(maximum time.Duration) {
			if readerDone {
				return
			}
			remaining := runnerWaitBudget(time.Now(), caseBegan.Add(45*time.Second), maximum)
			if remaining <= 0 {
				return
			}
			timer := time.NewTimer(remaining)
			select {
			case reader = <-finished:
				readerDone = true
				result.AppReaped = true
			case <-timer.C:
			}
			if !timer.Stop() {
				select {
				case <-timer.C:
				default:
				}
			}
		}
		waitReader(2 * time.Second)
		if !readerDone {
			for pid, watch := range watches {
				if pid != cmd.Process.Pid && watch.fact.Label != "authorization" {
					_ = runnerKillOwned(pid, watch.fact.Kernel.Identity, unix.SIGTERM)
				}
			}
			waitReader(time.Second)
		}
		if !readerDone {
			_ = cmd.Process.Kill()
			waitReader(time.Second)
		}
		if readerDone {
			_ = runnerWriteNew(filepath.Join(dir, "emergency-milestones.ndjson"), reader.raw)
		}
	}()

	appFact, e := observeRunnerProcess("app", "ai.sliccy.mac", cmd.Process.Pid, os.Getpid(), app, page.Origin)
	if e != nil || addWatch(appFact) != nil {
		fail("owned signed app observation unavailable")
	}
	if e == nil {
		result.Processes[cmd.Process.Pid] = appFact
	}
	if _, e := io.WriteString(input, page.Join+"\n"); e != nil {
		fail("synthetic join input failed")
	}
	owners := []runnerOwnerWitness{}
	refusals := []runnerRefusalClaim{}
	var counts runnerInventoryCounts
	launched := map[int]string{}
	reaped := map[int]string{}
	stages := map[string]runnerIncoming{}
	var timing []captureTimingRow
	var gate runnerMarkerGate
	var baselineSent time.Time
	var resetWire time.Time
	var remoteStopStarted bool
	var remoteStopSent time.Time
	type stopResult struct {
		err error
		at  time.Time
	}
	remoteStopDone := make(chan stopResult, 1)
	remoteStopReceived := false
	acceptRemoteStop := func(value stopResult) {
		remoteStopReceived = true
		if value.err != nil {
			fail("independent remote Stop did not complete")
		} else {
			result.RemoteStopLatencyMS = float64(value.at.Sub(remoteStopSent)) / float64(time.Millisecond)
			if result.RemoteStopLatencyMS > 1500 {
				fail("remote Stop exceeded original bound")
			}
		}
	}

	aborted := false
	var stopRow *runnerIncoming
	var terminal runnerIncoming
	var rootPaths = map[string]bool{}
	var cleanupDeadline time.Time
	sendMarker := func(marker string) {
		if marker == "runner-baseline" {
			baselineSent = time.Now()
		}
		if _, e := io.WriteString(input, marker+"\n"); e != nil {
			fail("fixed driver marker delivery failed")
		}
	}
	handleWatch := func(event runnerWatchEvent) {
		watch := watches[event.pid]
		if watch == nil {
			fail("unknown kernel monitor event")
			return
		}
		if event.event.Err != nil || event.event.Exec {
			fail("owned process exec/monitor failure")
		}
		if event.event.Exit {
			watch.exited = true
			if gate.Started && !gate.Stop && terminal.row.Stage == "" && watch.fact.Label != "authorization" {
				fail("required owner exited before stop")
			}
		}
	}

	deadlineC := ctx.Done()
	ticker := time.NewTicker(10 * time.Millisecond)
	defer ticker.Stop()
	loopComplete := runRunnerControllerLoop(caseBegan.Add(45*time.Second), func() bool { return !readerDone || incoming != nil }, func(hardDeadlineC <-chan time.Time) bool {
		if len(result.Failures) > 0 && !aborted {
			aborted = true
			_ = input.Close()
			page.stopLink()
			cleanupDeadline = time.Now().Add(3 * time.Second)
		}
		if !cleanupDeadline.IsZero() && time.Now().After(cleanupDeadline) {
			for pid, watch := range watches {
				if pid != cmd.Process.Pid && watch.fact.Label != "authorization" && !runnerProcessGone(pid, watch.fact.Kernel.Identity) {
					_ = runnerKillOwned(pid, watch.fact.Kernel.Identity, unix.SIGTERM)
				}
			}
			if watch := watches[cmd.Process.Pid]; watch != nil {
				_ = runnerKillOwned(cmd.Process.Pid, watch.fact.Kernel.Identity, unix.SIGKILL)
			} else {
				_ = cmd.Process.Kill()
			}
			cleanupDeadline = time.Now().Add(time.Second)
		}
		select {
		case received, ok := <-incoming:
			if !ok {
				incoming = nil
				return true
			}
			row := received.row
			if row.Elapsed > received.at.Sub(began).Seconds()*1000+1 {
				fail("app clock exceeds independent observation interval")
			}
			if row.Timing != nil {
				timing = append(timing, *row.Timing)
			}
			repeated := row.Stage == "source-admitted" || row.Stage == "native-admitted" || strings.HasPrefix(row.Stage, "reverse-re") || row.Stage == "surface-process" || row.Stage == "surface-window" || row.Stage == "protected-selection-refused" || row.Stage == "surface-launcher-started" || row.Stage == "surface-child-reaped"
			if !repeated {
				if _, ok := stages[row.Stage]; ok {
					fail("duplicate mandatory case milestone")
				}
				stages[row.Stage] = received
			}
			text := func(key string) string { s, _ := runnerText(row.Fields, key); return s }
			integer := func(key string) int { n, _ := runnerInt(row.Fields, key, -2147483648, 4294967295); return int(n) }
			switch row.Stage {
			case "runner-preflight":
				screenOK, _ := runnerBool(row.Fields, "screenCapture")
				listen, _ := runnerBool(row.Fields, "listenEvent")
				post, _ := runnerBool(row.Fields, "postEvent")
				hosted, _ := runnerBool(row.Fields, "hosted")
				if !screenOK || !hosted || selected == "hotkey-stop" && (!listen || !post) {
					result.Result = "FAILED_TO_DEMONSTRATE"
				}
			case "surface-launcher-started":
				pid := integer("pid")
				if _, ok := launched[pid]; ok {
					fail("duplicate owned launcher PID")
				}
				launched[pid] = text("label")
			case "child-started", "surface-process":
				label, bundle := "cli", "ai.sliccy.slicc"
				if row.Stage == "surface-process" {
					label, bundle = text("label"), text("bundleIdentifier")
				}
				pid := integer("pid")
				if label == "allowed" {
					if _, ok := launched[pid]; ok {
						fail("duplicate allowed child")
					}
					launched[pid] = label
				}
				parent := cmd.Process.Pid
				if label == "app" {
					parent = os.Getpid()
				}
				fact, e := observeRunnerProcess(label, bundle, pid, parent, app, page.Origin)
				if label == "app" {
					if pid != cmd.Process.Pid {
						e = fmt.Errorf("app owner substituted")
					}
				}
				if e != nil {
					result.Result = "FAILED_TO_DEMONSTRATE"
					fail("independent source/native process identity unavailable")
					break
				}
				if old, ok := result.Processes[pid]; ok && old.Kernel != fact.Kernel {
					fail("owner image changed")
				}
				if label != "app" && label != "authorization" {
					if parentFact, ok := result.Processes[cmd.Process.Pid]; !ok || fact.Kernel.Identity.ParentUnique != parentFact.Kernel.Identity.Unique || fact.Kernel.Identity.ParentVersion != parentFact.Kernel.Identity.Version {
						fail("owned child parent incarnation mismatch")
					}
				}
				result.Processes[pid] = fact
				if fact.Root != "" {
					rootPaths[fact.Root] = true
				}
				if addWatch(fact) != nil {
					result.Result = "FAILED_TO_DEMONSTRATE"
					fail("owner exec/exit monitor unavailable")
				}
				if label != "cli" {
					for _, owner := range owners {
						if owner.PID == pid || owner.Label == label {
							fail("duplicate declared surface owner")
						}
					}
					owners = append(owners, runnerOwnerWitness{label, pid, bundle})
				}
			case "surface-window":
				rect, _ := runnerGeometry(row.Fields["rect"])
				configMu.Lock()
				claims = append(claims, runnerWindowClaim{text("label"), integer("pid"), uint32(integer("windowID")), rect, int64(integer("layer")), text("profile")})
				configMu.Unlock()
			case "protected-selection-refused":
				predicate, _ := runnerBool(row.Fields, "predicateEvidence")
				claim := runnerRefusalClaim{Label: text("label"), PID: integer("pid"), Kind: text("type"), Predicate: predicate}
				if claim.Kind == "window" {
					id := uint32(integer("windowID"))
					claim.WindowID = &id
				}
				refusals = append(refusals, claim)
			case "surfaces-ready":
				var object map[string]json.RawMessage
				_ = json.Unmarshal(row.Fields["counts"], &object)
				n, _ := runnerInt(object, "processes", 1, 5)
				w, _ := runnerInt(object, "windows", 1, 128)
				counts = runnerInventoryCounts{int(n), int(w)}
				actual, e := readRunnerWindows(true)
				if e != nil || matchRunnerInventory(selected, owners, claims, actual, counts) != nil {
					result.Result = "FAILED_TO_DEMONSTRATE"
					fail("independent complete source window inventory unavailable")
					break
				}
				if selected == "authorization-exclusion" {
					for _, claim := range claims {
						if claim.Label == "authorization" && initialIDs[claim.ID] {
							result.Result = "FAILED_TO_DEMONSTRATE"
							fail("authorization window predates owned requester")
						}
					}
				}
				if display {
					page.Pages.mu.Lock()
					for _, pageSpec := range fixedProofPageCatalog {
						if page.Pages.delivered[pageSpec.Path] < 1 {
							fail("fixed browser page was not delivered")
						}
					}
					page.Pages.mu.Unlock()
				}
				result.Windows = actual
				result.TitleDiagnostics = runnerTitleDiagnostics(actual)
				configMu.Lock()
				configured = true
				configMu.Unlock()
				gate.Surfaces = true
			case "source-validated":
				if matchRunnerRefusals(claims, refusals) != nil {
					fail("incomplete independently attributed protected builder coverage")
				}
				if integer("allowedWindowCount") != 1 || integer("protectedWindowCount") != len(claims)-1 {
					fail("validated source count differs from independent inventory")
				}
			case "capture-started":
				gate.Started = true
			case "baseline-confirmed":
				if !gate.BaselineSent {
					fail("baseline confirmed without independent pixels")
					break
				}
				bound, e := boundRunnerClock(baselineSent, received.at, row.Event)
				if e != nil {
					fail("causal marker clock unavailable")
				} else {
					result.Clock = bound
				}
				actual, e := readRunnerWindows(true)
				if e != nil || matchRunnerInventory(selected, owners, claims, actual, counts) != nil {
					fail("window inventory changed before baseline")
				}
				for pid, fact := range result.Processes {
					current, e := inspectRunnerKernelImage(pid)
					if e != nil || current != fact.Kernel {
						fail("owner kernel image changed before baseline")
					}
				}
				if selected == "reciprocal-revoke" && !remoteStopStarted {
					remoteStopStarted = true
					remoteStopSent = time.Now()
					gate.Stop = true
					go func() {
						stopCtx, cancel := context.WithDeadline(ctx, remoteStopSent.Add(1500*time.Millisecond))
						defer cancel()
						err := page.stop(stopCtx)
						remoteStopDone <- stopResult{err, time.Now()}
					}()
				}
			case "stop-requested":
				copy := received
				stopRow = &copy
				gate.Stop = true
			case "surface-unavailable":
				result.Result = "FAILED_TO_DEMONSTRATE"
			case "surface-child-reaped":
				pid, label := integer("pid"), text("label")
				if launched[pid] != label || reaped[pid] != "" {
					fail("unmatched/duplicate owned child reap")
				}
				reaped[pid] = label
			case "child-exit-reaped":
				pid := integer("pid")
				fact, ok := result.Processes[pid]
				if !ok || fact.Label != "cli" {
					fail("native reap PID differs from observed child")
				}
			case "terminal":
				terminal = received
			}
		case <-page.Wake:
			facts, problem := page.snapshot()
			if problem != "" {
				fail("independent screen receiver rejected protocol/evidence")
			}
			black, white := false, false
			for _, fact := range facts {
				if fact.Kind == "frame" && fact.Admitted && fact.Pulse != nil {
					if *fact.Pulse {
						white = true
					} else {
						black = true
					}
				}
				invalidated := fact.Kind == "reset" || fact.Kind == "state" && fact.State != nil && len(fact.State.Caps) == 0 && fact.State.LastSession != nil
				if invalidated && resetWire.IsZero() {
					resetWire = fact.At
					gate.Reset = true
				}
			}
			gate.BaselinePixels = black && white
		case value := <-remoteStopDone:
			acceptRemoteStop(value)
		case event := <-watchEvents:
			handleWatch(event)
		case reader = <-finished:
			readerDone = true
			result.AppReaped = true
		case <-deadlineC:
			deadlineC = nil
			fail("fixed case execution deadline exceeded")
			if !aborted {
				aborted = true
				_ = input.Close()
				page.stopLink()
				cleanupDeadline = time.Now().Add(3 * time.Second)
			}
		case <-hardDeadlineC:
			return false
		case <-ticker.C:
		}
		if !aborted && len(result.Failures) == 0 {
			for marker := gate.next(); marker != ""; marker = gate.next() {
				sendMarker(marker)
			}
		}
		return true
	})
	if !loopComplete {
		page.Receiver.clear()
		page.stopLink()
		_ = input.Close()
		_ = stdout.Close()
		if !readerDone {
			_ = cmd.Process.Kill()
		}
		markRunnerLoopDeadline(&result, readerDone)
		result.CaseElapsedMS = float64(time.Since(caseBegan)) / float64(time.Millisecond)
		result.Wire, _ = page.snapshot()
		normalCleanup = true
		return result
	}
	result.MetadataReaderSettled = readerDone

	if remoteStopStarted && !remoteStopReceived {
		remaining := time.Until(remoteStopSent.Add(1500 * time.Millisecond))
		if remaining <= 0 {
			fail("remote Stop completion deadline exhausted")
		} else {
			timer := time.NewTimer(remaining)
			select {
			case value := <-remoteStopDone:
				acceptRemoteStop(value)
			case <-timer.C:
				fail("remote Stop completion missing")
			}
			if !timer.Stop() {
				select {
				case <-timer.C:
				default:
				}
			}
		}
	}

	settleUntil := time.Now().Add(2 * time.Second)
	if hard := began.Add(45 * time.Second); settleUntil.After(hard) {
		settleUntil = hard
	}
	if !page.closeAndWait(settleUntil) {
		fail("Pion workers did not settle before evidence closure")
	}
	monitorDeadline := time.NewTimer(runnerWaitBudget(time.Now(), caseBegan.Add(45*time.Second), 500*time.Millisecond))
	allExited := func() bool {
		for _, watch := range watches {
			if watch.fact.Label != "authorization" && !watch.exited {
				return false
			}
		}
		return true
	}
	for !allExited() {
		select {
		case event := <-watchEvents:
			handleWatch(event)
		case <-monitorDeadline.C:
			fail("owned process exit observation incomplete")
			goto monitorSettled
		}
	}
monitorSettled:
	if !monitorDeadline.Stop() {
		select {
		case <-monitorDeadline.C:
		default:
		}
	}
	stopWatches()
	for {
		select {
		case event := <-watchEvents:
			handleWatch(event)
		default:
			goto monitorDrained
		}
	}
monitorDrained:
	var finalProblem string
	result.Wire, finalProblem = page.snapshot()
	page.Receiver.mu.Lock()
	result.ReceiverInvalidatedAt = page.Receiver.invalidatedAt
	page.Receiver.mu.Unlock()
	for _, fact := range result.Wire {
		if fact.Kind == "frame" && fact.Admitted {
			if fact.AdmittedAt == nil || fact.AdmittedAt.Before(fact.At) || fact.DecodedAt == nil || fact.AdmittedAt.Before(*fact.DecodedAt) || !result.ReceiverInvalidatedAt.IsZero() && fact.AdmittedAt.After(result.ReceiverInvalidatedAt) {
				fail("receiver admitted pixels after reset or before decode")
			}
		}
	}
	if cmd.ProcessState != nil {
		result.ExitCode = cmd.ProcessState.ExitCode()
	} else {
		result.ExitCode = -1
	}
	if finalProblem != "" {
		fail("screen protocol worker failed before evidence closure")
	}
	if reader.err != nil || stderr.overflow || (bytes.Contains(reader.raw, []byte(page.Join)) || bytes.Contains(stderr.data, []byte(page.Join))) {
		fail("metadata loss/overflow/secret disclosure")
	}
	if terminal.row.Stage == "" {
		fail("terminal case disposition missing")
	} else {
		outcome, _ := runnerText(terminal.row.Fields, "outcome")
		if outcome == "failed-to-demonstrate" && len(result.Failures) == 0 {
			result.Result = "FAILED_TO_DEMONSTRATE"
		}
		if outcome == "complete" {
			for _, stage := range strings.Fields("runner-preflight child-started lanes-authenticated heartbeat-ready synthetic-link-observed surfaces-ready surfaces-confirmed source-validated grant-requested native-granted capture-started baseline-confirmed receiver-reset-confirmed capture-stopped reverse-ledger-closed child-exit-reaped") {
				if stages[stage].row.Stage == "" {
					fail("required successful-case milestone missing")
				}
			}
			if validateCaptureTiming(timing) != nil {
				fail("actual stop/admission/reciprocal timing evidence failed")
			}
			if matchRunnerWireAdmissions(timing, result.Wire) != nil {
				fail("wire/source/native frame correlation incomplete")
			}
			if stopRow == nil || resetWire.IsZero() {
				fail("independent wire invalidation missing")
			} else {
				upper, e := runnerWireStopLatency(selected, result.Clock, resetWire, stopRow.row.Event, remoteStopSent)
				if e != nil || upper > 1500*time.Millisecond {
					fail("independent wire invalidation exceeded causal 1500ms bound")
				} else {
					result.ReceiverLatencyUpperMS = float64(upper) / float64(time.Millisecond)
				}
			}
			if selected == "reciprocal-revoke" && (result.RemoteStopLatencyMS <= 0 || result.RemoteStopLatencyMS > 1500) {
				fail("reciprocal peer completion absent")
			}
			if !gate.SurfacesSent || !gate.BaselineSent || !gate.ResetSent {
				fail("independent required markers incomplete")
			}
			if reader.runErr != nil {
				fail("complete case returned nonzero")
			}
			if len(result.Failures) == 0 {
				result.Result = "PASS"
			}
		} else if outcome != "failed-to-demonstrate" {
			fail("signed fixture reported case failure")
		}
	}
	result.MonitorLoss = watchLoss.Load()
	if result.MonitorLoss {
		fail("kernel monitor delivery lost")
	}
	result.DirectChildrenGone = true
	for pid, label := range launched {
		if reaped[pid] != label {
			result.DirectChildrenGone = false
		}
		if fact, ok := result.Processes[pid]; ok {
			if !runnerProcessGone(pid, fact.Kernel.Identity) {
				result.DirectChildrenGone = false
			}
		} else {
			result.DirectChildrenGone = false
			result.AppClaimsOnlyReaps = append(result.AppClaimsOnlyReaps, pid)
		}
	}
	for pid, fact := range result.Processes {
		if fact.Label == "cli" && !runnerProcessGone(pid, fact.Kernel.Identity) {
			result.DirectChildrenGone = false
		}
	}
	result.RootsRemoved = true
	for path := range rootPaths {
		if _, e := os.Lstat(path); !os.IsNotExist(e) {
			result.RootsRemoved = false
		}
	}
	postWindows, e := readRunnerWindows(true)
	result.OwnedWindowsGone = e == nil
	if result.OwnedWindowsGone { result.OwnedWindowsGone = runnerDirectOwnedWindowsGone(postWindows,result.Processes) }
	var rootScanError error
	result.RootAssociatedProcesses, rootScanError = runnerRootProcesses(rootPaths, app)
	if !result.DirectChildrenGone || !result.RootsRemoved || !result.AppReaped || !result.OwnedWindowsGone || rootScanError != nil || len(result.RootAssociatedProcesses) > 0 {
		fail("bounded owned cleanup unconfirmed")
	}

	if _, e := runnerArtifactHashes(app, manifest); e != nil {
		fail("immutable fixture changed after case")
	}
	result.CaseElapsedMS = float64(time.Since(began)) / float64(time.Millisecond)
	if time.Since(began) > 45*time.Second {
		fail("case including cleanup exceeded 45 seconds")
	}
	if len(result.Failures) > 0 && result.Result == "PASS" {
		result.Result = "FAIL"
	}
	if result.Result == "PASS" {
		result.Coverage["selected owned window pixels"] = "PASS"
		if display {
			result.Coverage["hosting Chrome four independent profiles/all four owned windows"] = "PASS"
			result.Coverage["sliccy.app all independently visible windows"] = "PASS"
		}
		if selected == "authorization-exclusion" {
			result.Coverage["actually attributed authorization service/window"] = "PASS"
		}
		if selected == "active-stop" {
			result.Coverage["programmatic installed Stop button action"] = "PASS"
		}
		if selected == "hotkey-stop" {
			result.Coverage["fixed posted shortcut through actual Carbon handler"] = "PASS"
		}
		if selected == "reciprocal-revoke" {
			result.Coverage["remote Stop plus receive/enqueue/actual write/peer ACK"] = "PASS"
		}
	}
	if runnerWriteNew(filepath.Join(dir, "milestones.ndjson"), reader.raw) != nil || runnerWriteNew(filepath.Join(dir, "stderr.txt"), stderr.data) != nil {
		result.Result = "FAIL"
		fail("private row evidence write failed")
	}

	normalCleanup = true
	return result
}
func TestRunnerMarkerControllerCannotSubstituteSentFramesOrLocalClear(t *testing.T) {
	g := runnerMarkerGate{Started: true}
	if g.next() != "" {
		t.Fatal("capture-start alone permitted marker")
	}
	g.Surfaces = true
	if g.next() != "runner-surfaces-observed" {
		t.Fatal("verified surfaces marker missing")
	}
	if g.next() != "" {
		t.Fatal("sent-only frame treated as decoded baseline")
	}
	g.BaselinePixels = true
	if g.next() != "runner-baseline" {
		t.Fatal("actual decoded baseline did not permit marker")
	}
	g.Stop = true
	if g.next() != "" {
		t.Fatal("local viewer clear substituted for actual node invalidation")
	}
	g.Reset = true
	if g.next() != "runner-receiver-reset" || g.next() != "" {
		t.Fatal("real invalidation not acknowledged exactly once")
	}
}

func runnerWaitBudget(now, deadline time.Time, maximum time.Duration) time.Duration {
	remaining := deadline.Sub(now)
	if remaining <= 0 {
		return 0
	}
	if remaining < maximum {
		return remaining
	}
	return maximum
}
func TestRunnerCleanupWaitsDoNotRestartTheCaseDeadline(t *testing.T) {
	now := time.Unix(100, 0)
	if runnerWaitBudget(now, now.Add(20*time.Millisecond), time.Second) != 20*time.Millisecond || runnerWaitBudget(now, now.Add(time.Second), 20*time.Millisecond) != 20*time.Millisecond || runnerWaitBudget(now, now.Add(-time.Second), time.Second) != 0 {
		t.Fatal("cleanup extended the original deadline")
	}
}
