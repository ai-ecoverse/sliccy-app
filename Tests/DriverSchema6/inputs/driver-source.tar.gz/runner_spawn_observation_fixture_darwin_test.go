package integration
import (
 "context"
 "errors"
 "encoding/json"
 "testing"
 "time"
)
func TestRunnerSpawnSettlementRecordsExactIdentityWithoutSignalAuthority(t *testing.T){
 original:=runnerSpawnIdentity{PID:42,Parent:41,UID:501,Seconds:100,Microseconds:5,Role:"cli",CDHash:"5da1a3199bd3f895bce2e53023c28ca1c33d249e"}
 for _,name:=range []string{"same","absent","reused","unavailable","wrong-pid","reparented-same"}{t.Run(name,func(t *testing.T){
  current:=runnerBSDValue{PID:42,Parent:41,Effective:501,Real:501,Saved:501,Seconds:100,Microseconds:5}
  if name=="reused"{current.Microseconds=6};if name=="wrong-pid"{current.PID=43};if name=="reparented-same"{current.Parent=1}
  observe:=func(context.Context,*runnerNativeTrace,int)(runnerBSDReceipt,error){if name=="absent"||name=="unavailable"{return runnerBSDReceipt{},errors.New("synthetic-query-refused")};return runnerBSDReceipt{Accepted:true,Selected:&current},nil}
  s:=runnerObserveSpawnSettlement(context.Background(),newRunnerNativeTrace(),original,time.Now(),observe,func(pid int)bool{return name=="absent"&&pid==42})
  wanted:=map[string]string{"same":"same-incarnation-present","absent":"pid-absent","reused":"pid-reused-original-gone","unavailable":"unavailable","wrong-pid":"unavailable","reparented-same":"same-incarnation-present"}[name]
  if s.State!=wanted || s.OriginalGone!=(name=="absent"||name=="reused") || s.AtMS<0 {t.Fatalf("ASSERTION:spawn-settlement-%s",name)}
 })}
}

func TestRunnerActualSpawnRecordAndSettlementStorageCannotDisappear(t *testing.T){
 raw:=[]byte(`{"schema":6,"case":"selected-window","capture":true,"stage":"owned-process-recorded","elapsedMs":1,"eventElapsedMs":1,"role":"cli","pid":42,"parent":41,"uid":501,"startSeconds":"100","startMicroseconds":5,"cdHash":"5da1a3199bd3f895bce2e53023c28ca1c33d249e"}`)
 row,err:=decodeRunnerCaptureRow(raw);if err!=nil{t.Fatal(err)}
 records:=map[int]runnerSpawnObservation{}
 observation,err:=runnerRetainSpawnObservation(row,records)
 if err!=nil || len(records)!=1 || records[42].Original.Role!="cli" || records[42].Original.Seconds!=100 {t.Fatal("ASSERTION:spawn-original-retained")}
 if _,err:=runnerRetainSpawnObservation(row,records);err==nil {t.Fatal("duplicate spawn accepted")}
 observation.Settlement=&runnerSpawnSettlement{State:"pid-absent",OriginalGone:true}
 runnerStoreSpawnSettlement(records,42,observation)
 encoded,err:=json.Marshal(records);if err!=nil{t.Fatal(err)};var roundtrip map[int]runnerSpawnObservation;if json.Unmarshal(encoded,&roundtrip)!=nil||roundtrip[42].Settlement==nil||!roundtrip[42].Settlement.OriginalGone{t.Fatal("ASSERTION:spawn-settlement-retained")}
}
