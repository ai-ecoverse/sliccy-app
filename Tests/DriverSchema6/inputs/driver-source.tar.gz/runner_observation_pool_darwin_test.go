package integration

import (
	"context"
	"fmt"
 "encoding/json"
 "sort"
	"sync"
	"time"
)

type runnerObservation[T any] struct {
	Key string
	Value T
	Error error
	Submitted,Started,Finished time.Time
	CancelledBeforeStart bool
}

type runnerObservationJob[T any] struct {key string;query func(context.Context)(T,error)}

type runnerObservationState[T any] struct {result runnerObservation[T];settled bool}

type runnerObservationPool[T any] struct {
	mu sync.Mutex
	ctx context.Context
	cancel context.CancelFunc
	jobs chan runnerObservationJob[T]
	wake chan struct{}
	done chan struct{}
	states map[string]runnerObservationState[T]
	active int
	closed,lost bool
}

func newRunnerObservationPool[T any](ctx context.Context,deadline time.Time)*runnerObservationPool[T]{
	context,cancel:=context.WithDeadline(ctx,deadline)
	p:=&runnerObservationPool[T]{ctx:context,cancel:cancel,jobs:make(chan runnerObservationJob[T],256),wake:make(chan struct{},1),done:make(chan struct{}),states:map[string]runnerObservationState[T]{}}
	var workers sync.WaitGroup
	for i:=0;i<4;i++{workers.Add(1);go func(){defer workers.Done();p.worker()}()}
	go func(){workers.Wait();close(p.done);p.notify()}()
	return p
}

func(p *runnerObservationPool[T])notify(){select{case p.wake<-struct{}{}:default:}}

func(p *runnerObservationPool[T])Submit(key string,query func(context.Context)(T,error))error{
	p.mu.Lock()
	if key==""||len(key)>256||query==nil||p.closed||p.lost||p.ctx.Err()!=nil||len(p.states)>=256{p.mu.Unlock();return fmt.Errorf("native observation admission refused")}
	if _,exists:=p.states[key];exists{p.mu.Unlock();return fmt.Errorf("duplicate native observation key")}
	p.states[key]=runnerObservationState[T]{result:runnerObservation[T]{Key:key,Submitted:time.Now()}}
	select{case p.jobs<-runnerObservationJob[T]{key:key,query:query}:p.mu.Unlock();return nil;default:p.lost=true;p.mu.Unlock();return fmt.Errorf("native observation queue bound exceeded")}
}

func(p *runnerObservationPool[T])worker(){
	for{
		select{
		case <-p.ctx.Done():p.retireUnstarted();return
		case job:=<-p.jobs:
			p.mu.Lock()
			state:=p.states[job.key]
			if p.closed||p.ctx.Err()!=nil||state.settled{
				if !state.settled{state.result.CancelledBeforeStart=true;state.result.Error=context.Canceled;state.result.Finished=time.Now();state.settled=true;p.states[job.key]=state}
				p.mu.Unlock();p.notify();continue
			}
			state.result.Started=time.Now();p.active++;p.states[job.key]=state;p.mu.Unlock()
			value,err:=func()(value T,err error){defer func(){if recover()!=nil{err=fmt.Errorf("native observation panic/ABI unavailable")}}();return job.query(p.ctx)}()
			p.mu.Lock();state=p.states[job.key];state.result.Value=value;state.result.Error=err;state.result.Finished=time.Now();state.settled=true;p.states[job.key]=state;p.active--;p.mu.Unlock();p.notify()
		}
	}
}

func(p *runnerObservationPool[T])retireUnstarted(){
	p.mu.Lock()
	for key,state:=range p.states{if !state.settled&&state.result.Started.IsZero(){state.settled=true;state.result.CancelledBeforeStart=true;state.result.Error=context.Canceled;state.result.Finished=time.Now();p.states[key]=state}}
	p.mu.Unlock();p.notify()
}

func(p *runnerObservationPool[T])Result(key string)(runnerObservation[T],bool){
	p.mu.Lock();defer p.mu.Unlock();state,exists:=p.states[key];return state.result,exists&&state.settled
}

func(p *runnerObservationPool[T])Wait(keys []string,deadline time.Time)(map[string]runnerObservation[T],error){
	p.mu.Lock()
	seen:=map[string]bool{}
	for _,key:=range keys{if _,known:=p.states[key];!known||seen[key]{p.mu.Unlock();return nil,fmt.Errorf("missing/duplicate native observation dependency")};seen[key]=true}
	p.mu.Unlock()
	remaining:=time.Until(deadline)
	if remaining<=0{return nil,fmt.Errorf("native observation absolute deadline exhausted")}
	timer:=time.NewTimer(remaining);defer timer.Stop()
	for{
		results:=map[string]runnerObservation[T]{}
		for _,key:=range keys{if result,settled:=p.Result(key);settled{results[key]=result;if result.Error!=nil{return results,result.Error}}}
		if len(results)==len(keys){return results,nil}
		select{case <-timer.C:return results,fmt.Errorf("native observation absolute deadline exhausted");case <-p.ctx.Done():return results,p.ctx.Err();case <-p.wake:}
	}
}

func(p *runnerObservationPool[T])Close(){p.mu.Lock();p.closed=true;p.mu.Unlock();p.cancel();p.retireUnstarted()}

func(p *runnerObservationPool[T])Settled()bool{
	p.mu.Lock();defer p.mu.Unlock()
	if p.active!=0||p.lost{return false}
	for _,state:=range p.states{if !state.settled{return false}}
	select{case <-p.done:return true;default:return false}
}

func(p *runnerObservationPool[T])Snapshot()[]runnerObservation[T]{p.mu.Lock();defer p.mu.Unlock();values:=make([]runnerObservation[T],0,len(p.states));for _,state:=range p.states{values=append(values,state.result)};sort.Slice(values,func(i,j int)bool{return values[i].Key<values[j].Key});return values}

func(v runnerObservation[T])MarshalJSON()([]byte,error){
 problem:="";if v.Error!=nil{problem=v.Error.Error()}
 return json.Marshal(struct{
 Key string `json:"key"`
 Value T `json:"value"`
 Error string `json:"error"`
 Submitted,Started,Finished time.Time
 CancelledBeforeStart bool `json:"cancelledBeforeStart"`
 }{v.Key,v.Value,problem,v.Submitted,v.Started,v.Finished,v.CancelledBeforeStart})
}
