package integration

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"math"
	"math/big"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
)

type identityRow struct {
	proofRow
	Case string    `json:"case"`
	PID  *int      `json:"pid,omitempty"`
	At   time.Time `json:"-"`
}

func TestSignedAncillary(t *testing.T)  { runSignedIdentityCase(t, "ancillary") }
func TestSignedParentExec(t *testing.T) { runSignedIdentityCase(t, "parent-exec") }
func TestSignedLifecycle(t *testing.T)  { runSignedIdentityCase(t, "lifecycle") }
func runSignedIdentityCase(t *testing.T, which string) {
	executable := os.Getenv("SLICCY_SIGNED_PROOF_APP")
	if executable == "" {
		t.Skip("CI-signed build-3 executable not supplied")
	}
	evidence := os.Getenv("SLICCY_PROOF_EVIDENCE")
	if evidence == "" {
		t.Fatal("private case evidence directory required")
	}
	helper := os.Getenv("SLICCY_SIGNED_PROOF_HELPER")
	hash := os.Getenv("SLICCY_SIGNED_HELPER_CDHASH")
	if which == "parent-exec" && (helper == "" || len(hash) != 40) {
		t.Fatal("verified fixed helper manifest required")
	}
	appHash := os.Getenv("SLICCY_SIGNED_APP_CDHASH")
	if which == "ancillary" && len(appHash) != 40 {
		t.Fatal("verified original app manifest required")
	}
	var gate chan struct{}
	if which == "ancillary" {
		gate = make(chan struct{})
	}
	page, join, states := proofPageControlled(t, gate)
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, executable, "--screen-proof", "--case", which)
	cmd.Env = proofEnvironment(t)
	cmd.Stdin = strings.NewReader(join + "\n")
	stderr := &proofRows{}
	cmd.Stderr = stderr
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		t.Fatal("diagnostic pipe unavailable")
	}
	start := time.Now()
	if cmd.Start() != nil {
		t.Fatal("signed case launch failed")
	}
	execEvents, stopExec, watchErr := watchProofExec(cmd.Process.Pid)
	if watchErr != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("owned process observation unavailable")
	}
	defer stopExec()
	done := make(chan struct{})
	incoming := make(chan identityRow, 64)
	output := &proofRows{}
	var runErr, errorRead error
	go func() {
		scanner := bufio.NewScanner(stdout)
		scanner.Buffer(make([]byte, 4096), 65536)
		for scanner.Scan() {
			line := append([]byte(nil), scanner.Bytes()...)
			_, _ = output.Write(append(line, '\n'))
			var row identityRow
			decoder := json.NewDecoder(bytes.NewReader(line))
			decoder.DisallowUnknownFields()
			if decoder.Decode(&row) != nil {
				errorRead = fmt.Errorf("invalid metadata row")
				continue
			}
			row.At = time.Now()
			select {
			case incoming <- row:
			default:
				errorRead = fmt.Errorf("metadata queue exceeded")
			}
		}
		if scanner.Err() != nil {
			errorRead = fmt.Errorf("metadata stream failed")
		}
		close(incoming)
		runErr = cmd.Wait()
		close(done)
	}()
	rows := map[string]identityRow{}
	var failure string
	var failures []string
	refuse := func(reason string) {
		failures = append(failures, reason)
		if failure == "" {
			failure = reason
		}
	}
	allowed := map[string]bool{}
	for _, stage := range strings.Fields("child-started lanes-authenticated synthetic-link-observed heartbeat-ready exec-control-sent exec-control-echoed parent-exec-requested parent-exec-failed helper-child-owned helper-bootstrap-record-read helper-bootstrap-record-refused helper-safety-retained helper-frames-retained helper-safety-refused helper-frames-refused helper-app-role-refused helper-lanes-retained helper-control-written helper-control-write-refused helper-observation-ended helper-child-exit-reaped helper-terminal helper-child-already-reaped helper-ownership-refused helper-app-role-check-failed helper-cleanup-failed ancillary-control-sent ancillary-control-echoed ancillary-send-started ancillary-record-sent ancillary-send-refused ancillary-association-lost ancillary-observation-ended lifecycle-live-token-accepted lifecycle-stop-requested child-gate-invalidated child-authority-invalidated child-exit-reaped stale-token-refused stale-token-accepted terminal revoke-queued native-ack local-gate-invalidated") {
		allowed[stage] = true
	}
	var execAt, refusalAt, releaseAt, childExitAt time.Time
	var fdBefore, fdAfter nullFDInventory
	leakOutcome := "unproven"
	var baseline *big.Int
	var stateEvidence []map[string]any
	var helperVerified bool
	var helperCheckedAt time.Time
	var inspectionError string
	var childEvents <-chan proofExecEvent
	var stopChild func()
	var childExited bool
	processRow := func(row identityRow) {
		if row.Schema != 2 || row.Case != which || row.Capture == nil || *row.Capture || !allowed[row.Stage] || math.IsNaN(row.Elapsed) || math.IsInf(row.Elapsed, 0) || row.Elapsed < 0 || row.Elapsed > row.At.Sub(start).Seconds()*1000 {
			refuse("invalid case metadata")
			return
		}
		if row.PID != nil && (row.Stage != "child-started" && row.Stage != "parent-exec-requested" || *row.PID <= 0) {
			refuse("unexpected owned PID field")
			return
		}
		if row.Duration != nil && (math.IsNaN(*row.Duration) || math.IsInf(*row.Duration, 0) || *row.Duration < 0) {
			refuse("invalid duration")
			return
		}
		if _, exists := rows[row.Stage]; exists && row.Stage != "synthetic-link-observed" {
			refuse("duplicate case stage")
		}
		rows[row.Stage] = row
		if which == "ancillary" && row.Stage == "lanes-authenticated" && rows["child-started"].PID != nil {
			fdBefore = inspectOwnedNullFDs(*rows["child-started"].PID)
		}
		if which == "ancillary" && row.Stage == "heartbeat-ready" && releaseAt.IsZero() {
			releaseAt = time.Now()
			close(gate)
		}
		if row.Stage == "parent-exec-requested" && (row.PID == nil || *row.PID != cmd.Process.Pid) {
			refuse("same-parent PID not established")
		}
		if row.Stage == "child-started" {
			if row.PID == nil || *row.PID == cmd.Process.Pid {
				refuse("owned child PID missing")
				return
			}
			var e error
			childEvents, stopChild, e = watchProofExec(*row.PID)
			if e != nil {
				refuse("owned CLI exit observation unavailable")
			}
		}
	}
	inspect := func() {
		if (which != "parent-exec" && which != "ancillary") || (which == "parent-exec" && execAt.IsZero()) || refusalAt.IsZero() || helperVerified || inspectionError != "" {
			return
		}
		var digest string
		var e error
		want := hash
		if which == "ancillary" {
			if rows["child-started"].PID != nil {
				fdAfter = inspectOwnedNullFDs(*rows["child-started"].PID)
			}
			want = appHash
			digest, e = inspectProofImage(cmd.Process.Pid, executable, want, "ai.sliccy.mac", "ai.sliccy.proof-helper")
		} else {
			digest, e = inspectProofHelper(cmd.Process.Pid, helper, want)
		}
		helperCheckedAt = time.Now()
		if e != nil || digest != want {
			inspectionError = "live fixed helper identity not established"
			refuse(inspectionError)
			return
		}
		helperVerified = true
	}
	readStates := states
	readRows := incoming
	readExec := execEvents
	finished := false
	for !finished {
		select {
		case row, ok := <-readRows:
			if !ok {
				readRows = nil
				continue
			}
			processRow(row)
		case state := <-readStates:
			seq, ok := new(big.Int).SetString(state.Seq, 10)
			if !ok || seq.Sign() < 0 {
				refuse("invalid state sequence")
				continue
			}
			stateEvidence = append(stateEvidence, map[string]any{"stateSeq": state.Seq, "reason": state.Reason, "granted": len(state.Caps) > 0, "receivedMs": state.At.Sub(start).Seconds() * 1000})
			if baseline == nil && state.Reason == "awaiting-consent" {
				baseline = new(big.Int).Set(seq)
			}
			if (which == "parent-exec" || which == "ancillary") && baseline != nil && seq.Cmp(baseline) > 0 && state.Reason == "peer-lost" && len(state.Caps) == 0 && refusalAt.IsZero() {
				refusalAt = state.At
			}
			inspect()
		case event := <-readExec:
			if event.Err != nil {
				refuse("native parent observation failed")
				readExec = nil
				continue
			}
			if event.Exec && execAt.IsZero() {
				execAt = event.At
				if which == "ancillary" {
					refuse("original app unexpectedly execed")
				}
			}
			if event.Exit {
				readExec = nil
			}
			inspect()
		case event := <-childEvents:
			if event.Err != nil {
				refuse("native child observation failed")
				childEvents = nil
				continue
			}
			if event.Exec {
				refuse("unexpected released child exec")
			}
			if event.Exit {
				childExited = true
				childExitAt = event.At
				childEvents = nil
			}
		case <-done:
			for row := range incoming {
				processRow(row)
			}
			finished = true
		}
	}
	if !childExited && childEvents != nil {
		select {
		case event := <-childEvents:
			if event.Exit && event.Err == nil {
				childExited = true
				childExitAt = event.At
			}
		case <-time.After(time.Second):
		}
	}
	if stopChild != nil {
		stopChild()
	}

	if output.overflow || stderr.overflow || errorRead != nil {
		refuse("diagnostic metadata budget or parser failure")
	}
	if strings.Contains(string(output.data), join) {
		refuse("diagnostic disclosed synthetic join")
	}
	if runErr != nil {
		refuse("signed case returned failure")
	}
	for _, stage := range []string{"child-started", "lanes-authenticated", "synthetic-link-observed", "heartbeat-ready"} {
		if _, ok := rows[stage]; !ok {
			refuse("missing " + stage)
		}
	}
	if !childExited {
		refuse("owned CLI kernel exit not observed")
	}
	select {
	case <-page.Ready():
	default:
		refuse("no real Pion HELLO")
	}
	hello, ok := page.PeerHello()
	if !ok || hello.Version != "1.58.1" {
		refuse("unexpected released CLI HELLO")
	}
	if which == "parent-exec" {
		for _, stage := range []string{"exec-control-sent", "exec-control-echoed", "parent-exec-requested", "helper-child-owned", "helper-bootstrap-record-read", "helper-safety-retained", "helper-frames-retained", "helper-app-role-refused", "helper-lanes-retained", "helper-observation-ended", "helper-child-exit-reaped", "helper-terminal"} {
			if _, ok := rows[stage]; !ok {
				refuse("missing " + stage)
			}
		}
		if _, ok := rows["helper-control-written"]; !ok {
			if _, refused := rows["helper-control-write-refused"]; !refused {
				refuse("missing helper traffic outcome")
			}
		}
		for _, stage := range []string{"helper-safety-retained", "helper-frames-retained"} {
			reason := rows[stage].Reason
			if reason != "peer-matched" && reason != "peer-disconnected" {
				refuse("retained lane outcome unavailable")
			}
		}
		for _, stage := range []string{"helper-bootstrap-record-refused", "helper-safety-refused", "helper-frames-refused"} {
			if _, exists := rows[stage]; exists {
				refuse("helper descriptor/bootstrap validation refused")
			}
		}
		if rows["helper-observation-ended"].Reason != "elapsed" {
			refuse("helper observation did not complete")
		}
		if rows["helper-terminal"].Reason != "cleanup-complete" {
			refuse("helper cleanup not confirmed")
		}
		if execAt.IsZero() || refusalAt.IsZero() || !helperVerified {
			refuse("exec/live-helper/new native refusal not established")
		}
		delay := refusalAt.Sub(execAt)
		if delay < 0 || delay > 500*time.Millisecond {
			refuse("refusal not observed within exec sub-lease bound")
		}
		sent := rows["exec-control-sent"]
		echoed := rows["exec-control-echoed"]
		requested := rows["parent-exec-requested"]
		if requested.Elapsed-sent.Elapsed < 0 || requested.Elapsed-sent.Elapsed > 750 || requested.Elapsed-echoed.Elapsed < 0 || requested.Elapsed-echoed.Elapsed > 100 {
			refuse("fresh control bounds not established")
		}
		if refusalAt.Sub(start).Seconds()*1000 >= sent.Elapsed+1500 {
			refuse("lease-only refusal not excluded independently")
		}
	} else if which == "ancillary" {
		for _, stage := range []string{"ancillary-control-sent", "ancillary-control-echoed", "ancillary-send-started", "ancillary-record-sent", "ancillary-association-lost", "ancillary-observation-ended", "child-gate-invalidated", "child-authority-invalidated", "child-exit-reaped", "terminal"} {
			if _, ok := rows[stage]; !ok {
				refuse("missing " + stage)
			}
		}
		if _, exists := rows["ancillary-send-refused"]; exists {
			refuse("ancillary record not sent")
		}
		if rows["terminal"].Reason != "ancillary-observation-complete" || rows["ancillary-observation-ended"].Reason != "elapsed" {
			refuse("ancillary observation/cleanup incomplete")
		}
		sent := rows["ancillary-control-sent"]
		echoed := rows["ancillary-control-echoed"]
		attack := rows["ancillary-send-started"]
		lost := rows["ancillary-association-lost"]
		link := rows["synthetic-link-observed"]
		if releaseAt.IsZero() || !helperVerified || refusalAt.IsZero() || baseline == nil {
			refuse("original identity/fresh refusal/controlled release missing")
		}
		if attack.Elapsed-sent.Elapsed < 0 || attack.Elapsed-sent.Elapsed > 750 || attack.Elapsed-echoed.Elapsed < 0 || attack.Elapsed-echoed.Elapsed > 100 {
			refuse("ancillary fresh control not established")
		}
		if lost.Reason != "peer-lost" || lost.Elapsed-attack.Elapsed < 0 || lost.Elapsed-attack.Elapsed > 500 {
			refuse("native ancillary loss not timely peer refusal")
		}
		lower := releaseAt.Add(-time.Duration(link.Elapsed * 1e6))
		if lower.Before(start) {
			lower = start
		}
		upperDelay := refusalAt.Sub(lower.Add(time.Duration(attack.Elapsed * 1e6)))
		if upperDelay < 0 || upperDelay > 500*time.Millisecond {
			refuse("independent ancillary refusal bound not established")
		}
		if !refusalAt.Before(lower.Add(time.Duration((sent.Elapsed + 1500) * 1e6))) {
			refuse("ancillary lease-only refusal not excluded")
		}
		if rows["ancillary-observation-ended"].Elapsed-rows["ancillary-record-sent"].Elapsed < 2500 {
			refuse("ancillary held window incomplete")
		}
		if fdBefore.available && fdAfter.available && reflect.DeepEqual(fdBefore.fds, []int{2}) && fdBefore.at.Before(releaseAt) && !childExitAt.IsZero() && fdAfter.at.Before(childExitAt) {
			if reflect.DeepEqual(fdAfter.fds, []int{2}) {
				leakOutcome = "passed"
			} else {
				leakOutcome = "failed"
				refuse("receiver ancillary descriptor leaked")
			}
		}
	} else {
		for _, stage := range []string{"lifecycle-live-token-accepted", "lifecycle-stop-requested", "child-gate-invalidated", "child-authority-invalidated", "child-exit-reaped", "stale-token-refused", "terminal"} {
			if _, ok := rows[stage]; !ok {
				refuse("missing " + stage)
			}
		}
		if rows["child-gate-invalidated"].Reason != "invalidated" {
			refuse("real terminal gate invalidation not established")
		}
		if rows["terminal"].Reason != "lifecycle-only-complete" {
			refuse("lifecycle outcome incomplete")
		}
		if rows["child-gate-invalidated"].Elapsed >= rows["child-exit-reaped"].Elapsed {
			refuse("invalidation did not precede reap")
		}
		if rows["stale-token-refused"].Elapsed < rows["child-exit-reaped"].Elapsed {
			refuse("stale token checked before actual reap")
		}
		if _, exists := rows["stale-token-accepted"]; exists {
			refuse("stale token accepted")
		}
	}
	for name, data := range map[string][]byte{"milestones.ndjson": output.data, "stderr.txt": stderr.data} {
		if os.WriteFile(filepath.Join(evidence, name), data, 0600) != nil {
			t.Fatal("private case evidence unavailable")
		}
	}
	var helperMillis any
	var refusalMillis any
	if !helperCheckedAt.IsZero() {
		helperMillis = helperCheckedAt.Sub(start).Seconds() * 1000
	}
	if !refusalAt.IsZero() && !execAt.IsZero() {
		refusalMillis = refusalAt.Sub(execAt).Seconds() * 1000
	}
	facts := map[string]any{"case": which, "failure": failure, "failures": failures, "lanePeerStatus": map[string]string{"safety": rows["helper-safety-retained"].Reason, "frames": rows["helper-frames-retained"].Reason}, "laneStatusIsAuthentication": false, "exitCode": cmd.ProcessState.ExitCode(), "parentExecObserved": !execAt.IsZero(), "refusalAfterExecMs": refusalMillis, "liveHelperVerified": helperVerified, "helperInspectionMs": helperMillis, "helperInspectionFailure": inspectionError, "childKernelExit": childExited, "states": stateEvidence, "literalPIDReuseAttempted": false, "receiverLeakOutcome": leakOutcome, "receiverNullFDCounts": map[string]any{"before": len(fdBefore.fds), "after": len(fdAfter.fds), "beforeAvailable": fdBefore.available, "afterAvailable": fdAfter.available}, "controlledHubReleaseMs": releaseAt.Sub(start).Seconds() * 1000, "independentCLIRoleVerifierBranchProven": false}
	raw, _ := json.MarshalIndent(facts, "", "  ")
	if os.WriteFile(filepath.Join(evidence, "driver-observations.json"), append(raw, '\n'), 0600) != nil {
		t.Fatal("private observation evidence unavailable")
	}
	if failure != "" {
		t.Fatal(failure)
	}
	t.Logf("signed %s case PASS; independent CLI role branch and literal PID reuse not claimed", which)
}
