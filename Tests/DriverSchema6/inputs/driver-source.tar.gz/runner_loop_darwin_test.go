package integration

import (
	"testing"
	"time"
)

func runRunnerControllerLoop(deadline time.Time, unfinished func() bool, step func(<-chan time.Time) bool) bool {
	timer := time.NewTimer(time.Until(deadline))
	defer timer.Stop()
	for unfinished() {
		if !time.Now().Before(deadline) {
			return false
		}
		if !step(timer.C) {
			return false
		}
	}
	return true
}
func markRunnerLoopDeadline(result *runnerCaseResult, readerDone bool) {
	result.Result = "FAIL"
	result.LoopDeadlineExceeded = true
	result.MetadataReaderSettled = readerDone
	result.AppReaped = result.AppReaped && readerDone
	result.DirectChildrenGone = false
	result.RootsRemoved = false
	result.OwnedWindowsGone = false
	if !readerDone {
		result.ExitCode = -1
	}
	if len(result.Failures) < 32 {
		result.Failures = append(result.Failures, "absolute case deadline reached; reader/reap/cleanup unconfirmed")
	}
}
func runnerBlocksLaterCases(result runnerCaseResult) bool {
	return !result.NativeObservationSettled && len(result.NativeEvidence.Observations)>0 || result.AppPID > 0 && (result.MonitorLoss || result.LoopDeadlineExceeded || !result.MetadataReaderSettled || !result.DirectChildrenGone || !result.RootsRemoved || !result.AppReaped || !result.OwnedWindowsGone || len(result.RootAssociatedProcesses) > 0)
}
func TestRunnerAbsoluteLoopDeadlineStopsHeldReaderAndFailedCleanup(t *testing.T) {
	heldReader := make(chan runnerReadResult)
	execution := make(chan struct{})
	close(execution)
	executionC := (<-chan struct{})(execution)
	ticker := time.NewTicker(time.Millisecond)
	defer ticker.Stop()
	readerDone := false
	cleanupAttempts := 0
	var cleanupDeadline time.Time
	done := make(chan bool, 1)
	started := time.Now()
	deadline := started.Add(20 * time.Millisecond)
	go func() {
		done <- runRunnerControllerLoop(deadline, func() bool { return !readerDone }, func(hard <-chan time.Time) bool {
			select {
			case <-heldReader:
				readerDone = true
			case <-executionC:
				executionC = nil
			case <-ticker.C:
				cleanupAttempts++
				cleanupDeadline = time.Now().Add(time.Hour)
			case <-hard:
				return false
			}
			return true
		})
	}()
	select {
	case completed := <-done:
		if completed || readerDone || cleanupAttempts == 0 || cleanupDeadline.Before(deadline) {
			t.Fatal("held reader/failed cleanup was treated as complete")
		}
	case <-time.After(time.Second):
		t.Fatal("absolute loop bound depended on reader or cleanup completion")
	}
	result := runnerCaseResult{AppPID: 42, Result: "PASS", AppReaped: true, DirectChildrenGone: true, RootsRemoved: true, OwnedWindowsGone: true}
	markRunnerLoopDeadline(&result, readerDone)
	if result.Result != "FAIL" || result.AppReaped || result.MetadataReaderSettled || result.DirectChildrenGone || !runnerBlocksLaterCases(result) {
		t.Fatal("unconfirmed reap was inferred or later cases allowed")
	}
}
func TestRunnerLoopDrainsBufferedRowsAfterReaderCompletion(t *testing.T) {
	rows := make(chan int, 2)
	rows <- 1
	rows <- 2
	close(rows)
	finished := make(chan struct{}, 1)
	finished <- struct{}{}
	readerDone := false
	count := 0
	completed := runRunnerControllerLoop(time.Now().Add(time.Second), func() bool { return !readerDone || rows != nil }, func(hard <-chan time.Time) bool {
		select {
		case _, ok := <-rows:
			if ok {
				count++
			} else {
				rows = nil
			}
		case <-finished:
			readerDone = true
		case <-hard:
			return false
		}
		return true
	})
	if !completed || !readerDone || count != 2 {
		t.Fatal("reader exit discarded buffered final evidence")
	}
}
