package integration

import (
	"bytes"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"path/filepath"
	"strconv"
	"strings"
)

type runnerSliceMember struct {
	CPU, Subtype int64
	Offset, Size uint64
	Type         int64
	Hash, Full   []byte
}

type runnerCodeReceipt struct {
	Role, Site, Step string
	Passed           bool
	PID              int64
	Statuses         [][2]int64
	Selected         *runnerSliceMember
	Members          []runnerSliceMember
	Compared         map[string]json.RawMessage
}

func runnerReceiptText(raw json.RawMessage, max int) (string, error) {
	var value string
	if json.Unmarshal(raw, &value) != nil || value == "" || len(value) > max || strings.ContainsAny(value, "\x00\r\n") {
		return "", fmt.Errorf("invalid receipt text")
	}
	return value, nil
}

func runnerReceiptCounter(raw json.RawMessage) (uint64, error) {
	var value string
	if json.Unmarshal(raw, &value) != nil || !captureCanonical(value) {
		return 0, fmt.Errorf("noncanonical receipt counter")
	}
	return strconv.ParseUint(value, 10, 64)
}

func runnerReceiptData(raw json.RawMessage, min, max int) ([]byte, error) {
	var text string
	if json.Unmarshal(raw, &text) != nil {
		return nil, fmt.Errorf("invalid encoded receipt data")
	}
	value, e := base64.StdEncoding.Strict().DecodeString(text)
	if e != nil || len(value) < min || len(value) > max || base64.StdEncoding.EncodeToString(value) != text {
		return nil, fmt.Errorf("invalid receipt data length/encoding")
	}
	return value, nil
}

func runnerReceiptIdentity(raw json.RawMessage) (int64, []byte, []byte, error) {
	a, e := runnerRawArray(raw, 3)
	if e != nil {
		return 0, nil, nil, e
	}
	kind, e := runnerRawInteger(a[0], 1, 4)
	if e != nil {
		return 0, nil, nil, e
	}
	hash, e := runnerReceiptData(a[1], 20, 20)
	if e != nil {
		return 0, nil, nil, e
	}
	full, e := runnerReceiptData(a[2], 20, 64)
	if e != nil || !bytes.Equal(full[:20], hash) {
		return 0, nil, nil, fmt.Errorf("full digest/hash prefix mismatch")
	}
	return kind, hash, full, nil
}

func runnerDecodeMember(raw json.RawMessage) (runnerSliceMember, error) {
	var v runnerSliceMember
	a, e := runnerRawArray(raw, 7)
	if e != nil {
		return v, e
	}
	if v.CPU, e = runnerRawInteger(a[0], math.MinInt32, math.MaxInt32); e != nil {
		return v, e
	}
	if v.Subtype, e = runnerRawInteger(a[1], math.MinInt32, math.MaxInt32); e != nil {
		return v, e
	}
	if v.Offset, e = runnerReceiptCounter(a[2]); e != nil {
		return v, e
	}
	if v.Size, e = runnerReceiptCounter(a[3]); e != nil || v.Size < 28 || v.Offset > 128*1024*1024 || v.Size > 128*1024*1024-v.Offset {
		return v, fmt.Errorf("slice extent outside file limit")
	}
	identity, e := json.Marshal([]json.RawMessage{a[4], a[5], a[6]})
	if e != nil {
		return v, e
	}
	if v.Type, v.Hash, v.Full, e = runnerReceiptIdentity(identity); e != nil {
		return v, e
	}
	return v, nil
}

func runnerDecodeMembers(raw json.RawMessage) ([]runnerSliceMember, error) {
	var a []json.RawMessage
	if json.Unmarshal(raw, &a) != nil || len(a) < 1 || len(a) > 8 {
		return nil, fmt.Errorf("invalid member catalogue")
	}
	out := make([]runnerSliceMember, 0, len(a))
	for _, raw := range a {
		v, e := runnerDecodeMember(raw)
		if e != nil {
			return nil, e
		}
		for _, previous := range out {
			if v.CPU == previous.CPU && v.Subtype == previous.Subtype || v.Offset < previous.Offset+previous.Size && previous.Offset < v.Offset+v.Size {
				return nil, fmt.Errorf("duplicate/overlapping members")
			}
		}
		out = append(out, v)
	}
	return out, nil
}

func runnerReceiptRequirement(role string) (string, bool) {
	if !runnerKnownIdentifier(role) {
		return "", false
	}
	if strings.HasPrefix(role, "com.apple.") {
		return `anchor apple and identifier "` + role + `"`, true
	}
	team := "S8LB56P782"
	if role == "com.google.Chrome" {
		team = "EQHXZ8M8AV"
	}
	return `anchor apple generic and certificate leaf[field.1.2.840.113635.100.6.1.13] exists and certificate 1[field.1.2.840.113635.100.6.2.6] exists and identifier "` + role + `" and certificate leaf[subject.OU] = "` + team + `"`, true
}

func runnerReceiptKernel(raw json.RawMessage) (string, []byte, uint64, error) {
	a, e := runnerRawArray(raw, 3)
	if e != nil {
		return "", nil, 0, e
	}
	path, e := runnerReceiptText(a[0], 4096)
	if e != nil || !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return "", nil, 0, fmt.Errorf("noncanonical kernel path")
	}
	hash, e := runnerReceiptData(a[1], 20, 20)
	if e != nil {
		return "", nil, 0, e
	}
	flags, e := runnerReceiptCounter(a[2])
	if e != nil || flags > math.MaxUint32 {
		return "", nil, 0, fmt.Errorf("invalid kernel flags")
	}
	return path, hash, flags, nil
}

func runnerReceiptIncarnation(raw json.RawMessage, pid int64) (*runnerBSDValue, error) {
	var a []string
	if json.Unmarshal(raw, &a) != nil || len(a) != 9 {
		return nil, fmt.Errorf("invalid binding incarnation")
	}
	numbers := make([]uint64, 7)
	for i := range numbers {
		if !captureCanonical(a[i]) {
			return nil, fmt.Errorf("noncanonical incarnation")
		}
		n, e := strconv.ParseUint(a[i], 10, 64)
		if e != nil {
			return nil, e
		}
		numbers[i] = n
	}
	var observed []json.RawMessage
	if runnerStrict([]byte(a[8]), &observed, 3072) != nil || len(observed) != 5 {
		return nil, fmt.Errorf("missing complete incarnation controls")
	}
	r := runnerBSDReceipt{PID: pid}
	var e error
	if r.SelfPID, e = runnerRawInteger(observed[0], 1, math.MaxInt32); e != nil {
		return nil, e
	}
	if r.ParentPID, e = runnerRawInteger(observed[1], 1, math.MaxInt32); e != nil {
		return nil, e
	}
	for i := range r.Controls {
		if r.Controls[i], e = runnerDecodeBSDBracket(observed[i+2]); e != nil {
			return nil, e
		}
	}
	if r.Target, e = runnerDecodeBSDBracket(observed[4]); e != nil {
		return nil, e
	}
	selected, used := runnerBSDSelect(r)
	if selected == nil || a[7] != map[bool]string{false: "proc", true: "sysctl"}[used] || numbers[0] != uint64(selected.PID) || numbers[1] != uint64(selected.Parent) || numbers[2] != uint64(selected.Effective) || numbers[3] != uint64(selected.Real) || numbers[4] != uint64(selected.Saved) || numbers[5] != selected.Seconds || numbers[6] != selected.Microseconds {
		return nil, fmt.Errorf("incarnation disagrees with actual raw BSD receipt")
	}
	return selected, nil
}

func decodeRunnerCodeReceipt(fields map[string]json.RawMessage) (runnerCodeReceipt, error) {
	var r runnerCodeReceipt
	var e error
	if r.Role, e = runnerText(fields, "role"); e != nil || !runnerKnownIdentifier(r.Role) {
		return r, fmt.Errorf("unknown code-binding role")
	}
	if r.Site, e = runnerText(fields, "site"); e != nil || !runnerOneOf(r.Site, "preflight initial-live live live-copy signal self system-owner child-initial child-signal") {
		return r, fmt.Errorf("unknown code-binding site")
	}
	if r.Step, e = runnerText(fields, "step"); e != nil || !runnerOneOf(r.Step, "open catalogue live kernel-platform live-kernel unique selected-validity recheck complete child-complete child-refused") {
		return r, fmt.Errorf("unknown code-binding step")
	}
	if r.Passed, e = runnerBool(fields, "passed"); e != nil {
		return r, e
	}
	var statuses []json.RawMessage
	if json.Unmarshal(fields["statuses"], &statuses) != nil || len(statuses) > 32 {
		return r, fmt.Errorf("invalid validity status table")
	}
	for _, raw := range statuses {
		a, err := runnerRawArray(raw, 2)
		if err != nil {
			return r, err
		}
		flags, err := runnerRawInteger(a[0], 0, 25)
		if err != nil || !runnerOneOf(strconv.FormatInt(flags, 10), "0 9 16 25") {
			return r, fmt.Errorf("unknown validity flags")
		}
		status, err := runnerRawInteger(a[1], math.MinInt32, math.MaxInt32)
		if err != nil {
			return r, err
		}
		r.Statuses = append(r.Statuses, [2]int64{flags, status})
	}
	if string(fields["selected"]) != "null" {
		selected, err := runnerDecodeMember(fields["selected"])
		if err != nil {
			return r, err
		}
		r.Selected = &selected
	}
	if json.Unmarshal(fields["compared"], &r.Compared) != nil || r.Compared == nil {
		return r, fmt.Errorf("invalid binding comparison object")
	}
	if runnerOneOf(r.Site, "child-initial child-signal") {
		return runnerDecodeChildBoundary(r)
	}
	allowed := "pid requirement expected expectedCatalogue path operations information failure file members incarnationBefore incarnationAfter kernelBefore kernelAfter live"
	for key := range r.Compared {
		if !runnerOneOf(key, allowed) {
			return r, fmt.Errorf("unknown binding comparison")
		}
	}
	rule, _ := runnerReceiptRequirement(r.Role)
	if actual, err := runnerReceiptText(r.Compared["requirement"], 1024); err != nil || actual != rule {
		return r, fmt.Errorf("code receipt requirement mismatch")
	}
	if r.Site == "preflight" {
		if string(r.Compared["pid"]) != "null" || r.Selected != nil {
			return r, fmt.Errorf("preflight invents a live selection")
		}
	} else if r.PID, e = runnerInt(r.Compared, "pid", 1, math.MaxInt32); e != nil {
		return r, e
	}
	if raw, ok := r.Compared["members"]; ok {
		if r.Members, e = runnerDecodeMembers(raw); e != nil {
			return r, e
		}
	}
	if !r.Passed {
		return r, nil
	}
	if r.Step != "complete" || len(r.Members) == 0 {
		return r, fmt.Errorf("successful receipt lacks completed catalogue")
	}
	if e := runnerValidateSuccessfulCodeReceipt(r); e != nil {
		return r, e
	}
	return r, nil
}

func runnerDecodeChildBoundary(r runnerCodeReceipt) (runnerCodeReceipt, error) {
	if r.Role != "ai.sliccy.slicc" || r.Selected != nil || len(r.Statuses) != 0 || r.Passed != (r.Step == "child-complete") || !runnerOneOf(r.Step, "child-complete child-refused") {
		return r, fmt.Errorf("invalid CLI boundary receipt")
	}
	for key := range r.Compared {
		if !runnerOneOf(key, "pid signal incarnation expected") {
			return r, fmt.Errorf("unknown child comparison")
		}
	}
	var e error
	if r.PID, e = runnerInt(r.Compared, "pid", 1, math.MaxInt32); e != nil {
		return r, e
	}
	if r.Site == "child-initial" {
		if string(r.Compared["signal"]) != "null" {
			return r, fmt.Errorf("initial child has signal")
		}
	} else {
		signal, err := runnerInt(r.Compared, "signal", 1, 31)
		if err != nil || signal != 18 && signal != 15 && signal != 9 {
			return r, fmt.Errorf("unexpected child signal")
		}
	}
	if r.Passed {
		if len(r.Compared) != 4 {
			return r, fmt.Errorf("successful child boundary missing identity")
		}
		a, err := runnerRawArray(r.Compared["incarnation"], 5)
		if err != nil {
			return r, err
		}
		if n, err := runnerRawInteger(a[0], 1, math.MaxInt32); err != nil || n != r.PID {
			return r, fmt.Errorf("child incarnation PID mismatch")
		}
		if _, err := runnerRawInteger(a[1], 1, math.MaxInt32); err != nil {
			return r, err
		}
		if _, err := runnerRawInteger(a[2], 0, math.MaxUint32); err != nil {
			return r, err
		}
		if seconds, err := runnerReceiptCounter(a[3]); err != nil || seconds == 0 {
			return r, fmt.Errorf("child start unavailable")
		}
		if micros, err := runnerReceiptCounter(a[4]); err != nil || micros >= 1000000 {
			return r, fmt.Errorf("invalid child start fraction")
		}
		if hash, err := runnerReceiptData(r.Compared["expected"], 20, 20); err != nil || hex.EncodeToString(hash) != "5da1a3199bd3f895bce2e53023c28ca1c33d249e" {
			return r, fmt.Errorf("child boundary not exact released CLI")
		}
	}
	return r, nil
}

func runnerValidateSuccessfulCodeReceipt(r runnerCodeReceipt) error {
	if string(r.Compared["failure"]) != "{}" {
		return fmt.Errorf("successful binding retains a native failure")
	}
	var expectedFlags []int64
	chrome := r.Role == "com.google.Chrome"
	if r.Site == "preflight" {
		for range r.Members {
			if chrome {
				expectedFlags = append(expectedFlags, 9)
			}
			expectedFlags = append(expectedFlags, 25)
		}
	} else {
		dynamic := int64(16)
		if chrome {
			dynamic = 0
		}
		expectedFlags = append(expectedFlags, dynamic)
		if chrome {
			expectedFlags = append(expectedFlags, 9)
		}
		expectedFlags = append(expectedFlags, 25, dynamic)
	}
	if len(r.Statuses) != len(expectedFlags) {
		return fmt.Errorf("missing actual validity calls")
	}
	for i, status := range r.Statuses {
		if status[0] != expectedFlags[i] || status[1] != 0 && !(chrome && status[0] == 25 && status[1] == -66999) {
			return fmt.Errorf("validity sequence/policy mismatch")
		}
	}
	var operations [][]int64
	var information []json.RawMessage
	if json.Unmarshal(r.Compared["operations"], &operations) != nil || len(operations) < 2 || len(operations) > 64 || json.Unmarshal(r.Compared["information"], &information) != nil || len(information) < 1 || len(information) > 12 {
		return fmt.Errorf("incomplete operation/information trace")
	}
	for _, op := range operations {
		if len(op) < 3 || len(op) > 4 || op[0] < 1 || op[0] > 8 || op[1] != 0 || op[2] != 1 {
			return fmt.Errorf("unsuccessful actual operation in completed binding")
		}
		if op[0] == 4 {
			if len(op) != 4 || op[3] < 0 || op[3] >= int64(len(information)) {
				return fmt.Errorf("missing information trace index")
			}
		} else if len(op) != 3 {
			return fmt.Errorf("unexpected information index")
		}
	}
	var metadata []string
	if json.Unmarshal(r.Compared["file"], &metadata) != nil || len(metadata) != 8 {
		return fmt.Errorf("missing retained file metadata")
	}
	for _, value := range metadata {
		if _, err := strconv.ParseInt(value, 10, 64); err != nil {
			return fmt.Errorf("invalid file metadata")
		}
	}
	if e := runnerValidateInformationTrace(r, operations, information, metadata); e != nil {
		return e
	}
	if r.Site == "preflight" {
		return nil
	}
	path, kernel, flags, e := runnerReceiptKernel(r.Compared["kernelBefore"])
	if e != nil {
		return e
	}
	finalPath, finalHash, finalFlags, e := runnerReceiptKernel(r.Compared["kernelAfter"])
	if e != nil || path != finalPath || !bytes.Equal(kernel, finalHash) || flags != finalFlags {
		return fmt.Errorf("kernel image changed across binding")
	}
	if strings.HasPrefix(r.Role, "com.apple.") && flags&0x04000000 == 0 {
		return fmt.Errorf("Apple system owner is not platform code")
	}
	kind, hash, full, e := runnerReceiptIdentity(r.Compared["live"])
	if e != nil || !bytes.Equal(hash, kernel) {
		return fmt.Errorf("live/kernel identity mismatch")
	}
	matches := 0
	var match runnerSliceMember
	for _, member := range r.Members {
		if member.Type == kind && bytes.Equal(member.Hash, hash) {
			matches++
			match = member
		}
	}
	if matches != 1 || r.Selected == nil || match.CPU != r.Selected.CPU || match.Subtype != r.Selected.Subtype || match.Offset != r.Selected.Offset || match.Size != r.Selected.Size || match.Type != r.Selected.Type || !bytes.Equal(match.Hash, r.Selected.Hash) || !bytes.Equal(match.Full, r.Selected.Full) || !bytes.Equal(match.Full, full) {
		return fmt.Errorf("selected slice is not the unique complete live identity")
	}
	if string(r.Compared["expected"]) != "null" {
		expected, err := runnerReceiptData(r.Compared["expected"], 20, 20)
		if err != nil || !bytes.Equal(expected, hash) {
			return fmt.Errorf("running hash differs from retained pin")
		}
	}
	before, e := runnerReceiptIncarnation(r.Compared["incarnationBefore"], r.PID)
	if e != nil {
		return e
	}
	after, e := runnerReceiptIncarnation(r.Compared["incarnationAfter"], r.PID)
	if e != nil || !runnerBSDEqual(before, after) || !bytes.Equal(r.Compared["incarnationBefore"], r.Compared["incarnationAfter"]) {
		return fmt.Errorf("unstable binding incarnation")
	}
	return nil
}

func runnerValidateInformationTrace(r runnerCodeReceipt, operations [][]int64, information []json.RawMessage, metadata []string) error {
	fileSize, e := strconv.ParseUint(metadata[2], 10, 64)
	if e != nil || fileSize < 28 || fileSize > 128*1024*1024 {
		return fmt.Errorf("invalid sampled file size")
	}
	mode, e := strconv.ParseUint(metadata[3], 10, 32)
	if e != nil || mode&0170000 != 0100000 {
		return fmt.Errorf("sampled file is not regular")
	}
	for _, member := range r.Members {
		if member.Offset > fileSize || member.Size > fileSize-member.Offset {
			return fmt.Errorf("member outside sampled file")
		}
	}
	expectedPath := ""
	if r.Site == "preflight" {
		expectedPath, e = runnerReceiptText(r.Compared["path"], 4096)
		if e != nil || !filepath.IsAbs(expectedPath) || filepath.Clean(expectedPath) != expectedPath {
			return fmt.Errorf("invalid catalogue path")
		}
	} else {
		expectedPath, _, _, e = runnerReceiptKernel(r.Compared["kernelBefore"])
		if e != nil {
			return e
		}
	}
	type info struct {
		kind       int64
		hash, full []byte
		offset     *uint64
	}
	values := make([]info, len(information))
	for i, raw := range information {
		a, err := runnerRawArray(raw, 5)
		if err != nil {
			return err
		}
		hash, err := runnerReceiptData(a[0], 20, 20)
		if err != nil {
			return err
		}
		path, err := runnerReceiptText(a[1], 4096)
		if err != nil || path != expectedPath {
			return fmt.Errorf("information path mismatch")
		}
		identifier, err := runnerReceiptText(a[2], 256)
		if err != nil || identifier != r.Role {
			return fmt.Errorf("information role mismatch")
		}
		kind, digest, full, err := runnerReceiptIdentity(a[3])
		if err != nil || !bytes.Equal(hash, digest) {
			return fmt.Errorf("information hash/identity mismatch")
		}
		values[i] = info{kind: kind, hash: digest, full: full}
		if string(a[4]) != "null" {
			offset, err := runnerReceiptCounter(a[4])
			if err != nil {
				return err
			}
			values[i].offset = &offset
		}
	}
	var expectedOps []int64
	if r.Site == "preflight" {
		expectedOps = []int64{5, 1}
	} else {
		expectedOps = []int64{8, 1, 2, 7, 3, 4, 5}
	}
	for range r.Members {
		expectedOps = append(expectedOps, 6, 4)
	}
	if r.Site != "preflight" {
		expectedOps = append(expectedOps, 4, 3, 4, 7, 8)
	}
	if len(operations) != len(expectedOps) {
		return fmt.Errorf("operation trace omits actual native steps")
	}
	memberIndex := 0
	liveInfo, selectedInfo, finalInfo := -1, -1, -1
	for i, op := range operations {
		if op[0] != expectedOps[i] {
			return fmt.Errorf("actual operation ordering mismatch")
		}
		if op[0] != 4 {
			continue
		}
		value := values[op[3]]
		if i > 0 && operations[i-1][0] == 6 {
			member := r.Members[memberIndex]
			memberIndex++
			if value.offset == nil || *value.offset != member.Offset || value.kind != member.Type || !bytes.Equal(value.hash, member.Hash) || !bytes.Equal(value.full, member.Full) {
				return fmt.Errorf("explicit slice information does not match actual catalogue member")
			}
		} else if i > 0 && operations[i-1][0] == 3 {
			if liveInfo < 0 {
				liveInfo = int(op[3])
			} else {
				finalInfo = int(op[3])
			}
		} else {
			selectedInfo = int(op[3])
		}
	}
	if memberIndex != len(r.Members) {
		return fmt.Errorf("member information count mismatch")
	}
	if r.Site == "preflight" {
		return nil
	}
	if liveInfo < 0 || selectedInfo < 0 || finalInfo < 0 || r.Selected == nil {
		return fmt.Errorf("missing live/selected/final information")
	}
	for _, index := range []int{liveInfo, selectedInfo, finalInfo} {
		v := values[index]
		if v.kind != r.Selected.Type || !bytes.Equal(v.hash, r.Selected.Hash) || !bytes.Equal(v.full, r.Selected.Full) {
			return fmt.Errorf("live/selected/final information identity differs")
		}
	}
	if v := values[selectedInfo]; v.offset == nil || *v.offset != r.Selected.Offset {
		return fmt.Errorf("selected native CodeOffset mismatch")
	}
	if expected := r.Compared["expectedCatalogue"]; string(expected) != "null" {
		members, err := runnerDecodeMembers(expected)
		if err != nil || len(members) != len(r.Members) {
			return fmt.Errorf("expected catalogue unavailable/changed")
		}
		for i, member := range members {
			current := r.Members[i]
			if member.CPU != current.CPU || member.Subtype != current.Subtype || member.Offset != current.Offset || member.Size != current.Size || member.Type != current.Type || !bytes.Equal(member.Hash, current.Hash) || !bytes.Equal(member.Full, current.Full) {
				return fmt.Errorf("pre-spawn catalogue changed")
			}
		}
	}
	return nil
}
