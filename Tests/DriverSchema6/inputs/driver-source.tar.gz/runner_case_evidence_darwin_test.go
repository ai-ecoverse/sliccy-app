package integration

func runnerMarkUnavailable(result *runnerCaseResult, reason string) {
	result.EvidenceUnavailable = true
	result.Result = "FAILED_TO_DEMONSTRATE"
	if len(result.UnavailableReasons) < 32 {
		result.UnavailableReasons = append(result.UnavailableReasons, reason)
	}
}

func runnerObserveCaseAvailability(result *runnerCaseResult, row runnerCaptureRow) {
	switch row.Stage {
	case "runner-preflight":
		screen, _ := runnerBool(row.Fields, "screenCapture")
		hosted, _ := runnerBool(row.Fields, "hosted")
		listen, _ := runnerBool(row.Fields, "listenEvent")
		post, _ := runnerBool(row.Fields, "postEvent")
		if !screen || !hosted || result.Case == "hotkey-stop" && (!listen || !post) {
			runnerMarkUnavailable(result, "runner-preflight-refused")
		}
	case "surface-unavailable":
		runnerMarkUnavailable(result, "surface-unavailable")
	case "terminal":
		outcome, _ := runnerText(row.Fields, "outcome")
		if outcome == "failed-to-demonstrate" {
			runnerMarkUnavailable(result, "terminal-unavailable")
		}
	}
}

func runnerFinalizeCasePass(result *runnerCaseResult) bool {
	if len(result.Failures) == 0 && !result.EvidenceUnavailable {
		result.Result = "PASS"
		return true
	}
	if result.EvidenceUnavailable && len(result.Failures) == 0 {
		result.Result = "FAILED_TO_DEMONSTRATE"
	}
	return false
}
