package integration

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type proofRows struct {
	data     []byte
	overflow bool
}

func (p *proofRows) Write(data []byte) (int, error) {
	n := len(data)
	if len(p.data)+n > 65536 {
		p.overflow = true
		return n, nil
	}
	p.data = append(p.data, data...)
	return n, nil
}

type proofRow struct {
	Schema   int      `json:"schema"`
	Stage    string   `json:"stage"`
	Elapsed  float64  `json:"elapsedMs"`
	Capture  *bool    `json:"capture"`
	Duration *float64 `json:"durationMs,omitempty"`
	Reason   string   `json:"reason,omitempty"`
}

func TestSignedAppNoCapturePair(t *testing.T) {
	executable := os.Getenv("SLICCY_SIGNED_PROOF_APP")
	if executable == "" {
		t.Skip("CI-signed proof executable not supplied")
	}
	evidence := os.Getenv("SLICCY_PROOF_EVIDENCE")
	if evidence == "" {
		t.Fatal("private evidence path required")
	}
	page, join := proofPage(t)
	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, executable, "--screen-proof")
	cmd.Env = proofEnvironment(t)
	cmd.Stdin = strings.NewReader(join + "\n")
	output := &proofRows{}
	cmd.Stdout = output
	stderr := &proofRows{}
	cmd.Stderr = stderr
	runErr := cmd.Run()
	status := fmt.Sprintf("error=%v\nexit=%d\nstdoutBytes=%d\nstderrBytes=%d\n", runErr, cmd.ProcessState.ExitCode(), len(output.data), len(stderr.data))
	if os.WriteFile(filepath.Join(evidence, "signed-app-launch.txt"), []byte(status), 0600) != nil {
		t.Fatal("launch evidence unavailable")
	}
	if os.WriteFile(filepath.Join(evidence, "signed-app-stderr.txt"), stderr.data, 0600) != nil {
		t.Fatal("launch evidence unavailable")
	}
	if output.overflow {
		t.Fatal("proof output exceeded metadata budget")
	}
	if os.WriteFile(filepath.Join(evidence, "signed-app-milestones.ndjson"), output.data, 0600) != nil {
		t.Fatal("could not retain private metadata evidence")
	}
	if strings.Contains(string(output.data), join) {
		t.Fatal("proof output disclosed synthetic join URL")
	}
	allowed := map[string]bool{"child-started": true, "lanes-authenticated": true, "heartbeat-ready": true, "synthetic-link-observed": true, "automatic-stop": true, "local-gate-invalidated": true, "revoke-queued": true, "native-ack": true, "child-authority-invalidated": true, "child-exit-reaped": true, "terminal": true}
	rows := map[string]proofRow{}
	decoder := json.NewDecoder(strings.NewReader(string(output.data)))
	decoder.DisallowUnknownFields()
	for {
		var row proofRow
		err := decoder.Decode(&row)
		if errors.Is(err, io.EOF) {
			break
		}
		if err != nil || row.Schema != 1 || row.Capture == nil || *row.Capture || !allowed[row.Stage] || math.IsNaN(row.Elapsed) || math.IsInf(row.Elapsed, 0) || row.Elapsed < 0 {
			t.Fatal("invalid diagnostic metadata schema")
		}
		if _, exists := rows[row.Stage]; exists && row.Stage != "synthetic-link-observed" {
			t.Fatal("duplicate diagnostic stage")
		}
		if row.Duration != nil && (math.IsNaN(*row.Duration) || math.IsInf(*row.Duration, 0) || *row.Duration < 0) {
			t.Fatal("invalid diagnostic duration")
		}
		rows[row.Stage] = row
	}
	for _, stage := range []string{"child-started", "lanes-authenticated", "heartbeat-ready", "synthetic-link-observed", "automatic-stop", "local-gate-invalidated", "revoke-queued", "native-ack", "child-authority-invalidated", "child-exit-reaped", "terminal"} {
		if _, ok := rows[stage]; !ok {
			t.Fatalf("missing diagnostic stage %s", stage)
		}
	}
	if runErr != nil || rows["terminal"].Reason != "ipc-only-complete" {
		t.Fatal("signed diagnostic reported failure")
	}
	if rows["local-gate-invalidated"].Duration == nil || *rows["local-gate-invalidated"].Duration > 50 {
		t.Fatal("local no-capture gate invalidation exceeded target")
	}
	if rows["native-ack"].Duration == nil || *rows["native-ack"].Duration > 1500 {
		t.Fatal("native Stop acknowledgement exceeded deadline")
	}
	if rows["native-ack"].Elapsed < rows["revoke-queued"].Elapsed {
		t.Fatal("ack preceded revoke admission")
	}
	select {
	case <-page.Ready():
	default:
		t.Fatal("no synthetic page HELLO")
	}
	hello, ok := page.PeerHello()
	if !ok || hello.Version != "1.58.1" {
		t.Fatal("unexpected bundled CLI version")
	}
	t.Logf("signed native no-capture pairing PASS; local gate %.3fms; matching native ack %.3fms", *rows["local-gate-invalidated"].Duration, *rows["native-ack"].Duration)
}
