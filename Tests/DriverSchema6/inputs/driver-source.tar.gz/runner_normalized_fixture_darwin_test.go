package integration

import (
 "bytes"
 "bufio"
 "context"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "io"
 "math"
 "os"
 "os/exec"
 "path/filepath"
 "reflect"
 "regexp"
 "strings"
 "testing"
 "time"
)

const runnerNormalizedFixtureDriver = "1111111111111111111111111111111111111111111111111111111111111111"

func runnerNormalizationOperations(t *testing.T)[]string {
 t.Helper();source:= "runner_security_native_darwin_test.go";if _,e:=os.Stat(source);e!=nil{source=filepath.Join("test/nativeproof",source)};raw,e:=os.ReadFile(source);if e!=nil{t.Fatal(e)}
 libs:=regexp.MustCompile(`"(/[^"\n]+)":\s*&c\.(?:cf|sec|system|proc)`).FindAllSubmatch(raw,-1)
 symbols:=regexp.MustCompile(`\{"((?:CF|Sec)[^"]+)",\s*&c\.`).FindAllSubmatch(raw,-1)
 if len(libs)!=4||len(symbols)!=27{t.Fatal("ASSERTION:v83-source-linked-bootstrap-count",len(libs),len(symbols))}
 var names []string
 for _,entry:=range libs{names=append(names,"library-open:"+string(entry[1]))}
 for _,entry:=range symbols{names=append(names,"resolve-symbol:"+string(entry[1]))}
 return names
}

func runnerNormalizationSnapshot(t *testing.T,selected,sequence,owners int,trace *runnerNativeTrace)runnerDiagnosticSnapshot {
 t.Helper();return runnerNormalizationSnapshotWithOperations(t,selected,sequence,owners,trace,runnerNormalizationOperations(t))
}

func runnerNormalizationSnapshotWithOperations(t *testing.T,selected,sequence,owners int,trace *runnerNativeTrace,bootstrap []string)runnerDiagnosticSnapshot {
 t.Helper();ctx:=context.Background()
 windowCount:=owners;if owners==128{windowCount=512}
 if !trace.ReserveSnapshotStorage(owners,windowCount){t.Fatal("ASSERTION:v83-fixture-snapshot-reservation")}
 begin:=func(name string,pid int,flags uint32){id,ok:=trace.Begin(name,pid,flags);if !ok{t.Fatal("ASSERTION:v83-snapshot-trace-capacity")};zero:=int32(0);if !trace.EndDetailed(id,&zero,true,&zero){t.Fatal("ASSERTION:v83-snapshot-trace-capacity")}}
 begin("CGWindowListCopyWindowInfo-diagnostic",900+selected,0)
 at:=float64(sequence*2000)
 snapshot:=runnerDiagnosticSnapshot{Sequence:sequence,Trigger:"cadence",RequestedMS:at,StartedMS:&at,WindowsMS:&at,FinishedMS:&at,Complete:true,Owners:[]runnerDiagnosticOwner{},Windows:[]independentWindow{}}
 for n:=0;n<owners;n++ {
  pid:=10000+selected*1000+n
  target:=runnerBSDValue{PID:int64(pid),Parent:1,Effective:501,Real:501,Saved:501,Seconds:uint64(1793881443+selected),Microseconds:uint64(n+1)}
  fakeBSD:=func(_ context.Context,tr *runnerNativeTrace,pid int)(runnerBSDReceipt,error){
   read:=func(p int64,proc bool)runnerBSDRead{value:=target;value.PID=p;if p==700{value.Parent=699};count:=int64(648);name:="sysctl-KERN_PROC_PID";flags:=uint32(0);if proc{count=136;name="proc_pidinfo-PROC_PIDTBSDINFO";flags=3};begin(name,int(p),flags);return runnerBSDRead{Executed:true,NativeReturn:0,Status:0,Count:count,Expected:count,Value:&value}}
   return runnerObserveBSDWith(int64(pid),func()int{return 700},func()int{return 699},func(p int64)runnerBSDRead{return read(p,false)},func(p int64)runnerBSDRead{return read(p,true)})
  }
  fakeCode:=func(_ context.Context,tr *runnerNativeTrace,pid int)(*runnerKernelCode,*runnerCodeInformation,*int32,error){
   for _,op:=range bootstrap{begin(op,pid,0)}
   for _,op:=range []struct{name string;flags uint32}{{"proc_pidpath",0},{"csops-CDHASH",5},{"csops-STATUS",0},{"SecCodeCopyGuestWithAttributes",0},{"SecCodeCopyStaticCode",0},{"SecCodeCopySigningInformation",3},{"SecRequirementCreateWithString",0},{"diagnostic-apple-anchor",16}}{begin(op.name,pid,op.flags)}
   status:=int32(0);offset:=uint64(16384);hash:=bytes.Repeat([]byte{byte(n+1)},20);kernel:=&runnerKernelCode{Path:"/System/Library/CoreServices/FixtureOwner.app/Contents/MacOS/FixtureOwner",Flags:0x04000000};copy(kernel.Hash[:],hash)
   return kernel,&runnerCodeInformation{Identifier:"com.apple.fixture-owner",Path:kernel.Path,Type:2,Hash:hash,Full:append(append([]byte(nil),hash...),bytes.Repeat([]byte{2},12)...),Offset:&offset},&status,nil
  }
  owner:=runnerObserveDiagnosticOwner(ctx,trace,pid,runnerDiagnosticOwnerOps{BSD:fakeBSD,Code:fakeCode})
  snapshot.Owners=append(snapshot.Owners,owner)
  snapshot.Windows=append(snapshot.Windows,independentWindow{ID:uint32(n+1),PID:pid,Layer:0,Rect:independentRect{float64(n*10),0,1024,768},OnScreen:true})
 }
 for len(snapshot.Windows)<windowCount{n:=len(snapshot.Windows);snapshot.Windows=append(snapshot.Windows,independentWindow{ID:uint32(n+1),PID:10000+selected*1000+n%owners,Layer:0,Rect:independentRect{float64(n),0,1024,768},OnScreen:true})}
 trace.mu.Lock();for i:=range trace.rows{trace.rows[i].ElapsedMS=float64(i)/32};trace.mu.Unlock()
 return snapshot
}

func runnerNormalizationCase(name string)runnerCaseResult {
 return runnerCaseResult{Schema:1,Case:name,Result:"FAIL",NativeObservationSettled:true,NativeEvidence:runnerControllerNativeEvidence{Phases:map[string][]runnerNativePhase{},Lost:map[string]bool{},Pending:map[string]int{},Settled:true}}
}
func runnerNormalizationPopulate(value reflect.Value,depth int) {
 if depth>16||!value.CanSet(){return}
 if value.Type()==reflect.TypeOf(json.RawMessage{}){value.SetBytes([]byte(`{"fabricated":true}`));return}
 if value.Type()==reflect.TypeOf(time.Time{}){value.Set(reflect.ValueOf(time.Unix(1793881443,123456789).UTC()));return}
 switch value.Kind() {
 case reflect.Bool:value.SetBool(true)
 case reflect.String:value.SetString("fabricated-identity-only")
 case reflect.Int,reflect.Int8,reflect.Int16,reflect.Int32,reflect.Int64:value.SetInt(1)
 case reflect.Uint,reflect.Uint8,reflect.Uint16,reflect.Uint32,reflect.Uint64:value.SetUint(1)
 case reflect.Float32,reflect.Float64:value.SetFloat(1.0000000000000002)
 case reflect.Pointer:value.Set(reflect.New(value.Type().Elem()));runnerNormalizationPopulate(value.Elem(),depth+1)
 case reflect.Struct:for i:=0;i<value.NumField();i++{runnerNormalizationPopulate(value.Field(i),depth+1)}
 case reflect.Slice:value.Set(reflect.MakeSlice(value.Type(),1,1));runnerNormalizationPopulate(value.Index(0),depth+1)
 case reflect.Array:for i:=0;i<value.Len();i++{runnerNormalizationPopulate(value.Index(i),depth+1)}
 case reflect.Map:
  value.Set(reflect.MakeMap(value.Type()));key:=reflect.New(value.Type().Key()).Elem();entry:=reflect.New(value.Type().Elem()).Elem();runnerNormalizationPopulate(key,depth+1);runnerNormalizationPopulate(entry,depth+1);value.SetMapIndex(key,entry)
 case reflect.Interface:if reflect.TypeOf("fabricated-observation").AssignableTo(value.Type()){value.Set(reflect.ValueOf("fabricated-observation"))}
 }
}

func runnerNormalizationPopulatedCase(name string)runnerCaseResult {
 var result runnerCaseResult;runnerNormalizationPopulate(reflect.ValueOf(&result).Elem(),0)
 result.Schema=1;result.Case=name;result.Result="FAIL";result.DiagnosticSnapshots=nil
 result.NativeEvidence=runnerControllerNativeEvidence{Observations:[]runnerObservation[any]{{Key:"fabricated",Value:"fabricated-observation",Submitted:time.Unix(1793881443,0).UTC(),Started:time.Unix(1793881443,1).UTC(),Finished:time.Unix(1793881443,2).UTC()}},Phases:map[string][]runnerNativePhase{},Lost:map[string]bool{},Pending:map[string]int{},Settled:true}
 return result
}

func runnerNormalizationExpectedFields(t *testing.T,result runnerCaseResult)map[string]json.RawMessage {
 t.Helper();result.DiagnosticSnapshots=nil;result.NativeEvidence.Phases=nil
 raw,e:=json.Marshal(result);if e!=nil{t.Fatal(e)};var fields map[string]json.RawMessage;if e=json.Unmarshal(raw,&fields);e!=nil{t.Fatal(e)};delete(fields,"diagnosticSnapshots")
 var native map[string]json.RawMessage;if e=json.Unmarshal(fields["nativeEvidence"],&native);e!=nil{t.Fatal(e)};delete(native,"phases");fields["nativeEvidence"],e=json.Marshal(native);if e!=nil{t.Fatal(e)}
 return fields
}

func runnerNormalizationRowHash(rows []runnerNativePhase)string{raw,_:=json.Marshal(rows);sum:=sha256.Sum256(raw);return hex.EncodeToString(sum[:])}

func TestRunnerV83TraceClassesAndActualCounts(t *testing.T) {
 ordinary:=newRunnerNativeTrace()
 for i:=0;i<256;i++{id,ok:=ordinary.Begin("ordinary",42,0);if !ok||!ordinary.End(id,nil,true){t.Fatal("ASSERTION:v83-ordinary-positive")}}
 if _,ok:=ordinary.Begin("overflow",42,0);ok{t.Fatal("ASSERTION:v83-ordinary-bound-unchanged")}
 for _,owners:=range []int{6,10,128}{trace:=newRunnerSnapshotTrace();runnerNormalizationSnapshot(t,0,1,owners,trace);rows,lost,pending:=trace.Snapshot();if lost||pending!=0||len(rows)!=2+114*owners{t.Fatal("ASSERTION:v83-snapshot-exact-count",owners,len(rows),lost,pending)}}
}

func TestRunnerV83InlineOwnerPhaseRoundTrip(t *testing.T) {
 trace:=newRunnerSnapshotTrace();snapshot:=runnerNormalizationSnapshot(t,0,1,6,trace)
 for _,owner:=range snapshot.Owners{raw,e:=runnerEncodeInlineOwner(owner);if e!=nil{t.Fatal(e)};decoded,e:=runnerDecodeInlineOwner(raw);if e!=nil||!reflect.DeepEqual(owner,decoded){t.Fatal("ASSERTION:v83-inline-owner-roundtrip",e)}}
 for _,owner:=range []runnerDiagnosticOwner{{PID:1},{PID:2,Errors:map[string]string{}}}{raw,e:=runnerEncodeInlineOwner(owner);if e!=nil{t.Fatal(e)};got,e:=runnerDecodeInlineOwner(raw);if e!=nil||!reflect.DeepEqual(owner,got){t.Fatal("ASSERTION:v83-inline-null-empty",e)}}
 zero:=int32(0);no:=false
 for _,value:=range []float64{math.Copysign(0,-1),0,math.SmallestNonzeroFloat64,1.0000000000000002,1234.567890123456} {
  row:=runnerNativePhase{Ordinal:1,Operation:"exact",PID:42,Flags:math.MaxUint32,Phase:"completed",ElapsedMS:value,ReturnValue:&zero,ValuePresent:&no,Errno:&zero}
  tuple,e:=runnerPhaseTuple(row,1);if e!=nil{t.Fatal(e)};raw,_:=json.Marshal(tuple);got,e:=runnerDecodePhase(raw,[]string{"exact"});if e!=nil||math.Float64bits(got.ElapsedMS)!=math.Float64bits(value)||!reflect.DeepEqual(row,got){t.Fatal("ASSERTION:v83-phase-exact-float-null",e)}
 }
 result:=runnerNormalizationCase("selected-window");result.Limitations=[]string{};result.Failures=[]string{};raw,_:=json.Marshal(result);var fields map[string]json.RawMessage;json.Unmarshal(raw,&fields);delete(fields,"diagnosticSnapshots")
 var native map[string]json.RawMessage;json.Unmarshal(fields["nativeEvidence"],&native);delete(native,"phases");fields["nativeEvidence"],_=json.Marshal(native)
 if e:=runnerValidateNormalizedCaseFields(fields);e!=nil{t.Fatal("ASSERTION:v83-case-field-ledger",e)}
 for key:=range fields{copy:=map[string]json.RawMessage{};for k,v:=range fields{copy[k]=v};delete(copy,key);if key!="limitations"&&key!="rootAssociatedError"&&runnerValidateNormalizedCaseFields(copy)==nil{t.Fatal("ASSERTION:v83-case-missing-field",key)}}
 for _,original:=range []runnerCaseResult{result,runnerNormalizationPopulatedCase("selected-window")} {
  dir:=t.TempDir();writer,e:=newRunnerCaseEvidenceWriter(dir,"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,&runnerNormalizationBudget{});if e!=nil{t.Fatal(e)}
  index,e:=writer.Commit(original);if e!=nil{t.Fatal("ASSERTION:v83-populated-case-write",e)}
  file,e:=os.Open(filepath.Join(dir,"driver-evidence.v3.ndjson"));if e!=nil{t.Fatal(e)}
  decoded,e:=readRunnerNormalized(file,"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,nil,nil);file.Close()
  if e!=nil||runnerCheckNormalizedIndex(index,decoded.Index)!=nil||!reflect.DeepEqual(runnerNormalizationExpectedFields(t,original),decoded.Fields){t.Fatal("ASSERTION:v83-all-case-fields-roundtrip",e)}
 }

}

func runnerNormalizationSmallStream(t *testing.T)([]byte,runnerCaseEvidenceIndex) {
 t.Helper();dir:=t.TempDir();w,e:=newRunnerCaseEvidenceWriter(dir,"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,&runnerNormalizationBudget{});if e!=nil{t.Fatal(e)}
 trace:=newRunnerSnapshotTrace();snapshot:=runnerNormalizationSnapshot(t,0,1,6,trace)
 if _,e=w.WriteJob(context.Background(),"diagnostic-snapshot:1",trace,&snapshot);e!=nil{t.Fatal(e)}
 result:=runnerNormalizationCase("selected-window");result.DiagnosticSnapshots=[]runnerDiagnosticSnapshot{snapshot};result.NativeEvidence.Lost["diagnostic-snapshot:1"]=false;result.NativeEvidence.Pending["diagnostic-snapshot:1"]=0
 index,e:=w.Commit(result);if e!=nil{t.Fatal(e)};raw,e:=os.ReadFile(filepath.Join(dir,"driver-evidence.v3.ndjson"));if e!=nil{t.Fatal(e)};return raw,index
}

func TestRunnerV83StrictOperationTableFooter(t *testing.T) {
 if _,e:=runnerNormalizedReadLine(bufio.NewReaderSize(strings.NewReader(strings.Repeat("x",(1<<20)+1)+"\n"),128<<10));e==nil{t.Fatal("ASSERTION:v83-oversize-line-refused-before-decode")}

 probe:=json.RawMessage(`[1,4096,42,0,0,"0000000000000000",null,null,null]`)
 if _,e:=runnerDecodePhase(probe,[]string{"known"});e==nil{t.Fatal("ASSERTION:v83-strict-operation-ref")}
 raw,index:=runnerNormalizationSmallStream(t)
 good,e:=readRunnerNormalized(bytes.NewReader(raw),"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,nil,nil);if e!=nil||runnerCheckNormalizedIndex(index,good.Index)!=nil{t.Fatal("ASSERTION:v83-stream-positive",e,index,good.Index)}
 lines:=bytes.Split(bytes.TrimSuffix(raw,[]byte{'\n'}),[]byte{'\n'})
 for _,fault:=range []string{"operation-ref","footer-digest","footer-count","missing-footer","duplicate-key","record-order","extra-field"} {
  changed:=make([][]byte,len(lines));for i:=range lines{changed[i]=append([]byte(nil),lines[i]...)}
  for i,line:=range changed {var f map[string]json.RawMessage;json.Unmarshal(line,&f);var tag string;json.Unmarshal(f["tag"],&tag)
   switch {case fault=="operation-ref"&&tag=="phase-chunk":var rows [][]json.RawMessage;json.Unmarshal(f["rows"],&rows);rows[0][1]=json.RawMessage("4096");f["rows"],_=json.Marshal(rows)
   case fault=="footer-digest"&&tag=="footer":f["prefixSHA256"],_=json.Marshal(strings.Repeat("0",64))
   case fault=="footer-count"&&tag=="footer":f["owners"]=json.RawMessage("0")
   case fault=="record-order"&&tag=="footer":f["sequence"]=json.RawMessage("1")
   case fault=="extra-field"&&tag=="header":f["unexpected"]=json.RawMessage("true")
   default:continue};changed[i],_=json.Marshal(f);break
  }
  bad:=append(bytes.Join(changed,[]byte{'\n'}),'\n')
  if fault=="missing-footer"{bad=append(bytes.Join(changed[:len(changed)-1],[]byte{'\n'}),'\n')}
  if fault=="duplicate-key"{bad=bytes.Replace(bad,[]byte(`"version":3`),[]byte(`"version":3,"version":3`),1)}
  if _,e:=readRunnerNormalized(bytes.NewReader(bad),"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,nil,nil);e==nil{t.Fatal("ASSERTION:v83-strict-"+fault)}
 }
}

type runnerNormalizationFailSink struct{}
func(runnerNormalizationFailSink)Write(p []byte)(int,error){return 0,io.ErrShortWrite}
func(runnerNormalizationFailSink)Close()error{return nil}

func TestRunnerV83SingleCopyOwnershipAndRetirement(t *testing.T) {
 if runnerNormalizationJSONReservation(map[string]any{"value":strings.Repeat("x",1<<20)})==nil{t.Fatal("ASSERTION:v83-preallocation-record-bound")}
 budget:=&runnerNormalizationBudget{};w,e:=newRunnerCaseEvidenceWriter(t.TempDir(),"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,budget);if e!=nil{t.Fatal(e)}
 observer:=newRunnerControllerObserver(context.Background(),time.Now().Add(5*time.Second));observer.evidence=w
 if e=observer.Submit("synthetic",func(ctx context.Context,tr *runnerNativeTrace)(any,error){id,ok:=tr.Begin("synthetic",42,0);if !ok||!tr.End(id,nil,true){return nil,fmt.Errorf("trace")};return true,nil});e!=nil{t.Fatal(e)}
 if _,e=observer.Wait([]string{"synthetic"},time.Second);e!=nil{t.Fatal(e)}
 evidence:=observer.Finish();rows,_,_:=observer.traces["synthetic"].Snapshot()
 if !evidence.Settled||len(rows)!=0||!observer.traces["synthetic"].IsRetired()||len(evidence.Phases)!=0{t.Fatal("ASSERTION:v83-raw-array-retired-after-sink")}
 result:=runnerNormalizationCase("selected-window");result.NativeEvidence=evidence
 index,e:=w.Commit(result);if e!=nil||!index.EvidenceComplete{t.Fatal("ASSERTION:v83-retirement-committed",e)}
 if budget.Memory!=0||budget.PeakMemory>runnerNormalizationMemoryLimit{t.Fatal("ASSERTION:v83-memory-reservations-released",budget)}
 active:=[]*runnerNativeTrace{};activeSnapshots:=[]runnerDiagnosticSnapshot{}
 for i:=0;i<4;i++{tr:=newRunnerSnapshotTrace();tr.memoryBudget=budget;activeSnapshots=append(activeSnapshots,runnerNormalizationSnapshot(t,i,i+1,10,tr));active=append(active,tr)}
 concurrentWriter,e:=newRunnerCaseEvidenceWriter(t.TempDir(),"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,budget);if e!=nil{t.Fatal(e)}
 concurrentResult:=runnerNormalizationCase("selected-window")
 for i,tr:=range active {
  key:=fmt.Sprintf("diagnostic-snapshot:%d",i+1);receipt,e:=concurrentWriter.WriteJob(context.Background(),key,tr,&activeSnapshots[i]);if e!=nil{t.Fatal("ASSERTION:v83-four-worker-writer-reservation",e)}
  if !tr.Retire(receipt.Rows,receipt.PrefixSHA256){t.Fatal("ASSERTION:v83-reservation-retirement")}
  activeSnapshots[i].Owners=nil;activeSnapshots[i].Windows=nil;concurrentResult.DiagnosticSnapshots=append(concurrentResult.DiagnosticSnapshots,activeSnapshots[i]);concurrentResult.NativeEvidence.Lost[key]=false;concurrentResult.NativeEvidence.Pending[key]=0
 }
 if _,e=concurrentWriter.Commit(concurrentResult);e!=nil{t.Fatal(e)}
 if budget.PeakMemory>runnerNormalizationMemoryLimit{t.Fatal("ASSERTION:v83-four-worker-reservation-bound")}
 if budget.Memory!=0{t.Fatal("ASSERTION:v83-reservation-leak",budget.Memory)}
 exhausted:=&runnerNormalizationBudget{Memory:runnerNormalizationMemoryLimit-1}
 refused:=newRunnerSnapshotTrace();refused.memoryBudget=exhausted
 if refused.ReserveSnapshotStorage(1,1){t.Fatal("ASSERTION:v83-reservation-before-owner-allocation")}
 if _,lost,_:=refused.Snapshot();!lost{t.Fatal("ASSERTION:v83-reservation-loss-latched")}

 encoded,_:=json.Marshal(index);if bytes.Contains(encoded,[]byte("synthetic"))||bytes.Contains(encoded,[]byte("observations")){t.Fatal("ASSERTION:v83-index-not-expanded")}
 failWriter,e:=newRunnerCaseEvidenceWriter(t.TempDir(),"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,&runnerNormalizationBudget{});if e!=nil{t.Fatal(e)};failWriter.file.Close();failWriter.file=runnerNormalizationFailSink{}
 blocked:=newRunnerControllerObserver(context.Background(),time.Now().Add(time.Second));blocked.evidence=failWriter
 blocked.Submit("sink-loss",func(ctx context.Context,tr *runnerNativeTrace)(any,error){id,_:=tr.Begin("synthetic",42,0);tr.End(id,nil,true);return true,nil});blocked.Wait([]string{"sink-loss"},time.Second)
 loss:=blocked.Finish();saved,_,_:=blocked.traces["sink-loss"].Snapshot();if loss.Settled||len(saved)!=2||blocked.traces["sink-loss"].IsRetired(){t.Fatal("ASSERTION:v83-sink-loss-retains-raw")}
}

func runnerNominalVolumeAccepted(normalized,tarBytes int64,files int)bool{return normalized<=32<<20&&tarBytes<=120<<20&&(128<<20)-tarBytes>=8<<20&&files<=1024}

func TestRunnerV83ActualFullNominalVolumeGate(t *testing.T) {
 root:=t.TempDir();budget:=&runnerNormalizationBudget{};names:=[]string{"selected-window","display-exclusion","authorization-exclusion","reciprocal-revoke","active-stop","hotkey-stop"};indices:=[]runnerCaseEvidenceIndex{}
 totalPhases,totalOwners:=0,0;bootstrap:=runnerNormalizationOperations(t)
 for c,name:=range names {
  owners:=6;if c==1||c==2{owners=10};dir:=filepath.Join(root,name);if e:=os.Mkdir(dir,0700);e!=nil{t.Fatal(e)}
  w,e:=newRunnerCaseEvidenceWriter(dir,name,runnerManifestSHA256,runnerNormalizedFixtureDriver,budget);if e!=nil{t.Fatal(e)}
  result:=runnerNormalizationPopulatedCase(name);hashes:=map[string]string{};snapshotHashes:=map[int]string{}
  for slot:=1;slot<=78;slot++ {
   trace:=newRunnerSnapshotTrace();trace.memoryBudget=budget;snapshot:=runnerNormalizationSnapshotWithOperations(t,c,slot,owners,trace,bootstrap);rows,_,_:=trace.Snapshot();key:=fmt.Sprintf("diagnostic-snapshot:%d",slot);hashes[key]=runnerNormalizationRowHash(rows);snapshotRaw,_:=json.Marshal(snapshot);snapshotSum:=sha256.Sum256(snapshotRaw);snapshotHashes[slot]=hex.EncodeToString(snapshotSum[:])
   receipt,e:=w.WriteJob(context.Background(),key,trace,&snapshot);if e!=nil{t.Fatal("ASSERTION:v83-full-nominal-write",e)};if !trace.Retire(receipt.Rows,receipt.PrefixSHA256){t.Fatal("retirement")}
   totalPhases+=len(rows);totalOwners+=len(snapshot.Owners);snapshot.Owners=nil;snapshot.Windows=nil;result.DiagnosticSnapshots=append(result.DiagnosticSnapshots,snapshot);result.NativeEvidence.Lost[key]=false;result.NativeEvidence.Pending[key]=0
  }
  index,e:=w.Commit(result);if e!=nil{t.Fatal(e)};indices=append(indices,index);if e=runnerSaveNormalizedIndex(filepath.Join(dir,"driver-observations.json"),index,budget);e!=nil{t.Fatal(e)}
  file,e:=os.Open(filepath.Join(dir,"driver-evidence.v3.ndjson"));if e!=nil{t.Fatal(e)}
  observed,e:=readRunnerNormalized(file,name,runnerManifestSHA256,runnerNormalizedFixtureDriver,func(key string,rows []runnerNativePhase)error{if runnerNormalizationRowHash(rows)!=hashes[key]{return fmt.Errorf("changed phase field")};return nil},func(snapshot runnerDiagnosticSnapshot)error{raw,e:=json.Marshal(snapshot);if e!=nil{return e};sum:=sha256.Sum256(raw);if hex.EncodeToString(sum[:])!=snapshotHashes[snapshot.Sequence]{return fmt.Errorf("changed complete snapshot/owner/BSD field")};return nil});file.Close()
  if e!=nil||runnerCheckNormalizedIndex(index,observed.Index)!=nil||!reflect.DeepEqual(runnerNormalizationExpectedFields(t,result),observed.Fields){t.Fatal("ASSERTION:v83-nominal-roundtrip",e)}
 }
 if totalPhases!=392184||totalOwners!=3432{t.Fatal("ASSERTION:v83-nominal-population",totalPhases,totalOwners)}
 if e:=runnerSaveNormalizedIndex(filepath.Join(root,"capture-suite.json"),map[string]any{"schema":2,"cases":indices},budget);e!=nil{t.Fatal(e)}
 packer:=os.Getenv("SLICCY_VOLUME_PACKER");if packer==""{t.Fatal("actual wrapper packer fixture unavailable")}
 ctx,cancel:=context.WithTimeout(context.Background(),30*time.Second);defer cancel()
 arguments:=[]string{packer,root}
 for _,name:=range []string{"SLICCY_RECEIPT_FIXTURE","SLICCY_CLOCK_FIXTURE","SLICCY_REFUSAL_FIXTURE","SLICCY_SURFACE_REFUSAL_FIXTURE","SLICCY_BUILD16_FIXTURE"}{path:=os.Getenv(name);if path==""{t.Fatal("ASSERTION:v83-actual-encoder-volume-input",name)};arguments=append(arguments,path)}
 command:=exec.CommandContext(ctx,"/usr/bin/python3",arguments...);command.Env=[]string{"PATH=/usr/bin:/bin"};output,e:=command.CombinedOutput();if e!=nil{t.Fatal("ASSERTION:v83-actual-packer",e,string(output))}
 var sizes struct{TarBytes int64 `json:"tarBytes"`;Files int `json:"files"`;ImageBytes int64 `json:"imageBytes"`;OtherBytes int64 `json:"otherBytes"`;OverflowRefused bool `json:"overflowRefused"`;ActualEncoderFixtureSHA256 map[string]string `json:"actualEncoderFixtureSHA256"`}
 if json.Unmarshal(output,&sizes)!=nil||sizes.ImageBytes!=64<<20||sizes.OtherBytes<16<<20||!sizes.OverflowRefused||!runnerNominalVolumeAccepted(budget.Bytes,sizes.TarBytes,sizes.Files){t.Fatal("ASSERTION:v83-nominal-positive-margin",budget.Bytes,string(output))}
 if len(sizes.ActualEncoderFixtureSHA256)!=5{t.Fatal("ASSERTION:v83-actual-encoder-volume-count")}
 for i,path:=range arguments[2:]{raw,e:=os.ReadFile(path);if e!=nil{t.Fatal(e)};sum:=sha256.Sum256(raw);if sizes.ActualEncoderFixtureSHA256[fmt.Sprint(i)]!=hex.EncodeToString(sum[:]){t.Fatal("ASSERTION:v83-actual-encoder-volume-hash")}}
 t.Logf("actual-packer=%s",output)
 if runnerNominalVolumeAccepted(33<<20,100<<20,10)||runnerNominalVolumeAccepted(1,121<<20,10)||runnerNominalVolumeAccepted(1,1,1025){t.Fatal("ASSERTION:v83-nominal-gate-not-bypassed")}
 t.Logf("normalization bytes=%d phases=%d owners=%d receipts=%d tar=%d margin=%d files=%d reservedPeak=%d",budget.Bytes,totalPhases,totalOwners,totalOwners*2,sizes.TarBytes,(128<<20)-sizes.TarBytes,sizes.Files,budget.PeakMemory)
}

func TestRunnerV83MaxFixtureOverflowAndLossBlockers(t *testing.T) {
 w,e:=newRunnerCaseEvidenceWriter(t.TempDir(),"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,&runnerNormalizationBudget{});if e!=nil{t.Fatal(e)}
 failed:=false;bootstrap:=runnerNormalizationOperations(t)
 for slot:=1;slot<=78;slot++{
  trace:=newRunnerSnapshotTrace();trace.memoryBudget=w.budget;snapshot:=runnerNormalizationSnapshotWithOperations(t,0,slot,128,trace,bootstrap);key:=fmt.Sprintf("diagnostic-snapshot:%d",slot)
  receipt,e:=w.WriteJob(context.Background(),key,trace,&snapshot)
  if slot==1&&(e!=nil||receipt.Rows!=14594||len(snapshot.Owners)!=128||len(snapshot.Windows)!=512){t.Fatal("ASSERTION:v83-maximum-first-snapshot-preserved",e)}
  if e!=nil{trace.Lose();failed=true;t.Logf("first maximum refusal slot=%d bytes=%d records=%d reserved=%d peak=%d cause=%v",slot,w.bytes,w.seq,w.budget.Memory,w.budget.PeakMemory,e);break}
  if !trace.Retire(receipt.Rows,receipt.PrefixSHA256){t.Fatal("ASSERTION:v83-maximum-success-retirement")}
 }
 if !failed{t.Fatal("ASSERTION:v83-maximum-refuses-bound")}
 result:=runnerNormalizationCase("selected-window");result.Result="FAIL";result.NormalizationFailed=true
 index,e:=w.Commit(result);if e==nil||index.EvidenceComplete||!runnerBlocksLaterCases(result){t.Fatal("ASSERTION:v83-overflow-blocks-later-case",e)}
 raw:=newRunnerNativeTrace();id,_:=raw.Begin("held",42,0);if raw.Retire(1,strings.Repeat("0",64)){t.Fatal("ASSERTION:v83-pending-never-retires")};raw.NotExecuted(id)
 loss:=newRunnerNativeTrace();loss.Lose();if _,lost,_:=loss.Snapshot();!lost{t.Fatal("ASSERTION:v83-loss-latched")}
}

func TestRunnerNormalizedIndexFinalizationDeadline(t *testing.T) {
 for _,selected:=range []string{"within-bound","late-index","late-commit","index-error","commit-error"}{t.Run(selected,func(t *testing.T){
  dir:=t.TempDir();budget:=&runnerNormalizationBudget{};writer,e:=newRunnerCaseEvidenceWriter(dir,"selected-window",runnerManifestSHA256,runnerNormalizedFixtureDriver,budget);if e!=nil{t.Fatal(e)}
  result:=runnerNormalizationCase("selected-window");result.Result="PASS"
  began:=time.Unix(1793881443,0);current:=began.Add(runnerCaseAbsoluteBudget-time.Millisecond)
  path:=filepath.Join(dir,"driver-observations.json");saves:=0
  runnerFinalizeNormalizedCase(&result,began,func(value runnerCaseResult)(runnerCaseEvidenceIndex,error){
   index,e:=writer.Commit(value)
   if selected=="late-commit"{current=began.Add(runnerCaseAbsoluteBudget+time.Nanosecond)}
   if selected=="commit-error"{return index,fmt.Errorf("fabricated commit failure")};return index,e
  },func(index runnerCaseEvidenceIndex)error{
   saves++;e:=runnerSaveNormalizedIndex(path,index,budget)
   if selected=="late-index"{current=began.Add(runnerCaseAbsoluteBudget+time.Nanosecond)}
   if selected=="index-error"{return fmt.Errorf("fabricated index failure")};return e
  },func()time.Time{return current})
  if saves!=1||result.normalizationIndex==nil{t.Fatal("ASSERTION:v83-index-finalization-called-once")}
  index:=*result.normalizationIndex
  if selected=="within-bound"{if result.Result!="PASS"||result.NormalizationFailed||index.Result!="PASS"||!index.EvidenceComplete||index.BlockLaterCases||runnerBlocksLaterCases(result){t.Fatal("ASSERTION:v83-index-finalization-positive")};return}
  if result.Result!="FAIL"||!result.NormalizationFailed||index.Result!="FAIL"||index.EvidenceComplete||!index.BlockLaterCases||!runnerBlocksLaterCases(result){t.Fatal("ASSERTION:v83-index-finalization-refuses-late-or-error")}
  if selected=="late-index"{
   reason:="private evidence index finalization exceeded absolute case deadline"
   if len(result.Failures)!=1||result.Failures[0]!=reason||len(index.Failures)!=1||index.Failures[0]!=reason{t.Fatal("ASSERTION:v83-index-deadline-named")}
   raw,e:=os.ReadFile(path);if e!=nil{t.Fatal(e)};var persisted runnerCaseEvidenceIndex;if json.Unmarshal(raw,&persisted)!=nil{t.Fatal("ASSERTION:v83-index-persisted-shape")}
   if persisted.Result!="PASS"||!persisted.EvidenceComplete||runnerCheckNormalizedIndex(persisted,index)==nil{t.Fatal("ASSERTION:v83-late-index-cannot-promote-stale-disk-pass")}
  }
 })}
}
