package integration

import (
 "encoding/json"
 "fmt"
 "math"
 "strconv"
 "strings"
 "testing"
 "time"
)

const runnerLaunchStages = "runner-launch-owner runner-launches-ready runner-launch-recheck runner-launches-verified runner-launches-armed runner-launches-closed runner-launches-failed"
const runnerLaunchFailures = "launch-bsd-before launch-bsd-after launch-instance launch-event-limit launch-payload launch-identity launch-registration launch-duplicate launch-revision launch-pending launch-deadline launch-cancelled launch-marker launch-lifecycle"
type runnerLaunchRow struct {
 Stage,Label,Reason string
 Revision uint64
 Original runnerBSDValue
 Before,After runnerBSDValue
 EventSequence int
 Times [6]float64 // notification, before begin/end, comparison, after begin/end
 Count,Pending int
 Failed bool
}
func decodeRunnerLaunch(row runnerCaptureRow)(v runnerLaunchRow,err error) {
 v.Stage=row.Stage;f:=row.Fields
 exact:=func(keys string)error{return runnerExactFields(f,strings.Fields("schema case capture stage elapsedMs eventElapsedMs "+keys))}
 revision:=func()error{n,e:=runnerReceiptCounter(f["revision"]);if e!=nil||n==0{return fmt.Errorf("launch revision")};v.Revision=n;return nil}
 switch row.Stage {
 case "runner-launch-owner","runner-launch-recheck":
  if exact("revision label pid parent uid startSeconds startMicroseconds eventSequence notificationMs sampleBeforeBeganMs sampleBeforeEndedMs instanceComparedMs sampleAfterBeganMs sampleAfterEndedMs instanceEqual before after bundleIdentifier finished terminated")!=nil{return v,fmt.Errorf("launch owner field set")}
  if e:=revision();e!=nil{return v,e};v.Label,err=runnerText(f,"label");if err!=nil||!runnerDiagnosticEnum(v.Label,"a-1 a-2 b-1 b-2"){return v,fmt.Errorf("launch fixed profile")}
  if v.Original.PID,err=runnerInt(f,"pid",1,math.MaxInt32);err!=nil{return v,err};if v.Original.Parent,err=runnerInt(f,"parent",1,math.MaxInt32);err!=nil{return v,err}
  uid,e:=runnerInt(f,"uid",0,math.MaxUint32);if e!=nil{return v,e};v.Original.Effective=uint32(uid)
  if v.Original.Seconds,err=runnerReceiptCounter(f["startSeconds"]);err!=nil||v.Original.Seconds==0{return v,fmt.Errorf("launch original start")}
  micros,e:=runnerInt(f,"startMicroseconds",0,999999);if e!=nil{return v,e};v.Original.Microseconds=uint64(micros)
  seq,e:=runnerInt(f,"eventSequence",1,64);if e!=nil{return v,e};v.EventSequence=int(seq)
  for i,key:=range strings.Fields("notificationMs sampleBeforeBeganMs sampleBeforeEndedMs instanceComparedMs sampleAfterBeganMs sampleAfterEndedMs") {
   if string(f[key])=="null"||json.Unmarshal(f[key],&v.Times[i])!=nil||!finiteNonnegative(v.Times[i])||v.Times[i]>row.Event||i>0&&v.Times[i]<v.Times[i-1]{return v,fmt.Errorf("launch later sample ordering")}
  }
  equal,e:=runnerBool(f,"instanceEqual");if e!=nil||!equal{return v,fmt.Errorf("launch instance not equal")}
  finished,e:=runnerBool(f,"finished");if e!=nil||!finished{return v,fmt.Errorf("launch registration unfinished")}
  terminated,e:=runnerBool(f,"terminated");if e!=nil||terminated{return v,fmt.Errorf("launch instance terminated")}
  bundle,e:=runnerText(f,"bundleIdentifier");if e!=nil||bundle!="com.google.Chrome"{return v,fmt.Errorf("launch bundle")}
  before,e:=runnerDecodeBSDValue(f["before"]);if e!=nil||before==nil{return v,fmt.Errorf("launch before BSD")};after,e:=runnerDecodeBSDValue(f["after"]);if e!=nil||after==nil{return v,fmt.Errorf("launch after BSD")};v.Before=*before;v.After=*after
  originalMatches:=func(b runnerBSDValue)bool{o:=v.Original;return b.PID==o.PID&&b.Parent==o.Parent&&b.Effective==o.Effective&&b.Seconds==o.Seconds&&b.Microseconds==o.Microseconds}
  if !originalMatches(v.Before)||!originalMatches(v.After)||v.Before!=v.After{return v,fmt.Errorf("launch original BSD mismatch")}
 case "runner-launches-ready","runner-launches-verified":
  if exact("revision count")!=nil{return v,fmt.Errorf("launch milestone fields")};if e:=revision();e!=nil{return v,e};count,e:=runnerInt(f,"count",4,4);if e!=nil{return v,e};v.Count=int(count)
 case "runner-launches-armed":
  if exact("revision pending")!=nil{return v,fmt.Errorf("launch armed fields")};if e:=revision();e!=nil{return v,e};if _,e:=runnerInt(f,"pending",0,0);e!=nil{return v,e}
 case "runner-launches-closed":
  if exact("pending failed")!=nil{return v,fmt.Errorf("launch closed fields")};n,e:=runnerInt(f,"pending",0,65);if e!=nil{return v,e};v.Pending=int(n);v.Failed,err=runnerBool(f,"failed");if err!=nil{return v,err}
 case "runner-launches-failed":
  if exact("reason")!=nil{return v,fmt.Errorf("launch failure fields")};v.Reason,err=runnerText(f,"reason");if err!=nil||!runnerDiagnosticEnum(v.Reason,runnerLaunchFailures){return v,fmt.Errorf("launch failure enum")}
 default:return v,fmt.Errorf("launch stage")
 }
 return v,nil
}

type runnerLaunchLedger struct {
 Revision uint64
 Owners,Rechecks map[string]runnerLaunchRow
 Ready,Verified,Armed,Closed,Failed bool
}
func (l *runnerLaunchLedger) Add(v runnerLaunchRow)error {
 if l.Closed{return fmt.Errorf("launch metadata after close")}
 if v.Stage=="runner-launches-failed"{if l.Failed{return fmt.Errorf("duplicate launch failure")};l.Failed=true;return nil}
 if v.Stage=="runner-launches-closed"{l.Closed=true;l.Failed=l.Failed||v.Failed||v.Pending!=0;return nil}
 if l.Failed{return fmt.Errorf("launch readiness after failure")}
 if l.Revision==0{l.Revision=v.Revision};if v.Revision!=l.Revision{return fmt.Errorf("launch candidate revision changed")}
 switch v.Stage {
 case "runner-launch-owner":
  if l.Ready{return fmt.Errorf("launch owner after ready")};if l.Owners==nil{l.Owners=map[string]runnerLaunchRow{}}
  if _,ok:=l.Owners[v.Label];ok{return fmt.Errorf("duplicate launch owner")}
  for _,old:=range l.Owners{if old.Original.PID==v.Original.PID||old.EventSequence==v.EventSequence{return fmt.Errorf("launch duplicate PID/event")}}
  l.Owners[v.Label]=v
 case "runner-launches-ready":if l.Ready||len(l.Owners)!=4{return fmt.Errorf("launch ready count/order")};l.Ready=true
 case "runner-launch-recheck":
  if !l.Ready||l.Verified{return fmt.Errorf("launch recheck order")};if l.Rechecks==nil{l.Rechecks=map[string]runnerLaunchRow{}};if _,ok:=l.Rechecks[v.Label];ok{return fmt.Errorf("duplicate launch recheck")}
  old,ok:=l.Owners[v.Label];if !ok||old.Original!=v.Original||old.Before!=v.Before||old.EventSequence!=v.EventSequence||old.Times[0]!=v.Times[0]||v.Times[1]<old.Times[5]{return fmt.Errorf("launch recheck original notification changed")};l.Rechecks[v.Label]=v
 case "runner-launches-verified":if !l.Ready||l.Verified||len(l.Rechecks)!=4{return fmt.Errorf("launch verification count/order")};l.Verified=true
 case "runner-launches-armed":if !l.Verified||l.Armed{return fmt.Errorf("launch arm order")};l.Armed=true
 default:return fmt.Errorf("launch ledger stage")
 };return nil
}
func(l *runnerLaunchLedger)Complete(required bool)error {
 if !required{if l.Revision!=0||l.Closed||l.Failed{return fmt.Errorf("unexpected launch handshake")};return nil}
 if !l.Ready||!l.Verified||!l.Armed||!l.Closed||l.Failed{return fmt.Errorf("incomplete launch handshake")};return nil
}
func(l *runnerLaunchLedger)MatchIndependent(processes map[int]runnerProcessFact,owned map[int]runnerSpawnObservation)error {
 if !l.Ready||l.Failed||len(l.Owners)!=4{return fmt.Errorf("launch candidate unavailable")}
 for profile,row:=range l.Owners {
  fact,ok:=processes[int(row.Original.PID)];spawn,has:=owned[int(row.Original.PID)]
  if !ok||!has||fact.Label!="chrome-"+profile||fact.Identity!=row.Before||!runnerSpawnMatchesFact(spawn,fact){return fmt.Errorf("launch independent original identity mismatch")}
 };return nil
}

type runnerLaunchGateEvidence struct {
 Revision uint64 `json:"revision"`
 ReadyReceived time.Time `json:"readyReceived"`
 IdentityComplete time.Time `json:"identityComplete"`
 PagesComplete time.Time `json:"pagesComplete"`
 WindowsComplete time.Time `json:"windowsComplete"`
 Windows []independentWindow `json:"windows"`
 MarkerBefore time.Time `json:"markerBefore"`
 MarkerAfter time.Time `json:"markerAfter"`
 MarkerComplete bool `json:"markerComplete"`
 Error string `json:"error"`
}

func decodeRunnerWorkspaceStop(row runnerCaptureRow)error {
 f:=row.Fields
 if runnerExactNullableFields(f,strings.Fields("schema case capture stage elapsedMs eventElapsedMs sequence origin stopCallBeforeMs stopCallAfterMs applicationStatus pid bundle"),"pid")!=nil{return fmt.Errorf("workspace attribution fields")}
 if _,e:=runnerInt(f,"sequence",1,64);e!=nil{return e}
 origin,e:=runnerText(f,"origin");if e!=nil||!runnerDiagnosticEnum(origin,"workspace-launch workspace-terminate"){return fmt.Errorf("workspace attribution origin")}
 var before,after float64
 if json.Unmarshal(f["stopCallBeforeMs"],&before)!=nil||json.Unmarshal(f["stopCallAfterMs"],&after)!=nil||!finiteNonnegative(before)||!finiteNonnegative(after)||before!=row.Event||after<before||after>row.Elapsed{return fmt.Errorf("workspace stop ordering")}
 status,e:=runnerText(f,"applicationStatus");if e!=nil||!runnerDiagnosticEnum(status,"missing-application invalid-application invalid-pid present"){return fmt.Errorf("workspace payload status")}
 if status=="present"{if _,e=runnerInt(f,"pid",1,math.MaxInt32);e!=nil{return e}}else if string(f["pid"])!="null"{return fmt.Errorf("workspace unavailable PID")}
 bundle,e:=runnerDiagnosticIdentifierValue(f["bundle"]);if e!=nil{return e};if runnerDiagnosticEnum(status,"missing-application invalid-application")&&bundle.Status!="unavailable"{return fmt.Errorf("workspace absent object identifier")};return nil
}

func TestRunnerLaunchSchemaRequiresInstanceEqualityAndOriginalBSD(t *testing.T) {
 // App ScreenRunnerBSD.Sample.fields emits a 7-array [pid,parent,effective,real,saved,"seconds",microseconds];
 // runnerDecodeBSDValue accepts only that shape. Fixture must round-trip the real decoder (not json.Marshal of the struct).
 encodeBSD:=func(v runnerBSDValue)json.RawMessage{
  raw,_:=json.Marshal([]any{v.PID,v.Parent,v.Effective,v.Real,v.Saved,strconv.FormatUint(v.Seconds,10),v.Microseconds})
  return raw
 }
 row:=runnerCaptureRow{Schema:6,Case:"display-exclusion",Stage:"runner-launch-owner",Elapsed:40,Event:30,Fields:map[string]json.RawMessage{}}
 bools:=func(m map[string]any){for k,v:=range m{raw,_:=json.Marshal(v);row.Fields[k]=raw}}
 bools(map[string]any{"schema":6,"case":"display-exclusion","capture":true,"stage":"runner-launch-owner","elapsedMs":40.0,"eventElapsedMs":30.0,
  "revision":"1","label":"a-1","pid":101,"parent":50,"uid":501,"startSeconds":"10","startMicroseconds":20,"eventSequence":1,
  "notificationMs":1.0,"sampleBeforeBeganMs":2.0,"sampleBeforeEndedMs":3.0,"instanceComparedMs":4.0,"sampleAfterBeganMs":5.0,"sampleAfterEndedMs":6.0,
  "instanceEqual":true,"finished":true,"terminated":false,"bundleIdentifier":"com.google.Chrome"})
 before:=runnerBSDValue{PID:101,Parent:50,Effective:501,Real:501,Saved:501,Seconds:10,Microseconds:20}
 raw:=encodeBSD(before);row.Fields["before"]=raw;row.Fields["after"]=raw
 decoded,e:=runnerDecodeBSDValue(raw);if e!=nil||decoded==nil||*decoded!=before{t.Fatalf("ASSERTION:launch-bsd-array-roundtrip %v",e)}
 v,e:=decodeRunnerLaunch(row);if e!=nil{t.Fatalf("ASSERTION:launch-owner-positive %v",e)}
 if v.Before!=before||v.After!=before{t.Fatal("ASSERTION:launch-owner-bsd-fields")}
 row.Fields["instanceEqual"]=[]byte("false")
 if _,e:=decodeRunnerLaunch(row);e==nil{t.Fatal("ASSERTION:launch-instance-required")}
 row.Fields["instanceEqual"]=[]byte("true")
 changed:=before;changed.Seconds=11;row.Fields["before"]=encodeBSD(changed)
 if _,e:=decodeRunnerLaunch(row);e==nil{t.Fatal("ASSERTION:launch-original-bsd-required")}
}

func TestRunnerLaunchLedgerRejectsRevisionChangeAndIncompleteArm(t *testing.T) {
 makeOwner:=func(label string,pid int64,seq int)runnerLaunchRow{
  return runnerLaunchRow{Stage:"runner-launch-owner",Label:label,Revision:7,EventSequence:seq,Original:runnerBSDValue{PID:pid,Parent:1,Effective:501,Seconds:10},Before:runnerBSDValue{PID:pid,Parent:1,Effective:501,Seconds:10},After:runnerBSDValue{PID:pid,Parent:1,Effective:501,Seconds:10},Times:[6]float64{1,2,3,4,5,6}}
 }
 ledger:=runnerLaunchLedger{}
 for i,label:=range []string{"a-1","a-2","b-1","b-2"}{if e:=ledger.Add(makeOwner(label,100+int64(i),i+1));e!=nil{t.Fatal(e)}}
 if e:=ledger.Add(runnerLaunchRow{Stage:"runner-launches-ready",Revision:7,Count:4});e!=nil{t.Fatal(e)}
 bad:=makeOwner("a-1",100,1);bad.Stage="runner-launch-recheck";bad.Revision=8
 if e:=ledger.Add(bad);e==nil{t.Fatal("ASSERTION:launch-revision-immutable")}
 ledger=runnerLaunchLedger{}
 for i,label:=range []string{"a-1","a-2","b-1","b-2"}{if e:=ledger.Add(makeOwner(label,100+int64(i),i+1));e!=nil{t.Fatal(e)}}
 if e:=ledger.Add(runnerLaunchRow{Stage:"runner-launches-ready",Revision:7,Count:4});e!=nil{t.Fatal(e)}
 for i,label:=range []string{"a-1","a-2","b-1","b-2"}{
  row:=makeOwner(label,100+int64(i),i+1);row.Stage="runner-launch-recheck";row.Times=[6]float64{1,7,8,9,10,11}
  if e:=ledger.Add(row);e!=nil{t.Fatal(e)}
 }
 if e:=ledger.Add(runnerLaunchRow{Stage:"runner-launches-verified",Revision:7,Count:4});e!=nil{t.Fatal(e)}
 if e:=ledger.Add(runnerLaunchRow{Stage:"runner-launches-armed",Revision:7});e!=nil{t.Fatal(e)}
 if e:=ledger.Complete(true);e==nil{t.Fatal("ASSERTION:launch-incomplete-without-close")}
 if e:=ledger.Add(runnerLaunchRow{Stage:"runner-launches-closed",Pending:0,Failed:false});e!=nil{t.Fatal(e)}
 if e:=ledger.Complete(true);e!=nil{t.Fatal(e)}
}
