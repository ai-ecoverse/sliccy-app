package integration

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

const snapshotArmHash = "0055c051f48364dbf6d3744c637a06353305a392d06edbedd96bd6764adb5a73"
const snapshotIntelHash = "9ff520697095ce930cc25d4a5e208a72eb82a072211fd7b9bbd6da2b9b78278e"
const snapshotArmCD = "5da1a3199bd3f895bce2e53023c28ca1c33d249e"
const snapshotAppCD = "debaccef3ef320c2f65de9b08acfddcac3887f79"

func TestSignedSnapshotMutation(t *testing.T)    { runSignedSnapshot(t, "snapshot-mutation") }
func TestSignedSnapshotReplacement(t *testing.T) { runSignedSnapshot(t, "snapshot-replacement") }

type snapshotSample struct {
	Kernel kernelImageObservation
	Status uint32
	Live   bool
	Error  string
	At     time.Time
}

func runSignedSnapshot(t *testing.T, which string) {
	executable := os.Getenv("SLICCY_SIGNED_PROOF_APP")
	if executable == "" {
		t.Skip("signed build8 fixture required")
	}
	evidence := os.Getenv("SLICCY_PROOF_EVIDENCE")
	if evidence == "" {
		t.Fatal("private evidence required")
	}
	contents := filepath.Dir(filepath.Dir(executable))
	expected := map[string]string{
		executable:                                                "64337a190c648b49bc95ee5e8a1a5420e37f540750551e40815c26b6de89c58d",
		filepath.Join(contents, "Info.plist"):                     "18a2574a1e46343a8c726d2dcb569ea18842e198a3e6b08ac6f6ed7a4732e724",
		filepath.Join(contents, "Resources/slicc"):                snapshotArmHash,
		filepath.Join(contents, "Resources/slicc-snapshot-amd64"): snapshotIntelHash,
	}
	readFixed := func(path, want string) []byte {
		raw, e := os.ReadFile(path)
		h := sha256.Sum256(raw)
		if e != nil || hex.EncodeToString(h[:]) != want {
			t.Fatal("fixed artifact mismatch")
		}
		return raw
	}
	for path, want := range expected {
		raw := readFixed(path, want)
		if path != filepath.Join(contents, "Info.plist") {
			s, e := signedSnapshotSlices(raw)
			role := "ai.sliccy.slicc"
			if path == executable {
				role = "ai.sliccy.mac"
			}
			if e != nil || len(s) != 1 || validateStaticSlice(path, role, s[0]) != nil {
				t.Fatal("signed fixed artifact refused")
			}
		}
	}
	arm := readFixed(filepath.Join(contents, "Resources/slicc"), snapshotArmHash)
	intel := readFixed(filepath.Join(contents, "Resources/slicc-snapshot-amd64"), snapshotIntelHash)
	gate := make(chan struct{})
	_, join, _ := proofPageControlled(t, gate)
	t.Cleanup(func() { close(gate) })
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, executable, "--screen-proof", "--case", which)
	cmd.Env = proofEnvironment(t)
	input, e := cmd.StdinPipe()
	if e != nil {
		t.Fatal(e)
	}
	defer input.Close()
	stdout, e := cmd.StdoutPipe()
	if e != nil {
		t.Fatal(e)
	}
	stderr := &proofRows{}
	cmd.Stderr = stderr
	if cmd.Start() != nil {
		t.Fatal("signed snapshot app did not start")
	}
	if _, e = io.WriteString(input, join+"\n"); e != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("join input failed")
	}
	parentEvents, stopParent, e := watchProofExec(cmd.Process.Pid)
	if e != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("app monitor unavailable")
	}
	defer stopParent()
	output := &proofRows{}
	var failures, missing []string
	fail := func(s string) { failures = append(failures, s) }
	incomplete := func(s string) { missing = append(missing, s) }
	rows := map[string]snapshotRow{}
	samples := map[string]snapshotSample{}
	fileFacts := map[string]any{}
	var files *snapshotFiles
	defer func() {
		if files != nil {
			files.close()
		}
	}()
	var initial kernelImageObservation
	var directory string
	childPID := 0
	var childEvents <-chan proofExecEvent
	var stopChild func()
	childExited, unexpectedExec := false, false
	completed, denied, baseline := false, false, false
	originalMarker, resultMarker := false, false
	sample := func() snapshotSample {
		result := snapshotSample{At: time.Now()}
		k, e := inspectOwnedKernelImage(childPID, cmd.Process.Pid)
		if e != nil {
			result.Error = "kernel/live incarnation unavailable"
			return result
		}
		if k.CPU != 0x0100000c || k.Offset != 0 || k.CDHash != snapshotArmCD || (initial.Identity.PID != 0 && k.Identity != initial.Identity) {
			result.Error = "running identity/image mismatch"
			fail(result.Error)
			return result
		}
		flags, id, e := inspectOwnedCodeStatus(childPID, cmd.Process.Pid)
		if e != nil || id != k.Identity {
			result.Error = "kernel status unavailable"
			return result
		}
		result.Kernel = k
		result.Status = flags
		result.Live = true
		return result
	}
	send := func(marker string) {
		if _, e := io.WriteString(input, marker+"\n"); e != nil {
			fail("observation marker write failed")
		}
	}
	incoming := make(chan snapshotRow, 64)
	done := make(chan struct{})
	var readErr, runErr error
	go func() {
		scanner := bufio.NewScanner(stdout)
		scanner.Buffer(make([]byte, 4096), 4096)
		for scanner.Scan() {
			line := append([]byte(nil), scanner.Bytes()...)
			_, _ = output.Write(append(line, '\n'))
			row, e := decodeSnapshotRow(line)
			if e != nil {
				readErr = e
				continue
			}
			row.At = time.Now()
			select {
			case incoming <- row:
			default:
				readErr = fmt.Errorf("snapshot metadata queue exceeded")
			}
		}
		if scanner.Err() != nil {
			readErr = scanner.Err()
		}
		close(incoming)
		runErr = cmd.Wait()
		close(done)
	}()
	lastElapsed := -1.0
	process := func(row snapshotRow) {
		if row.Case != which || row.Elapsed < lastElapsed {
			fail("case/monotonic metadata mismatch")
		}
		lastElapsed = row.Elapsed
		key := row.Stage
		if row.Component != "" {
			key += "/" + row.Component
		}
		if _, ok := rows[key]; ok {
			fail("duplicate snapshot stage/component")
			return
		}
		rows[key] = row
		switch row.Stage {
		case "snapshot-started":
			if row.PID == nil || *row.PID != cmd.Process.Pid {
				fail("wrong app PID")
				return
			}
			if _, e := inspectProofImage(cmd.Process.Pid, executable, snapshotAppCD, "ai.sliccy.mac", "ai.sliccy.proof-helper"); e != nil {
				fail("genuine signed app live identity refused")
			}
		case "snapshot-prepared":
			directory = row.Directory
			if row.OriginalSHA256 != snapshotArmHash || row.OriginalCDHash != snapshotArmCD {
				fail("original metadata mismatch")
			}
			if which == "snapshot-replacement" && (row.ReplacementSHA256 != snapshotIntelHash || row.ReplacementCDHash != "bf246edfa276fa4242db674e139a872270633673") {
				fail("replacement metadata mismatch")
			}
		case "child-started":
			if row.PID == nil || *row.PID <= 0 || *row.PID == cmd.Process.Pid {
				fail("wrong owned child PID")
				return
			}
			childPID = *row.PID
			var e error
			childEvents, stopChild, e = watchProofExec(childPID)
			if e != nil {
				fail("owned child monitor unavailable")
			}
		case "baseline-live-positive":
			if row.SelectedCDHash != snapshotArmCD || rows["heartbeat-ready"].Stage == "" {
				fail("baseline not genuinely heartbeat-ready")
			}
			samples["baseline"] = sample()
			initial = samples["baseline"].Kernel
			if !samples["baseline"].Live {
				fail("baseline live kernel binding unavailable")
			}
			if _, e := inspectProofImage(childPID, filepath.Join(directory, "candidate"), snapshotArmCD, "ai.sliccy.slicc", "ai.sliccy.mac"); e != nil {
				fail("baseline child image/role/path mismatch")
			}
			var e error
			replacement := intel
			if which == "snapshot-mutation" {
				replacement = nil
			}
			files, e = openSnapshotFiles(directory, arm, replacement)
			if e != nil {
				fail("owned original snapshots unavailable")
			} else {
				f, e := files.observeChange(which, false)
				if e != nil {
					fail("original static snapshots not valid")
				} else {
					fileFacts["baseline"] = f
					baseline = true
				}
			}
			originalMarker = true
			send("snapshot-original-observed")
		case "change-attempted":
			if !originalMarker || row.Operation != strings.TrimPrefix(which, "snapshot-") {
				fail("change without observed baseline")
			}
		case "change-completed", "change-denied":
			if rows["change-attempted"].Stage == "" || row.Operation != strings.TrimPrefix(which, "snapshot-") {
				fail("unexpected change operation")
			}
			completed = row.Stage == "change-completed"
			denied = !completed
			if completed && which == "snapshot-mutation" && (row.Offset == nil || *row.Offset != 17947039 || row.Before == nil || *row.Before != 0 || row.After == nil || *row.After != 1) {
				fail("wrong mutation recipe")
			}
			if completed && which == "snapshot-replacement" && (row.OldSnapshotRetained == nil || !*row.OldSnapshotRetained || row.PathNowReplacement == nil || !*row.PathNowReplacement) {
				fail("replacement metadata contradiction")
			}
			if files != nil {
				f, e := files.observeChange(which, completed)
				if e != nil {
					fail("independent changed snapshot check failed")
				} else {
					fileFacts["changed"] = f
				}
			}
		case "post-verifier-started":
			if !completed && !denied {
				fail("component before change outcome")
			}
			if *row.AwaitingObservation {
				samples[row.Component+"-before"] = sample()
				send("snapshot-" + row.Component + "-observed")
			}
		case "post-verifier-result":
			started, ok := rows["post-verifier-started/"+row.Component]
			if !ok {
				fail("result without call boundary")
				return
			}
			after := sample()
			samples[row.Component+"-after"] = after
			before := samples[row.Component+"-before"]
			if *row.Called && (!*started.AwaitingObservation || !*row.ChildAliveBefore) {
				fail("called/liveness metadata contradiction")
			}
			if row.Component == "guest" && row.Outcome == "accepted" && before.Live && after.Live && row.SelectedCDHash != snapshotArmCD {
				fail("accepted guest metadata does not bind original running hash")
			}
			if *row.Called && (!before.Live || !after.Live || !*row.ChildAliveAfter) {
				incomplete(row.Component + " call lacks independent live bracket")
			}
		case "result-ready":
			samples["result"] = sample()
			if files != nil {
				f, e := files.observeChange(which, completed)
				if e != nil {
					fail("final snapshot evidence mismatch")
				} else {
					fileFacts["final"] = f
				}
			}
			resultMarker = true
			send("snapshot-result-observed")
		case "child-exit-reaped":
			if row.PID == nil || *row.PID != childPID || rows["child-gate-invalidated"].Stage == "" {
				fail("owned child invalidation/reap order mismatch")
			}
		}
	}
	finished := false
	for !finished {
		select {
		case row, ok := <-incoming:
			if ok {
				process(row)
			} else {
				incoming = nil
			}
		case event := <-parentEvents:
			if event.Err != nil || event.Exec {
				fail("unexpected app exec/monitor error")
			}
			if event.Exit {
				parentEvents = nil
			}
		case event := <-childEvents:
			if event.Err != nil {
				fail("child monitor failure")
			}
			if event.Exec {
				unexpectedExec = true
				fail("unexpected child exec")
			}
			if event.Exit {
				childExited = true
				childEvents = nil
			}
		case <-done:
			if incoming != nil {
				for row := range incoming {
					process(row)
				}
			}
			finished = true
		}
	}
	if childEvents != nil {
		select {
		case event := <-childEvents:
			childExited = event.Exit && event.Err == nil && !event.Exec
		case <-time.After(time.Second):
		}
	}
	if stopChild != nil {
		stopChild()
	}
	if readErr != nil || output.overflow || stderr.overflow {
		fail("bounded strict metadata failure")
	}
	if strings.Contains(string(output.data), join) {
		fail("join disclosed")
	}
	if !childExited || rows["child-exit-reaped"].Stage == "" {
		fail("owned child kernel exit/reap missing")
	}
	if _, e := os.Lstat(directory); directory == "" || !os.IsNotExist(e) {
		fail("owned staging cleanup incomplete")
	}
	for path, want := range expected {
		raw, e := os.ReadFile(path)
		h := sha256.Sum256(raw)
		if e != nil || hex.EncodeToString(h[:]) != want {
			fail("sealed artifact changed")
		}
	}
	guest := rows["post-verifier-result/guest"]
	endpoint := rows["post-verifier-result/endpoint"]
	for _, component := range []string{"guest", "endpoint"} {
		r, ok := rows["post-verifier-result/"+component]
		if !ok || r.Outcome == "unavailable" {
			incomplete(component + " verifier not demonstrated")
		}
	}
	if !baseline || !originalMarker || !resultMarker || !completed || denied || unexpectedExec {
		incomplete("baseline/change/observation prerequisites incomplete")
	}
	if rows["terminal"].Reason != "observation-complete" {
		incomplete("fixture did not complete observation")
	}
	if runErr != nil && rows["terminal"].Reason == "observation-complete" {
		fail("completed fixture exited unsuccessfully")
	}
	if which == "snapshot-mutation" && completed && guest.Outcome == "accepted" && samples["guest-before"].Live && samples["guest-after"].Live {
		fail("mutation accepted; not a live verifier refusal")
	}
	if which == "snapshot-mutation" && (guest.Outcome != "refused" || endpoint.Outcome != "refused") {
		incomplete("mutation live guest refusal unavailable")
	}
	if which == "snapshot-replacement" && guest.Outcome != "accepted" {
		incomplete("replacement conservative refusal does not establish live/static binding")
	}
	result := "PASS"
	if len(missing) > 0 {
		result = "FAILED_TO_DEMONSTRATE"
	}
	if len(failures) > 0 {
		result = "FAIL"
	}
	facts := map[string]any{"result": result, "case": which, "capture": false, "failures": failures, "missingEvidence": missing, "samples": samples, "snapshotFiles": fileFacts, "guestOutcome": guest.Outcome, "endpointOutcome": endpoint.Outcome, "childKernelExit": childExited, "source": "fa6b6d834041cf4e76725461f2de17a812ab2673", "appRun": "41585799632", "productionKernelHashComparisonClaimed": false, "staticPageBranchClaimed": false}
	data, _ := json.MarshalIndent(facts, "", "  ")
	for name, raw := range map[string][]byte{"milestones.ndjson": output.data, "stderr.txt": stderr.data, "driver-observations.json": append(data, '\n')} {
		if os.WriteFile(filepath.Join(evidence, name), raw, 0600) != nil {
			t.Fatal("private evidence write failed")
		}
	}
	if result != "PASS" {
		t.Fatalf("%s: failures=%v missing=%v", result, failures, missing)
	}
	t.Log(which + " PASS; actual whole-verifier outcome only")
}
