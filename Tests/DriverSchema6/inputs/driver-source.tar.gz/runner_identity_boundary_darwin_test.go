package integration

import (
	"context"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

type runnerIdentitySpec struct {
	PID, Parent              int
	Label, Role, App, Origin string
	ParentIdentity           *runnerBSDValue
}

type runnerBoundProcess struct {
	Label, Bundle, Path, Root, Profile string
	Identity                           runnerBSDValue
	Code                               runnerNativeBindingObservation
	Owned                              bool
}

type runnerIdentityOps struct {
	Bind      func(context.Context, *runnerNativeTrace, int, string, string, string) (runnerNativeBindingObservation, error)
	BSD       func(context.Context, *runnerNativeTrace, int) (runnerBSDReceipt, error)
	Arguments func(int) ([]string, string, error)
	Resolve   func(string) (string, error)
	Root      func(string) (string, error)
	Chrome    func([]string, string, string, string) (string, error)
}

func runnerIdentityPolicy(spec runnerIdentitySpec) (path, pin string, owned bool, err error) {
	contents := filepath.Dir(filepath.Dir(spec.App))
	switch spec.Label {
	case "app":
		if spec.Role != "ai.sliccy.mac" {
			break
		}
		return spec.App, "4eb3c52aba60a8693924fbb2cc596f5f00bdb44b", true, nil
	case "allowed":
		if spec.Role != "ai.sliccy.proof-helper" {
			break
		}
		return filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/MacOS/ScreenProofSurface"), "37517f1a6e6a0085f9188f3723ab6209fd131dfd", true, nil
	case "cli":
		if spec.Role != "ai.sliccy.slicc" {
			break
		}
		return filepath.Join(contents, "Resources/slicc"), "5da1a3199bd3f895bce2e53023c28ca1c33d249e", true, nil
	case "chrome-a-1", "chrome-a-2", "chrome-b-1", "chrome-b-2":
		if spec.Role != "com.google.Chrome" {
			break
		}
		return "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "", true, nil
	case "authorization-requester":
		if spec.Role != "com.apple.osascript" {
			break
		}
		return "/usr/bin/osascript", "", true, nil
	case "authorization":
		if spec.Role != "com.apple.SecurityAgent" {
			break
		}
		return "", "", false, nil
	case "window-manager", "dock", "finder", "window-server":
		roles := map[string]string{"window-manager": "com.apple.WindowManager", "dock": "com.apple.dock", "finder": "com.apple.finder", "window-server": "com.apple.WindowServer"}
		if spec.Role != roles[spec.Label] {
			break
		}
		return "", "", false, nil
	}
	return "", "", false, fmt.Errorf("fixed independent identity role/label mismatch")
}

func observeRunnerIdentityWith(ctx context.Context, trace *runnerNativeTrace, spec runnerIdentitySpec, ops runnerIdentityOps) (fact runnerBoundProcess, err error) {
	fact.Label, fact.Bundle = spec.Label, spec.Role
	expected, pin, owned, err := runnerIdentityPolicy(spec)
	fact.Owned = owned
	if err != nil {
		return fact, err
	}
	if ctx == nil || trace == nil || ctx.Err() != nil || spec.PID < 1 || ops.Bind == nil || ops.Resolve == nil || ops.BSD == nil {
		return fact, fmt.Errorf("independent identity boundary incomplete")
	}
	if owned && (spec.Parent < 1 || spec.ParentIdentity == nil || spec.ParentIdentity.PID != int64(spec.Parent)) {
		return fact, fmt.Errorf("retained parent incarnation missing")
	}
	var parentBefore runnerBSDReceipt
	if owned {
		parentBefore, err = ops.BSD(ctx, trace, spec.Parent)
		if err != nil || !parentBefore.Accepted || !runnerBSDEqual(parentBefore.Selected, spec.ParentIdentity) {
			return fact, fmt.Errorf("owned parent before bracket mismatch")
		}
	}
	if expected != "" {
		expected, err = ops.Resolve(expected)
		if err != nil || !filepath.IsAbs(expected) {
			return fact, fmt.Errorf("fixed executable path unresolved")
		}
	}
	fact.Code, err = ops.Bind(ctx, trace, spec.PID, spec.Role, expected, pin)
	bound := fact.Code.Binding
	fact.Identity, fact.Path = bound.BSD, bound.Path
	if err != nil || !bound.Bound || bound.PID != spec.PID || bound.Identifier != spec.Role || bound.BSD.PID != int64(spec.PID) || expected != "" && bound.Path != expected {
		return fact, fmt.Errorf("independent complete process binding unavailable")
	}
	if owned && (bound.BSD.Parent != int64(spec.Parent) || bound.BSD.Effective != uint32(os.Getuid()) || bound.BSD.Real != uint32(os.Getuid()) || bound.BSD.Saved != uint32(os.Getuid())) {
		return fact, fmt.Errorf("process not same-credential direct owned child")
	}
	if !owned && !strings.HasPrefix(bound.Path, "/System/") && !strings.HasPrefix(bound.Path, "/usr/") {
		return fact, fmt.Errorf("Apple role outside fixed system path family")
	}
	if strings.HasPrefix(spec.Label, "chrome-") || spec.Label == "allowed" || spec.Label == "authorization-requester" {
		if ops.Arguments == nil || ops.Root == nil {
			return fact, fmt.Errorf("owned argv facility missing")
		}
		id, ok := trace.Begin("sysctl-KERN_PROCARGS2", spec.PID, 49)
		if !ok {
			return fact, fmt.Errorf("argv trace retired")
		}
		args, tmp, queryErr := ops.Arguments(spec.PID)
		if !trace.End(id, nil, queryErr == nil) {
			return fact, fmt.Errorf("argv diagnostic completion lost")
		}
		if queryErr != nil {
			return fact, queryErr
		}
		if strings.HasPrefix(spec.Label, "chrome-") {
			if ops.Chrome == nil {
				return fact, fmt.Errorf("Chrome fixed-profile boundary missing")
			}
			fact.Root, err = ops.Chrome(args, tmp, spec.Label, spec.Origin)
			fact.Profile = strings.TrimPrefix(spec.Label, "chrome-")
		} else {
			fact.Root, err = ops.Root(tmp)
			want := []string{expected}
			if spec.Label == "authorization-requester" {
				want = append(want, "-e", `do shell script "/usr/bin/true" with administrator privileges`)
			}
			if len(args) != len(want) {
				return fact, fmt.Errorf("fixed owned argv count mismatch")
			}
			for i := range want {
				if args[i] != want[i] {
					return fact, fmt.Errorf("fixed owned argv mismatch")
				}
			}
		}
		if err != nil {
			return fact, err
		}
	}
	after, err := ops.BSD(ctx, trace, spec.PID)
	if err != nil || !after.Accepted || !runnerBSDEqual(after.Selected, &bound.BSD) {
		return fact, fmt.Errorf("process incarnation changed around argv/ownership checks")
	}
	if owned {
		parentAfter, queryErr := ops.BSD(ctx, trace, spec.Parent)
		if queryErr != nil || !parentAfter.Accepted || !runnerBSDEqual(parentAfter.Selected, parentBefore.Selected) || !runnerBSDEqual(parentAfter.Selected, spec.ParentIdentity) {
			return fact, fmt.Errorf("owned parent incarnation changed")
		}
	}
	_, lost, pending := trace.Snapshot()
	if ctx.Err() != nil || lost || pending != 0 {
		return fact, fmt.Errorf("independent identity incomplete or timed out")
	}
	return fact, nil
}

func observeRunnerIdentity(ctx context.Context, trace *runnerNativeTrace, spec runnerIdentitySpec) (runnerBoundProcess, error) {
	return observeRunnerIdentityWith(ctx, trace, spec, runnerIdentityOps{Bind: observeRunnerNativeBinding, BSD: runnerObserveBSDContext, Arguments: runnerProcArguments, Resolve: filepath.EvalSymlinks, Root: runnerOwnedRoot, Chrome: runnerChromeArguments})
}

func (f runnerBoundProcess) Union() runnerUnionOwnerFact {
	b := f.Code.Binding
	return runnerUnionOwnerFact{Label: f.Label, Identifier: f.Bundle, Hash: hex.EncodeToString(b.Kernel.Hash[:]), BSD: f.Identity, CodeBound: b.Bound, Platform: b.Kernel.Flags&0x04000000 != 0, Before: b.Before, After: b.After}
}

func runnerBoundSame(a, b runnerBoundProcess) bool {
	return a.Label == b.Label && a.Bundle == b.Bundle && a.Owned == b.Owned && a.Path == b.Path && a.Root == b.Root && a.Profile == b.Profile && a.Identity == b.Identity && a.Code.Binding.Bound && b.Code.Binding.Bound && a.Code.Binding.Kernel == b.Code.Binding.Kernel && a.Code.Binding.Selected.CPU == b.Code.Binding.Selected.CPU && a.Code.Binding.Selected.Subtype == b.Code.Binding.Selected.Subtype && a.Code.Binding.Selected.Offset == b.Code.Binding.Selected.Offset && a.Code.Binding.Selected.Type == b.Code.Binding.Selected.Type
}
