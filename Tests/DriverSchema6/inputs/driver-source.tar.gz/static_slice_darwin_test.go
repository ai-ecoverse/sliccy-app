package integration

import (
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"testing"
	"unsafe"

	"github.com/ebitengine/purego"
)

func validateStaticSlice(path, role string, slice snapshotSlice) (err error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path || (role != "ai.sliccy.mac" && role != "ai.sliccy.slicc") || len(slice.CDHash) != 40 || slice.Offset > uint64(^uint64(0)>>1) {
		return fmt.Errorf("invalid fixed snapshot input")
	}
	defer func() {
		if recover() != nil {
			err = fmt.Errorf("explicit static slice API unavailable")
		}
	}()
	cf, e := purego.Dlopen("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return e
	}
	defer purego.Dlclose(cf)
	sec, e := purego.Dlopen("/System/Library/Frameworks/Security.framework/Security", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return e
	}
	defer purego.Dlclose(sec)
	var release func(uintptr)
	var urlCreate func(uintptr, *byte, int64, bool) uintptr
	var numberCreate func(uintptr, int32, unsafe.Pointer) uintptr
	var dictCreate func(uintptr, *uintptr, *uintptr, int64, uintptr, uintptr) uintptr
	var stringCreate func(uintptr, *byte, uint32) uintptr
	var dictGet func(uintptr, uintptr) uintptr
	var dataLength func(uintptr) int64
	var dataBytes func(uintptr) *byte
	for _, v := range []struct {
		name string
		fn   any
	}{{"CFRelease", &release}, {"CFURLCreateFromFileSystemRepresentation", &urlCreate}, {"CFNumberCreate", &numberCreate}, {"CFDictionaryCreate", &dictCreate}, {"CFStringCreateWithCString", &stringCreate}, {"CFDictionaryGetValue", &dictGet}, {"CFDataGetLength", &dataLength}, {"CFDataGetBytePtr", &dataBytes}} {
		purego.RegisterLibFunc(v.fn, cf, v.name)
	}
	var create func(uintptr, uint32, uintptr, *uintptr) int32
	var requirementCreate func(uintptr, uint32, *uintptr) int32
	var validity func(uintptr, uint32, uintptr) int32
	var information func(uintptr, uint32, *uintptr) int32
	purego.RegisterLibFunc(&create, sec, "SecStaticCodeCreateWithPathAndAttributes")
	purego.RegisterLibFunc(&requirementCreate, sec, "SecRequirementCreateWithString")
	purego.RegisterLibFunc(&validity, sec, "SecStaticCodeCheckValidity")
	purego.RegisterLibFunc(&information, sec, "SecCodeCopySigningInformation")
	symbol := func(name string) uintptr {
		value, e := readProofExport(sec, name)
		if e != nil {
			return 0
		}
		return value
	}

	keys := [2]uintptr{symbol("kSecCodeAttributeArchitecture"), symbol("kSecCodeAttributeSubarchitecture")}
	unique := symbol("kSecCodeInfoUnique")
	for _, key := range keys {
		if key == 0 {
			return fmt.Errorf("static architecture key unavailable")
		}
	}
	if unique == 0 {
		return fmt.Errorf("static identity key unavailable")
	}
	cpu, sub := int32(slice.CPU), int32(slice.Subtype)
	values := [2]uintptr{numberCreate(0, 3, unsafe.Pointer(&cpu)), numberCreate(0, 3, unsafe.Pointer(&sub))}
	for _, v := range values {
		if v == 0 {
			return fmt.Errorf("architecture value unavailable")
		}
		defer release(v)
	}
	keyCallbacks, e := purego.Dlsym(cf, "kCFTypeDictionaryKeyCallBacks")
	if e != nil || keyCallbacks == 0 {
		return fmt.Errorf("CF dictionary key callbacks unavailable")
	}
	valueCallbacks, e := purego.Dlsym(cf, "kCFTypeDictionaryValueCallBacks")
	if e != nil || valueCallbacks == 0 {
		return fmt.Errorf("CF dictionary value callbacks unavailable")
	}
	attributes := dictCreate(0, &keys[0], &values[0], 2, keyCallbacks, valueCallbacks)
	if attributes == 0 {
		return fmt.Errorf("architecture attributes unavailable")
	}
	defer release(attributes)
	pathBytes := []byte(path)
	url := urlCreate(0, &pathBytes[0], int64(len(pathBytes)), false)
	runtime.KeepAlive(pathBytes)
	if url == 0 {
		return fmt.Errorf("snapshot URL unavailable")
	}
	defer release(url)
	var code uintptr
	if create(url, 0, attributes, &code) != 0 || code == 0 {
		return fmt.Errorf("architecture-explicit snapshot refused")
	}
	defer release(code)
	source := append([]byte(`anchor apple generic and certificate leaf[field.1.2.840.113635.100.6.1.13] exists and certificate 1[field.1.2.840.113635.100.6.2.6] exists and certificate leaf[subject.OU] = "S8LB56P782" and identifier "`+role+`"`), 0)
	text := stringCreate(0, &source[0], 0x08000100)
	runtime.KeepAlive(source)
	if text == 0 {
		return fmt.Errorf("static requirement unavailable")
	}
	defer release(text)
	var requirement uintptr
	if requirementCreate(text, 0, &requirement) != 0 || requirement == 0 {
		return fmt.Errorf("static requirement invalid")
	}
	defer release(requirement)
	if validity(code, 16, requirement) != 0 {
		return fmt.Errorf("explicit slice signature/role refused")
	}
	var info uintptr
	if information(code, 2, &info) != 0 || info == 0 {
		return fmt.Errorf("explicit slice signing information unavailable")
	}
	defer release(info)
	hash := dictGet(info, unique)
	if hash == 0 || dataLength(hash) != 20 {
		return fmt.Errorf("explicit slice CodeDirectory unavailable")
	}
	pointer := dataBytes(hash)
	if pointer == nil {
		return fmt.Errorf("explicit slice hash bytes unavailable")
	}
	actual := hex.EncodeToString(unsafe.Slice(pointer, 20))
	if actual != slice.CDHash || validity(code, 16, requirement) != 0 {
		return fmt.Errorf("validated explicit slice differs from parsed snapshot")
	}
	return nil
}

func TestExplicitStaticSliceReleased(t *testing.T) {
	path := os.Getenv("SLICC_RELEASE_PROOF_BINARY")
	if path == "" {
		t.Skip("verified release snapshot required")
	}
	raw, e := os.ReadFile(path)
	if e != nil {
		t.Fatal(e)
	}
	slices, e := signedSnapshotSlices(raw)
	if e != nil || len(slices) != 1 || slices[0].CDHash != "5da1a3199bd3f895bce2e53023c28ca1c33d249e" {
		t.Fatal("unexpected snapshot")
	}
	if e := validateStaticSlice(path, "ai.sliccy.slicc", slices[0]); e != nil {
		t.Fatal(e)
	}
	wrong := slices[0]
	wrong.CPU = 0x01000007
	if e := validateStaticSlice(path, "ai.sliccy.slicc", wrong); e == nil {
		t.Fatal("wrong architecture accepted")
	}
	wrong = slices[0]
	wrong.CDHash = "0000000000000000000000000000000000000000"
	if e := validateStaticSlice(path, "ai.sliccy.slicc", wrong); e == nil {
		t.Fatal("different snapshot CodeDirectory accepted")
	}
	if e := validateStaticSlice(path, "ai.sliccy.mac", slices[0]); e == nil {
		t.Fatal("wrong signed role accepted")
	}
}
