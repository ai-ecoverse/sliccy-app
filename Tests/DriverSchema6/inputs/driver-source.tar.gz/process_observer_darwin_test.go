package integration

import (
	"encoding/hex"
	"errors"
	"path/filepath"
	"runtime"
	"time"
	"unsafe"

	"github.com/ebitengine/purego"
	"golang.org/x/sys/unix"
)

type proofExecEvent struct {
	At   time.Time
	Exec bool
	Exit bool
	Err  error
}

func watchProofExec(pid int) (<-chan proofExecEvent, func(), error) {
	fd, err := unix.Kqueue()
	if err != nil {
		return nil, nil, err
	}
	unix.CloseOnExec(fd)
	change := unix.Kevent_t{Ident: uint64(pid), Filter: unix.EVFILT_PROC, Flags: unix.EV_ADD | unix.EV_ENABLE, Fflags: unix.NOTE_EXEC | unix.NOTE_EXIT}
	if _, err = unix.Kevent(fd, []unix.Kevent_t{change}, nil, nil); err != nil {
		_ = unix.Close(fd)
		return nil, nil, err
	}
	events := make(chan proofExecEvent, 4)
	stop := make(chan struct{})
	done := make(chan struct{})
	go func() {
		defer close(done)
		defer unix.Close(fd)
		for {
			select {
			case <-stop:
				return
			default:
			}
			var output [1]unix.Kevent_t
			timeout := unix.Timespec{Nsec: 100000000}
			n, e := unix.Kevent(fd, nil, output[:], &timeout)
			if e == unix.EINTR {
				continue
			}
			if e != nil {
				events <- proofExecEvent{Err: e}
				return
			}
			if n > 0 {
				event := proofExecEvent{At: time.Now(), Exec: output[0].Fflags&unix.NOTE_EXEC != 0, Exit: output[0].Fflags&unix.NOTE_EXIT != 0}
				select {
				case events <- event:
				case <-stop:
					return
				}
				if event.Exit {
					return
				}
			}
		}
	}()
	return events, func() { close(stop); <-done }, nil
}

func readProofExport(library uintptr, name string) (uintptr, error) {
	pointer, e := purego.Dlsym(library, name)
	if e != nil || pointer == 0 {
		return 0, errors.New("native constant unavailable")
	}
	system, e := purego.Dlopen("/usr/lib/libSystem.B.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return 0, e
	}
	defer purego.Dlclose(system)
	var copyValue func(*uintptr, uintptr, uintptr) uintptr
	purego.RegisterLibFunc(&copyValue, system, "memcpy")
	var value uintptr
	copyValue(&value, pointer, unsafe.Sizeof(value))
	runtime.KeepAlive(&value)
	return value, nil
}

func inspectProofHelper(pid int, path, wantHash string) (string, error) {
	return inspectProofImage(pid, path, wantHash, "ai.sliccy.proof-helper", "ai.sliccy.mac")
}
func inspectProofImage(pid int, path, wantHash, role, wrongRole string) (string, error) {
	return inspectProofImageCPU(pid, path, wantHash, role, wrongRole, 0x0100000c)
}
func runnerDeveloperRule(role, team string) string {
	return `anchor apple generic and certificate leaf[field.1.2.840.113635.100.6.1.13] exists and certificate 1[field.1.2.840.113635.100.6.2.6] exists and certificate leaf[subject.OU] = "` + team + `" and identifier "` + role + `"`
}
func inspectProofImageCPU(pid int, path, wantHash, role, wrongRole string, expectedCPU int32) (string, error) {
	return inspectRunnerImageRules(pid, path, wantHash, runnerDeveloperRule(role, "S8LB56P782"), runnerDeveloperRule(wrongRole, "S8LB56P782"), expectedCPU)
}
func inspectRunnerImageRules(pid int, path, wantHash, goodRule, wrongRule string, expectedCPU int32) (value string, err error) {
	defer func() {
		if recover() != nil {
			value = ""
			err = errors.New("live identity API unavailable")
		}
	}()
	return inspectRunnerImageRulesUnchecked(pid, path, wantHash, goodRule, wrongRule, expectedCPU)
}
func inspectRunnerImageRulesUnchecked(pid int, path, wantHash, goodRule, wrongRule string, expectedCPU int32) (string, error) {
	fail := func() (string, error) { return "", errors.New("live helper identity check failed") }
	proc, err := purego.Dlopen("/usr/lib/libproc.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if err != nil {
		return fail()
	}
	defer purego.Dlclose(proc)
	var procPath func(int32, *byte, uint32) int32
	var procInfo func(int32, int32, uint64, *int32, int32) int32
	purego.RegisterLibFunc(&procPath, proc, "proc_pidpath")
	purego.RegisterLibFunc(&procInfo, proc, "proc_pidinfo")
	checkPath := func() bool {
		var buffer [4096]byte
		n := procPath(int32(pid), &buffer[0], uint32(len(buffer)))
		if n <= 0 || int(n) > len(buffer) {
			return false
		}
		length := 0
		for length < len(buffer) && buffer[length] != 0 {
			length++
		}
		actual, err := filepath.EvalSymlinks(string(buffer[:length]))
		expected, e := filepath.EvalSymlinks(path)
		return err == nil && e == nil && actual == expected
	}
	if !checkPath() {
		return fail()
	}
	var architecture [2]int32
	if procInfo(int32(pid), 19, 0, &architecture[0], 8) != 8 || runtime.GOARCH != "arm64" || architecture[0] != expectedCPU {
		return fail()
	}
	cf, err := purego.Dlopen("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if err != nil {
		return fail()
	}
	defer purego.Dlclose(cf)
	sec, err := purego.Dlopen("/System/Library/Frameworks/Security.framework/Security", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if err != nil {
		return fail()
	}
	defer purego.Dlclose(sec)
	var release func(uintptr)
	var number func(uintptr, int32, *int32) uintptr
	var dict func(uintptr, *uintptr, *uintptr, int64, uintptr, uintptr) uintptr
	var stringCreate func(uintptr, *byte, uint32) uintptr
	var dictGet func(uintptr, uintptr) uintptr
	var dataLength func(uintptr) int64
	var dataBytes func(uintptr) *byte
	purego.RegisterLibFunc(&release, cf, "CFRelease")
	purego.RegisterLibFunc(&number, cf, "CFNumberCreate")
	purego.RegisterLibFunc(&dict, cf, "CFDictionaryCreate")
	purego.RegisterLibFunc(&stringCreate, cf, "CFStringCreateWithCString")
	purego.RegisterLibFunc(&dictGet, cf, "CFDictionaryGetValue")
	purego.RegisterLibFunc(&dataLength, cf, "CFDataGetLength")
	purego.RegisterLibFunc(&dataBytes, cf, "CFDataGetBytePtr")
	var guestCopy func(uintptr, uintptr, uint32, *uintptr) int32
	var reqCreate func(uintptr, uint32, *uintptr) int32
	var check func(uintptr, uint32, uintptr) int32
	var staticCopy func(uintptr, uint32, *uintptr) int32
	var staticCheck func(uintptr, uint32, uintptr) int32
	var infoCopy func(uintptr, uint32, *uintptr) int32
	purego.RegisterLibFunc(&guestCopy, sec, "SecCodeCopyGuestWithAttributes")
	purego.RegisterLibFunc(&reqCreate, sec, "SecRequirementCreateWithString")
	purego.RegisterLibFunc(&check, sec, "SecCodeCheckValidity")
	purego.RegisterLibFunc(&staticCopy, sec, "SecCodeCopyStaticCode")
	purego.RegisterLibFunc(&staticCheck, sec, "SecStaticCodeCheckValidity")
	purego.RegisterLibFunc(&infoCopy, sec, "SecCodeCopySigningInformation")
	symbol := func(name string) uintptr {
		value, e := readProofExport(sec, name)
		if e != nil {
			return 0
		}
		return value
	}

	key := symbol("kSecGuestAttributePid")
	unique := symbol("kSecCodeInfoUnique")
	if key == 0 || unique == 0 {
		return fail()
	}
	identifier := int32(pid)
	value := number(0, 3, &identifier)
	if value == 0 {
		return fail()
	}
	defer release(value)
	attributes := dict(0, &key, &value, 1, 0, 0)
	if attributes == 0 {
		return fail()
	}
	defer release(attributes)
	var guest uintptr
	if guestCopy(0, attributes, 0, &guest) != 0 || guest == 0 {
		return fail()
	}
	defer release(guest)
	requirement := func(rule string) uintptr {
		source := append([]byte(rule), 0)
		text := stringCreate(0, &source[0], 0x08000100)
		runtime.KeepAlive(source)
		if text == 0 {
			return 0
		}
		defer release(text)
		var req uintptr
		if reqCreate(text, 0, &req) != 0 {
			return 0
		}
		return req
	}
	good := requirement(goodRule)
	wrong := requirement(wrongRule)
	if good == 0 || wrong == 0 {
		return fail()
	}
	defer release(good)
	defer release(wrong)
	if check(guest, 0, good) != 0 || check(guest, 0, wrong) == 0 {
		return fail()
	}
	var static uintptr
	if staticCopy(guest, 0, &static) != 0 || static == 0 {
		return fail()
	}
	defer release(static)
	if staticCheck(static, 16, good) != 0 {
		return fail()
	}
	var info uintptr
	if infoCopy(guest, 2, &info) != 0 || info == 0 {
		return fail()
	}
	defer release(info)
	hash := dictGet(info, unique)
	if hash == 0 {
		return fail()
	}
	length := dataLength(hash)
	pointer := dataBytes(hash)
	if length != 20 || pointer == nil {
		return fail()
	}
	digest := hex.EncodeToString(unsafe.Slice(pointer, int(length)))
	if digest != wantHash || check(guest, 0, good) != 0 || !checkPath() {
		return fail()
	}
	return digest, nil
}
