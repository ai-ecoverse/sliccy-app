package integration

import (
	"bytes"
	"context"
	"image"
	"image/color"
	"image/draw"
	"image/jpeg"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
	"github.com/ai-ecoverse/slicc-cli/internal/link"
	"github.com/pion/webrtc/v4"
)

func runnerSyntheticJPEG(t *testing.T, pulse bool) []byte {
	t.Helper()
	img := image.NewRGBA(image.Rect(0, 0, 256, 256))
	for i, c := range fixtureQuadrants {
		draw.Draw(img, image.Rect(i%2*128, i/2*128, i%2*128+128, i/2*128+128), image.NewUniform(color.RGBA{byte(c[0]), byte(c[1]), byte(c[2]), 255}), image.Point{}, draw.Src)
	}
	v := byte(0)
	if pulse {
		v = 255
	}
	draw.Draw(img, image.Rect(8, 8, 24, 24), image.NewUniform(color.RGBA{v, v, v, 255}), image.Point{}, draw.Src)
	var body bytes.Buffer
	if jpeg.Encode(&body, img, &jpeg.Options{Quality: 65}) != nil {
		t.Fatal("synthetic JPEG encoder failed")
	}
	return body.Bytes()
}
func TestRunnerLivePionFixtureClearsWhileDecoderIsBlocked(t *testing.T){runRunnerPionFixture(t,false)}
func TestRunnerLivePionUnsettledWorkerBlocksLaterCases(t *testing.T){runRunnerPionFixture(t,true)}
func runRunnerPionFixture(t *testing.T,observeUnsettled bool){
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	api := link.NewAPI(link.APIOptions{Loopback: true})
	pagePC, e := api.NewPeerConnection(webrtc.Configuration{})
	if e != nil {
		t.Fatal(e)
	}
	nodePC, e := api.NewPeerConnection(webrtc.Configuration{})
	if e != nil {
		t.Fatal(e)
	}
	var saved atomic.Int32
	entered, release := make(chan struct{}), make(chan struct{})
	var released sync.Once
	defer released.Do(func() { close(release) })
	p := &runnerCapturePage{Wake: make(chan struct{}, 1), Done: make(chan struct{}), LinkDone: make(chan struct{}), TransportDone: make(chan struct{}), Receiver: runnerReceiver{ceiling: screen.DefaultLimits(), scope: "window"}}
	p.inspect = func(f screen.Frame, img image.Image) (bool, error) {
		if f.Seq == "3" {
			close(entered)
			select {
			case <-release:
			case <-ctx.Done():
			}
		}
		pulse, _, e := inspectRunnerCapturePixels(img, independentRect{128, 128, 256, 256}, nil)
		return pulse, e
	}
	p.save = func(_ screen.Frame, _ []byte) error { saved.Add(1); return nil }
	p.Page, e = link.New(pagePC, link.RolePage, link.Options{Hello: link.Hello{Caps: []string{"screen-state"}}, Handlers: map[string]link.Handler{"screen-state": p.handleState}})
	if e != nil {
		t.Fatal(e)
	}
	streamReady := make(chan *link.Stream, 1)
	var badAck atomic.Bool
	binding := screen.Binding{Link: screen.ID(16), Session: screen.ID(16), Source: screen.ID(16), GrantEpoch: "1", SourceEpoch: "1", ProtectionEpoch: "1"}
	nodeLink, e := link.New(nodePC, link.RoleNode, link.Options{Hello: link.Hello{Caps: []string{}, Screen: screen.Support{V: 1, Scopes: []string{"window"}, Codec: "jpeg", Limits: screen.DefaultLimits()}}, Handlers: map[string]link.Handler{"screen": func(s *link.Stream) {
		var open screen.Open
		if screen.Strict(s.OpenPayload(), &open, 4096) != nil || open.Binding != binding {
			t.Error("invalid fixture OPEN")
			_ = s.Reset("EPROTO")
			return
		}
		if s.Accept(map[string]any{"v": 1, "binding": binding, "codec": "jpeg", "maxWidth": 256, "maxHeight": 256, "maxFps": 5}) != nil {
			t.Error("fixture OPENED failed")
			return
		}
		streamReady <- s
	}, "screen-stop": func(s *link.Stream) {
		var stop screen.Stop
		if screen.Strict(s.OpenPayload(), &stop, 4096) != nil || stop.Kind != "screen-stop" || stop.V != 1 || stop.Link != binding.Link || stop.Session == nil || *stop.Session != binding.Session {
			_ = s.Reset("EPROTO")
			return
		}
		_ = s.Accept(map[string]any{"v": 1, "stopped": !badAck.Load()})
		_ = s.CloseWrite()
	}}})
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { _ = nodeLink.Close(); _ = p.Page.Close() })
	go func() {
		defer close(p.LinkDone)
		<-p.Page.Done()
		p.Receiver.clear()
		p.fact(runnerWireFact{Kind: "link-lost", At: time.Now()})
	}()
	offer, e := pagePC.CreateOffer(nil)
	if e != nil {
		t.Fatal(e)
	}
	gather := webrtc.GatheringCompletePromise(pagePC)
	if pagePC.SetLocalDescription(offer) != nil {
		t.Fatal("fixture offer failed")
	}
	select {
	case <-gather:
	case <-ctx.Done():
		t.Fatal("fixture offer deadline")
	}
	if nodePC.SetRemoteDescription(*pagePC.LocalDescription()) != nil {
		t.Fatal("fixture remote offer failed")
	}
	answer, e := nodePC.CreateAnswer(nil)
	if e != nil {
		t.Fatal(e)
	}
	gather = webrtc.GatheringCompletePromise(nodePC)
	if nodePC.SetLocalDescription(answer) != nil {
		t.Fatal("fixture answer failed")
	}
	select {
	case <-gather:
	case <-ctx.Done():
		t.Fatal("fixture answer deadline")
	}
	if pagePC.SetRemoteDescription(*nodePC.LocalDescription()) != nil {
		t.Fatal("fixture remote answer failed")
	}
	for _, ready := range []<-chan struct{}{p.Page.Ready(), nodeLink.Ready()} {
		select {
		case <-ready:
		case <-ctx.Done():
			t.Fatal("fixture HELLO deadline")
		}
	}
	state := func(value screen.State) {
		s, e := nodeLink.Open(ctx, value, link.OpenOptions{Shared: true})
		if e != nil {
			t.Fatal("fixture state OPEN failed", e)
		}
		_ = s.CloseWrite()
	}
	state(screen.State{Kind: "screen-state", V: 1, Seq: "1", Caps: []string{}, Link: binding.Link, Reason: "awaiting-consent"})
	limits := screen.DefaultLimits()
	state(screen.State{Kind: "screen-state", V: 1, Seq: "2", Caps: []string{"screen"}, Binding: &binding, Scope: "window", Reason: "active", Limits: &limits})
	var stream *link.Stream
	select {
	case stream = <-streamReady:
	case <-ctx.Done():
		t.Fatal("fixture screen subscription absent")
	}
	frame := func(sequence screen.Counter, pulse bool) {
		f := screen.Frame{Type: "frame", V: 1, Binding: binding, Seq: sequence, Captured: sequence, Width: 256, Height: 256, Codec: "jpeg"}
		body := runnerSyntheticJPEG(t, pulse)
		if sequence == "1" {
			if body[2] != 255 || body[3] != 219 {
				t.Fatal("generated DQT marker absent")
			}
			size := int(body[4])<<8 | int(body[5])
			table := body[2 : 4+size]
			padded := []byte{255, 216}
			for i := 0; i < 2400; i++ {
				padded = append(padded, table...)
			}
			body = append(padded, body[2:]...)
			if len(body) <= link.Window {
				t.Fatal("fixture does not cross credit window")
			}
		}
		if screen.WriteRecord(stream.Conn(), f, body, time.Second) != nil {
			t.Fatal("fixture frame write failed")
		}
	}
	wait := func(test func([]runnerWireFact) bool) {
		for {
			facts, problem := p.snapshot()
			if problem != "" {
				t.Fatal(problem)
			}
			if test(facts) {
				return
			}
			select {
			case <-p.Wake:
			case <-ctx.Done():
				t.Fatal("fixture observation deadline")
			}
		}
	}
	frame("1", false)
	frame("2", true)
	wait(func(facts []runnerWireFact) bool {
		n := 0
		for _, f := range facts {
			if f.Kind == "frame" && f.Admitted {
				n++
			}
		}
		return n == 2
	})
	frame("3", false)
	select {
	case <-entered:
	case <-ctx.Done():
		t.Fatal("fixture decoder did not block")
	}
	session := binding.Session
	state(screen.State{Kind: "screen-state", V: 1, Seq: "3", Caps: []string{}, Link: binding.Link, LastSession: &session, Reason: "stopped"})
	p.Receiver.mu.Lock()
	granted := p.Receiver.granted
	p.Receiver.mu.Unlock()
	if granted {
		t.Fatal("control state blocked behind decoder")
	}
 if observeUnsettled{
  result:=runnerCaseResult{Result:"PASS",AppPID:42,AppReaped:true,DirectChildrenGone:true,RootsRemoved:true,OwnedWindowsGone:true,MetadataReaderSettled:true,NativeObservationSettled:true}
  _ = stream.Reset("EACCES")
  if closeRunnerCaseProtocol(&result,p,time.Now().Add(20*time.Millisecond))||result.ProtocolWorkersSettled||result.Result!="FAIL"{t.Fatal("ASSERTION:pion-unsettled-closing-boundary")}
  if !runnerBlocksLaterCases(result){t.Fatal("ASSERTION:pion-unsettled-blocks-later-cases")}
  released.Do(func(){close(release)})
  if !p.closeAndWait(time.Now().Add(2*time.Second)){t.Fatal("Pion fixture did not physically settle after test release")}
  if result.Result!="FAIL"||result.ProtocolWorkersSettled{t.Fatal("failed settlement observation promoted after later release")}
  clean:=runnerCaseResult{Result:"PASS",AppPID:42,AppReaped:true,DirectChildrenGone:true,RootsRemoved:true,OwnedWindowsGone:true,MetadataReaderSettled:true,NativeObservationSettled:true}
  if !closeRunnerCaseProtocol(&clean,p,time.Now().Add(time.Second))||runnerBlocksLaterCases(clean){t.Fatal("settled Pion control did not permit independent later cases")}
  return
 }
	_ = stream.Reset("EACCES")
	released.Do(func() { close(release) })
	wait(func(facts []runnerWireFact) bool {
		for _, f := range facts {
			if f.Kind == "reset" {
				return true
			}
		}
		return false
	})
	facts, problem := p.snapshot()
	if problem != "" {
		t.Fatal(problem)
	}
	seenLate := false
	for _, f := range facts {
		if f.Frame != nil && f.Frame.Seq == "3" {
			seenLate = true
			if f.Admitted {
				t.Fatal("decode completing after reset admitted pixels")
			}
		}
	}
	if !seenLate || saved.Load() != 3 {
		t.Fatal("complete inflight frame evidence lost")
	}

	stopCtx, stopCancel := context.WithTimeout(ctx, time.Second)
	if p.stop(stopCtx) != nil {
		t.Fatal("actual Stop RPC fixture failed")
	}
	stopCancel()
	badAck.Store(true)
	stopCtx, stopCancel = context.WithTimeout(ctx, time.Second)
	if p.stop(stopCtx) == nil {
		t.Fatal("malformed Stop acknowledgement accepted")
	}
	stopCancel()
	if !p.closeAndWait(time.Now().Add(2 * time.Second)) {
		facts, _ := p.snapshot()
		last := facts[len(facts)-1]
		t.Fatal("fixture Pion workers did not settle", last.Kind, last.Reason)
	}
}
