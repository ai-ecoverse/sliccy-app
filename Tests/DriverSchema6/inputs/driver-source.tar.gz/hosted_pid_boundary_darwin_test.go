package integration

import "testing"

func TestHostedPIDObservationEndedAllowsImmediateStop(t *testing.T) {
	markerSent, alive := false, true
	samples, failures := []string{}, []string{}
	sample := func(label string) bool { samples = append(samples, label); return alive }
	marker := func(value string) {
		if value != "pid-result-observed" || len(samples) != 1 || samples[0] != "current-after-old-call" {
			t.Fatal("required live sample did not precede fixed marker")
		}
		alive = false
	}
	incomplete := func(reason string) { failures = append(failures, reason) }
	hostedPIDObservationBoundary("pid-reuse-current-token-rechecked", &markerSent, true, sample, marker, incomplete)
	hostedPIDObservationBoundary("pid-reuse-observation-ended", &markerSent, true, sample, marker, incomplete)
	if !markerSent || len(samples) != 1 || len(failures) != 0 {
		t.Fatalf("permitted immediate stop was treated as failure: samples=%v failures=%v", samples, failures)
	}
}
func TestHostedPIDRequiredPreMarkerControlStillFails(t *testing.T) {
	for _, oldRefused := range []bool{false, true} {
		markerSent, failed := false, false
		hostedPIDObservationBoundary("pid-reuse-current-token-rechecked", &markerSent, oldRefused, func(string) bool { return false }, func(string) {}, func(string) { failed = true })
		if !failed {
			t.Fatal("missing old refusal/live current control was accepted")
		}
	}
	markerSent, failed := false, false
	hostedPIDObservationBoundary("pid-reuse-observation-ended", &markerSent, true, func(string) bool { t.Fatal("post-marker live sampling is forbidden"); return false }, func(string) {}, func(string) { failed = true })
	if !failed {
		t.Fatal("observation end without marker was accepted")
	}
}
