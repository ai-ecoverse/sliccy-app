package integration

import (
	"encoding/json"
	"fmt"
	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
	"math"
	"strconv"
	"strings"
	"testing"
)

type captureTimingRow struct {
	Schema          int      `json:"schema"`
	Case            string   `json:"case"`
	Capture         *bool    `json:"capture"`
	Stage           string   `json:"stage"`
	Elapsed         float64  `json:"elapsedMs"`
	Event           float64  `json:"eventElapsedMs"`
	Trigger         string   `json:"trigger,omitempty"`
	Duration        *float64 `json:"durationMs,omitempty"`
	Sequence        string   `json:"frameSeq,omitempty"`
	Captured        string   `json:"capturedMonoMs,omitempty"`
	Ordinal         *int     `json:"revokeOrdinal,omitempty"`
	StopBegan       *float64 `json:"stopBeganElapsedMs,omitempty"`
	Requests        *int     `json:"requests,omitempty"`
	Written         *int     `json:"written,omitempty"`
	Pending         *int     `json:"pending,omitempty"`
	PendingAtCutoff *int     `json:"pendingAtCutoff,omitempty"`
	ReadInFlight    *bool    `json:"readInFlightAtCutoff,omitempty"`
	TransportOpen   *bool    `json:"transportWasOpen,omitempty"`
	Invalid         *bool    `json:"invalid,omitempty"`
	Settled         *bool    `json:"workersSettled,omitempty"`
	Complete        *bool    `json:"complete,omitempty"`
}

func captureCanonical(s string) bool {
	if s == "" || len(s) > 20 || len(s) > 1 && s[0] == '0' {
		return false
	}
	for _, c := range s {
		if c < '0' || c > '9' {
			return false
		}
	}
	_, e := strconv.ParseUint(s, 10, 64)
	return e == nil
}

func decodeCaptureTiming(raw []byte) (captureTimingRow, error) {
	var row captureTimingRow
	if runnerStrict(raw, &row, 4096) != nil || row.Schema != 6 || row.Capture == nil || !*row.Capture || !finiteNonnegative(row.Elapsed) || !finiteNonnegative(row.Event) || row.Event > row.Elapsed {
		return row, fmt.Errorf("invalid capture timing envelope")
	}
	switch row.Case {
	case "selected-window", "display-exclusion", "authorization-exclusion", "reciprocal-revoke", "active-stop", "hotkey-stop":
	default:
		return row, fmt.Errorf("unknown capture case")
	}
	keys := strings.Fields("schema case capture stage elapsedMs eventElapsedMs")
	switch row.Stage {
	case "stop-requested", "stop-handler-entered":
		keys = append(keys, "trigger")
	case "local-gate-invalidated":
		keys = append(keys, "durationMs")
	case "native-ack":
		keys = append(keys, "durationMs", "revokeOrdinal")
	case "revoke-queued":
		keys = append(keys, "revokeOrdinal", "stopBeganElapsedMs")
	case "source-admitted":
		keys = append(keys, "frameSeq", "capturedMonoMs")
	case "native-admitted":
		keys = append(keys, "frameSeq")
	case "reverse-revoke-received", "reverse-reply-enqueued", "reverse-reply-written":
		keys = append(keys, "revokeOrdinal")
	case "reverse-ledger-closed":
		keys = append(keys, strings.Fields("requests written pending pendingAtCutoff readInFlightAtCutoff transportWasOpen invalid workersSettled complete")...)
	case "grant-requested", "capture-started", "receiver-reset-confirmed", "capture-stopped":
	default:
		return row, fmt.Errorf("not a capture timing stage")
	}
	var fields map[string]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil || len(fields) != len(keys) {
		return row, fmt.Errorf("wrong capture timing field set")
	}
	for _, key := range keys {
		v, ok := fields[key]
		if !ok || strings.TrimSpace(string(v)) == "null" {
			return row, fmt.Errorf("missing capture timing field")
		}
	}
	if row.Trigger != "" && row.Trigger != "button" && row.Trigger != "hotkey" && row.Trigger != "remote" {
		return row, fmt.Errorf("invalid trigger")
	}
	if row.Stage == "stop-handler-entered" && row.Trigger == "remote" {
		return row, fmt.Errorf("remote is not a local handler")
	}
	if row.Duration != nil && !finiteNonnegative(*row.Duration) {
		return row, fmt.Errorf("invalid duration")
	}
	if row.Sequence != "" && (!captureCanonical(row.Sequence) || row.Sequence == "0") {
		return row, fmt.Errorf("invalid frame sequence")
	}
	if row.Stage == "source-admitted" && !captureCanonical(row.Captured) {
		return row, fmt.Errorf("invalid capture timestamp")
	}
	if (row.Stage == "source-admitted" || row.Stage == "native-admitted") && row.Sequence == "" {
		return row, fmt.Errorf("missing frame sequence")
	}
	if row.StopBegan != nil && (!finiteNonnegative(*row.StopBegan) || *row.StopBegan > row.Event) {
		return row, fmt.Errorf("invalid own revoke start")
	}
	if row.Ordinal != nil && (*row.Ordinal < 1 || strings.HasPrefix(row.Stage, "reverse-") && *row.Ordinal > 8) {
		return row, fmt.Errorf("invalid reverse ordinal")
	}
	for _, v := range []*int{row.Requests, row.Written, row.Pending, row.PendingAtCutoff} {
		if v != nil && (*v < 0 || *v > 8) {
			return row, fmt.Errorf("invalid reverse count")
		}
	}
	return row, nil
}

func validateCaptureTiming(rows []captureTimingRow) error {
	if _, err := runnerCaptureDurationBound(rows); err != nil {
		return err
	}
	if len(rows) > 512 {
		return fmt.Errorf("timing row budget exceeded")
	}
	singleton := map[string]captureTimingRow{}
	source, native := map[string]captureTimingRow{}, map[string]captureTimingRow{}
	reverse := map[int]map[string]captureTimingRow{}
	own := map[int]map[string]captureTimingRow{}
	var selected string
	last := 0.0
	for _, row := range rows {
		if selected == "" {
			selected = row.Case
		}
		if row.Case != selected || row.Elapsed < last {
			return fmt.Errorf("mixed cases or reordered emission")
		}
		last = row.Elapsed
		switch row.Stage {
		case "source-admitted", "native-admitted":
			target := source
			if row.Stage == "native-admitted" {
				target = native
			}
			if _, ok := target[row.Sequence]; ok {
				return fmt.Errorf("duplicate admission")
			}
			target[row.Sequence] = row
		case "revoke-queued", "native-ack":
			if row.Ordinal == nil {
				return fmt.Errorf("missing own request ordinal")
			}
			if own[*row.Ordinal] == nil {
				own[*row.Ordinal] = map[string]captureTimingRow{}
			}
			if _, duplicate := own[*row.Ordinal][row.Stage]; duplicate {
				return fmt.Errorf("duplicate own revoke admission/ACK")
			}
			own[*row.Ordinal][row.Stage] = row
		case "reverse-revoke-received", "reverse-reply-enqueued", "reverse-reply-written":
			if row.Ordinal == nil {
				return fmt.Errorf("missing ordinal")
			}
			if reverse[*row.Ordinal] == nil {
				reverse[*row.Ordinal] = map[string]captureTimingRow{}
			}
			if _, ok := reverse[*row.Ordinal][row.Stage]; ok {
				return fmt.Errorf("duplicate reverse phase")
			}
			reverse[*row.Ordinal][row.Stage] = row
		default:
			if _, ok := singleton[row.Stage]; ok {
				return fmt.Errorf("duplicate timing milestone")
			}
			singleton[row.Stage] = row
		}
	}
	for _, stage := range []string{"stop-requested", "local-gate-invalidated", "receiver-reset-confirmed", "capture-stopped", "reverse-ledger-closed"} {
		if _, ok := singleton[stage]; !ok {
			return fmt.Errorf("missing %s", stage)
		}
	}
	stop, gate, reset, closed := singleton["stop-requested"], singleton["local-gate-invalidated"], singleton["receiver-reset-confirmed"], singleton["reverse-ledger-closed"]
	if gate.Duration == nil || *gate.Duration > 50 {
		return fmt.Errorf("gate missed original target")
	}
	if reset.Event < gate.Event || reset.Event-stop.Event > 1500 || closed.Event < reset.Event || closed.Event-stop.Event > 1500 || singleton["capture-stopped"].Event > closed.Event {
		return fmt.Errorf("stop/closure exceeded original deadline or order")
	}
	if selected == "reciprocal-revoke" {
		if stop.Trigger != "remote" || len(reverse) == 0 || gate.Event > stop.Event {
			return fmt.Errorf("missing reciprocal evidence")
		}
	} else {
		want := "button"
		if selected == "hotkey-stop" {
			want = "hotkey"
		}
		handler, ok := singleton["stop-handler-entered"]
		if !ok || handler.Trigger != want || stop.Trigger != want || handler.Event < stop.Event || handler.Event > gate.Event || gate.Event-stop.Event > 50 {
			return fmt.Errorf("missing actual local handler")
		}
		if len(own) == 0 {
			return fmt.Errorf("missing own revoke evidence")
		}
	}
	cutoffStart := stop.Event
	if gate.Duration == nil || gate.Event < *gate.Duration {
		return fmt.Errorf("invalid gate clock")
	}
	if gate.Event-*gate.Duration < cutoffStart {
		cutoffStart = gate.Event - *gate.Duration
	}
	previousACK := -1.0
	for ordinal := 1; ordinal <= len(own); ordinal++ {
		phases, ok := own[ordinal]
		queued, qok := phases["revoke-queued"]
		ack, aok := phases["native-ack"]
		if !ok || len(phases) != 2 || !qok || !aok || queued.StopBegan == nil || ack.Duration == nil || queued.Event < gate.Event || *queued.StopBegan < gate.Event || ack.Event < queued.Event || ack.Event > closed.Event || queued.Event > closed.Event || *queued.StopBegan < previousACK || ack.Event-*queued.StopBegan > 1500 || *ack.Duration > 1500 {
			return fmt.Errorf("own revoke gap, revival or missed deadline")
		}
		if *queued.StopBegan < cutoffStart {
			cutoffStart = *queued.StopBegan
		}
		if math.Abs((ack.Event-*queued.StopBegan)-*ack.Duration) > 0.000001 {
			return fmt.Errorf("ACK duration is not from its original request")
		}
		previousACK = ack.Event
	}
	if reset.Event-cutoffStart > 1500 || closed.Event-cutoffStart > 1500 {
		return fmt.Errorf("earliest Stop cutoff missed")
	}
	if len(source) == 0 || len(native) == 0 {
		return fmt.Errorf("missing capture admissions")
	}
	for seq, row := range source {
		if row.Event > gate.Event {
			return fmt.Errorf("source admitted after invalidation")
		}
		if n, ok := native[seq]; ok && n.Event < row.Event {
			return fmt.Errorf("native preceded source")
		}
	}
	for seq, row := range native {
		if _, ok := source[seq]; !ok || row.Event > gate.Event {
			return fmt.Errorf("unmatched/late native admission")
		}
	}
	if closed.Requests == nil || closed.Written == nil || closed.Pending == nil || closed.PendingAtCutoff == nil || closed.ReadInFlight == nil || closed.TransportOpen == nil || closed.Invalid == nil || closed.Settled == nil || closed.Complete == nil || *closed.Requests != len(reverse) || *closed.Written != len(reverse) || *closed.Pending != 0 || *closed.PendingAtCutoff != 0 || *closed.ReadInFlight || !*closed.TransportOpen || *closed.Invalid || !*closed.Settled || !*closed.Complete {
		return fmt.Errorf("incomplete reverse closure")
	}
	for ordinal, phases := range reverse {
		if ordinal < 1 || ordinal > len(reverse) || len(phases) != 3 {
			return fmt.Errorf("reverse gap or incomplete phase")
		}
		received, rok := phases["reverse-revoke-received"]
		enqueued, eok := phases["reverse-reply-enqueued"]
		written, wok := phases["reverse-reply-written"]
		if !rok || !eok || !wok || received.Event > enqueued.Event || enqueued.Event > written.Event || written.Event > closed.Event || written.Event-stop.Event > 1500 || (selected == "reciprocal-revoke" && (gate.Event > received.Event || (ordinal == 1 && received.Event != stop.Event))) {
			return fmt.Errorf("reverse event order/deadline invalid")
		}
	}
	return nil
}

func TestCaptureTimingRejectsLossAndDistinguishesEventFromEmission(t *testing.T) {
	makeRows := func() []captureTimingRow { return runnerCaptureTimingFixture(t) }
	if e := validateCaptureTiming(makeRows()); e != nil {
		t.Fatal(e)
	}
	delayed := makeRows()
	for i := 9; i < len(delayed); i++ {
		delayed[i].Elapsed = 2000 + float64(i)
	}
	if e := validateCaptureTiming(delayed); e != nil {
		t.Fatal("delayed final observation substituted for actual cutoff time", e)
	}
	fresh := makeRows()
	queued, ack := fresh[3], fresh[6]
	ordinal := 2
	began := 16.0
	duration := 1.0
	queued.Ordinal = &ordinal
	queued.StopBegan = &began
	queued.Event = 16
	queued.Elapsed = 200
	ack.Ordinal = &ordinal
	ack.Duration = &duration
	ack.Event = 17
	ack.Elapsed = 201
	fresh = append(fresh, queued, ack)
	if e := validateCaptureTiming(fresh); e != nil {
		t.Fatal("fresh request after a valid ACK must retain its own ordinal", e)
	}
	badFresh := append([]captureTimingRow(nil), fresh...)
	tooEarly := 14.0
	badFresh[len(badFresh)-2].StopBegan = &tooEarly
	if validateCaptureTiming(badFresh) == nil {
		t.Fatal("new admission before pending ACK accepted")
	}
	if validateCaptureTiming(append(fresh, ack)) == nil {
		t.Fatal("duplicate own ACK accepted")
	}
	if validateCaptureTiming(fresh[:len(fresh)-1]) == nil {
		t.Fatal("missing own ACK accepted")
	}
	changes := []func([]captureTimingRow){
		func(r []captureTimingRow) { r[1].Event = 12.1 },
		func(r []captureTimingRow) { r[0].Event = 12.1 },
		func(r []captureTimingRow) { r[5].Event = 61 },
		func(r []captureTimingRow) { r[9].Event = 1511 },
		func(r []captureTimingRow) { v := 1; r[9].PendingAtCutoff = &v },
		func(r []captureTimingRow) { v := true; r[9].ReadInFlight = &v },
		func(r []captureTimingRow) { v := false; r[9].Settled = &v },
		func(r []captureTimingRow) { r[4].Trigger = "hotkey" },
		func(r []captureTimingRow) { r[1].Sequence = "2" },
	}
	for i, change := range changes {
		r := makeRows()
		change(r)
		if validateCaptureTiming(r) == nil {
			t.Fatalf("bad timing mutation %d passed", i)
		}
	}
	if validateCaptureTiming(makeRows()[:9]) == nil {
		t.Fatal("missing closure accepted")
	}
	remote := makeRows()
	remote = append(remote[:3], remote[5:]...)
	for i := range remote {
		remote[i].Case = "reciprocal-revoke"
	}
	remote[2].Trigger = "remote"
	remote[3].Event = 9
	remote = append(remote[:4], remote[5:]...)
	count := 1
	for i := range remote {
		if remote[i].Stage == "reverse-ledger-closed" {
			remote[i].Requests = &count
			remote[i].Written = &count
		}
	}
	for i, stage := range []string{"reverse-revoke-received", "reverse-reply-enqueued", "reverse-reply-written"} {
		raw := fmt.Sprintf(`{"schema":6,"case":"reciprocal-revoke","capture":true,"elapsedMs":%d,"eventElapsedMs":%d,"stage":"%s","revokeOrdinal":1}`, 200+i, 10+i, stage)
		row, e := decodeCaptureTiming([]byte(raw))
		if e != nil {
			t.Fatal(e)
		}
		remote = append(remote, row)
	}
	if e := validateCaptureTiming(remote); e != nil {
		t.Fatal("remote invalidation must precede its validated receipt observation", e)
	}
	badRemote := append([]captureTimingRow(nil), remote...)
	badRemote[3].Event = 10.1
	if validateCaptureTiming(badRemote) == nil {
		t.Fatal("remote gate after validated request accepted")
	}
	if validateCaptureTiming(append(remote, remote[len(remote)-1])) == nil {
		t.Fatal("duplicate reverse completion accepted")
	}
	badRemote = append([]captureTimingRow(nil), remote...)
	badRemote[len(badRemote)-1].Event = 19
	if validateCaptureTiming(badRemote) == nil {
		t.Fatal("actual write after cutoff accepted")
	}
	good := `{"schema":6,"case":"active-stop","capture":true,"elapsedMs":2,"eventElapsedMs":1,"stage":"source-admitted","frameSeq":"1","capturedMonoMs":"10"}`
	for _, bad := range []string{
		strings.Replace(good, `"eventElapsedMs":1`, `"eventElapsedMs":3`, 1),
		strings.Replace(good, `"frameSeq":"1"`, `"frameSeq":"01"`, 1),
		strings.Replace(good, `"frameSeq":"1"`, `"frameSeq":"18446744073709551616"`, 1),
		strings.Replace(good, `"frameSeq":"1"`, `"frameSeq":"1","frameSeq":"2"`, 1),
		strings.Replace(good, `"capture":true`, `"capture":null`, 1),
		strings.Replace(good, `"schema":6`, `"schema":6,"unknown":false`, 1),
		strings.Replace(good, `"capturedMonoMs":"10"`, `"capturedMonoMs":null`, 1),
		good + " {}",
	} {
		if _, e := decodeCaptureTiming([]byte(bad)); e == nil {
			t.Fatal("invalid timing metadata passed")
		}
	}
}

func matchRunnerWireAdmissions(rows []captureTimingRow, facts []runnerWireFact) error {
	source, native := map[string]captureTimingRow{}, map[string]bool{}
	for _, row := range rows {
		if row.Stage == "source-admitted" {
			source[row.Sequence] = row
		}
		if row.Stage == "native-admitted" {
			native[row.Sequence] = true
		}
	}
	var lastCapture uint64
	seen := false
	for _, fact := range facts {
		if fact.Kind != "frame" || !fact.Admitted {
			continue
		}
		if fact.Frame == nil {
			return fmt.Errorf("missing admitted frame header")
		}
		sequence := string(fact.Frame.Seq)
		row, ok := source[sequence]
		if !ok || !native[sequence] || row.Captured != string(fact.Frame.Captured) {
			return fmt.Errorf("wire frame not correlated to actual source/native admissions")
		}
		captured, e := runnerCounter(fact.Frame.Captured)
		if e != nil || seen && captured <= lastCapture {
			return fmt.Errorf("captured freshness counter did not advance")
		}
		lastCapture = captured
		seen = true
	}
	if !seen {
		return fmt.Errorf("no independently admitted pixels")
	}
	return nil
}
func TestRunnerWireFramesMustMatchSourceAndNativeAdmissionLedger(t *testing.T) {
	rows := []captureTimingRow{{Stage: "source-admitted", Sequence: "1", Captured: "10"}, {Stage: "native-admitted", Sequence: "1"}}
	frame := screen.Frame{Seq: "1", Captured: "10"}
	facts := []runnerWireFact{{Kind: "frame", Admitted: true, Frame: &frame}}
	if matchRunnerWireAdmissions(rows, facts) != nil {
		t.Fatal("valid admission correlation rejected")
	}
	frame.Captured = "11"
	if matchRunnerWireAdmissions(rows, facts) == nil {
		t.Fatal("different capture timestamp accepted")
	}
	frame.Captured = "10"
	if matchRunnerWireAdmissions(rows[:1], facts) == nil {
		t.Fatal("missing native admission accepted")
	}
	facts = append(facts, facts[0])
	if matchRunnerWireAdmissions(rows, facts) == nil {
		t.Fatal("repeated captured timestamp accepted")
	}
}

func runnerCaptureTimingFixture(t *testing.T) []captureTimingRow {
	t.Helper()
	stages := []string{
		`"stage":"source-admitted","eventElapsedMs":2,"frameSeq":"1","capturedMonoMs":"10"`,
		`"stage":"native-admitted","eventElapsedMs":3,"frameSeq":"1"`,
		`"stage":"stop-requested","eventElapsedMs":10,"trigger":"button"`,
		`"stage":"revoke-queued","eventElapsedMs":13,"revokeOrdinal":1,"stopBeganElapsedMs":12`,
		`"stage":"stop-handler-entered","eventElapsedMs":11,"trigger":"button"`,
		`"stage":"local-gate-invalidated","eventElapsedMs":12,"durationMs":1`,
		`"stage":"native-ack","eventElapsedMs":15,"durationMs":3,"revokeOrdinal":1`,
		`"stage":"receiver-reset-confirmed","eventElapsedMs":16`,
		`"stage":"capture-stopped","eventElapsedMs":17`,
		`"stage":"reverse-ledger-closed","eventElapsedMs":18,"requests":0,"written":0,"pending":0,"pendingAtCutoff":0,"readInFlightAtCutoff":false,"transportWasOpen":true,"invalid":false,"workersSettled":true,"complete":true`,
	}
	var result []captureTimingRow
	for i, s := range stages {
		raw := fmt.Sprintf(`{"schema":6,"case":"active-stop","capture":true,"elapsedMs":%d,%s}`, 100+i, s)
		row, e := decodeCaptureTiming([]byte(raw))
		if e != nil {
			t.Fatal(e)
		}
		result = append(result, row)
	}
	for i, stage := range []string{"grant-requested", "capture-started"} {
		raw := fmt.Sprintf(`{"schema":6,"case":"active-stop","capture":true,"elapsedMs":%d,"eventElapsedMs":%g,"stage":"%s"}`, 110+i, 0.5+float64(i)*0.5, stage)
		row, e := decodeCaptureTiming([]byte(raw))
		if e != nil {
			t.Fatal(e)
		}
		result = append(result, row)
	}

	return result
}

type runnerCaptureDurationEvidence struct {
	Basis                string  `json:"basis"`
	BeforeStartEventMS   float64 `json:"beforeStartEventMs"`
	StartedObservationMS float64 `json:"startedObservationMs"`
	StoppedEventMS       float64 `json:"stoppedEventMs"`
	UpperMS              float64 `json:"upperMs"`
}

func runnerCaptureDurationBound(rows []captureTimingRow) (e runnerCaptureDurationEvidence, err error) {
	stages := map[string]captureTimingRow{}
	for _, row := range rows {
		if runnerOneOf(row.Stage, "grant-requested capture-started capture-stopped") {
			if _, duplicate := stages[row.Stage]; duplicate {
				return e, fmt.Errorf("duplicate capture span milestone")
			}
			stages[row.Stage] = row
		}
	}
	grant, gok := stages["grant-requested"]
	started, sok := stages["capture-started"]
	stopped, eok := stages["capture-stopped"]
	if !gok || !sok || !eok || !finiteNonnegative(grant.Event) || !finiteNonnegative(started.Event) || !finiteNonnegative(stopped.Event) || started.Event < grant.Event || stopped.Event < started.Event {
		return e, fmt.Errorf("capture span unavailable or unordered")
	}
	e = runnerCaptureDurationEvidence{Basis: "grant-requested-before-stream-start", BeforeStartEventMS: grant.Event, StartedObservationMS: started.Event, StoppedEventMS: stopped.Event, UpperMS: stopped.Event - grant.Event}
	if e.UpperMS > 10000 {
		return e, fmt.Errorf("conservative capture span exceeds10seconds")
	}
	return e, nil
}

func TestRunnerCaptureDurationIncludesPreStreamStartAndRejectsOverLimit(t *testing.T) {
	for _, name := range []string{"baseline", "boundary", "over-limit", "prestart-delay", "missing-grant", "missing-start", "stopped-before-start", "early-frame-before-start-observation"} {
		t.Run(name, func(t *testing.T) {
			rows := runnerCaptureTimingFixture(t)
			shift := 0.0
			if name == "boundary" {
				shift = 9983.5
			}
			if name == "over-limit" || name == "prestart-delay" {
				shift = 10000
			}
			for i := range rows {
				row := &rows[i]
				row.Elapsed += shift
				if row.Stage != "grant-requested" && row.Stage != "capture-started" {
					row.Event += shift
					if row.StopBegan != nil {
						copy := *row.StopBegan + shift
						row.StopBegan = &copy
					}
				}
				if name == "prestart-delay" && row.Stage == "capture-started" {
					row.Event = 10000
				}
				if name == "stopped-before-start" && row.Stage == "capture-started" {
					row.Event = 18
				}
				if name == "early-frame-before-start-observation" && row.Stage == "source-admitted" {
					row.Event = 0.75
				}
			}
			if name == "missing-grant" || name == "missing-start" {
				stage := "grant-requested"
				if name == "missing-start" {
					stage = "capture-started"
				}
				filtered := []captureTimingRow{}
				for _, row := range rows {
					if row.Stage != stage {
						filtered = append(filtered, row)
					}
				}
				rows = filtered
			}
			err := validateCaptureTiming(rows)
			valid := runnerOneOf(name, "baseline boundary early-frame-before-start-observation")
			if valid {
				if err != nil {
					t.Fatalf("ASSERTION:capture-span-valid-%s %v", name, err)
				}
			} else if err == nil {
				t.Fatalf("ASSERTION:capture-span-refuse-%s", name)
			}
			if name == "boundary" {
				bound, err := runnerCaptureDurationBound(rows)
				if err != nil || bound.UpperMS != 10000 {
					t.Fatal("exact10second boundary not retained")
				}
			}
		})
	}
}
