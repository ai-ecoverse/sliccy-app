package integration

import (
	"bytes"
	"encoding/hex"
	"fmt"
	"strings"
)

type runnerCodeInformation struct {
	Identifier, Path string
	Type             int64
	Hash, Full       []byte
	Offset           *uint64
}

type runnerFileSlice struct {
	CPU, Subtype int32
	Offset, Size uint64
}

type runnerFileSnapshot struct {
	Path     string
	Slices   []runnerFileSlice
	Metadata []string
	Recheck  func() error
	Close    func()
}

type runnerKernelCode struct {
	Path  string
	Hash  [20]byte
	Flags uint32
}

type runnerIndependentCodeOps struct {
	BSD                  func(string) (runnerBSDReceipt, error)
	Kernel               func() (runnerKernelCode, error)
	GuestValidity        func(uint32, string) int32
	GuestStaticValidity  func(uint32, string) int32
	ChromeBundleValidity func(uint32, string) int32
	LiveInformation      func() (runnerCodeInformation, error)
	Open                 func(string) (*runnerFileSnapshot, error)
	ExplicitInformation  func(runnerFileSlice) (runnerCodeInformation, error)
	ExplicitValidity     func(runnerFileSlice, uint32, string) int32
}

type runnerIndependentCodeFact struct {
	PID              int
	Identifier, Path string
	BSD              runnerBSDValue
	Before, After    runnerBSDReceipt
	Kernel           runnerKernelCode
	Selected         runnerSliceMember
	Members          []runnerSliceMember
	Statuses         []runnerIndependentValidity
	FileMetadata     []string
	Bound            bool
}

type runnerIndependentValidity struct {
	Operation string
	Flags     uint32
	Status    int32
}

func runnerInformationValid(v runnerCodeInformation, role, path string) bool {
	return v.Identifier == role && v.Path == path && v.Type >= 1 && v.Type <= 4 && len(v.Hash) == 20 && len(v.Full) >= 20 && len(v.Full) <= 64 && bytes.Equal(v.Full[:20], v.Hash)
}

func runnerInformationEqual(a, b runnerCodeInformation) bool {
	return a.Identifier == b.Identifier && a.Path == b.Path && a.Type == b.Type && bytes.Equal(a.Hash, b.Hash) && bytes.Equal(a.Full, b.Full)
}

func bindRunnerIndependentCode(pid int, role, expectedPath, pin string, ops runnerIndependentCodeOps) (fact runnerIndependentCodeFact, err error) {
	fact.PID, fact.Identifier = pid, role
	if pid < 1 || ops.BSD == nil || ops.Kernel == nil || ops.GuestValidity == nil || ops.LiveInformation == nil || ops.Open == nil || ops.ExplicitInformation == nil || ops.ExplicitValidity == nil {
		return fact, fmt.Errorf("incomplete independent code observation boundary")
	}
	rule, known := runnerReceiptRequirement(role)
	if !known || pin != "" && !runnerHexHash(pin) {
		return fact, fmt.Errorf("unknown independent code requirement/pin")
	}
	fact.Before, err = ops.BSD("before")
	if err != nil || !runnerIndependentBSDValid(fact.Before, pid, role, "before") {
		return fact, fmt.Errorf("independent before-incarnation missing")
	}
	status := func(operation string, flags uint32, value int32) int32 {
		fact.Statuses = append(fact.Statuses, runnerIndependentValidity{operation, flags, value})
		return value
	}
	chrome := role == "com.google.Chrome"
	if chrome {
		if ops.ChromeBundleValidity == nil || ops.GuestStaticValidity == nil {
			return fact, fmt.Errorf("Chrome-specific validation boundary missing")
		}
		if status("chrome-bundle", 9, ops.ChromeBundleValidity(9, rule)) != 0 {
			return fact, fmt.Errorf("Chrome bundle identity refused")
		}
		strict := status("chrome-bundle", 25, ops.ChromeBundleValidity(25, rule))
		if strict != 0 && strict != -66999 {
			return fact, fmt.Errorf("Chrome bundle strict error is not typed detritus")
		}
		if status("chrome-guest-static", 0, ops.GuestStaticValidity(0, rule)) != 0 {
			return fact, fmt.Errorf("Chrome live static identity refused")
		}
	}
	flags := uint32(16)
	if chrome {
		flags = 0
	}
	if status("live", flags, ops.GuestValidity(flags, rule)) != 0 {
		return fact, fmt.Errorf("independent live role refused")
	}
	if status("wrong-live-role", flags, ops.GuestValidity(flags, `identifier "ai.sliccy.invalid-proof-role"`)) == 0 {
		return fact, fmt.Errorf("live requirement negative control accepted")
	}
	kernel, err := ops.Kernel()
	if err != nil || kernel.Path == "" || kernel.Hash == [20]byte{} || expectedPath != "" && kernel.Path != expectedPath {
		return fact, fmt.Errorf("independent kernel code/path unavailable")
	}
	fact.Path, fact.Kernel = kernel.Path, kernel
	if strings.HasPrefix(role, "com.apple.") && kernel.Flags&0x04000000 == 0 {
		return fact, fmt.Errorf("Apple system role is not platform code")
	}
	live, err := ops.LiveInformation()
	if err != nil || !runnerInformationValid(live, role, kernel.Path) || !bytes.Equal(live.Hash, kernel.Hash[:]) || pin != "" && hex.EncodeToString(live.Hash) != pin {
		return fact, fmt.Errorf("independent live/kernel/pin comparison refused")
	}
	snapshot, err := ops.Open(kernel.Path)
	if err != nil || snapshot == nil {
		return fact, fmt.Errorf("independent retained file unavailable")
	}
	if snapshot.Close != nil {
		defer snapshot.Close()
	}
	if snapshot.Path != kernel.Path || snapshot.Recheck == nil || len(snapshot.Slices) < 1 || len(snapshot.Slices) > 8 {
		return fact, fmt.Errorf("invalid independent file catalogue")
	}
	if err := snapshot.Recheck(); err != nil {
		return fact, err
	}
	fact.FileMetadata = append([]string(nil), snapshot.Metadata...)
	matches, selectedIndex := 0, -1
	for i, slice := range snapshot.Slices {
		if slice.Size < 28 || slice.Offset > 128*1024*1024 || slice.Size > 128*1024*1024-slice.Offset {
			return fact, fmt.Errorf("independent slice extent outside bound")
		}
		for _, previous := range snapshot.Slices[:i] {
			if previous.CPU == slice.CPU && previous.Subtype == slice.Subtype || previous.Offset < slice.Offset+slice.Size && slice.Offset < previous.Offset+previous.Size {
				return fact, fmt.Errorf("independent duplicate/overlapping slice")
			}
		}
		info, err := ops.ExplicitInformation(slice)
		if err != nil || !runnerInformationValid(info, role, kernel.Path) || info.Offset == nil || *info.Offset != slice.Offset {
			return fact, fmt.Errorf("explicit static slice attributes/CodeOffset refused")
		}
		member := runnerSliceMember{CPU: int64(slice.CPU), Subtype: int64(slice.Subtype), Offset: slice.Offset, Size: slice.Size, Type: info.Type, Hash: append([]byte(nil), info.Hash...), Full: append([]byte(nil), info.Full...)}
		fact.Members = append(fact.Members, member)
		if info.Type == live.Type && bytes.Equal(info.Hash, live.Hash) {
			matches++
			selectedIndex = i
		}
	}
	if matches != 1 {
		return fact, fmt.Errorf("independent live hash has zero/multiple same-type static slices")
	}
	selectedSlice := snapshot.Slices[selectedIndex]
	fact.Selected = fact.Members[selectedIndex]
	if chrome && status("selected-static", 9, ops.ExplicitValidity(selectedSlice, 9, rule)) != 0 {
		return fact, fmt.Errorf("Chrome selected slice identity refused")
	}
	strict := status("selected-static", 25, ops.ExplicitValidity(selectedSlice, 25, rule))
	if strict != 0 && !(chrome && strict == -66999) {
		return fact, fmt.Errorf("selected strict validity refused")
	}
	selectedInfo, err := ops.ExplicitInformation(selectedSlice)
	if err != nil || !runnerInformationEqual(live, selectedInfo) || selectedInfo.Offset == nil || *selectedInfo.Offset != selectedSlice.Offset {
		return fact, fmt.Errorf("selected slice identity changed")
	}
	if err := snapshot.Recheck(); err != nil {
		return fact, err
	}
	if status("live-final", flags, ops.GuestValidity(flags, rule)) != 0 {
		return fact, fmt.Errorf("final live role refused")
	}
	finalInfo, err := ops.LiveInformation()
	if err != nil || !runnerInformationEqual(live, finalInfo) {
		return fact, fmt.Errorf("final live code changed")
	}
	finalKernel, err := ops.Kernel()
	if err != nil || finalKernel != kernel {
		return fact, fmt.Errorf("kernel code changed across observation")
	}
	fact.After, err = ops.BSD("after")
	if err != nil || !runnerIndependentBSDValid(fact.After, pid, role, "after") || !runnerBSDEqual(fact.Before.Selected, fact.After.Selected) {
		return fact, fmt.Errorf("independent incarnation changed")
	}
	if role == "com.apple.WindowServer" {
		if _, err := runnerBSDReceiptPair(fact.Before, fact.After); err != nil {
			return fact, err
		}
	}
	if err := snapshot.Recheck(); err != nil {
		return fact, err
	}
	fact.BSD = *fact.Before.Selected
	fact.Bound = true
	return fact, nil
}

func runnerIndependentBSDValid(r runnerBSDReceipt, pid int, role, phase string) bool {
	selected, used := runnerBSDSelect(r)
	return r.Role == role && r.Phase == phase && r.PID == int64(pid) && r.Accepted && runnerBSDEqual(selected, r.Selected) && r.UsedSysctl != nil && *r.UsedSysctl == used && r.ControlsAgreed != nil && *r.ControlsAgreed == runnerBSDControls(r)
}
