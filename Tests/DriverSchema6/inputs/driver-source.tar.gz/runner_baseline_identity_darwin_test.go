package integration

import (
 "context"
 "fmt"
 "os"
 "path/filepath"
 "reflect"
 "strconv"
 "syscall"
 "time"
)

type runnerBaselineIdentityEvidence struct {
 PID int
 Role string
 Before,After runnerBSDReceipt
 KernelBefore,KernelAfter runnerKernelCode
 FileMetadata []string
 DynamicStatus,WrongRoleStatus int32
 Complete bool
}

type runnerBaselineIdentityOps struct {
 BSD func(context.Context,*runnerNativeTrace,int)(runnerBSDReceipt,error)
 Kernel func()(runnerKernelCode,error)
 Dynamic func(uint32,string)int32
 Stat func(string)([]string,error)
}

func runnerRestatExecutable(path string)([]string,error) {
 canonical,err:=filepath.EvalSymlinks(path);if err!=nil||canonical!=path {return nil,fmt.Errorf("baseline executable no longer canonical")}
 info,err:=os.Lstat(path);if err!=nil {return nil,err}
 st,ok:=info.Sys().(*syscall.Stat_t);if !ok||!info.Mode().IsRegular(){return nil,fmt.Errorf("baseline executable no longer regular")}
 return []string{strconv.FormatInt(int64(st.Dev),10),strconv.FormatUint(st.Ino,10),strconv.FormatInt(st.Size,10),strconv.FormatUint(uint64(st.Mode),10),strconv.FormatInt(st.Mtimespec.Sec,10),strconv.FormatInt(st.Mtimespec.Nsec,10),strconv.FormatInt(st.Ctimespec.Sec,10),strconv.FormatInt(st.Ctimespec.Nsec,10)},nil
}

func runnerRecheckBaselineIdentity(ctx context.Context,trace *runnerNativeTrace,old runnerProcessFact,ops runnerBaselineIdentityOps)(out runnerBaselineIdentityEvidence,err error) {
 out.PID,out.Role=int(old.Identity.PID),old.Bundle
 if ctx==nil||trace==nil||ctx.Err()!=nil||!old.Code.Binding.Bound||len(old.Code.Binding.FileMetadata)!=8||ops.BSD==nil||ops.Kernel==nil||ops.Dynamic==nil||ops.Stat==nil {return out,fmt.Errorf("baseline immutable binding missing")}
 rule,known:=runnerReceiptRequirement(old.Bundle);if !known{return out,fmt.Errorf("baseline role unknown")}
 out.Before,err=ops.BSD(ctx,trace,out.PID);if err!=nil||!out.Before.Accepted||!runnerBSDEqual(out.Before.Selected,&old.Identity){return out,fmt.Errorf("baseline before incarnation changed")}
 flags:=uint32(16);if old.Bundle=="com.google.Chrome"{flags=0}
 out.DynamicStatus=ops.Dynamic(flags,rule);if out.DynamicStatus!=0{return out,fmt.Errorf("baseline dynamic requirement refused")}
 out.WrongRoleStatus=ops.Dynamic(flags,`identifier "ai.sliccy.invalid-proof-role"`);if out.WrongRoleStatus==0{return out,fmt.Errorf("baseline negative control accepted")}
 out.KernelBefore,err=ops.Kernel();if err!=nil||out.KernelBefore!=old.Code.Binding.Kernel{return out,fmt.Errorf("baseline kernel identity changed")}
 out.FileMetadata,err=ops.Stat(old.Path);if err!=nil||!reflect.DeepEqual(out.FileMetadata,old.Code.Binding.FileMetadata){return out,fmt.Errorf("baseline executable metadata changed")}
 out.KernelAfter,err=ops.Kernel();if err!=nil||out.KernelAfter!=out.KernelBefore{return out,fmt.Errorf("baseline kernel bracket changed")}
 out.After,err=ops.BSD(ctx,trace,out.PID);if err!=nil||!out.After.Accepted||!runnerBSDEqual(out.After.Selected,&old.Identity){return out,fmt.Errorf("baseline after incarnation changed")}
 _,lost,pending:=trace.Snapshot()
 if ctx.Err()!=nil||lost||pending!=0{return out,fmt.Errorf("baseline total budget or observation incomplete")}
 out.Complete=true;return out,nil
}

func observeRunnerBaselineIdentity(ctx context.Context,trace *runnerNativeTrace,old runnerProcessFact)(runnerBaselineIdentityEvidence,error) {
 c,err:=openRunnerSecurityContext(ctx,trace,int(old.Identity.PID));if err!=nil{return runnerBaselineIdentityEvidence{},err};defer c.close()
 return runnerRecheckBaselineIdentity(ctx,trace,old,runnerBaselineIdentityOps{BSD:runnerObserveBSDContext,Kernel:c.kernel,Dynamic:runnerBaselineDynamic(c,old.Bundle,old.Path),Stat:func(path string)([]string,error){return runnerTracedQuery(ctx,trace,"baseline-executable-lstat",func()([]string,error){return runnerRestatExecutable(path)})}})
}

func runnerBaselineDeadline(now,hard time.Time)time.Time {deadline:=now.Add(2*time.Second);if hard.Before(deadline){deadline=hard};return deadline}

func runnerBaselineDynamic(c *runnerSecurityContext,role,path string)func(uint32,string)int32 {
 return c.operations(role,path).GuestValidity
}
