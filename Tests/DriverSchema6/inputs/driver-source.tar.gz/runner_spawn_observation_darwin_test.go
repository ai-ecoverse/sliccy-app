package integration
import (
 "context"
 "encoding/hex"
 "fmt"
 "math"
 "time"
)
type runnerSpawnIdentity struct {
 PID int `json:"pid"`
 Parent int64 `json:"parent"`
 UID uint32 `json:"uid"`
 Seconds uint64 `json:"startSeconds"`
 Microseconds uint64 `json:"startMicroseconds"`
 Role string `json:"role"`
 CDHash string `json:"cdHash"`
}
type runnerSpawnObservation struct {
 AtMS float64 `json:"atMs"`
 Original runnerSpawnIdentity `json:"original"`
 IndependentlyBound bool `json:"independentlyBound"`
 ObservationError string `json:"observationError,omitempty"`
 Settlement *runnerSpawnSettlement `json:"settlement"`
}
type runnerSpawnSettlement struct {
 AtMS float64 `json:"atMs"`
 State string `json:"state"`
 OriginalGone bool `json:"originalGone"`
 Current *runnerBSDValue `json:"current"`
 BSD *runnerBSDReceipt `json:"bsd"`
 Error string `json:"error,omitempty"`
}
func runnerSpawnFromRow(row runnerCaptureRow)(runnerSpawnObservation,error){
 r:=runnerSpawnObservation{AtMS:row.Event};r.Original.Role,_=runnerText(row.Fields,"role");r.Original.CDHash,_=runnerText(row.Fields,"cdHash")
 pid,e:=runnerInt(row.Fields,"pid",1,math.MaxInt32);if e!=nil{return r,e};r.Original.PID=int(pid)
 r.Original.Parent,e=runnerInt(row.Fields,"parent",1,math.MaxInt32);if e!=nil{return r,e}
 uid,e:=runnerInt(row.Fields,"uid",0,math.MaxUint32);if e!=nil{return r,e};r.Original.UID=uint32(uid)
 r.Original.Seconds,e=runnerReceiptCounter(row.Fields["startSeconds"]);if e!=nil || r.Original.Seconds==0{return r,fmt.Errorf("spawn start unavailable")}
 micros,e:=runnerInt(row.Fields,"startMicroseconds",0,999999);if e!=nil{return r,e};r.Original.Microseconds=uint64(micros)
 if !runnerOneOf(r.Original.Role,"surface cli chrome authorization-requester") || !runnerHexHash(r.Original.CDHash){return r,fmt.Errorf("spawn role/hash unavailable")};return r,nil
}
func runnerSpawnMatchesFact(r runnerSpawnObservation,f runnerProcessFact)bool{
 b:=f.Identity;o:=r.Original
 return f.Owned && matchSpawnRole(o.Role,f.Label) && b.PID==int64(o.PID) && b.Parent==o.Parent && b.Effective==o.UID && b.Seconds==o.Seconds && b.Microseconds==o.Microseconds && hex.EncodeToString(f.Code.Binding.Kernel.Hash[:])==o.CDHash && f.Code.Binding.Bound
}
func matchSpawnRole(role,label string)bool{
 if role=="surface" {return label=="allowed"};if role=="chrome" {return runnerOneOf(label,"chrome-a-1 chrome-a-2 chrome-b-1 chrome-b-2")};return role==label && runnerOneOf(role,"cli authorization-requester")
}
func runnerObserveSpawnSettlement(ctx context.Context,trace *runnerNativeTrace,original runnerSpawnIdentity,began time.Time,observe func(context.Context,*runnerNativeTrace,int)(runnerBSDReceipt,error),absent func(int)bool)runnerSpawnSettlement{
 s:=runnerSpawnSettlement{AtMS:float64(time.Since(began))/float64(time.Millisecond),State:"unavailable"}
 if ctx.Err()!=nil {s.Error="settlement deadline exhausted";return s}
 r,e:=observe(ctx,trace,original.PID);s.BSD=&r
 if e!=nil || !r.Accepted || r.Selected==nil {
  if e!=nil {s.Error=runnerSanitizeDiagnostic(e.Error(),nil)}
  if absent(original.PID) {s.State="pid-absent";s.OriginalGone=true};return s
 }
 current:=*r.Selected;s.Current=&current
 if current.PID!=int64(original.PID) {s.Error="settlement query PID mismatch";return s}
 if current.Seconds!=original.Seconds || current.Microseconds!=original.Microseconds {s.State="pid-reused-original-gone";s.OriginalGone=true;return s}
 s.State="same-incarnation-present";return s
}

func runnerRetainSpawnObservation(row runnerCaptureRow,records map[int]runnerSpawnObservation)(runnerSpawnObservation,error){
 observation,err:=runnerSpawnFromRow(row);if err!=nil{return observation,err}
 if _,exists:=records[observation.Original.PID];exists{return observation,fmt.Errorf("duplicate original spawn identity")}
 records[observation.Original.PID]=observation
 return observation,nil
}
func runnerStoreSpawnSettlement(records map[int]runnerSpawnObservation,pid int,observation runnerSpawnObservation){records[pid]=observation}
