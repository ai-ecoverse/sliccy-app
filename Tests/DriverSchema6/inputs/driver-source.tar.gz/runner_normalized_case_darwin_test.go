package integration

import (
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "strings"
 "reflect"
 "time"
)

const runnerManifestSHA256 = "69fd7986228a0e258c57724989bd747a56d7401f029048de8ad6ac2e4ec47167"

const runnerNormalizedCaseFields = "normalizationFailed protectedCoverage pageDeliveries diagnosticCadenceSkipped clockAnchor diagnostics appOutput spawnedChildren schema case result evidenceUnavailable unavailableReasons captureDurationBound failures appPID exitCode caseElapsedMs processes independentWindows wire clock receiverLatencyUpperMs remoteStopLatencyMs directChildrenGone appReaped rootObservations rootsRemoved monitorLoss appClaimsOnlySecondaryReaps rootAssociatedProcesses ownedWindowsGone titleDiagnostics observerAccess receiverInvalidatedAt loopDeadlineExceeded protocolPageCreated protocolSettlementAttempted protocolWorkersSettled metadataReaderSettled nativeObservationSettled nativeEvidence coverage"
const runnerNormalizedCaseNullable = "protectedCoverage pageDeliveries diagnostics spawnedChildren unavailableReasons captureDurationBound failures processes independentWindows wire rootObservations appClaimsOnlySecondaryReaps rootAssociatedProcesses titleDiagnostics coverage"

func runnerValidateNormalizedCaseFields(fields map[string]json.RawMessage)error {
 allowed:=strings.Fields(runnerNormalizedCaseFields)
 for _,optional:=range []string{"limitations","rootAssociatedError"}{if _,exists:=fields[optional];exists{allowed=append(allowed,optional)}}
 if e:=runnerExactNullableFields(fields,allowed,runnerNormalizedCaseNullable);e!=nil{return fmt.Errorf("normalization case field ledger: %w",e)}
 native,e:=runnerDiagnosticObject(fields["nativeEvidence"],"observations diagnosticLoss pendingNativeCalls settled","observations diagnosticLoss pendingNativeCalls");if e!=nil{return e}
 var observations []json.RawMessage;if json.Unmarshal(native["observations"],&observations)!=nil||len(observations)>256{return fmt.Errorf("normalization native observations")}
 for _,raw:=range observations {
  if _,e:=runnerDiagnosticObject(raw,"key value error Submitted Started Finished cancelledBeforeStart","value");e!=nil{return e}
  var observation struct{Key string `json:"key"`;Value json.RawMessage `json:"value"`;Error string `json:"error"`;Submitted,Started,Finished string;Cancelled bool `json:"cancelledBeforeStart"`}
  if runnerNormalizedStrict(raw,&observation)!=nil||observation.Key==""||len(observation.Key)>256{return fmt.Errorf("normalization observation shape")}
  for _,stamp:=range []string{observation.Submitted,observation.Started,observation.Finished}{if _,e:=time.Parse(time.RFC3339Nano,stamp);e!=nil{return fmt.Errorf("normalization observation timestamp")}}
 }
 var lost map[string]bool;var pending map[string]int
 if json.Unmarshal(native["diagnosticLoss"],&lost)!=nil||json.Unmarshal(native["pendingNativeCalls"],&pending)!=nil||len(lost)>256||len(pending)>256{return fmt.Errorf("normalization trace maps")}
 for key,n:=range pending{if key==""||len(key)>256||n<0||n>runnerSnapshotTraceRows{return fmt.Errorf("normalization pending count")}}
 if _,e:=runnerBool(native,"settled");e!=nil{return e}
 copy:=make(map[string]json.RawMessage,len(fields));for key,value:=range fields{if key!="nativeEvidence"{copy[key]=value}}
 raw,e:=json.Marshal(copy);if e!=nil{return e};var typed runnerCaseResult
 if e=runnerNormalizedStrict(raw,&typed);e!=nil{return e}
 shape:=reflect.TypeOf(typed)
 for i:=0;i<shape.NumField();i++{field:=shape.Field(i);tag:=strings.Split(field.Tag.Get("json"),",")[0];if tag==""||tag=="nativeEvidence"||tag=="diagnosticSnapshots"{continue};if value,exists:=fields[tag];exists{if e:=runnerNormalizedTypedShape(value,field.Type);e!=nil{return e}}}
 if typed.Schema!=1||!runnerDiagnosticEnum(typed.Case,"selected-window display-exclusion authorization-exclusion reciprocal-revoke active-stop hotkey-stop")||!runnerDiagnosticEnum(typed.Result,"PASS FAIL FAILED_TO_DEMONSTRATE"){return fmt.Errorf("normalization case identity/outcome")}
 return nil
}

func runnerDriverInputDigest(directory string)(string,error) {
 entries,e:=os.ReadDir(directory);if e!=nil{return "",e}
 type input struct{Name string `json:"name"`;SHA256 string `json:"sha256"`}
 values:=[]input{};total:=int64(0)
 for _,entry:=range entries {
  if !strings.HasSuffix(entry.Name(),".go"){continue}
  info,e:=os.Lstat(filepath.Join(directory,entry.Name()));if e!=nil||!info.Mode().IsRegular()||info.Size()>1<<20{return "",fmt.Errorf("normalization driver source regularity")}
  total+=info.Size();if total>32<<20||len(values)>=256{return "",fmt.Errorf("normalization driver source bound")}
  raw,e:=os.ReadFile(filepath.Join(directory,entry.Name()));if e!=nil{return "",e};sum:=sha256.Sum256(raw);values=append(values,input{entry.Name(),hex.EncodeToString(sum[:])})
 }
 if len(values)==0{return "",fmt.Errorf("normalization driver source absent")}
 raw,e:=json.Marshal(values);if e!=nil{return "",e};sum:=sha256.Sum256(raw);return hex.EncodeToString(sum[:]),nil
}

func runnerIncompleteCaseIndex(result runnerCaseResult)runnerCaseEvidenceIndex {
 return runnerCaseEvidenceIndex{Schema:2,NormalizationVersion:2,Case:result.Case,Path:result.Case+"/driver-evidence.v2.ndjson",Result:result.Result,Failures:runnerCloneStrings(result.Failures),EvidenceUnavailable:result.EvidenceUnavailable,UnavailableReasons:runnerCloneStrings(result.UnavailableReasons),NativeObservationSettled:result.NativeObservationSettled,DirectChildrenGone:result.DirectChildrenGone,RootsRemoved:result.RootsRemoved,ProtocolWorkersSettled:result.ProtocolWorkersSettled,BlockLaterCases:runnerBlocksLaterCases(result)}
}

func runnerNormalizedCaseSummary(fields map[string]json.RawMessage)runnerCaseResult {
 copy:=make(map[string]json.RawMessage,len(fields));for key,value:=range fields{if key!="nativeEvidence"{copy[key]=value}}
 raw,_:=json.Marshal(copy);var result runnerCaseResult;json.Unmarshal(raw,&result)
 var native map[string]json.RawMessage;json.Unmarshal(fields["nativeEvidence"],&native)
 var observations []json.RawMessage;json.Unmarshal(native["observations"],&observations)
 result.NativeEvidence.Observations=make([]runnerObservation[any],len(observations))
 return result
}

func runnerCheckNormalizedIndex(want,actual runnerCaseEvidenceIndex)error {
 a,e:=json.Marshal(want);if e!=nil{return e};b,e:=json.Marshal(actual);if e!=nil{return e}
 if string(a)!=string(b){return fmt.Errorf("normalization case/suite index mismatch")};return nil
}

func runnerCloneStrings(values []string)[]string{if values==nil{return nil};out:=make([]string,len(values));copy(out,values);return out}
func runnerSaveNormalizedIndex(path string,value any,budget *runnerNormalizationBudget)error {
 if e:=runnerNormalizationJSONReservation(value);e!=nil{return e}
 if !budget.reserveMemory(4<<20){return fmt.Errorf("normalization index reservation bound")};defer budget.releaseMemory(4<<20)
 raw,e:=json.MarshalIndent(value,"","  ");if e!=nil{return e};raw=append(raw,'\n')
 if len(raw)>1<<20||!budget.reserveBytes(int64(len(raw))){return fmt.Errorf("normalization index storage bound")}
 return runnerWriteNew(path,raw)
}

func runnerFinalizeNormalizedCase(result *runnerCaseResult,began time.Time,commit func(runnerCaseResult)(runnerCaseEvidenceIndex,error),save func(runnerCaseEvidenceIndex)error,now func()time.Time) {
 index,e:=commit(*result)
 refuse:=func(reason string){result.Result="FAIL";result.NormalizationFailed=true;result.Failures=append(result.Failures,reason);index.Result="FAIL";index.EvidenceComplete=false;index.Failures=append([]string(nil),result.Failures...);index.BlockLaterCases=true}
 if e!=nil||now().Sub(began)>runnerCaseAbsoluteBudget{refuse("private normalization evidence incomplete or absolute deadline exceeded")}
 if e=save(index);e!=nil{refuse("private evidence index write failed")}
 if now().Sub(began)>runnerCaseAbsoluteBudget{refuse("private evidence index finalization exceeded absolute case deadline")}
 result.normalizationIndex=&index
}

func runnerCommitUnlaunchedCase(root string,result runnerCaseResult,budget *runnerNormalizationBudget,driver string)(runnerCaseEvidenceIndex,error) {
 dir:=filepath.Join(root,result.Case)
 if e:=os.Mkdir(dir,0700);e!=nil{return runnerIncompleteCaseIndex(result),e}
 writer,e:=newRunnerCaseEvidenceWriter(dir,result.Case,runnerManifestSHA256,driver,budget);if e!=nil{return runnerIncompleteCaseIndex(result),e}
 index,e:=writer.Commit(result);if e!=nil{return index,e}
 if e=runnerSaveNormalizedIndex(filepath.Join(dir,"driver-observations.json"),index,budget);e!=nil{return index,e}
 return index,nil
}
