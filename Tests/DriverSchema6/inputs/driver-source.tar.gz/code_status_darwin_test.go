package integration

import (
	"encoding/binary"
	"fmt"
	"os"
	"testing"

	"github.com/ebitengine/purego"
)

func inspectOwnedCodeStatus(pid, parent int) (flags uint32, identity ownedIncarnation, err error) {
	before, e := inspectOwnedIncarnation(pid, parent)
	if e != nil {
		return 0, identity, e
	}
	defer func() {
		if recover() != nil {
			err = fmt.Errorf("owned code status unavailable")
		}
	}()
	lib, e := purego.Dlopen("/usr/lib/libSystem.B.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return 0, identity, e
	}
	defer purego.Dlclose(lib)
	var csops func(int32, uint32, *byte, uint64) int32
	purego.RegisterLibFunc(&csops, lib, "csops")
	var bytes [4]byte
	if csops(int32(pid), 0, &bytes[0], 4) != 0 {
		return 0, identity, fmt.Errorf("kernel code status refused")
	}
	after, e := inspectOwnedIncarnation(pid, parent)
	if e != nil || before != after {
		return 0, identity, fmt.Errorf("code status incarnation changed")
	}
	return binary.LittleEndian.Uint32(bytes[:]), before, nil
}
func TestOwnKernelCodeStatus(t *testing.T) {
	status, before, e := inspectOwnedCodeStatus(os.Getpid(), os.Getppid())
	if e != nil {
		t.Fatal(e)
	}
	if status&1 == 0 || before.PID != os.Getpid() {
		t.Fatal("running signed test code status invalid")
	}
	if _, _, e := inspectOwnedCodeStatus(os.Getpid(), 0); e == nil {
		t.Fatal("invalid parent accepted")
	}
}
