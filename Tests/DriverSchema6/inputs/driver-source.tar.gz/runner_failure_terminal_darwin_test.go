package integration

import (
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "errors"
 "fmt"
 "syscall"
 "sort"
 "math"
 "reflect"
 "unicode/utf8"
)

const runnerEmergencyReserve = 256 << 10
const runnerEmergencyPayloadLimit = 192 << 10
// Includes bounded critical structs, JSON encoder staging and returned buffers.
// This is a reservation ledger, not a claim about whole-process RSS.
const runnerEmergencyMemory = 1 << 20

type runnerNormalizationFailure struct {
 Stage string `json:"stage"`
 Reason string `json:"reason"`
 Detail string `json:"detail"`
 Errno *int64 `json:"errno"`
 Measured int64 `json:"measured"`
 Limit int64 `json:"limit"`
}
func (e *runnerNormalizationFailure) Error()string{return e.Stage+": "+e.Reason+": "+e.Detail}
func runnerBoundedFact(s string,limit int)string {
 if len(s)>limit{s=s[:limit]};for !utf8.ValidString(s)&&len(s)>0{s=s[:len(s)-1]};return s
}
func runnerNormalizationError(stage,reason string,e error,measured,limit int64)*runnerNormalizationFailure {
 var old *runnerNormalizationFailure;if errors.As(e,&old){return old}
 value:=&runnerNormalizationFailure{Stage:stage,Reason:reason,Measured:measured,Limit:limit}
 if e!=nil{value.Detail=runnerBoundedFact(runnerSanitizeDiagnostic(e.Error(),nil),512);var errno syscall.Errno;if errors.As(e,&errno){n:=int64(errno);value.Errno=&n}}
 return value
}

type runnerCriticalChild struct {
 Original runnerSpawnIdentity `json:"original"`
 IndependentlyBound bool `json:"independentlyBound"`
 SettlementObserved bool `json:"settlementObserved"`
 State string `json:"state"`
 OriginalGone bool `json:"originalGone"`
 Current *runnerBSDValue `json:"current"`
 Error string `json:"error"`
}
type runnerCriticalRoot struct {
 Observation runnerRootObservation `json:"observation"`
 TimeBits string `json:"timeBits"`
 PathBytes int `json:"pathBytes"`
 PathSHA256 string `json:"pathSHA256"`
}
type runnerCriticalEvidence struct {
 Version int `json:"version"`
 Case string `json:"case"`
 AppPID int `json:"appPID"`
 Output runnerCaseOutput `json:"output"`
 FirstCaseFailure string `json:"firstCaseFailure"`
 FirstDiagnostic *runnerDiagnosticRecord `json:"firstDiagnostic"`
 FirstDiagnosticTimeBits string `json:"firstDiagnosticTimeBits"`
 ChildrenObserved int `json:"childrenObserved"`
 Children []runnerCriticalChild `json:"children"`
 RootsObserved bool `json:"rootsObserved"`
 RootCount int `json:"rootCount"`
 Roots []runnerCriticalRoot `json:"roots"`
 AppReaped bool `json:"appReaped"`
 DirectChildrenGone bool `json:"directChildrenGone"`
 RootsRemoved bool `json:"rootsRemoved"`
 OwnedWindowsGone bool `json:"ownedWindowsGone"`
 ProtocolSettled bool `json:"protocolSettled"`
 MetadataSettled bool `json:"metadataSettled"`
 NativeSettled bool `json:"nativeSettled"`
 Limited bool `json:"limited"`
}
func runnerCriticalSummary(result runnerCaseResult) runnerCriticalEvidence {
 c:=runnerCriticalEvidence{Version:1,Case:result.Case,AppPID:result.AppPID,Output:result.AppOutput,
  Limited:len(result.SpawnedChildren)>8,ChildrenObserved:len(result.SpawnedChildren),RootsObserved:result.RootObservations!=nil,RootCount:len(result.RootObservations),
  AppReaped:result.AppReaped,DirectChildrenGone:result.DirectChildrenGone,RootsRemoved:result.RootsRemoved,OwnedWindowsGone:result.OwnedWindowsGone,
  ProtocolSettled:result.ProtocolWorkersSettled,MetadataSettled:result.MetadataReaderSettled,NativeSettled:result.NativeObservationSettled}
 bound:=func(value string,n int)string{result:=runnerBoundedFact(value,n);if result!=value{c.Limited=true};return result}
 c.Output.StdoutTail=bound(c.Output.StdoutTail,4096);c.Output.StderrTail=bound(c.Output.StderrTail,4096)
 if len(result.Failures)>0{c.FirstCaseFailure=bound(result.Failures[0],512)}
 for _,path:=range result.Diagnostics {for _,record:=range path.Records{if c.FirstDiagnostic==nil||record.Order<c.FirstDiagnostic.Order{copy:=record;c.FirstDiagnostic=&copy}}}
 if d:=c.FirstDiagnostic;d!=nil {
  c.FirstDiagnosticTimeBits=fmt.Sprintf("%016x",math.Float64bits(d.MonotonicMS))
  if !finiteNonnegative(d.MonotonicMS){d.MonotonicMS=0;c.Limited=true}
  d.Step=bound(d.Step,128);d.ErrorType=bound(d.ErrorType,128);d.Tail=bound(d.Tail,1024)
 }
 pids:=runnerSortedSpawnPIDs(result.SpawnedChildren)
 for _,pid:=range pids {
  if len(c.Children)==8{c.Limited=true;break};value:=result.SpawnedChildren[pid]
  child:=runnerCriticalChild{Original:value.Original,IndependentlyBound:value.IndependentlyBound}
  child.Original.Role=bound(child.Original.Role,32);child.Original.CDHash=bound(child.Original.CDHash,64)
  if value.Settlement!=nil {s:=value.Settlement;child.SettlementObserved=true;child.State=bound(s.State,64);child.OriginalGone=s.OriginalGone;if s.Current!=nil{copy:=*s.Current;child.Current=&copy};child.Error=bound(s.Error,512)}
  c.Children=append(c.Children,child)
 }
 for _,r:=range result.RootObservations {
  if len(c.Roots)==8{c.Limited=true;break}
  root:=runnerCriticalRoot{PathBytes:len(r.Path),TimeBits:fmt.Sprintf("%016x",math.Float64bits(r.AtMS))}
  root.PathSHA256=runnerHashText(r.Path)
  if !finiteNonnegative(r.AtMS){r.AtMS=0;c.Limited=true}
  r.Path=bound(r.Path,1024);r.Error=bound(r.Error,512);r.ErrorType=bound(r.ErrorType,128)
  r.State=bound(r.State,64);r.Type=bound(r.Type,32)
  root.Observation=r;c.Roots=append(c.Roots,root)
 }
 if c.Limited{c.DirectChildrenGone=false;c.RootsRemoved=false}
 return c
}

func (w *runnerCaseEvidenceWriter) failureIndex(result runnerCaseResult,critical *runnerCriticalEvidence,cause *runnerNormalizationFailure)runnerCaseEvidenceIndex {
 index:=w.index(result,false);index.Result="FAIL";index.EvidenceComplete=false;index.BlockLaterCases=true
 index.Failures=nil;index.EvidenceUnavailable=true;index.UnavailableReasons=nil
 index.NormalizationFailure=cause;index.Critical=critical;index.DirectChildrenGone=critical.DirectChildrenGone;index.RootsRemoved=critical.RootsRemoved;return index
}

// Uses only the pre-reserved emergency allowance. Never repairs a partial sink.
func (w *runnerCaseEvidenceWriter) emergencyRecord(tag string,fields map[string]any)error {
 if w.closed||w.sinkBroken{return fmt.Errorf("failure sink unavailable")}
 fields["tag"]=tag;fields["sequence"]=w.seq+1
 if e:=runnerNormalizationJSONReservationWithin(fields,runnerEmergencyPayloadLimit-1);e!=nil{return e}
 raw,e:=json.Marshal(fields);if e!=nil{return e};raw=append(raw,'\n')
 if len(raw)>runnerEmergencyPayloadLimit||int64(len(raw))>w.emergencyRemaining{return fmt.Errorf("failure terminal reservation exceeded")}
 n,e:=w.file.Write(raw)
 if n>0{w.digest.Write(raw[:n]);w.bytes+=int64(n);w.emergencyRemaining-=int64(n)}
 if e!=nil||n!=len(raw){w.sinkBroken=true;return runnerNormalizationError("failure-terminal","short-write",e,int64(n),int64(len(raw)))}
 w.seq++;return nil
}
func (w *runnerCaseEvidenceWriter) writeFailedTerminal(result runnerCaseResult,critical *runnerCriticalEvidence,cause *runnerNormalizationFailure)error {
 if w.closed||w.sinkBroken||w.terminalWritten{return fmt.Errorf("failure footer unavailable")}
 prefix:=hex.EncodeToString(w.digest.Sum(nil));before:=w.bytes;records:=w.seq
 payload:=map[string]any{"case":w.selected,"critical":critical,"failure":cause,"prefixSHA256":prefix,"prefixBytes":before,"prefixRecords":records,
  "evidenceComplete":false,"outcome":"FAIL","blockLaterCases":true}
 if e:=w.emergencyRecord("failed-terminal",payload);e!=nil{return e}
 prefix=hex.EncodeToString(w.digest.Sum(nil))
 if e:=w.emergencyRecord("failed-footer",map[string]any{"case":w.selected,"prefixSHA256":prefix,"prefixBytes":w.bytes,"prefixRecords":w.seq,
  "evidenceComplete":false,"outcome":"FAIL","blockLaterCases":true});e!=nil{return e}
 w.terminalWritten=true;return nil
}

func runnerCriticalDigest(c *runnerCriticalEvidence)string{raw,_:=json.Marshal(c);sum:=sha256.Sum256(raw);return hex.EncodeToString(sum[:])}

func runnerSortedSpawnPIDs(values map[int]runnerSpawnObservation)[]int{
 pids:=make([]int,0,8)
 for pid:=range values{at:=sort.SearchInts(pids,pid);if at>=8{continue};if len(pids)<8{pids=append(pids,0)};copy(pids[at+1:],pids[at:len(pids)-1]);pids[at]=pid};return pids
}

func runnerDecodeCritical(raw json.RawMessage)(*runnerCriticalEvidence,error) {
 var value runnerCriticalEvidence
 if len(raw)>runnerEmergencyPayloadLimit||runnerNormalizedStrict(raw,&value)!=nil||runnerNormalizedTypedShape(raw,reflect.TypeOf(value))!=nil{return nil,fmt.Errorf("critical shape")}
 if value.Version!=1||len(value.Children)>8||len(value.Roots)>8||value.ChildrenObserved<len(value.Children)||value.RootCount<len(value.Roots){return nil,fmt.Errorf("critical counts")}
 bounded:=func(s string,n int)bool{return utf8.ValidString(s)&&len(s)<=n}
 if !bounded(value.Output.StdoutTail,4096)||!bounded(value.Output.StderrTail,4096)||!bounded(value.FirstCaseFailure,512){return nil,fmt.Errorf("critical tail bound")}
 if value.Limited&&(value.DirectChildrenGone||value.RootsRemoved){return nil,fmt.Errorf("critical limited completeness")}
 if value.ChildrenObserved>8||value.RootCount>8{if !value.Limited{return nil,fmt.Errorf("critical truncation claim")}}
 if d:=value.FirstDiagnostic;d!=nil{if !bounded(d.Step,128)||!bounded(d.ErrorType,128)||!bounded(d.Tail,1024)||!finiteNonnegative(d.MonotonicMS)||len(value.FirstDiagnosticTimeBits)!=16{return nil,fmt.Errorf("critical diagnostic bound")}}else if value.FirstDiagnosticTimeBits!=""{return nil,fmt.Errorf("critical absent diagnostic")}
 seen:=map[int]bool{}
 for _,c:=range value.Children{if seen[c.Original.PID]||!bounded(c.Original.Role,32)||!bounded(c.Original.CDHash,64)||!bounded(c.State,64)||!bounded(c.Error,512){return nil,fmt.Errorf("critical child bound")};seen[c.Original.PID]=true;if !c.SettlementObserved&&(c.OriginalGone||c.Current!=nil||c.State!=""||c.Error!=""){return nil,fmt.Errorf("critical unobserved settlement")}}
 for _,r:=range value.Roots {o:=r.Observation;if !bounded(o.Path,1024)||!bounded(o.Error,512)||!bounded(o.ErrorType,128)||!bounded(o.State,64)||!bounded(o.Type,32)||!finiteNonnegative(o.AtMS)||r.PathBytes<len(o.Path)||len(r.TimeBits)!=16||len(r.PathSHA256)!=64{return nil,fmt.Errorf("critical root bound")};if r.PathBytes!=len(o.Path)&&!value.Limited{return nil,fmt.Errorf("critical path truncation")}}
 return &value,nil
}

func runnerFailedEnvelope(f map[string]json.RawMessage,selected,prefix string,bytesRead int64,sequence uint64)error {
 name,e:=runnerText(f,"case");if e!=nil||name!=selected{return fmt.Errorf("failed terminal case")}
 hash,e:=runnerText(f,"prefixSHA256");if e!=nil||hash!=prefix{return fmt.Errorf("failed terminal digest")}
 count,e:=runnerInt(f,"prefixBytes",0,runnerNormalizationStorageLimit);if e!=nil||count!=bytesRead{return fmt.Errorf("failed terminal byte count")}
 records,e:=runnerInt(f,"prefixRecords",0,32768);if e!=nil||uint64(records)!=sequence{return fmt.Errorf("failed terminal record count")}
 complete,e:=runnerBool(f,"evidenceComplete");if e!=nil||complete{return fmt.Errorf("failed terminal complete claim")}
 block,e:=runnerBool(f,"blockLaterCases");if e!=nil||!block{return fmt.Errorf("failed terminal later-case claim")}
 outcome,e:=runnerText(f,"outcome");if e!=nil||outcome!="FAIL"{return fmt.Errorf("failed terminal outcome")};return nil
}
func runnerDecodeNormalizationFailure(raw json.RawMessage)(*runnerNormalizationFailure,error) {
 var value runnerNormalizationFailure
 if runnerNormalizedStrict(raw,&value)!=nil||runnerNormalizedTypedShape(raw,reflect.TypeOf(value))!=nil||len(value.Detail)>512||!utf8.ValidString(value.Detail){return nil,fmt.Errorf("normalization failure shape")}
 if !runnerDiagnosticEnum(value.Stage,"commit close failure-terminal json-reservation record-encode record-write result-encode result-schema job-write index-write")||!runnerDiagnosticEnum(value.Reason,"busy closed unavailable io short-write size depth type memory storage fields deadline"){return nil,fmt.Errorf("normalization failure enum")}
 return &value,nil
}

func runnerHashText(value string)string{
 h:=sha256.New();var chunk [1024]byte
 for len(value)>0{n:=copy(chunk[:],value);h.Write(chunk[:n]);value=value[n:]};return hex.EncodeToString(h.Sum(nil))
}
