package integration

import (
	"fmt"
	"image"
	"math"
	"testing"
)

func inspectRunnerCapturePixels(img image.Image, source independentRect, windows []runnerWindowClaim) (bool, map[uint32]int, error) {
	allowed := independentRect{128, 128, 256, 256}
	if source.X == 128 && source.Y == 128 && source.Width == 256 && source.Height == 256 {
		allowed = source
	}
	bounds := img.Bounds()
	if float64(bounds.Dx()) != source.Width || float64(bounds.Dy()) != source.Height {
		return false, nil, fmt.Errorf("actual capture dimensions differ from independent source")
	}
	mapped, e := mapFixtureWindow(allowed, source, bounds.Dx(), bounds.Dy())
	if e != nil {
		return false, nil, e
	}
	pulse, e := inspectFixturePattern(img, mapped)
	if e != nil {
		return false, nil, e
	}
	counts := map[uint32]int{}
	if source == allowed {
		return pulse, counts, nil
	}
	inside := func(x, y float64, r independentRect) bool {
		return x >= r.X && y >= r.Y && x < r.X+r.Width && y < r.Y+r.Height
	}
	halo := independentRect{allowed.X - 8, allowed.Y - 8, allowed.Width + 16, allowed.Height + 16}
	for y := 0; y < bounds.Dy(); y++ {
		for x := 0; x < bounds.Dx(); x++ {
			px, py := source.X+float64(x)+0.5, source.Y+float64(y)+0.5
			if inside(px, py, halo) {
				continue
			}
			red, green, blue, _ := img.At(x, y).RGBA()
			if red>>8 > 12 || green>>8 > 12 || blue>>8 > 12 {
				return false, nil, fmt.Errorf("nonselected compositor pixels visible outside fixed helper")
			}
			for _, window := range windows {
				if window.Label == "allowed" {
					continue
				}
				margin := math.Min(4, math.Min(window.Rect.Width, window.Rect.Height)/4)
				interior := independentRect{window.Rect.X + margin, window.Rect.Y + margin, window.Rect.Width - 2*margin, window.Rect.Height - 2*margin}
				if inside(px, py, interior) {
					counts[window.ID]++
				}
			}
		}
	}
	for _, window := range windows {
		if window.Label != "allowed" && counts[window.ID] < 4 {
			return false, nil, fmt.Errorf("protected window lacks independently positioned omission samples")
		}
	}
	return pulse, counts, nil
}
func TestRunnerPixelExclusionCannotIgnoreColoredProtectedRegions(t *testing.T) {
	img := image.NewRGBA(image.Rect(0, 0, 1024, 768))
	for y := 0; y < 768; y++ {
		for x := 0; x < 1024; x++ {
			img.Pix[img.PixOffset(x, y)+3] = 255
		}
	}
	for y := 128; y < 384; y++ {
		for x := 128; x < 384; x++ {
			v := fixtureQuadrants[((y-128)/128)*2+(x-128)/128]
			i := img.PixOffset(x, y)
			img.Pix[i] = byte(v[0])
			img.Pix[i+1] = byte(v[1])
			img.Pix[i+2] = byte(v[2])
		}
	}
	for y := 136; y < 152; y++ {
		for x := 136; x < 152; x++ {
			i := img.PixOffset(x, y)
			img.Pix[i] = 0
			img.Pix[i+1] = 0
			img.Pix[i+2] = 0
		}
	}
	protected := []runnerWindowClaim{{Label: "chrome-a", ID: 1, Rect: independentRect{416, 64, 288, 224}}}
	if _, n, e := inspectRunnerCapturePixels(img, independentRect{0, 0, 1024, 768}, protected); e != nil || n[1] < 4 {
		t.Fatal(e)
	}
	img.Pix[img.PixOffset(500, 100)] = 224
	if _, _, e := inspectRunnerCapturePixels(img, independentRect{0, 0, 1024, 768}, protected); e == nil {
		t.Fatal("colored protected-region leak ignored")
	}
	img.Pix[img.PixOffset(500, 100)] = 0
	protected[0].Rect = independentRect{128, 128, 100, 100}
	if _, _, e := inspectRunnerCapturePixels(img, independentRect{0, 0, 1024, 768}, protected); e == nil {
		t.Fatal("fully confounded protected rectangle counted as compositor evidence")
	}
}
