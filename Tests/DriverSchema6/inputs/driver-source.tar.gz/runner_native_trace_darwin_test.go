package integration

import (
	"sync"
	"time"
 "unsafe"
 "encoding/hex"
)

type runnerNativePhase struct {
	Ordinal      uint64  `json:"ordinal"`
	Operation    string  `json:"operation"`
	PID          int     `json:"pid"`
	Flags        uint32  `json:"flags"`
	Phase        string  `json:"phase"`
	ElapsedMS    float64 `json:"elapsedMs"`
	ReturnValue  *int32  `json:"returnValue"`
	ValuePresent *bool   `json:"valuePresent"`
	Errno        *int32  `json:"errno"`
}

const runnerOrdinaryTraceRows = 512
const runnerSnapshotTraceRows = 2 + 114*128

type runnerNativeTrace struct {
 capacity int
 retired bool
 retiredRows int
 retiredDigest string
 memoryBudget *runnerNormalizationBudget
 memoryCharge int64
 snapshotWindowsReserved bool
 snapshotOwnersReserved bool
	mu      sync.Mutex
	began   time.Time
	next    uint64
	rows    []runnerNativePhase
	pending map[uint64]runnerNativePhase
	lost    bool
}

func newRunnerNativeTrace() *runnerNativeTrace {
	return &runnerNativeTrace{began: time.Now(), pending: map[uint64]runnerNativePhase{},capacity:runnerOrdinaryTraceRows}
}

func newRunnerSnapshotTrace() *runnerNativeTrace {
 return &runnerNativeTrace{began:time.Now(),pending:map[uint64]runnerNativePhase{},capacity:runnerSnapshotTraceRows}
}

func (t *runnerNativeTrace) Retire(rows int,digest string) bool {
 t.mu.Lock();defer t.mu.Unlock()
 if _,e:=hex.DecodeString(digest);e!=nil{return false}
 if t.retired||len(t.pending)!=0||rows!=len(t.rows)||len(digest)!=64{return false}
 t.retiredRows=rows;t.retiredDigest=digest;t.rows=nil;t.pending=nil;t.retired=true
 if t.memoryBudget!=nil {t.memoryBudget.releaseMemory(t.memoryCharge);t.memoryCharge=0}
 return true
}

func (t *runnerNativeTrace) Begin(operation string, pid int, flags uint32) (uint64, bool) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.lost || t.retired || len(t.rows) >= t.capacity || operation == "" || len(operation) > 256 || pid < 1 {
		t.lost = true
		return 0, false
	}
	if t.rows==nil {
  charge:=int64(t.capacity)*(3*int64(unsafe.Sizeof(runnerNativePhase{}))+64)
  if t.memoryBudget!=nil&&!t.memoryBudget.reserveMemory(charge){t.lost=true;return 0,false}
  if t.memoryBudget!=nil{t.memoryCharge+=charge}
  t.rows=make([]runnerNativePhase,0,t.capacity)
 }
 if t.memoryBudget!=nil {
  charge:=int64(len(operation)+128)
  if !t.memoryBudget.reserveMemory(charge){t.lost=true;return 0,false}
  t.memoryCharge+=charge
 }
	t.next++
	row := runnerNativePhase{Ordinal: t.next, Operation: operation, PID: pid, Flags: flags, Phase: "entered", ElapsedMS: float64(time.Since(t.began)) / float64(time.Millisecond)}
	t.pending[row.Ordinal] = row
	t.rows = append(t.rows, row)
	return row.Ordinal, true
}

func (t *runnerNativeTrace) End(ordinal uint64, value *int32, present bool) bool {
	return t.EndDetailed(ordinal, value, present, nil)
}

func (t *runnerNativeTrace) EndDetailed(ordinal uint64, value *int32, present bool, errno *int32) bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	row, known := t.pending[ordinal]
	if t.lost || t.retired || !known || ordinal == 0 || len(t.rows) >= t.capacity {
		t.lost = true
		return false
	}
	delete(t.pending, ordinal)
	if errno != nil {
		copy := *errno
		row.Errno = &copy
	}
	row.Phase = "completed"
	row.ElapsedMS = float64(time.Since(t.began)) / float64(time.Millisecond)
	if value != nil {
		copy := *value
		row.ReturnValue = &copy
	}
	copyPresent := present
	row.ValuePresent = &copyPresent
	t.rows = append(t.rows, row)
	return true
}

func (t *runnerNativeTrace) Snapshot() ([]runnerNativePhase, bool, int) {
	t.mu.Lock()
	defer t.mu.Unlock()
	rows := append([]runnerNativePhase(nil), t.rows...)
	for i := range rows {
		if rows[i].ReturnValue != nil {
			v := *rows[i].ReturnValue
			rows[i].ReturnValue = &v
		}
		if rows[i].ValuePresent != nil {
			v := *rows[i].ValuePresent
			rows[i].ValuePresent = &v
		}
		if rows[i].Errno != nil {
			v := *rows[i].Errno
			rows[i].Errno = &v
		}
	}
	return rows, t.lost, len(t.pending)
}

func (t *runnerNativeTrace) NotExecuted(ordinal uint64) bool {
	t.mu.Lock()
	defer t.mu.Unlock()
	row, known := t.pending[ordinal]
	if t.lost || t.retired || !known || len(t.rows) >= t.capacity {
		t.lost = true
		return false
	}
	delete(t.pending, ordinal)
	row.Phase = "not-executed"
	row.ElapsedMS = float64(time.Since(t.began)) / float64(time.Millisecond)
	t.rows = append(t.rows, row)
	return true
}

func(t *runnerNativeTrace) Lose(){t.mu.Lock();t.lost=true;t.mu.Unlock()}
func(t *runnerNativeTrace) IsRetired()bool{t.mu.Lock();defer t.mu.Unlock();return t.retired}

func(t *runnerNativeTrace) ReserveSnapshotStorage(owners,windows int)bool {
 t.mu.Lock();defer t.mu.Unlock()
 if t.capacity!=runnerSnapshotTraceRows||t.retired||t.lost||owners<0||owners>128||windows<0||windows>512||owners>0&&t.snapshotOwnersReserved||windows>0&&t.snapshotWindowsReserved{t.lost=true;return false}
 charge:=int64(owners)*(64<<10)+int64(windows)*256
 if t.memoryBudget!=nil&&!t.memoryBudget.reserveMemory(charge){t.lost=true;return false}
 if t.memoryBudget!=nil{t.memoryCharge+=charge}
 if owners>0{t.snapshotOwnersReserved=true};if windows>0{t.snapshotWindowsReserved=true}
 return true
}
