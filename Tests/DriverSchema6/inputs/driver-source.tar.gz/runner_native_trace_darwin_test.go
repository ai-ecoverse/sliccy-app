package integration

import (
	"sync"
	"time"
)

type runnerNativePhase struct {
	Ordinal uint64 `json:"ordinal"`
	Operation string `json:"operation"`
	PID int `json:"pid"`
	Flags uint32 `json:"flags"`
	Phase string `json:"phase"`
	ElapsedMS float64 `json:"elapsedMs"`
	ReturnValue *int32 `json:"returnValue"`
	ValuePresent *bool `json:"valuePresent"`
	Errno *int32 `json:"errno"`
}

type runnerNativeTrace struct {
	mu sync.Mutex
	began time.Time
	next uint64
	rows []runnerNativePhase
	pending map[uint64]runnerNativePhase
	lost bool
}

func newRunnerNativeTrace()*runnerNativeTrace{return &runnerNativeTrace{began:time.Now(),pending:map[uint64]runnerNativePhase{}}}

func(t *runnerNativeTrace)Begin(operation string,pid int,flags uint32)(uint64,bool){
	t.mu.Lock();defer t.mu.Unlock()
	if t.lost||len(t.rows)>=512||operation==""||len(operation)>256||pid<1{t.lost=true;return 0,false}
	t.next++
	row:=runnerNativePhase{Ordinal:t.next,Operation:operation,PID:pid,Flags:flags,Phase:"entered",ElapsedMS:float64(time.Since(t.began))/float64(time.Millisecond)}
	t.pending[row.Ordinal]=row;t.rows=append(t.rows,row)
	return row.Ordinal,true
}

func(t *runnerNativeTrace)End(ordinal uint64,value *int32,present bool)bool{return t.EndDetailed(ordinal,value,present,nil)}

func(t *runnerNativeTrace)EndDetailed(ordinal uint64,value *int32,present bool,errno *int32)bool{
	t.mu.Lock();defer t.mu.Unlock()
	row,known:=t.pending[ordinal]
	if t.lost||!known||ordinal==0||len(t.rows)>=512{t.lost=true;return false}
	delete(t.pending,ordinal)
	if errno!=nil{copy:=*errno;row.Errno=&copy}
	row.Phase="completed";row.ElapsedMS=float64(time.Since(t.began))/float64(time.Millisecond)
	if value!=nil{copy:=*value;row.ReturnValue=&copy};copyPresent:=present;row.ValuePresent=&copyPresent
	t.rows=append(t.rows,row)
	return true
}

func(t *runnerNativeTrace)Snapshot()([]runnerNativePhase,bool,int){
	t.mu.Lock();defer t.mu.Unlock()
	rows:=append([]runnerNativePhase(nil),t.rows...)
	for i:=range rows{if rows[i].ReturnValue!=nil{v:=*rows[i].ReturnValue;rows[i].ReturnValue=&v};if rows[i].ValuePresent!=nil{v:=*rows[i].ValuePresent;rows[i].ValuePresent=&v};if rows[i].Errno!=nil{v:=*rows[i].Errno;rows[i].Errno=&v}}
	return rows,t.lost,len(t.pending)
}

func(t *runnerNativeTrace)NotExecuted(ordinal uint64)bool{
	t.mu.Lock();defer t.mu.Unlock()
	row,known:=t.pending[ordinal]
	if t.lost||!known||len(t.rows)>=512{t.lost=true;return false}
	delete(t.pending,ordinal);row.Phase="not-executed";row.ElapsedMS=float64(time.Since(t.began))/float64(time.Millisecond);t.rows=append(t.rows,row);return true
}
