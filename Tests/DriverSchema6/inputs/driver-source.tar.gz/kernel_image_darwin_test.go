package integration

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"os/exec"
	"runtime"
	"testing"
	"time"

	"github.com/ebitengine/purego"
)

type kernelImageObservation struct {
	Identity ownedIncarnation
	CPU      int32
	Subtype  int32
	CDHash   string
	Offset   uint64
	Mode     string
}

func inspectOwnedKernelImage(pid, parent int) (result kernelImageObservation, err error) {
	return inspectKernelImageUsing(pid, func() (ownedIncarnation, error) { return inspectOwnedIncarnation(pid, parent) })
}
func inspectRunnerKernelImage(pid int) (result kernelImageObservation, err error) {
	return inspectKernelImageUsing(pid, func() (ownedIncarnation, error) { return inspectRunnerIncarnation(pid) })
}
func inspectKernelImageUsing(pid int, identity func() (ownedIncarnation, error)) (result kernelImageObservation, err error) {
	before, e := identity()
	if e != nil {
		return result, e
	}
	defer func() {
		if recover() != nil {
			err = fmt.Errorf("kernel image observer unavailable")
		}
	}()
	proc, e := purego.Dlopen("/usr/lib/libproc.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return result, e
	}
	defer purego.Dlclose(proc)
	lib, e := purego.Dlopen("/usr/lib/libSystem.B.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return result, e
	}
	defer purego.Dlclose(lib)
	var info func(int32, int32, uint64, *byte, int32) int32
	var csops func(int32, uint32, *byte, uint64) int32
	purego.RegisterLibFunc(&info, proc, "proc_pidinfo")
	purego.RegisterLibFunc(&csops, lib, "csops")
	var arch [8]byte
	if info(int32(pid), 19, 0, &arch[0], 8) != 8 {
		return result, fmt.Errorf("kernel running architecture unavailable")
	}
	var hash [20]byte
	var offset [8]byte
	if csops(int32(pid), 5, &hash[0], 20) != 0 || csops(int32(pid), 6, &offset[0], 8) != 0 {
		return result, fmt.Errorf("kernel code hash/offset unavailable")
	}
	runtime.KeepAlive(hash)
	runtime.KeepAlive(offset)
	after, e := identity()
	if e != nil || after != before {
		return result, fmt.Errorf("kernel image incarnation changed")
	}
	if hash == [20]byte{} || binary.LittleEndian.Uint64(offset[:]) > uint64(^uint64(0)>>1) {
		return result, fmt.Errorf("kernel image result invalid")
	}
	return kernelImageObservation{before, int32(binary.LittleEndian.Uint32(arch[:4])), int32(binary.LittleEndian.Uint32(arch[4:])), hex.EncodeToString(hash[:]), binary.LittleEndian.Uint64(offset[:]), "csops-with-incarnation-brackets"}, nil
}
func TestOwnedSignedKernelImageObserver(t *testing.T) {
	binaryPath := os.Getenv("SLICC_RELEASE_PROOF_BINARY")
	if binaryPath == "" {
		t.Skip("verified released binary required")
	}
	raw, e := os.ReadFile(binaryPath)
	if e != nil {
		t.Fatal("release read failed")
	}
	digest := sha256.Sum256(raw)
	if hex.EncodeToString(digest[:]) != "0055c051f48364dbf6d3744c637a06353305a392d06edbedd96bd6764adb5a73" {
		t.Fatal("unexpected release bytes")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	child := exec.CommandContext(ctx, binaryPath, "-", "follow", "--json")
	child.Env = proofEnvironment(t)
	input, e := child.StdinPipe()
	if e != nil {
		t.Fatal("isolated input unavailable")
	}
	defer input.Close()
	child.Stdout = io.Discard
	child.Stderr = io.Discard
	if child.Start() != nil {
		t.Fatal("owned signed child launch failed")
	}
	defer func() { cancel(); _ = child.Wait() }()
	events, stop, e := watchProofExec(child.Process.Pid)
	if e != nil {
		t.Fatal("owned process monitor unavailable")
	}
	defer stop()
	before, e := inspectOwnedKernelImage(child.Process.Pid, os.Getpid())
	if e != nil {
		t.Fatal(e)
	}
	hash, e := inspectProofImage(child.Process.Pid, binaryPath, "5da1a3199bd3f895bce2e53023c28ca1c33d249e", "ai.sliccy.slicc", "ai.sliccy.mac")
	if e != nil || hash != before.CDHash || before.CDHash != "5da1a3199bd3f895bce2e53023c28ca1c33d249e" || before.Offset != 0 || before.CPU != 0x0100000c {
		t.Fatal("kernel/signed thin native snapshot mismatch")
	}
	after, e := inspectOwnedKernelImage(child.Process.Pid, os.Getpid())
	if e != nil || before != after {
		t.Fatal("owned kernel image changed during static comparison")
	}
	select {
	case <-events:
		t.Fatal("unexpected owned exec/exit during sample")
	default:
	}
	if _, e := inspectOwnedKernelImage(child.Process.Pid, os.Getppid()); e == nil {
		t.Fatal("unowned process accepted")
	}
	if _, e := inspectOwnedKernelImage(0, os.Getpid()); e == nil {
		t.Fatal("invalid process accepted")
	}
	t.Log("kernel hash+offset+running CPU matched independent signed native thin snapshot; no universal claim")
}
