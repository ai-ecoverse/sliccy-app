package integration

import (
	"strings"
	"testing"
)

func TestUniversalStageFieldsStrict(t *testing.T) {
	good := `{"schema":2,"case":"universal-native","capture":false,"stage":"universal-started","elapsedMs":0,"pid":42,"reportedArchitecture":"arm64"}`
	if _, e := decodeUniversalRow([]byte(good)); e != nil {
		t.Fatal("valid fixed row rejected")
	}
	for _, bad := range []string{
		strings.Replace(good, `"elapsedMs":0`, `"elapsedMs":null`, 1),
		strings.Replace(good, `"pid":42`, `"pid":42,"pid":43`, 1),
		strings.Replace(good, `"stage":"universal-started"`, `"stage":"native-pair-observed"`, 1),
		strings.Replace(good, `"elapsedMs":0,`, "", 1),
		strings.Replace(good, `"pid":42`, `"pid":"42"`, 1),
		strings.Replace(good, `"schema":2`, `"schema":2,"extra":false`, 1),
		good + " {}",
	} {
		if _, e := decodeUniversalRow([]byte(bad)); e == nil {
			t.Fatal("malformed/unexpected stage data accepted")
		}
	}
}
