package integration

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"strings"
	"testing"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
)

type snapshotRow struct {
	identityRow
	Directory           string `json:"directory,omitempty"`
	OriginalSHA256      string `json:"originalSHA256,omitempty"`
	OriginalCDHash      string `json:"originalCDHash,omitempty"`
	ReplacementSHA256   string `json:"replacementSHA256,omitempty"`
	ReplacementCDHash   string `json:"replacementCDHash,omitempty"`
	SelectedCDHash      string `json:"selectedCDHash,omitempty"`
	Operation           string `json:"operation,omitempty"`
	Offset              *int   `json:"offset,omitempty"`
	Before              *int   `json:"before,omitempty"`
	After               *int   `json:"after,omitempty"`
	OldSnapshotRetained *bool  `json:"oldSnapshotRetained,omitempty"`
	PathNowReplacement  *bool  `json:"pathNowReplacement,omitempty"`
	Component           string `json:"component,omitempty"`
	AwaitingObservation *bool  `json:"awaitingObservation,omitempty"`
	Called              *bool  `json:"called,omitempty"`
	ChildAliveBefore    *bool  `json:"childAliveBefore,omitempty"`
	ChildAliveAfter     *bool  `json:"childAliveAfter,omitempty"`
	Outcome             string `json:"outcome,omitempty"`
}

func decodeSnapshotRow(line []byte) (snapshotRow, error) {
	var row snapshotRow
	if screen.Strict(line, &row, 4096) != nil || row.Schema != 2 || row.Capture == nil || *row.Capture || (row.Case != "snapshot-mutation" && row.Case != "snapshot-replacement") || row.Elapsed < 0 || math.IsNaN(row.Elapsed) || math.IsInf(row.Elapsed, 0) {
		return row, fmt.Errorf("invalid snapshot row")
	}
	required := strings.Fields("schema case capture stage elapsedMs")
	switch row.Stage {
	case "snapshot-started", "child-started", "child-exit-reaped":
		required = append(required, "pid")
	case "snapshot-prepared":
		required = append(required, "directory", "originalSHA256", "originalCDHash")
		if row.Case == "snapshot-replacement" {
			required = append(required, "replacementSHA256", "replacementCDHash")
		}
	case "baseline-live-positive":
		required = append(required, "selectedCDHash")
	case "change-attempted":
		required = append(required, "operation")
	case "change-completed":
		required = append(required, "operation")
		if row.Case == "snapshot-mutation" {
			required = append(required, "offset", "before", "after")
		} else {
			required = append(required, "oldSnapshotRetained", "pathNowReplacement")
		}
	case "change-denied":
		required = append(required, "operation", "reason")
	case "post-verifier-started":
		required = append(required, "component", "awaitingObservation")
	case "post-verifier-result":
		required = append(required, "component", "called", "childAliveBefore", "childAliveAfter", "outcome")
		if row.Component == "guest" && row.Outcome == "accepted" {
			required = append(required, "selectedCDHash")
		}
	case "terminal":
		required = append(required, "reason")
	case "lanes-authenticated", "heartbeat-ready", "original-observation-confirmed", "result-ready", "result-observation-confirmed", "child-gate-invalidated":
	default:
		return row, fmt.Errorf("unknown snapshot stage")
	}
	var fields map[string]json.RawMessage
	if json.Unmarshal(line, &fields) != nil || len(fields) != len(required) {
		return row, fmt.Errorf("wrong snapshot field set")
	}
	for _, key := range required {
		value, ok := fields[key]
		if !ok || bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			return row, fmt.Errorf("missing snapshot field")
		}
	}
	if strings.HasPrefix(row.Stage, "post-verifier-") && row.Component != "guest" && row.Component != "endpoint" {
		return row, fmt.Errorf("unknown component")
	}
	if row.Stage == "post-verifier-result" {
		if row.Outcome != "accepted" && row.Outcome != "refused" && row.Outcome != "unavailable" {
			return row, fmt.Errorf("unknown verifier outcome")
		}
		if *row.Called != (row.Outcome != "unavailable") {
			return row, fmt.Errorf("call/outcome contradiction")
		}
	}
	return row, nil
}
func TestSnapshotStageFieldsStrict(t *testing.T) {
	good := `{"schema":2,"case":"snapshot-mutation","capture":false,"stage":"post-verifier-result","elapsedMs":1,"component":"guest","called":true,"childAliveBefore":true,"childAliveAfter":true,"outcome":"accepted","selectedCDHash":"5da1a3199bd3f895bce2e53023c28ca1c33d249e"}`
	if _, e := decodeSnapshotRow([]byte(good)); e != nil {
		t.Fatal(e)
	}
	for _, bad := range []string{strings.Replace(good, `"called":true`, `"called":false`, 1), strings.Replace(good, `"called":true`, `"called":null`, 1), strings.Replace(good, `"component":"guest"`, `"component":"endpoint"`, 1), strings.Replace(good, `"elapsedMs":1`, `"elapsedMs":1,"elapsedMs":2`, 1), strings.Replace(good, `"outcome":"accepted"`, `"outcome":"refused"`, 1), strings.Replace(good, `"schema":2`, `"schema":2,"extra":0`, 1)} {
		if _, e := decodeSnapshotRow([]byte(bad)); e == nil {
			t.Fatal("invalid snapshot row accepted")
		}
	}
}
