package integration

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"os"
	"path/filepath"
	"testing"
)

func TestSnapshotOwnedFileBoundary(t *testing.T) {
	var suffix [4]byte
	if _, e := rand.Read(suffix[:]); e != nil {
		t.Fatal(e)
	}
	root := filepath.Join("/private/tmp", "sliccy-snapshot."+hex.EncodeToString(suffix[:]))
	if e := os.Mkdir(root, 0700); e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { _ = os.RemoveAll(root) })
	arm := []byte("owned nonexecutable synthetic original")
	intel := []byte("owned nonexecutable replacement")
	if os.WriteFile(filepath.Join(root, "candidate"), arm, 0600) != nil || os.Link(filepath.Join(root, "candidate"), filepath.Join(root, "baseline")) != nil || os.WriteFile(filepath.Join(root, "replacement"), intel, 0600) != nil {
		t.Fatal("owned fixture setup")
	}
	s, e := openSnapshotFiles(root, arm, intel)
	if e != nil {
		t.Fatal(e)
	}
	raw, _, e := snapshotRead(s.Original)
	if e != nil || !bytes.Equal(raw, arm) {
		t.Fatal("retained original read mismatch")
	}
	s.close()
	if _, e := openSnapshotFiles(root, arm, []byte("wrong")); e == nil {
		t.Fatal("wrong replacement accepted")
	}
	if os.Remove(filepath.Join(root, "baseline")) != nil || os.Symlink("candidate", filepath.Join(root, "baseline")) != nil {
		t.Fatal("symlink fixture setup")
	}
	if _, e := openSnapshotFiles(root, arm, intel); e == nil {
		t.Fatal("symlink baseline accepted")
	}
	if _, e := openSnapshotFiles("/private/tmp/unrelated", arm, intel); e == nil {
		t.Fatal("unowned prefix accepted")
	}
}
