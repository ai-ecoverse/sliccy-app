package integration

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"strings"
	"testing"
)

type runnerFakeCode struct {
	role                    string
	value                   runnerBSDValue
	kernel                  runnerKernelCode
	live                    runnerCodeInformation
	slices                  []runnerFileSlice
	info                    func(runnerFileSlice) runnerCodeInformation
	ops                     runnerIndependentCodeOps
	closed, opened, checked int
	actualFlags             []uint32
}

func runnerFakeBSD(value runnerBSDValue, role, phase string) runnerBSDReceipt {
	bracket := func(v runnerBSDValue) runnerBSDBracket {
		var b runnerBSDBracket
		for i := range b {
			copy := v
			b[i] = runnerBSDRead{Expected: 648, Count: 648, Value: &copy}
		}
		b[1].Expected = 136
		b[1].Count = 136
		return b
	}
	r := runnerBSDReceipt{Role: role, Phase: phase, PID: value.PID, SelfPID: 70, ParentPID: 69}
	self := runnerBSDValue{PID: 70, Parent: 69, Effective: 501, Real: 501, Saved: 501, Seconds: 10, Microseconds: 1}
	parent := self
	parent.PID = 69
	parent.Parent = 1
	r.Controls = [2]runnerBSDBracket{bracket(self), bracket(parent)}
	r.Target = bracket(value)
	r.Selected, _ = runnerBSDSelect(r)
	used, controls := false, runnerBSDControls(r)
	r.Accepted = r.Selected != nil
	r.UsedSysctl = &used
	r.ControlsAgreed = &controls
	return r
}

func newRunnerFakeCode(role string) *runnerFakeCode {
	f := &runnerFakeCode{role: role, value: runnerBSDValue{PID: 42, Parent: 70, Effective: 501, Real: 501, Saved: 501, Seconds: 20, Microseconds: 1}}
	f.kernel.Path = "/fixture/Executable"
	copy(f.kernel.Hash[:], bytes.Repeat([]byte{1}, 20))
	if strings.HasPrefix(role, "com.apple.") {
		f.kernel.Flags = 0x04000000
	}
	if role == "com.apple.WindowServer" {
		f.value.Parent = 1
		f.value.Effective = 88
		f.value.Real = 0
		f.value.Saved = 0
	}
	f.live = runnerCodeInformation{Identifier: role, Path: f.kernel.Path, Type: 2, Hash: bytes.Repeat([]byte{1}, 20), Full: bytes.Repeat([]byte{1}, 32)}
	f.slices = []runnerFileSlice{{CPU: 16777228, Subtype: 0, Offset: 0, Size: 4096}, {CPU: 16777228, Subtype: 2, Offset: 4096, Size: 4096}}
	f.info = func(slice runnerFileSlice) runnerCodeInformation {
		v := f.live
		offset := slice.Offset
		v.Offset = &offset
		if slice.Subtype == 2 {
			v.Type = 3
		}
		return v
	}
	f.ops = runnerIndependentCodeOps{
		BSD:    func(phase string) (runnerBSDReceipt, error) { return runnerFakeBSD(f.value, f.role, phase), nil },
		Kernel: func() (runnerKernelCode, error) { return f.kernel, nil },
		GuestValidity: func(flags uint32, rule string) int32 {
			f.actualFlags = append(f.actualFlags, flags)
			want, _ := runnerReceiptRequirement(f.role)
			if rule != want {
				return -67050
			}
			return 0
		},
		GuestStaticValidity:  func(flags uint32, rule string) int32 { f.actualFlags = append(f.actualFlags, flags); return 0 },
		ChromeBundleValidity: func(flags uint32, rule string) int32 { f.actualFlags = append(f.actualFlags, flags); return 0 },
		LiveInformation:      func() (runnerCodeInformation, error) { return f.live, nil },
		Open: func(path string) (*runnerFileSnapshot, error) {
			f.opened++
			return &runnerFileSnapshot{Path: path, Slices: f.slices, Metadata: []string{"1", "2", "8192", "33188", "20", "0", "20", "0"}, Recheck: func() error { f.checked++; return nil }, Close: func() { f.closed++ }}, nil
		},
		ExplicitInformation: func(slice runnerFileSlice) (runnerCodeInformation, error) { return f.info(slice), nil },
		ExplicitValidity: func(slice runnerFileSlice, flags uint32, rule string) int32 {
			f.actualFlags = append(f.actualFlags, flags)
			return 0
		},
	}
	return f
}

func TestRunnerIndependentCodeBindsUniqueTypeAndActualBoundaries(t *testing.T) {
	for _, role := range []string{"ai.sliccy.mac", "ai.sliccy.proof-helper", "ai.sliccy.slicc", "com.google.Chrome", "com.apple.SecurityAgent", "com.apple.osascript", "com.apple.WindowManager", "com.apple.dock", "com.apple.finder", "com.apple.WindowServer"} {
		f := newRunnerFakeCode(role)
		fact, e := bindRunnerIndependentCode(42, role, f.kernel.Path, "", f.ops)
		if e != nil || !fact.Bound || fact.Selected.Type != 2 || fact.Selected.Offset != 0 || len(fact.Members) != 2 || f.closed != 1 || f.checked != 3 {
			t.Errorf("ASSERTION:unique-same-type-control role=%s error=%v", role, e)
		}
		flags := []uint32{16, 16, 25, 16}
		if role == "com.google.Chrome" {
			flags = []uint32{9, 25, 0, 0, 0, 9, 25, 0}
		}
		if len(fact.Statuses) != len(flags) || len(f.actualFlags) != len(flags) {
			t.Fatalf("ASSERTION:actual-role-call-count %s", role)
		}
		for i, want := range flags {
			if fact.Statuses[i].Flags != want || f.actualFlags[i] != want {
				t.Errorf("ASSERTION:actual-role-flags %s index=%d", role, i)
			}
		}
	}
	cases := []struct {
		name, role string
		change     func(*runnerFakeCode)
	}{
		{"kernel-live", "ai.sliccy.mac", func(f *runnerFakeCode) { f.kernel.Hash[0] = 2 }},
		{"full-prefix", "ai.sliccy.mac", func(f *runnerFakeCode) { f.live.Full = bytes.Repeat([]byte{2}, 32) }},
		{"platform", "com.apple.dock", func(f *runnerFakeCode) { f.kernel.Flags = 0 }},
		{"tuple", "com.apple.WindowServer", func(f *runnerFakeCode) { f.value.Effective = 89 }},
		{"control", "com.apple.WindowServer", func(f *runnerFakeCode) {
			old := f.ops.BSD
			f.ops.BSD = func(phase string) (runnerBSDReceipt, error) {
				r, e := old(phase)
				r.Controls[0][1].Value.Real++
				v := runnerBSDControls(r)
				r.ControlsAgreed = &v
				return r, e
			}
		}},
		{"before-routing", "ai.sliccy.mac", func(f *runnerFakeCode) {
			old := f.ops.BSD
			f.ops.BSD = func(phase string) (runnerBSDReceipt, error) { r, e := old(phase); r.PID++; return r, e }
		}},
		{"after-incarnation", "ai.sliccy.mac", func(f *runnerFakeCode) {
			f.ops.BSD = func(phase string) (runnerBSDReceipt, error) {
				v := f.value
				if phase == "after" {
					v.Seconds++
				}
				return runnerFakeBSD(v, f.role, phase), nil
			}
		}},
		{"selected-validity", "ai.sliccy.mac", func(f *runnerFakeCode) {
			f.ops.ExplicitValidity = func(runnerFileSlice, uint32, string) int32 { return -67050 }
		}},
		{"negative-control", "ai.sliccy.mac", func(f *runnerFakeCode) { f.ops.GuestValidity = func(uint32, string) int32 { return 0 } }},
		{"zero-match", "ai.sliccy.mac", func(f *runnerFakeCode) {
			f.info = func(s runnerFileSlice) runnerCodeInformation {
				v := f.live
				offset := s.Offset
				v.Offset = &offset
				v.Hash = bytes.Repeat([]byte{2}, 20)
				v.Full = bytes.Repeat([]byte{2}, 32)
				return v
			}
		}},
		{"multiple-match", "ai.sliccy.mac", func(f *runnerFakeCode) {
			old := f.info
			f.info = func(s runnerFileSlice) runnerCodeInformation { v := old(s); v.Type = 2; return v }
		}},
		{"wrong-type", "ai.sliccy.mac", func(f *runnerFakeCode) {
			old := f.info
			f.info = func(s runnerFileSlice) runnerCodeInformation { v := old(s); v.Type = 3; return v }
		}},
		{"offset", "ai.sliccy.mac", func(f *runnerFakeCode) {
			old := f.info
			f.info = func(s runnerFileSlice) runnerCodeInformation {
				v := old(s)
				wrong := s.Offset + 1
				v.Offset = &wrong
				return v
			}
		}},
		{"file-check", "ai.sliccy.mac", func(f *runnerFakeCode) {
			old := f.ops.Open
			f.ops.Open = func(path string) (*runnerFileSnapshot, error) {
				s, e := old(path)
				s.Recheck = func() error { return fmt.Errorf("changed file") }
				return s, e
			}
		}},
		{"kernel-final", "ai.sliccy.mac", func(f *runnerFakeCode) {
			calls := 0
			f.ops.Kernel = func() (runnerKernelCode, error) {
				calls++
				k := f.kernel
				if calls > 1 {
					k.Hash[0]++
				}
				return k, nil
			}
		}},
		{"chrome-bundle9", "com.google.Chrome", func(f *runnerFakeCode) {
			f.ops.ChromeBundleValidity = func(flags uint32, _ string) int32 {
				if flags == 9 {
					return -67050
				}
				return 0
			}
		}},
		{"chrome-bundle25", "com.google.Chrome", func(f *runnerFakeCode) {
			f.ops.ChromeBundleValidity = func(flags uint32, _ string) int32 {
				if flags == 25 {
					return -1
				}
				return 0
			}
		}},
		{"chrome-guest", "com.google.Chrome", func(f *runnerFakeCode) { f.ops.GuestStaticValidity = func(uint32, string) int32 { return -1 } }},
		{"chrome-slice9", "com.google.Chrome", func(f *runnerFakeCode) {
			f.ops.ExplicitValidity = func(_ runnerFileSlice, flags uint32, _ string) int32 {
				if flags == 9 {
					return -67050
				}
				return 0
			}
		}},
		{"chrome-slice25", "com.google.Chrome", func(f *runnerFakeCode) {
			f.ops.ExplicitValidity = func(_ runnerFileSlice, flags uint32, _ string) int32 {
				if flags == 25 {
					return -1
				}
				return 0
			}
		}},
	}
	for _, test := range cases {
		f := newRunnerFakeCode(test.role)
		test.change(f)
		fact, e := bindRunnerIndependentCode(42, test.role, f.kernel.Path, "", f.ops)
		if e == nil || fact.Bound {
			t.Errorf("ASSERTION:refuse-%s", test.name)
		}
		if f.opened > 0 && f.closed != 1 {
			t.Errorf("ASSERTION:file-release-%s", test.name)
		}
	}
	f := newRunnerFakeCode("com.google.Chrome")
	f.ops.ChromeBundleValidity = func(flags uint32, _ string) int32 {
		if flags == 25 {
			return -66999
		}
		return 0
	}
	f.ops.ExplicitValidity = func(_ runnerFileSlice, flags uint32, _ string) int32 {
		if flags == 25 {
			return -66999
		}
		return 0
	}
	if fact, e := bindRunnerIndependentCode(42, f.role, f.kernel.Path, "", f.ops); e != nil || !fact.Bound {
		t.Errorf("ASSERTION:typed-chrome-detritus %v", e)
	}
}

func TestRunnerExecutableSlicesRetainSameCPUCapabilitiesAndBounds(t *testing.T) {
	makeThin := func(cpu, sub uint32) []byte {
		data := make([]byte, 4096)
		binary.LittleEndian.PutUint32(data, 0xfeedfacf)
		binary.LittleEndian.PutUint32(data[4:], cpu)
		binary.LittleEndian.PutUint32(data[8:], sub)
		return data
	}
	first, second := makeThin(16777228, 0x80000002), makeThin(16777228, 0x8000000c)
	raw := make([]byte, 12288)
	binary.BigEndian.PutUint32(raw, 0xcafebabe)
	binary.BigEndian.PutUint32(raw[4:], 2)
	for i, sub := range []uint32{0x80000002, 0x8000000c} {
		at := 8 + 20*i
		binary.BigEndian.PutUint32(raw[at:], 16777228)
		binary.BigEndian.PutUint32(raw[at+4:], sub)
		binary.BigEndian.PutUint32(raw[at+8:], uint32(4096*(i+1)))
		binary.BigEndian.PutUint32(raw[at+12:], 4096)
		binary.BigEndian.PutUint32(raw[at+16:], 12)
	}
	copy(raw[4096:], first)
	copy(raw[8192:], second)
	if slices, e := runnerFileSlices(raw); e != nil || len(slices) != 2 || slices[0].Subtype != -2147483646 || slices[1].Subtype != -2147483636 {
		t.Fatalf("ASSERTION:capability-slices %v", e)
	}
	for _, change := range []func([]byte){func(v []byte) { binary.BigEndian.PutUint32(v[4:], 9) }, func(v []byte) { binary.BigEndian.PutUint32(v[36:], 4096) }, func(v []byte) { binary.BigEndian.PutUint32(v[20:], 8192) }, func(v []byte) { binary.BigEndian.PutUint32(v[20:], 0xffffffff) }, func(v []byte) { binary.BigEndian.PutUint32(v[24:], 31) }, func(v []byte) { binary.LittleEndian.PutUint32(v[8196:], 1) }} {
		bad := append([]byte(nil), raw...)
		change(bad)
		if _, e := runnerFileSlices(bad); e == nil {
			t.Error("ASSERTION:invalid-slice-range")
		}
	}
	if slices, e := runnerFileSlices(first); e != nil || len(slices) != 1 || slices[0].Offset != 0 {
		t.Fatalf("ASSERTION:thin-slice %v", e)
	}
}
