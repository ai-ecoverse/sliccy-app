package integration
import (
 "errors"
 "fmt"
 "io"
 "strings"
 "testing"
 "time"
 "syscall"
 "sync"
 "github.com/pion/webrtc/v4"
)
type runnerSignallingFailureReporter struct{failures int}
func(r *runnerSignallingFailureReporter)Error(...any){r.failures++}
func TestRunnerSignallingRejectsKeepActualUnderlyingError(t *testing.T){
 for _,step:=range []string{"fixture.answer","fixture.candidate-marshal","fixture.candidate-decode","fixture.candidate-add"}{t.Run(step,func(t *testing.T){
  d:=newRunnerDiagnostics(time.Now());reporter:=&runnerSignallingFailureReporter{}
  ops:=proofSignallingOps{Answer:func(webrtc.SessionDescription)error{return errors.New("fixed-answer-error")},Candidate:func(webrtc.ICECandidateInit)error{return errors.New("fixed-candidate-error")}}
  action,body:="ice-candidate",map[string]any{"candidate":map[string]any{"candidate":"synthetic-not-real"}}
  switch step {case "fixture.answer":action="answer";body=map[string]any{"answer":map[string]any{"sdp":"secret-sdp"}};case "fixture.candidate-marshal":body["candidate"]=func(){};case "fixture.candidate-decode":body["candidate"]=17}
  proofApplySignalling(reporter,action,body,d,ops)
  path:=d.Snapshot()[step]
  if reporter.failures!=1 || len(path.Records)!=1 || !path.Records[0].First || path.Records[0].Tail=="" || path.Records[0].Order!=1 || path.Records[0].MonotonicMS<0 {t.Fatalf("ASSERTION:signalling-diagnostic-%s",step)}
 })}
}
type runnerBrokenReader struct{}
func(runnerBrokenReader)Read([]byte)(int,error){return 0,errors.New("fixed-reader-fault")}
func TestRunnerMetadataFailurePathsKeepFirstUnderlyingError(t *testing.T){
 for _,kind:=range []string{"decoder","envelope","queue","pipe","terminal","problem","wait"}{t.Run(kind,func(t *testing.T){
  d:=newRunnerDiagnostics(time.Now());var reader io.Reader=strings.NewReader("");capacity:=2
  valid:=`{"schema":6,"case":"selected-window","capture":true,"stage":"runner-preflight","elapsedMs":1,"eventElapsedMs":1,"screenCapture":true,"listenEvent":true,"postEvent":true,"hosted":true,"osMajor":27,"architecture":"arm64"}`
  switch kind {case "decoder":reader=strings.NewReader("{broken\n");case "envelope":reader=strings.NewReader(strings.Replace(valid,"selected-window","active-stop",1)+"\n");case "queue":capacity=0;reader=strings.NewReader(valid+"\n");case "pipe":reader=runnerBrokenReader{}}
  incoming:=make(chan runnerIncoming,capacity);finished:=make(chan runnerReadResult,1);aborts:=0
  wait:=func()(error,runnerProcessExit){if kind=="wait"{return errors.New("fixed-wait-fault"),runnerProcessExit{Observed:true,Code:1}};return nil,runnerProcessExit{Observed:true,Exited:true,Code:0}}
  readRunnerRowsWithWait(reader,wait,"selected-window",incoming,finished,func(){aborts++},d)
  result:=<-finished;records:=d.Snapshot()["metadata."+kind].Records
  if len(records)==0 || !records[0].First || records[0].Tail=="" {t.Fatalf("ASSERTION:metadata-diagnostic-%s",kind)}
  if kind!="wait" && (aborts!=1 || result.err==nil) {t.Fatal("existing metadata refusal changed")}
 })}
}
func TestRunnerDiagnosticFirstOrderBoundsAndSanitization(t *testing.T){
 d:=newRunnerDiagnostics(time.Now());secret:="fixed-private-secret-1234567890";d.AddSecret(secret)
 d.Record("page.problem",fmt.Errorf("first underlying: %s https://example.invalid/%s 'content' 192.0.2.1\nsecret payload",secret,secret))
 d.Record("metadata.problem",errors.New("second underlying"))
 for i:=0;i<100;i++{d.Record("page.problem",errors.New(strings.Repeat("x",500)))}
 paths:=d.Snapshot();first:=paths["page.problem"].Records[0]
 if !first.First || first.Order!=1 || paths["metadata.problem"].Records[0].Order!=2 || first.MonotonicMS<0 || !strings.Contains(first.Tail,"first underlying") {t.Fatal("ASSERTION:diagnostic-first-order")}
 if paths["page.problem"].Bytes>4096 || paths["page.problem"].Omitted==0 {t.Fatal("ASSERTION:diagnostic-path-bound")}
 for _,v:=range paths {for _,r:=range v.Records {if strings.Contains(r.Tail,secret)||strings.Contains(r.Tail,"example.invalid")||strings.Contains(r.Tail,"192.0.2.1")||strings.Contains(r.Tail,"content")||strings.Contains(r.Tail,"secret payload"){t.Fatal("ASSERTION:diagnostic-secrets-sanitized")}}}
}
func TestRunnerAppOutputTailAndSignalFactsAreRetained(t *testing.T){
 tail:=&runnerOutputTail{};_,_=tail.Write([]byte(strings.Repeat("safe ",4000)));_,_=tail.Write([]byte("private-token-12345678901234567890 first-fixed-error\nlast-fixed-error"));text,total:=tail.Snapshot([]string{"private-token-12345678901234567890"})
 if total<20000 || len(text)>4096 || !strings.Contains(text,"last-fixed-error") || strings.Contains(text,"private-token") {t.Fatal("ASSERTION:app-output-tail")}
 exit:=runnerCaptureWaitStatus(true,false,-1,syscall.WaitStatus(syscall.SIGTERM))
 if !exit.Observed || !exit.Signaled || exit.Signal!=int(syscall.SIGTERM) || exit.Code!=-1 {t.Fatal("ASSERTION:app-exit-signal")}
}

func TestRunnerSensitiveHexLeadingFieldsAreRemovedBeforeTransformations(t *testing.T){
 for _,field:=range []string{"a=ice-pwd:","a=ice-ufrag:","candidate:","foundation:","ice_pwd=","ice_ufrag="}{for _,multiline:=range []bool{false,true}{
  name:=field+"single";if multiline{name=field+"multiline"}
  t.Run(name,func(t *testing.T){
   value:=field+"deadbeefSecretKey123456"
   input:="fixed error "+value
   var result string
   if multiline{tail:=&runnerOutputTail{};_,_=tail.Write([]byte("fixed first error\n"+input+"\nlast-fixed-error"));result,_=tail.Snapshot(nil)}else{result=runnerSanitizeDiagnostic(input,nil)}
   if strings.Contains(result,"SecretKey")||strings.Contains(result,"deadbeef")||!strings.Contains(result,"<sensitive-field>"){t.Fatalf("ASSERTION:sensitive-field-%s-%t",field,multiline)}
  })
 }}
 unknown:=runnerSanitizeDiagnostic("fixed error OddSecretX",nil)
 if strings.Contains(unknown,"OddSecretX") {t.Fatal("ASSERTION:diagnostic-unknown-value-redacted")}
}
func TestRunnerExitFactsPublishOnlyAfterFinishedResult(t *testing.T){
 d:=newRunnerDiagnostics(time.Now());incoming:=make(chan runnerIncoming,1);finished:=make(chan runnerReadResult,1)
 entered,release,done:=make(chan struct{}),make(chan struct{}),make(chan struct{})
 var released sync.Once;defer released.Do(func(){close(release)})
 wait:=func()(error,runnerProcessExit){close(entered);<-release;return errors.New("fixed-wait-fault"),runnerCaptureWaitStatus(true,false,-1,syscall.WaitStatus(syscall.SIGTERM))}
 go func(){defer close(done);readRunnerRowsWithWait(strings.NewReader(""),wait,"selected-window",incoming,finished,nil,d)}()
 select{case <-entered:case <-time.After(time.Second):t.Fatal("synthetic wait boundary not reached")}
 if result:=runnerSettledExit(runnerReadResult{exit:runnerProcessExit{Observed:true,Code:123}},false);result.Observed||result.Code!=-1{t.Fatal("ASSERTION:unsettled-exit-unobserved")}
 select{case <-finished:t.Fatal("exit published before wait settled");default:}
 released.Do(func(){close(release)})
 select{case r:=<-finished:
  exit:=runnerSettledExit(r,true)
  if !exit.Observed||!exit.Signaled||exit.Signal!=int(syscall.SIGTERM)||exit.Code!=-1{t.Fatal("ASSERTION:settled-exit-channel")}
 case <-time.After(time.Second):t.Fatal("settled exit record missing")}
 select{case <-done:case <-time.After(time.Second):t.Fatal("synthetic reader unsettled")}
}
