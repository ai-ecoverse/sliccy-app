package integration

import (
 "bufio"
 "bytes"
 "encoding/json"
 "fmt"
 "math"
 "os"
 "strings"
 "testing"
)

func runnerBuild16FixtureRows(t *testing.T)([][]byte,[][]byte) {
 t.Helper();path:=os.Getenv("SLICCY_BUILD16_FIXTURE");if path==""{t.Fatal("actual build16 Foundation producer fixture absent")}
 raw,e:=os.ReadFile(path);if e!=nil||len(raw)>1<<20{t.Fatal("build16 fixture",e)}
 scanner:=bufio.NewScanner(bytes.NewReader(raw));scanner.Buffer(make([]byte,4096),4096);var structural,display [][]byte
 for scanner.Scan(){line:=append([]byte(nil),scanner.Bytes()...);var header struct{Stage string `json:"stage"`};if json.Unmarshal(line,&header)!=nil{t.Fatal("fixture JSON")};if header.Stage=="protected-structural-refused"{structural=append(structural,line)}else{display=append(display,line)}}
 if scanner.Err()!=nil||len(structural)!=65||len(display)!=218{t.Fatal("ASSERTION:v83-build16-actual-max-rows",len(structural),len(display),scanner.Err())}
 return structural,display
}

func runnerStructuralFixture(t *testing.T)([]runnerWindowClaim,[]runnerRefusalClaim,[]runnerStructuralRefusal,map[int]runnerProcessFact,[]runnerUnionWindowClaim,[]independentWindow) {
 t.Helper();rows,_:=runnerBuild16FixtureRows(t);var structural []runnerStructuralRefusal
 for _,raw:=range rows{row,e:=decodeRunnerCaptureRow(raw);if e!=nil||row.Structural==nil{t.Fatal("ASSERTION:v83-C-actual-encoder",e)};structural=append(structural,*row.Structural)}
 identity:=runnerBSDValue{PID:42,Parent:1,Effective:88,Real:0,Saved:0,Seconds:math.MaxUint64,Microseconds:999999}
 fact:=runnerProcessFact{Label:"window-server",Bundle:"com.apple.WindowServer",Identity:identity}
 fact.Code.Binding.Bound=true;fact.Code.Binding.Kernel.Flags=0x04000000;fact.Code.Binding.Before=runnerFakeBSD(identity,"com.apple.WindowServer","before");fact.Code.Binding.After=runnerFakeBSD(identity,"com.apple.WindowServer","after")
 var windows []runnerWindowClaim;var union []runnerUnionWindowClaim;var actual []independentWindow
 for index,id:=range structural[0].PairedWindowIDs{rect:=independentRect{float64(index),0,1024,768};windows=append(windows,runnerWindowClaim{Label:"window-server",PID:42,ID:id,Rect:rect,Layer:-2147483626});union=append(union,runnerUnionWindowClaim{ID:id,PID:42,Identifier:"com.apple.WindowServer",Kind:"system",InCG:true,InSCK:true,Layer:-2147483626,Rect:rect});actual=append(actual,independentWindow{ID:id,PID:42,Rect:rect,Layer:-2147483626,OnScreen:true})}
 return windows,nil,structural,map[int]runnerProcessFact{42:fact},union,actual
}

func TestRunnerV83StructuralActualEncoderStrictUnion(t *testing.T) {
 rows,_:=runnerBuild16FixtureRows(t)
 for _,raw:=range rows{row,e:=decodeRunnerCaptureRow(raw);if e!=nil||row.Structural==nil{t.Fatal("ASSERTION:v83-C-actual-encoder",e)}}
 for _,change:=range []struct{key string;value any}{{"predicateEvidence",true},{"rawSCKBundleEmpty",false},{"reason","verified-windowserver-empty-sck-bundle "},{"role","com.apple.finder"},{"label","finder"},{"startSeconds","0"},{"startMicroseconds",1000000},{"pid",0},{"windowID",3},{"pairedWindowIDs",[]uint32{}},{"extra",false}}{
  if _,e:=decodeRunnerCaptureRow(runnerRefusalReplace(rows[0],[]string{change.key},change.value));e==nil{t.Fatal("ASSERTION:v83-C-invalid-"+change.key)}
 }
 bad:=runnerRefusalReplace(rows[1],[]string{"pairedWindowIDs"},[]uint32{1});if _,e:=decodeRunnerCaptureRow(bad);e==nil{t.Fatal("ASSERTION:v83-C-window-union")}
}

func TestRunnerV83StructuralCoverageKeepsStrongerClaimUndemonstrated(t *testing.T) {
 w,r,s,f,u,a:=runnerStructuralFixture(t)
 coverage,e:=matchRunnerProtectedCoverage(w,r,s,f,u,a)
 if e!=nil||coverage==nil||coverage.ProtectedTargetRefusalCoverage!="complete"{t.Fatal("ASSERTION:v83-C-complete-structural-coverage",e)}
 if coverage.AllOwnerProtectedPredicatesDemonstrated||coverage.StrongerEveryOwnerPredicateClaim!="FAILED_TO_DEMONSTRATE"||coverage.WindowServerProtectedPredicateClaim!="FAILED_TO_DEMONSTRATE"||coverage.OwnerEvidenceCategories[42]!=runnerStructuralReason{t.Fatal("ASSERTION:v83-C-no-predicate-promotion")}
 id:=uint32(1);ordinaryWindows:=[]runnerWindowClaim{{Label:"app",PID:10,ID:id,Rect:independentRect{0,0,1,1},Layer:25}};ordinary:=[]runnerRefusalClaim{{Label:"app",PID:10,Kind:"display",Predicate:true},{Label:"app",PID:10,Kind:"window",WindowID:&id}}
 coverage,e=matchRunnerProtectedCoverage(ordinaryWindows,ordinary,nil,nil,nil,nil);if e!=nil||!coverage.AllOwnerProtectedPredicatesDemonstrated{t.Fatal("ASSERTION:v83-C-ordinary-path-preserved",e)}
}

func TestRunnerV83StructuralOwnerAndCGCorrelation(t *testing.T) {
 for _,fault:=range []string{"role","platform","credentials","incarnation","cg-pid","cg-rect","cg-layer","cg-missing","union-sck","union-selectable"}{
  w,r,s,f,u,a:=runnerStructuralFixture(t);fact:=f[42]
  switch fault{case "role":fact.Label="finder";fact.Bundle="com.apple.finder";case "platform":fact.Code.Binding.Kernel.Flags=0;case "credentials":fact.Identity.Effective=0;case "incarnation":s[0].Seconds--;case "cg-pid":a[0].PID++;case "cg-rect":a[0].Rect.X++;case "cg-layer":a[0].Layer++;case "cg-missing":a=a[1:];case "union-sck":u[0].InSCK=false;case "union-selectable":u[0].Selectable=true};f[42]=fact
  if _,e:=matchRunnerProtectedCoverage(w,r,s,f,u,a);e==nil{t.Fatal("ASSERTION:v83-C-correlation-"+fault)}
 }
}

func TestRunnerV83StructuralCategoriesAreDisjointAndComplete(t *testing.T) {
 for _,fault:=range []string{"mixed","missing-display","missing-window","duplicate-window","extra-window","wrong-set"}{w,r,s,f,u,a:=runnerStructuralFixture(t)
  switch fault{case "mixed":r=append(r,runnerRefusalClaim{Label:"window-server",PID:42,Kind:"display",Predicate:true});case "missing-display":s=s[1:];case "missing-window":s=s[:len(s)-1];case "duplicate-window":s=append(s,s[1]);case "extra-window":id:=uint32(2);s=append(s,runnerStructuralRefusal{PID:42,Kind:"window",Seconds:math.MaxUint64,Microseconds:999999,WindowID:&id});case "wrong-set":s[0].PairedWindowIDs=append([]uint32(nil),s[0].PairedWindowIDs...);s[0].PairedWindowIDs[0]--}
  if _,e:=matchRunnerProtectedCoverage(w,r,s,f,u,a);e==nil{t.Fatal("ASSERTION:v83-C-category-"+fault)}
 }
}

func TestRunnerV83DisplayActualEncoderMaximumJournalVolume(t *testing.T) {
 structural,display:=runnerBuild16FixtureRows(t);var ledger runnerDisplayLedger;total,maxRow:=0,0
 for _,raw:=range append(structural,display...){total+=len(raw)+1;if len(raw)+1>maxRow{maxRow=len(raw)+1}}
 for _,raw:=range display{row,e:=decodeRunnerCaptureRow(raw);if e!=nil||row.DisplayDiagnostic==nil{t.Fatal("ASSERTION:v83-display-actual-encoder",e)};if e=ledger.Add(*row.DisplayDiagnostic);e!=nil{t.Fatal("ASSERTION:v83-display-out-of-order-completion",e)}}
 if e:=ledger.Complete();e!=nil{t.Fatal("ASSERTION:v83-display-max-complete",e)}
 if total+541696>1048576||maxRow>4096{t.Fatal("ASSERTION:v83-app-journal-positive-margin",total,maxRow)}
 t.Logf("actual structuralRows=%d displayRows=%d combinedBytes=%d maxRow=%d appNominal=%d margin=%d",len(structural),len(display),total,maxRow,total+541696,1048576-total-541696)
}

func TestRunnerV83DisplayStrictOriginAndScreenFields(t *testing.T) {
 _,rows:=runnerBuild16FixtureRows(t)
 for _,raw:=range rows {
  var f map[string]json.RawMessage;json.Unmarshal(raw,&f);var stage string;json.Unmarshal(f["stage"],&stage)
  if stage=="display-diagnostic-origin"||stage=="display-observation-screen"||stage=="display-diagnostic-closed" {
   bad:=runnerRefusalReplace(raw,[]string{"unknown"},false);if _,e:=decodeRunnerCaptureRow(bad);e==nil{t.Fatal("ASSERTION:v83-display-exact-"+stage)}
   for key:=range f{if strings.Contains(" schema case capture stage elapsedMs eventElapsedMs "," "+key+" "){continue};copy:=map[string]json.RawMessage{};for k,v:=range f{copy[k]=v};delete(copy,key);bad,_:=json.Marshal(copy);if _,e:=decodeRunnerCaptureRow(bad);e==nil{t.Fatal("ASSERTION:v83-display-missing-"+key)}}
  }
  if stage=="display-observation"{for _,value:=range []string{" notification","notification ","notification preflight","notification\t",""}{bad:=runnerRefusalReplace(raw,[]string{"trigger"},value);if _,e:=decodeRunnerCaptureRow(bad);e==nil{t.Fatal("ASSERTION:v83-display-exact-trigger")}}}
 }
}

func TestRunnerV83DisplayLedgerRefusesMissingParentCountAndClose(t *testing.T) {
 _,rows:=runnerBuild16FixtureRows(t)
 decode:=func(raw []byte)runnerDisplayDiagnostic{row,e:=decodeRunnerCaptureRow(raw);if e!=nil||row.DisplayDiagnostic==nil{t.Fatal(e)};return *row.DisplayDiagnostic}
 origin:=decode(rows[0]);var observation,screen,closed runnerDisplayDiagnostic
 for _,raw:=range rows{v:=decode(raw);switch v.Stage{case "display-observation":observation=v;case "display-observation-screen":screen=v;case "display-diagnostic-closed":closed=v}}
 var positive runnerDisplayLedger;for _,raw:=range rows{if e:=positive.Add(decode(raw));e!=nil{t.Fatal(e)}}
 if e:=positive.Complete();e!=nil{t.Fatal(e)}
 for _,fault:=range []string{"parent","count","close","unfinished","duplicate"}{var ledger runnerDisplayLedger;ledger.Add(origin)
  switch fault{
  case "parent":if ledger.Add(screen)==nil{t.Fatal("ASSERTION:v83-display-parent-required")}
  case "count":observation.Ordinal=1;observation.Retained=1;observation.Reported=1;ledger.Add(observation);closed.Admitted=1;closed.Completed=1;closed.Unfinished=0;if ledger.Add(closed)==nil{t.Fatal("ASSERTION:v83-display-screen-count-required")}
  case "close":for _,raw:=range rows[1:len(rows)-1]{if e:=ledger.Add(decode(raw));e!=nil{t.Fatal(e)}};if ledger.Complete()==nil{t.Fatal("ASSERTION:v83-display-close-required")}
  case "unfinished":for _,trigger:=range strings.Fields(runnerDisplayMilestones){v:=runnerDisplayDiagnostic{Stage:"display-observation",Ordinal:len(ledger.Observations)+1,Trigger:trigger,Status:"unfinished"};if e:=ledger.Add(v);e!=nil{t.Fatal(e)}};if e:=ledger.Add(runnerDisplayDiagnostic{Stage:"display-diagnostic-closed",Admitted:8,Unfinished:8});e!=nil{t.Fatal(e)};if ledger.Complete()==nil{t.Fatal("ASSERTION:v83-display-unfinished-refused")}
  case "duplicate":ledger.Add(observation);if ledger.Add(observation)==nil{t.Fatal("ASSERTION:v83-display-duplicate-refused")}
  }
 }
}

func TestRunnerV83DisplayDiagnosticsNeverSupplyIdentityOrSuccess(t *testing.T) {
 _,rows:=runnerBuild16FixtureRows(t)
 for _,raw:=range rows{row,e:=decodeRunnerCaptureRow(raw);if e!=nil{t.Fatal(e)};result:=runnerCaseResult{Result:"FAIL"};runnerObserveCaseAvailability(&result,row);if result.Result!="FAIL"||len(result.Processes)!=0||result.NativeObservationSettled{t.Fatal("ASSERTION:v83-display-no-authority")}}
 var ledger runnerCaseMetadataLedger
 terminal:=runnerCaptureRow{Stage:"terminal",Fields:map[string]json.RawMessage{"outcome":json.RawMessage(`"complete"`)}}
 if ledger.Add(terminal)==nil{t.Fatal("ASSERTION:v83-display-terminal-needs-ledger")}
 for _,raw:=range rows{row,e:=decodeRunnerCaptureRow(raw);if e!=nil||ledger.Add(row)!=nil{t.Fatal(fmt.Sprintf("actual display ledger: %v",e))}}
 if e:=ledger.Add(terminal);e!=nil{t.Fatal("ASSERTION:v83-display-complete-control",e)}
}
