package integration

import (
	"bytes"
	"context"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"unsafe"

	"github.com/ebitengine/purego"
	"golang.org/x/sys/unix"
)

type runnerProcessFact = runnerBoundProcess

func runnerPlacement() error {
	env := map[string]string{}
	for _, key := range []string{"GITHUB_ACTIONS", "GITHUB_REPOSITORY", "GITHUB_EVENT_NAME", "GITHUB_REF", "SLICCY_RUNNER_ENVIRONMENT"} {
		env[key] = os.Getenv(key)
	}
	version := os.Getenv("SLICCY_RUNNER_OS_VERSION")
	if e := hostedPIDPlacement(env, version, runtime.GOARCH); e != nil {
		return e
	}
	if os.Getenv("RUNNER_ENVIRONMENT") != "github-hosted" {
		return fmt.Errorf("real hosted placement required")
	}
	return nil
}
func runnerProcessPath(pid int) (string, error) {
	lib, e := purego.Dlopen("/usr/lib/libproc.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return "", e
	}
	defer purego.Dlclose(lib)
	var path func(int32, *byte, uint32) int32
	purego.RegisterLibFunc(&path, lib, "proc_pidpath")
	var buf [4096]byte
	n := path(int32(pid), &buf[0], 4096)
	if n <= 0 || n >= 4096 {
		return "", fmt.Errorf("process path unavailable")
	}
	end := bytes.IndexByte(buf[:], 0)
	if end < 1 {
		return "", fmt.Errorf("process path not bounded")
	}
	p, e := filepath.EvalSymlinks(string(buf[:end]))
	if e != nil || !filepath.IsAbs(p) {
		return "", fmt.Errorf("process path unresolved")
	}
	return p, nil
}
func runnerProcArguments(pid int) ([]string, string, error) {
	var size uintptr
	mib := []int32{1, 49, int32(pid)}
	_, _, errno := syscall.Syscall6(syscall.SYS___SYSCTL, uintptr(unsafe.Pointer(&mib[0])), 3, 0, uintptr(unsafe.Pointer(&size)), 0, 0)
	if errno != 0 || size < 8 || size > 262144 {
		return nil, "", fmt.Errorf("bounded process arguments unavailable")
	}
	data := make([]byte, size)
	_, _, errno = syscall.Syscall6(syscall.SYS___SYSCTL, uintptr(unsafe.Pointer(&mib[0])), 3, uintptr(unsafe.Pointer(&data[0])), uintptr(unsafe.Pointer(&size)), 0, 0)
	runtime.KeepAlive(mib)
	if errno != 0 || size > uintptr(len(data)) {
		return nil, "", fmt.Errorf("process arguments query failed")
	}
	return parseRunnerArguments(data[:size])
}
func parseRunnerArguments(data []byte) ([]string, string, error) {
	if len(data) < 8 || len(data) > 262144 {
		return nil, "", fmt.Errorf("argument buffer outside bounds")
	}
	count := int(binary.LittleEndian.Uint32(data[:4]))
	if count < 1 || count > 64 {
		return nil, "", fmt.Errorf("argument count outside bounds")
	}
	rest := data[4:]
	end := bytes.IndexByte(rest, 0)
	if end < 1 {
		return nil, "", fmt.Errorf("missing executable argument")
	}
	rest = rest[end+1:]
	for len(rest) > 0 && rest[0] == 0 {
		rest = rest[1:]
	}
	var args []string
	total := 0
	for i := 0; i < count; i++ {
		end = bytes.IndexByte(rest, 0)
		if end < 0 {
			return nil, "", fmt.Errorf("partial argv")
		}
		total += end
		if total > 16384 {
			return nil, "", fmt.Errorf("argv outside budget")
		}
		args = append(args, string(rest[:end]))
		rest = rest[end+1:]
	}
	tmp := ""
	for len(rest) > 0 {
		end = bytes.IndexByte(rest, 0)
		if end < 0 {
			return nil, "", fmt.Errorf("partial environment")
		}
		if end == 0 {
			break
		}
		item := rest[:end]
		if bytes.HasPrefix(item, []byte("TMPDIR=")) {
			if tmp != "" {
				return nil, "", fmt.Errorf("duplicate temporary root")
			}
			tmp = string(item[7:])
		}
		rest = rest[end+1:]
	}
	return args, tmp, nil
}
func runnerOwnedRoot(tmp string) (string, error) {
	root := filepath.Dir(filepath.Clean(tmp))
	if filepath.Dir(root) != "/private/tmp" || !strings.HasPrefix(filepath.Base(root), "sliccy-runner.") || len(filepath.Base(root)) != len("sliccy-runner.")+8 || filepath.Base(filepath.Clean(tmp)) != "tmp" {
		return "", fmt.Errorf("unexpected owned root")
	}
	for _, path := range []string{root, filepath.Join(root, "tmp"), filepath.Join(root, "config")} {
		s, e := os.Lstat(path)
		if e != nil || !s.IsDir() || s.Mode()&os.ModeSymlink != 0 || s.Mode().Perm()&0077 != 0 {
			return "", fmt.Errorf("unsafe owned directory")
		}
		st, ok := s.Sys().(*syscall.Stat_t)
		if !ok || st.Uid != uint32(os.Getuid()) {
			return "", fmt.Errorf("owned directory UID mismatch")
		}
	}
	return root, nil
}
func runnerChromeArguments(args []string, tmp, label, origin string) (string, error) {
	root, e := runnerOwnedRoot(tmp)
	if e != nil {
		return "", e
	}
	profile := strings.TrimPrefix(label, "chrome-")
	if !runnerOneOf(profile, "a-1 a-2 b-1 b-2") {
		return "", fmt.Errorf("unknown browser profile")
	}
	var page fixedProofPage
	found := false
	for _, candidate := range fixedProofPageCatalog {
		if candidate.Profile == profile {
			if found {
				return "", fmt.Errorf("ambiguous frozen profile")
			}
			page = candidate
			found = true
		}
	}
	if !found {
		return "", fmt.Errorf("missing frozen profile")
	}
	want := []string{"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "--user-data-dir=" + filepath.Join(root, "config/chrome-"+profile), "--no-first-run", "--no-default-browser-check", "--use-mock-keychain", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--disable-default-apps", fmt.Sprintf("--window-position=%d,%d", int(page.Rect.X), int(page.Rect.Y)), "--window-size=288,224", "--app=" + origin + page.Path}
	if len(args) != len(want) {
		return "", fmt.Errorf("unexpected browser argv")
	}
	for i := range want {
		if args[i] != want[i] {
			return "", fmt.Errorf("browser argv differs from fixed profile")
		}
	}
	return root, nil
}
func readRunnerMainDisplay() (result independentRect, err error) {
	if runnerPlacement() != nil {
		return result, fmt.Errorf("hosted display observation required")
	}
	defer func() {
		if recover() != nil {
			err = fmt.Errorf("display ABI unavailable")
		}
	}()
	lib, e := purego.Dlopen("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return result, e
	}
	defer purego.Dlclose(lib)
	var main func() uint32
	var bounds func(uint32) independentRect
	purego.RegisterLibFunc(&main, lib, "CGMainDisplayID")
	purego.RegisterLibFunc(&bounds, lib, "CGDisplayBounds")
	result = bounds(main())
	if result.X != 0 || result.Y != 0 || result.Width < 1024 || result.Height < 768 || result.Width > 2560 || result.Height > 2560 || result.Width*result.Height > 4000000 {
		return result, fmt.Errorf("unsupported independent display geometry")
	}
	return result, nil
}
func runnerProcessGone(pid int, identity runnerBSDValue) bool {
	current, e := runnerObserveBSD(pid)
	if e != nil {
		return runnerPIDAbsent(pid)
	}
	return current.Selected != nil && !runnerBSDEqual(current.Selected, &identity)
}

func runnerKillBoundOwned(ctx context.Context, trace *runnerNativeTrace, fact runnerProcessFact, signal unix.Signal) error {
	if !fact.Owned || !runnerOneOf(fact.Label, "app allowed cli authorization-requester chrome-a-1 chrome-a-2 chrome-b-1 chrome-b-2") || !fact.Code.Binding.Bound || (signal != unix.SIGKILL && signal != unix.SIGTERM) {
		return fmt.Errorf("refuse signal without retained direct ownership")
	}
	pin := hex.EncodeToString(fact.Code.Binding.Kernel.Hash[:])
	observation, e := observeRunnerNativeBinding(ctx, trace, int(fact.Identity.PID), fact.Bundle, fact.Path, pin)
	if e != nil || !observation.Binding.Bound || !runnerBSDEqual(&observation.Binding.BSD, &fact.Identity) || observation.Binding.Kernel != fact.Code.Binding.Kernel {
		return fmt.Errorf("refuse signal after incarnation/live code change")
	}
	if ctx.Err() != nil {
		return ctx.Err()
	}
	id, ok := trace.Begin("owned-kill", int(fact.Identity.PID), uint32(signal))
	if !ok {
		return fmt.Errorf("signal diagnostic retired")
	}
	e = unix.Kill(int(fact.Identity.PID), signal)
	status := int32(0)
	if errno, ok := e.(unix.Errno); ok {
		status = int32(errno)
	}
	if !trace.End(id, &status, e == nil) {
		return fmt.Errorf("signal completion lost")
	}
	return e
}

func runnerRootAssociated(args []string, tmp string, roots map[string]bool) bool {
	for root := range roots {
		if filepath.Clean(tmp) == filepath.Join(root, "tmp") {
			return true
		}
		for _, arg := range args {
			if strings.HasPrefix(arg, "--user-data-dir="+filepath.Join(root, "config")+"/") {
				return true
			}
		}
	}
	return false
}

type runnerRootDiscoveryOps struct {
	List      func() ([]int, error)
	BSD       func(int) runnerBSDRead
	Path      func(int) (string, error)
	Arguments func(int) ([]string, string, error)
	Absent    func(int) bool
}

func runnerRootProcessesWith(ctx context.Context, roots map[string]bool, app string, ops runnerRootDiscoveryOps) (found []int, err error) {
	if len(roots) == 0 {
		return nil, nil
	}
	if ctx == nil || ctx.Err() != nil {
		return nil, fmt.Errorf("residual discovery context expired")
	}
	if ops.List == nil || ops.BSD == nil || ops.Path == nil || ops.Arguments == nil || ops.Absent == nil {
		return nil, fmt.Errorf("residual discovery boundary incomplete")
	}
	pids, err := ops.List()
	if err != nil || len(pids) < 1 || len(pids) > 4096 {
		return nil, fmt.Errorf("bounded residual process list unavailable")
	}
	seen := map[int]bool{}
	for _, pid := range pids {
		if ctx.Err() != nil {
			return found, ctx.Err()
		}
		if pid < 1 {
			continue
		}
		if seen[pid] {
			return found, fmt.Errorf("duplicate residual process PID")
		}
		seen[pid] = true
		before := ops.BSD(pid)
		if !runnerBSDValid(before, int64(pid)) {
			if ops.Absent(pid) {
				continue
			}
			path, e := ops.Path(pid)
			if e != nil || runnerCleanupCandidate(path, app) {
				return found, fmt.Errorf("residual-identity pid=%d status=%d count=%d expected=%d pathError=%v", pid, before.Status, before.Count, before.Expected, e)
			}
			continue
		}
		if before.Value.Effective != uint32(os.Getuid()) {
			continue
		}
		if ctx.Err() != nil {
			return found, ctx.Err()
		}
		path, e := ops.Path(pid)
		if e != nil {
			if ops.Absent(pid) {
				continue
			}
			return found, fmt.Errorf("residual-path pid=%d error=%v", pid, e)
		}
		if !runnerCleanupCandidate(path, app) {
			continue
		}
		if ctx.Err() != nil {
			return found, ctx.Err()
		}
		args, tmp, e := ops.Arguments(pid)
		if e != nil {
			if ops.Absent(pid) {
				continue
			}
			return found, fmt.Errorf("residual-argv pid=%d error=%v", pid, e)
		}
		after := ops.BSD(pid)
		if !runnerBSDValid(after, int64(pid)) || !runnerBSDEqual(before.Value, after.Value) {
			if ops.Absent(pid) {
				continue
			}
			return found, fmt.Errorf("residual-incarnation pid=%d before=%v after=%v status=%d count=%d", pid, before.Value, after.Value, after.Status, after.Count)
		}
		if runnerRootAssociated(args, tmp, roots) {
			found = append(found, pid)
		}
	}
	return found, nil
}

func runnerRootProcesses(ctx context.Context, roots map[string]bool, app string) ([]int, error) {
	if runnerPlacement() != nil {
		return nil, fmt.Errorf("hosted residual discovery required")
	}
	ops := runnerRootDiscoveryOps{BSD: func(pid int) runnerBSDRead { return runnerBSDSystemRead(int64(pid)) }, Path: runnerProcessPath, Arguments: runnerProcArguments, Absent: runnerPIDAbsent}
	ops.List = func() ([]int, error) {
		lib, e := purego.Dlopen("/usr/lib/libproc.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
		if e != nil {
			return nil, e
		}
		defer purego.Dlclose(lib)
		var all func(*int32, int32) int32
		purego.RegisterLibFunc(&all, lib, "proc_listallpids")
		raw := make([]int32, 4096)
		n := all(&raw[0], int32(len(raw)*4))
		if n < 1 || n >= int32(len(raw)) {
			return nil, fmt.Errorf("residual process list exceeded bound")
		}
		pids := make([]int, n)
		for i, pid := range raw[:n] {
			pids[i] = int(pid)
		}
		return pids, nil
	}
	return runnerRootProcessesWith(ctx, roots, app, ops)
}

func runnerCleanupCandidate(path, app string) bool {
	contents := filepath.Dir(filepath.Dir(app))
	return path == app || path == filepath.Join(contents, "Resources/slicc") || path == filepath.Join(contents, "Helpers/ScreenProofSurface.app/Contents/MacOS/ScreenProofSurface") || strings.HasPrefix(path, "/Applications/Google Chrome.app/")
}

func runnerPIDAbsent(pid int) bool { return pid > 0 && unix.Kill(pid, runnerExistenceProbe) == unix.ESRCH }

type runnerObserverAccess struct {
	PID                            int   `json:"pid"`
	ScreenCapturePreflight         *bool `json:"screenCapturePreflight"`
	ResponsiblePID                 *int  `json:"responsiblePID"`
	ResponsibilityEstablished      bool  `json:"responsibilityEstablished"`
	PermissionInferredFromAncestry bool  `json:"permissionInferredFromAncestry"`
}

func readRunnerObserverAccess() (result runnerObserverAccess) {
	result.PID = os.Getpid()
	if runnerPlacement() != nil {
		return result
	}
	defer func() {
		if recover() != nil {
			result.ScreenCapturePreflight = nil
		}
	}()
	lib, e := purego.Dlopen("/System/Library/Frameworks/CoreGraphics.framework/CoreGraphics", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return result
	}
	defer purego.Dlclose(lib)
	var preflight func() bool
	purego.RegisterLibFunc(&preflight, lib, "CGPreflightScreenCaptureAccess")
	value := preflight()
	result.ScreenCapturePreflight = &value
	return result
}

const runnerExistenceProbe unix.Signal = 0
