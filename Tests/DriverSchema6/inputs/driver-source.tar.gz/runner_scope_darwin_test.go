package integration

import "testing"

func runnerApplyAuthorizationPurpose(result *runnerCaseResult) {
	if result.Case != "authorization-exclusion" { return }
	if result.Coverage == nil { result.Coverage = map[string]string{} }
	result.Coverage["independent authorization purpose"] = "FAILED_TO_DEMONSTRATE"
	if result.Result == "PASS" {
		result.Result = "FAILED_TO_DEMONSTRATE"
		result.Limitations = append(result.Limitations,"no independently verified authorization purpose; temporal/requester/window correlation has no purpose authority")
	}
}

func runnerDirectOwnedWindowsGone(windows []independentWindow,processes map[int]runnerProcessFact) bool {
	for _,window:=range windows {
		fact,known:=processes[window.PID]
		if !known { continue }
		if runnerOneOf(fact.Label,"app allowed cli authorization-requester chrome-a-1 chrome-a-2 chrome-b-1 chrome-b-2") { return false }
	}
	return true
}

func TestRunnerAuthorizationPurposeDoesNotPromoteTemporalEvidenceOrBlockCleanCases(t *testing.T) {
	result:=runnerCaseResult{Case:"authorization-exclusion",Result:"PASS",AppPID:42,DirectChildrenGone:true,RootsRemoved:true,AppReaped:true,OwnedWindowsGone:true,MetadataReaderSettled:true}
	runnerApplyAuthorizationPurpose(&result)
	if result.Result!="FAILED_TO_DEMONSTRATE"||len(result.Limitations)!=1||runnerBlocksLaterCases(result){t.Fatal("ASSERTION:purpose-unavailable-independent-cases")}
	result.Result="FAIL";runnerApplyAuthorizationPurpose(&result)
	if result.Result!="FAIL"{t.Fatal("ASSERTION:purpose-does-not-hide-failure")}
	ordinary:=runnerCaseResult{Case:"selected-window",Result:"PASS"};runnerApplyAuthorizationPurpose(&ordinary)
	if ordinary.Result!="PASS"{t.Fatal("ASSERTION:purpose-does-not-change-other-cases")}
}

func TestRunnerCleanupDoesNotClaimProtectedSystemWindowsAreOwned(t *testing.T) {
	processes:=map[int]runnerProcessFact{10:{Label:"allowed"},11:{Label:"app"},12:{Label:"chrome-a-1"},13:{Label:"authorization"},14:{Label:"system"}}
	protected:=[]independentWindow{{ID:1,PID:13},{ID:2,PID:14}}
	if !runnerDirectOwnedWindowsGone(protected,processes){t.Fatal("ASSERTION:protected-window-not-owned-cleanup")}
	for _,pid:=range []int{10,11,12}{post:=append(append([]independentWindow(nil),protected...),independentWindow{ID:99,PID:pid});if runnerDirectOwnedWindowsGone(post,processes){t.Fatal("ASSERTION:owned-window-remains",pid)}}
}
