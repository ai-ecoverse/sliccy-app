package integration

import (
	"context"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strconv"
	"testing"
	"time"
)

func TestRunnerControllerObserverReturnsWithHeldNativeCallAndNoInferredCleanup(t *testing.T) {
	deadline := time.Now().Add(40 * time.Millisecond)
	observer := newRunnerControllerObserver(context.Background(), deadline)
	entered, release := make(chan struct{}), make(chan struct{})
	defer close(release)
	if err := observer.Submit("held-CG", func(ctx context.Context, trace *runnerNativeTrace) (any, error) {
		id, ok := trace.Begin("CGWindowListCopyWindowInfo", 42, 0)
		if !ok {
			return nil, fmt.Errorf("trace begin")
		}
		close(entered)
		<-release
		trace.End(id, nil, true)
		return 7, nil
	}); err != nil {
		t.Fatal(err)
	}
	select {
	case <-entered:
	case <-time.After(time.Second):
		t.Fatal("query did not enter")
	}
	start := time.Now()
	_, err := observer.Wait([]string{"held-CG"}, time.Second)
	if err == nil || time.Since(start) > time.Second {
		t.Fatal("ASSERTION:controller-native-absolute-bound")
	}
	evidence := observer.Finish()
	if evidence.Settled || evidence.Pending["held-CG"] != 1 || len(evidence.Phases["held-CG"]) != 1 || evidence.Phases["held-CG"][0].Phase != "entered" {
		t.Fatal("ASSERTION:controller-native-unconfirmed")
	}
	result := runnerCaseResult{NativeEvidence: evidence, NativeObservationSettled: evidence.Settled}
	if !runnerBlocksLaterCases(result) {
		t.Fatal("ASSERTION:controller-unsettled-blocks-later-cases")
	}
}

func runnerPresenceFixture() (map[int]runnerProcessFact, []independentWindow) {
	labels := []string{"app", "allowed", "chrome-a-1", "chrome-a-2", "chrome-b-1", "chrome-b-2"}
	rects := []independentRect{{64, 512, 320, 128}, {128, 128, 256, 256}}
	for _, page := range fixedProofPageCatalog {
		rects = append(rects, page.Rect)
	}
	processes := map[int]runnerProcessFact{}
	windows := []independentWindow{}
	for i, label := range labels {
		pid := 100 + i
		fact := runnerProcessFact{Label: label, Identity: runnerBSDValue{PID: int64(pid)}}
		fact.Code.Binding.Bound = true
		processes[pid] = fact
		windows = append(windows, independentWindow{ID: uint32(i + 1), PID: pid, Rect: rects[i], OnScreen: true, Layer: 0})
	}
	return processes, windows
}

func TestRunnerControllerFixturePresenceUsesPIDBoundsAndNoTitleAuthority(t *testing.T) {
	for _, name := range []string{"valid-no-titles", "wrong-pid", "wrong-bounds", "ambiguous-bounds", "extra-Chrome-window", "missing-profile", "wrong-layer", "off-screen", "unbound-owner", "duplicate-role"} {
		t.Run(name, func(t *testing.T) {
			processes, windows := runnerPresenceFixture()
			switch name {
			case "wrong-pid":
				windows[2].PID = 999
			case "wrong-bounds":
				windows[2].Rect.Width++
			case "ambiguous-bounds":
				copy := windows[2]
				copy.ID = 99
				windows = append(windows, copy)
			case "extra-Chrome-window":
				copy := windows[2]
				copy.ID = 99
				copy.Rect.X++
				windows = append(windows, copy)
			case "missing-profile":
				delete(processes, 105)
			case "wrong-layer":
				windows[2].Layer = 1
			case "off-screen":
				windows[2].OnScreen = false
			case "unbound-owner":
				fact := processes[102]
				fact.Code.Binding.Bound = false
				processes[102] = fact
			case "duplicate-role":
				fact := processes[102]
				fact.Identity.PID = 999
				processes[999] = fact
			}
			err := runnerFixturePresence("display-exclusion", processes, windows)
			if name == "valid-no-titles" {
				if err != nil {
					t.Fatalf("ASSERTION:controller-presence-no-title %v", err)
				}
			} else if err == nil {
				t.Fatalf("ASSERTION:controller-presence-%s", name)
			}
		})
	}
}

func TestRunnerControllerWindowRecheckIgnoresDiagnosticTitleButNoIdentityField(t *testing.T) {
	_, original := runnerPresenceFixture()
	for _, name := range []string{"title", "pid", "bounds", "layer", "on-screen", "extra", "duplicate"} {
		t.Run(name, func(t *testing.T) {
			changed := append([]independentWindow(nil), original...)
			switch name {
			case "title":
				changed[0].Title = "diagnostic changed"
			case "pid":
				changed[0].PID++
			case "bounds":
				changed[0].Rect.X++
			case "layer":
				changed[0].Layer++
			case "on-screen":
				changed[0].OnScreen = false
			case "extra":
				changed = append(changed, independentWindow{ID: 99})
			case "duplicate":
				changed[1] = changed[0]
			}
			if runnerWindowSetsEqual(original, changed) != (name == "title") {
				t.Fatalf("ASSERTION:controller-window-set-%s", name)
			}
		})
	}
}

func TestRunnerControllerOriginalOwnedRecordBindsStartRoleAndHash(t *testing.T) {
	spec := runnerIdentitySpec{PID: 42, Parent: 70, Label: "allowed", Role: "ai.sliccy.proof-helper", App: "/fixture/Sliccy.app/Contents/MacOS/Sliccy"}
	_, fixture := runnerFakeIdentityOps(spec)
	fact := *fixture
	fact.Code.Binding.Kernel.Hash = [20]byte{1}
	for _, name := range []string{"valid", "pid", "parent", "uid", "startSeconds", "startMicroseconds", "cdHash", "role", "unowned"} {
		t.Run(name, func(t *testing.T) {
			fields := map[string]any{"pid": 42, "parent": 70, "uid": fact.Identity.Effective, "startSeconds": "100", "startMicroseconds": 1, "cdHash": "0100000000000000000000000000000000000000", "role": "surface"}
			local := fact
			switch name {
			case "pid":
				fields[name] = 43
			case "parent":
				fields[name] = 71
			case "uid":
				fields[name] = fact.Identity.Effective + 1
			case "startSeconds":
				fields[name] = "101"
			case "startMicroseconds":
				fields[name] = 2
			case "cdHash":
				fields[name] = "0200000000000000000000000000000000000000"
			case "role":
				fields[name] = "chrome"
			case "unowned":
				local.Owned = false
			}
			row := runnerCaptureRow{Stage: "owned-process-recorded", Fields: map[string]json.RawMessage{}}
			for key, value := range fields {
				row.Fields[key] = runnerUnionJSON(value)
			}
			err := matchRunnerOwnedRecord(row, local)
			if name == "valid" {
				if err != nil {
					t.Fatalf("ASSERTION:controller-original-positive %v", err)
				}
			} else if err == nil {
				t.Fatalf("ASSERTION:controller-original-%s", name)
			}
		})
	}
}

func TestRunnerControllerReceiptCoverageRequiresEveryCLIStream(t *testing.T) {
	identity := runnerBSDValue{PID: 42, Parent: 70, Effective: 501, Real: 501, Saved: 501, Seconds: 20, Microseconds: 1}
	hash, _ := hex.DecodeString("5da1a3199bd3f895bce2e53023c28ca1c33d249e")
	member := runnerSliceMember{CPU: 16777228, Subtype: 0, Size: 4096, Type: 2, Hash: hash, Full: append(append([]byte(nil), hash...), make([]byte, 12)...)}
	process := runnerProcessFact{Label: "cli", Bundle: "ai.sliccy.slicc", Identity: identity, Owned: true}
	process.Code.Binding.Bound = true
	process.Code.Binding.Selected = member
	sample := func(pid, parent int64) []any { return []any{pid, parent, 501, 501, 501, "20", 1} }
	bracket := func(v []any) []any { return []any{[]any{0, 648, 648, v}, []any{0, 136, 136, v}, []any{0, 648, 648, v}} }
	raw, _ := json.Marshal([]any{70, 69, bracket(sample(70, 69)), bracket(sample(69, 1)), bracket(sample(42, 70))})
	incarnation := []string{"42", "70", "501", "501", "501", "20", "1", "proc", string(raw)}
	for _, missing := range []string{"none", "initial-live", "signal", "child-initial", "child-signal", "start-mismatch", "slice-mismatch", "refused"} {
		t.Run(missing, func(t *testing.T) {
			book := runnerReceiptBook{Entries: map[string]runnerReceiptEntry{}}
			for i, site := range []string{"initial-live", "signal", "child-initial", "child-signal"} {
				if site == missing {
					continue
				}
				code := &runnerCodeReceipt{Role: process.Bundle, PID: 42, Site: site, Passed: true, Selected: &member, Compared: map[string]json.RawMessage{"incarnationBefore": runnerUnionJSON(incarnation)}}
				if site == "child-initial" || site == "child-signal" {
					code.Selected = nil
					code.Compared = map[string]json.RawMessage{"incarnation": runnerUnionJSON([]any{42, 70, 501, "20", "1"})}
				}
				if missing == "start-mismatch" && site == "initial-live" {
					changed := append([]string(nil), incarnation...)
					changed[5] = "21"
					code.Compared["incarnationBefore"] = runnerUnionJSON(changed)
				}
				if missing == "slice-mismatch" && site == "initial-live" {
					changed := member
					changed.Subtype = 2
					code.Selected = &changed
				}
				if missing == "refused" && site == "child-signal" {
					code.Passed = false
				}
				book.Entries[strconv.Itoa(i)] = runnerReceiptEntry{Receipt: runnerReceipt{Code: code}}
			}
			err := runnerValidateCaseReceipts(book, map[int]runnerProcessFact{42: process})
			if missing == "none" {
				if err != nil {
					t.Fatalf("ASSERTION:controller-cli-coverage-positive %v", err)
				}
			} else if err == nil {
				t.Fatalf("ASSERTION:controller-cli-coverage-%s", missing)
			}
		})
	}
}

func TestRunnerControllerPartialIdentityBatchRetainsOnlyAcceptedRoots(t *testing.T) {
	observer := newRunnerControllerObserver(context.Background(), time.Now().Add(time.Second))
	defer observer.Finish()
	good := runnerProcessFact{Label: "allowed", Identity: runnerBSDValue{PID: 42}, Root: "/owned/good", Owned: true}
	good.Code.Binding.Bound = true
	refused := runnerProcessFact{Label: "chrome-a-1", Identity: runnerBSDValue{PID: 43}, Root: "/owned/refused", Owned: true}
	refused.Code.Binding.Bound = true
	if err := observer.Submit("good", func(context.Context, *runnerNativeTrace) (any, error) { return good, nil }); err != nil {
		t.Fatal(err)
	}
	if err := observer.Submit("refused", func(context.Context, *runnerNativeTrace) (any, error) {
		return refused, fmt.Errorf("ownership fixture refusal")
	}); err != nil {
		t.Fatal(err)
	}
	select {
	case <-time.After(time.Second):
		t.Fatal("fixture setup deadline")
	case <-func() <-chan struct{} {
		done := make(chan struct{})
		go func() {
			defer close(done)
			for _, key := range []string{"good", "refused"} {
				for {
					if _, settled := observer.pool.Result(key); settled {
						break
					}
					select {
					case <-observer.pool.wake:
					case <-observer.pool.ctx.Done():
						return
					}
				}
			}
		}()
		return done
	}():
	}
	processes := map[int]runnerProcessFact{}
	roots := map[string]bool{}
	registered := []int{}
	err := runnerCollectIdentityResults(observer, map[int]string{42: "good", 43: "refused"}, processes, roots, func(fact runnerProcessFact) error {
		registered = append(registered, int(fact.Identity.PID))
		return nil
	})
	if err == nil || len(processes) != 1 || processes[42].Label != "allowed" || !roots["/owned/good"] || roots["/owned/refused"] || len(registered) != 1 || registered[0] != 42 {
		t.Fatal("ASSERTION:controller-partial-ownership-retention")
	}
}
