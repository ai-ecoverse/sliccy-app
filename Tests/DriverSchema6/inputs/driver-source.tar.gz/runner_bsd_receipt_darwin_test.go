package integration

import (
	"encoding/json"
	"fmt"
	"math"
	"strconv"
	"testing"
)

type runnerBSDValue struct {
	PID, Parent            int64
	Effective, Real, Saved uint32
	Seconds                uint64
	Microseconds           uint64
}

type runnerBSDRead struct {
	Executed        bool
	NativeReturn    int32
	Errno           int32
	Status          int64
	Count, Expected int64
	Value           *runnerBSDValue
}

type runnerBSDBracket [3]runnerBSDRead

type runnerBSDReceipt struct {
	Role, Phase                     string
	PID, Status, SelfPID, ParentPID int64
	Controls                        [2]runnerBSDBracket
	Target                          runnerBSDBracket
	Accepted                        bool
	UsedSysctl, ControlsAgreed      *bool
	Selected                        *runnerBSDValue
}

func runnerRawInteger(raw json.RawMessage, low, high int64) (int64, error) {
	var n int64
	if string(raw) == "null" || json.Unmarshal(raw, &n) != nil || n < low || n > high {
		return 0, fmt.Errorf("invalid bounded integer")
	}
	return n, nil
}

func runnerRawArray(raw json.RawMessage, count int) ([]json.RawMessage, error) {
	var values []json.RawMessage
	if json.Unmarshal(raw, &values) != nil || len(values) != count {
		return nil, fmt.Errorf("invalid fixed array")
	}
	return values, nil
}

func runnerDecodeBSDValue(raw json.RawMessage) (*runnerBSDValue, error) {
	if string(raw) == "null" {
		return nil, nil
	}
	a, e := runnerRawArray(raw, 7)
	if e != nil {
		return nil, e
	}
	v := &runnerBSDValue{}
	if v.PID, e = runnerRawInteger(a[0], 0, math.MaxInt32); e != nil {
		return nil, e
	}
	if v.Parent, e = runnerRawInteger(a[1], 0, math.MaxInt32); e != nil {
		return nil, e
	}
	for i, target := range []*uint32{&v.Effective, &v.Real, &v.Saved} {
		n, err := runnerRawInteger(a[i+2], 0, math.MaxUint32)
		if err != nil {
			return nil, err
		}
		*target = uint32(n)
	}
	var seconds string
	if json.Unmarshal(a[5], &seconds) != nil || !captureCanonical(seconds) {
		return nil, fmt.Errorf("invalid BSD seconds")
	}
	if json.Unmarshal([]byte(seconds), &v.Seconds) != nil {
		return nil, fmt.Errorf("invalid BSD seconds range")
	}
	n, e := runnerRawInteger(a[6], 0, 999999)
	if e != nil {
		return nil, e
	}
	v.Microseconds = uint64(n)
	return v, nil
}

func runnerDecodeBSDRead(raw json.RawMessage) (runnerBSDRead, error) {
	var r runnerBSDRead
	a, e := runnerRawArray(raw, 4)
	if e != nil {
		return r, e
	}
	if r.Status, e = runnerRawInteger(a[0], math.MinInt32, math.MaxInt32); e != nil {
		return r, e
	}
	if r.Count, e = runnerRawInteger(a[1], 0, 4096); e != nil {
		return r, e
	}
	if r.Expected, e = runnerRawInteger(a[2], 0, 4096); e != nil {
		return r, e
	}
	if r.Value, e = runnerDecodeBSDValue(a[3]); e != nil {
		return r, e
	}
	if (r.Value != nil) != (r.Status == 0 && r.Count == r.Expected) {
		return r, fmt.Errorf("BSD availability disagrees with status/size")
	}
	return r, nil
}

func runnerDecodeBSDBracket(raw json.RawMessage) (runnerBSDBracket, error) {
	var b runnerBSDBracket
	a, e := runnerRawArray(raw, 3)
	if e != nil {
		return b, e
	}
	for i := range b {
		if b[i], e = runnerDecodeBSDRead(a[i]); e != nil {
			return b, e
		}
	}
	return b, nil
}

func runnerBSDValid(r runnerBSDRead, pid int64) bool {
	return pid > 0 && pid <= math.MaxInt32 && r.Status == 0 && r.Expected > 0 && r.Count == r.Expected && r.Value != nil && r.Value.PID == pid && r.Value.Parent >= 0 && r.Value.Parent <= math.MaxInt32 && r.Value.Seconds > 0 && r.Value.Microseconds < 1000000
}

func runnerBSDEqual(a, b *runnerBSDValue) bool { return a != nil && b != nil && *a == *b }

func runnerBSDControl(b runnerBSDBracket, pid int64) bool {
	return runnerBSDValid(b[0], pid) && runnerBSDValid(b[1], pid) && runnerBSDValid(b[2], pid) && runnerBSDEqual(b[0].Value, b[1].Value) && runnerBSDEqual(b[1].Value, b[2].Value)
}

func runnerBSDControls(r runnerBSDReceipt) bool {
	return r.SelfPID > 0 && r.ParentPID > 0 && r.SelfPID != r.ParentPID && runnerBSDControl(r.Controls[0], r.SelfPID) && runnerBSDControl(r.Controls[1], r.ParentPID) && r.Controls[0][1].Value.Parent == r.ParentPID
}

func runnerBSDSelect(r runnerBSDReceipt) (*runnerBSDValue, bool) {
	b := r.Target
	if r.Status != 0 || !runnerBSDValid(b[0], r.PID) || !runnerBSDValid(b[2], r.PID) || !runnerBSDEqual(b[0].Value, b[2].Value) {
		return nil, false
	}
	if b[1].Status == 0 {
		if !runnerBSDValid(b[1], r.PID) || !runnerBSDEqual(b[0].Value, b[1].Value) {
			return nil, false
		}
		return b[1].Value, false
	}
	if b[1].Status != 1 || b[1].Count != 0 || !runnerBSDControls(r) {
		return nil, false
	}
	return b[0].Value, true
}

func runnerNullableBool(raw json.RawMessage) (*bool, error) {
	if string(raw) == "null" {
		return nil, nil
	}
	var value bool
	if json.Unmarshal(raw, &value) != nil {
		return nil, fmt.Errorf("invalid nullable boolean")
	}
	return &value, nil
}

func decodeRunnerBSDReceipt(fields map[string]json.RawMessage) (runnerBSDReceipt, error) {
	var r runnerBSDReceipt
	var e error
	if r.Role, e = runnerText(fields, "role"); e != nil {
		return r, e
	}
	if !runnerOneOf(r.Role, "com.apple.WindowManager com.apple.dock com.apple.finder com.apple.WindowServer com.apple.SecurityAgent") {
		return r, fmt.Errorf("unknown BSD role")
	}
	if r.Phase, e = runnerText(fields, "phase"); e != nil || !runnerOneOf(r.Phase, "before after") {
		return r, fmt.Errorf("unknown BSD phase")
	}
	if r.PID, e = runnerInt(fields, "pid", 1, math.MaxInt32); e != nil {
		return r, e
	}
	if r.Status, e = runnerInt(fields, "status", math.MinInt32, math.MaxInt32); e != nil {
		return r, e
	}
	if r.SelfPID, e = runnerInt(fields, "selfPID", 0, math.MaxInt32); e != nil {
		return r, e
	}
	if r.ParentPID, e = runnerInt(fields, "parentPID", 0, math.MaxInt32); e != nil {
		return r, e
	}
	controls, e := runnerRawArray(fields["controls"], 2)
	if e != nil {
		return r, e
	}
	for i := range r.Controls {
		if r.Controls[i], e = runnerDecodeBSDBracket(controls[i]); e != nil {
			return r, e
		}
	}
	if r.Target, e = runnerDecodeBSDBracket(fields["target"]); e != nil {
		return r, e
	}
	if r.Accepted, e = runnerBool(fields, "accepted"); e != nil {
		return r, e
	}
	if r.UsedSysctl, e = runnerNullableBool(fields["usedSysctl"]); e != nil {
		return r, e
	}
	if r.ControlsAgreed, e = runnerNullableBool(fields["controlsAgreed"]); e != nil {
		return r, e
	}
	var used bool
	r.Selected, used = runnerBSDSelect(r)
	if r.Accepted != (r.Selected != nil) {
		return r, fmt.Errorf("BSD decision disagrees with raw observations")
	}
	if !r.Accepted {
		if r.UsedSysctl != nil || r.ControlsAgreed != nil {
			return r, fmt.Errorf("refused BSD receipt invents selected metadata")
		}
	} else if r.UsedSysctl == nil || *r.UsedSysctl != used || r.ControlsAgreed == nil || *r.ControlsAgreed != runnerBSDControls(r) {
		return r, fmt.Errorf("BSD selection/control metadata mismatch")
	}
	return r, nil
}

func runnerBSDReceiptPair(before, after runnerBSDReceipt) (*runnerBSDValue, error) {
	if before.Role != after.Role || before.PID != after.PID || before.Phase != "before" || after.Phase != "after" || !before.Accepted || !after.Accepted || !runnerBSDEqual(before.Selected, after.Selected) {
		return nil, fmt.Errorf("unstable or missing BSD identity pair")
	}
	v := before.Selected
	if before.Role == "com.apple.WindowServer" && (!runnerBSDControls(before) || !runnerBSDControls(after) || v.Parent != 1 || v.Effective != 88 || v.Real != 0 || v.Saved != 0) {
		return nil, fmt.Errorf("WindowServer control/credential mismatch")
	}
	return v, nil
}

func TestRunnerBSDReceiptDecisionUsesRawObservations(t *testing.T) {
	value := func(pid, parent int64) *runnerBSDValue {
		return &runnerBSDValue{PID: pid, Parent: parent, Effective: 501, Real: 501, Saved: 501, Seconds: 20, Microseconds: 1}
	}
	bracket := func(v *runnerBSDValue) runnerBSDBracket {
		var b runnerBSDBracket
		for i := range b {
			copy := *v
			b[i] = runnerBSDRead{Expected: 648, Count: 648, Value: &copy}
		}
		b[1].Expected = 136
		b[1].Count = 136
		return b
	}
	makeReceipt := func() runnerBSDReceipt {
		r := runnerBSDReceipt{PID: 42, SelfPID: 70, ParentPID: 69, Role: "com.apple.WindowServer", Phase: "before"}
		r.Controls = [2]runnerBSDBracket{bracket(value(70, 69)), bracket(value(69, 1))}
		v := value(42, 1)
		v.Effective = 88
		v.Real = 0
		v.Saved = 0
		r.Target = bracket(v)
		return r
	}
	r := makeReceipt()
	if v, used := runnerBSDSelect(r); v == nil || used {
		t.Fatal("matching readable proc rejected")
	}
	r.Target[1] = runnerBSDRead{Status: 1, Expected: 136}
	if v, used := runnerBSDSelect(r); v == nil || !used {
		t.Fatal("gated EPERM fallback rejected")
	}
	for i := 0; i < 7; i++ {
		bad := makeReceipt()
		bad.Target[1] = runnerBSDRead{Status: 1, Expected: 136}
		v := bad.Controls[0][1].Value
		switch i {
		case 0:
			v.PID++
		case 1:
			v.Parent++
		case 2:
			v.Effective++
		case 3:
			v.Real++
		case 4:
			v.Saved++
		case 5:
			v.Seconds++
		case 6:
			v.Microseconds++
		}
		if v, _ := runnerBSDSelect(bad); v != nil {
			t.Fatalf("control field %d ignored", i)
		}
	}
	for _, change := range []func(*runnerBSDReceipt){
		func(r *runnerBSDReceipt) { r.Target[1].Count = 1 },
		func(r *runnerBSDReceipt) { r.Target[1].Status = 13 },
		func(r *runnerBSDReceipt) { r.Target[2].Value.Seconds++ },
		func(r *runnerBSDReceipt) { r.Target[2].Value.PID++ },
		func(r *runnerBSDReceipt) { r.Target[0].Value.Seconds = 0; r.Target[2].Value.Seconds = 0 },
		func(r *runnerBSDReceipt) { r.Target[0].Expected = 0 },
	} {
		bad := makeReceipt()
		bad.Target[1] = runnerBSDRead{Status: 1, Expected: 136}
		change(&bad)
		if v, _ := runnerBSDSelect(bad); v != nil {
			t.Fatal("invalid fallback accepted")
		}
	}
	for _, raw := range []string{`[42,1,88,0,0,"20",0]`, `[42,1,88,0,0,"18446744073709551615",999999]`} {
		if _, e := runnerDecodeBSDValue([]byte(raw)); e != nil {
			t.Fatal(e)
		}
	}
	for _, raw := range []string{`[42,1,88,0,0,20,0]`, `[42,1,88,0,0,"020",0]`, `[42,1,88,0,0,"20",1000000]`, `[42,1,true,0,0,"20",0]`, `[42,1,88,0,0,"20",null]`, `[42,1,88,0,0,"20",0,0]`} {
		if _, e := runnerDecodeBSDValue([]byte(raw)); e == nil {
			t.Fatal("malformed BSD value accepted")
		}
	}
}

func TestRunnerBSDReceiptStrictParserRecomputesFlags(t *testing.T) {
	value := func(pid, parent int) []any { return []any{pid, parent, 501, 501, 501, "20", 1} }
	bracket := func(v []any) []any { return []any{[]any{0, 648, 648, v}, []any{0, 136, 136, v}, []any{0, 648, 648, v}} }
	makeFields := func() map[string]json.RawMessage {
		v := map[string]any{"role": "com.apple.dock", "phase": "before", "pid": 42, "status": 0, "selfPID": 70, "parentPID": 69, "controls": []any{bracket(value(70, 69)), bracket(value(69, 1))}, "target": bracket(value(42, 1)), "accepted": true, "usedSysctl": false, "controlsAgreed": true}
		raw, _ := json.Marshal(v)
		var fields map[string]json.RawMessage
		if json.Unmarshal(raw, &fields) != nil {
			t.Fatal("fixture encoding failed")
		}
		return fields
	}
	if r, e := decodeRunnerBSDReceipt(makeFields()); e != nil || !r.Accepted || r.Selected == nil {
		t.Fatal("complete typed receipt rejected", e)
	}
	for _, field := range []string{"accepted", "usedSysctl", "controlsAgreed"} {
		for _, wrong := range []string{"0", "1", "null", `"true"`} {
			f := makeFields()
			f[field] = json.RawMessage(wrong)
			if _, e := decodeRunnerBSDReceipt(f); e == nil {
				t.Fatal("wrong flag type accepted", field, wrong)
			}
		}
	}
	for _, field := range []string{"pid", "selfPID", "parentPID", "status"} {
		f := makeFields()
		f[field] = json.RawMessage("null")
		if _, e := decodeRunnerBSDReceipt(f); e == nil {
			t.Fatal("null integer accepted", field)
		}
	}
	f := makeFields()
	f["accepted"] = json.RawMessage("false")
	if _, e := decodeRunnerBSDReceipt(f); e == nil {
		t.Fatal("invented refusal accepted over matching samples")
	}
	f = makeFields()
	f["status"] = json.RawMessage(strconv.Itoa(1))
	f["accepted"] = json.RawMessage("false")
	f["usedSysctl"] = json.RawMessage("null")
	f["controlsAgreed"] = json.RawMessage("null")
	if r, e := decodeRunnerBSDReceipt(f); e != nil || r.Accepted || r.Selected != nil {
		t.Fatal("typed failed observation was not preserved", e)
	}
}

func TestRunnerBSDRawBoundaryRejectsInvalidPIDParentAndMicroseconds(t *testing.T) {
	for _, name := range []string{"valid", "pid-limit", "negative-parent", "parent-limit", "zero-start", "microseconds"} {
		t.Run(name, func(t *testing.T) {
			pid := int64(42)
			value := runnerBSDValue{PID: pid, Parent: 70, Seconds: 20, Microseconds: 1}
			switch name {
			case "pid-limit":
				pid = math.MaxInt32 + 1
				value.PID = pid
			case "negative-parent":
				value.Parent = -1
			case "parent-limit":
				value.Parent = math.MaxInt32 + 1
			case "zero-start":
				value.Seconds = 0
			case "microseconds":
				value.Microseconds = 1000000
			}
			read := runnerBSDRead{Expected: 648, Count: 648, Value: &value}
			if runnerBSDValid(read, pid) != (name == "valid") {
				t.Fatal("ASSERTION:bsd-raw-bound-" + name)
			}
		})
	}
}
