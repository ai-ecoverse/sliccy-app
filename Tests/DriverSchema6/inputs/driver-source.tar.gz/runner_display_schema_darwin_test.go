package integration

import (
 "encoding/json"
 "fmt"
 "math"
 "strings"
)

const runnerDisplayMilestones = "before-activation-policy after-activation-policy did-finish-launching preflight helper-spawned before-indicator indicator-ordered indicator-placed"

type runnerDisplayDiagnostic struct {
 Stage,Trigger,Status string
 Ordinal,Index,Reported,Retained,Admitted,Completed,Unfinished int
 Requested,Finished float64
 Started *float64
 Overflow bool
}

func runnerDisplayNumber(raw json.RawMessage,nullable,nonnegative bool)(*float64,error) {
 if string(raw)=="null"&&nullable{return nil,nil}
 var n float64
 if string(raw)=="null"||json.Unmarshal(raw,&n)!=nil||math.IsNaN(n)||math.IsInf(n,0)||nonnegative&&n<0{return nil,fmt.Errorf("display diagnostic numeric field")}
 return &n,nil
}

func decodeRunnerDisplayDiagnostic(row runnerCaptureRow)(v runnerDisplayDiagnostic,err error) {
 v.Stage=row.Stage;f:=row.Fields
 base:="schema case capture stage elapsedMs eventElapsedMs"
 integer:=func(key string,low,high int64)(int,error){n,e:=runnerInt(f,key,low,high);return int(n),e}
 switch row.Stage {
 case "display-diagnostic-origin":
  if runnerExactFields(f,strings.Fields(base+" originBeforeJournalMs maximumDisplays maximumNotifications maximumMilestones"))!=nil{return v,fmt.Errorf("display origin fields")}
  if _,err=runnerDisplayNumber(f["originBeforeJournalMs"],false,true);err!=nil{return v,err}
  for key,want:=range map[string]int64{"maximumDisplays":8,"maximumNotifications":16,"maximumMilestones":8}{if _,e:=runnerInt(f,key,want,want);e!=nil{return v,e}}
 case "display-observation":
  if runnerExactNullableFields(f,strings.Fields(base+" ordinal trigger requestedMs startedMs finishedMs status reportedCount retainedCount"),"startedMs reportedCount")!=nil{return v,fmt.Errorf("display observation fields")}
  if v.Ordinal,err=integer("ordinal",1,24);err!=nil{return v,err}
  if v.Trigger,err=runnerText(f,"trigger");err!=nil||!runnerDiagnosticEnum(v.Trigger,runnerDisplayMilestones+" notification"){return v,fmt.Errorf("display trigger enum")}
  if v.Status,err=runnerText(f,"status");err!=nil||!runnerDiagnosticEnum(v.Status,"complete unavailable too-many-displays unfinished"){return v,fmt.Errorf("display status enum")}
  requested,e:=runnerDisplayNumber(f["requestedMs"],false,true);if e!=nil{return v,e};v.Requested=*requested
  v.Started,err=runnerDisplayNumber(f["startedMs"],true,true);if err!=nil{return v,err}
  finished,e:=runnerDisplayNumber(f["finishedMs"],false,true);if e!=nil{return v,e};v.Finished=*finished
  if v.Finished<v.Requested||v.Started!=nil&&(*v.Started<v.Requested||v.Finished<*v.Started){return v,fmt.Errorf("display sample causal interval")}
  if v.Retained,err=integer("retainedCount",0,8);err!=nil{return v,err}
  v.Reported=-1
  if string(f["reportedCount"])!="null"{if v.Reported,err=integer("reportedCount",0,math.MaxInt64);err!=nil{return v,err}}
  if v.Status=="unfinished" {
   if v.Started!=nil||v.Reported!=-1||v.Retained!=0{return v,fmt.Errorf("unfinished display sample has invented observations")}
  } else {
   if v.Started==nil||v.Reported<0{return v,fmt.Errorf("completed display sample lacks actual query")}
   switch v.Status {
   case "complete":if v.Reported<1||v.Reported!=v.Retained{return v,fmt.Errorf("display count mismatch")}
   case "unavailable":if v.Reported!=0||v.Retained!=0{return v,fmt.Errorf("unavailable screen set shape")}
   case "too-many-displays":if v.Reported<=8||v.Retained!=0{return v,fmt.Errorf("display overflow sample shape")}
   }
  }
 case "display-observation-screen":
  if runnerExactNullableFields(f,strings.Fields(base+" ordinal index displayID frame visibleFrame cgBounds scale color colorModel colorComponents colorNameBytes mode"),"displayID cgBounds scale colorModel colorComponents colorNameBytes mode")!=nil{return v,fmt.Errorf("display screen fields")}
  if v.Ordinal,err=integer("ordinal",1,24);err!=nil{return v,err};if v.Index,err=integer("index",0,7);err!=nil{return v,err}
  for key,bounds:=range map[string][2]int64{"displayID":{0,math.MaxUint32},"colorModel":{math.MinInt32,math.MaxInt32},"colorComponents":{0,math.MaxInt64},"colorNameBytes":{0,math.MaxInt64}} {
   if string(f[key])!="null" {if _,e:=runnerInt(f,key,bounds[0],bounds[1]);e!=nil{return v,e}}
  }
  for _,key:=range []string{"frame","visibleFrame","cgBounds"}{if key=="cgBounds"&&string(f[key])=="null"{continue};if _,e:=runnerDiagnosticRectangle(f[key]);e!=nil{return v,e}}
  if _,e:=runnerDisplayNumber(f["scale"],true,false);e!=nil{return v,e}
  color,e:=runnerText(f,"color");if e!=nil||!runnerDiagnosticEnum(color,"srgb display-p3 linear-srgb other unavailable"){return v,fmt.Errorf("display color enum")}
  if string(f["mode"])!="null" {
   m,e:=runnerDiagnosticObject(f["mode"],"id flags width height pixelWidth pixelHeight refreshRate","refreshRate");if e!=nil{return v,e}
   for key,bounds:=range map[string][2]int64{"id":{math.MinInt32,math.MaxInt32},"flags":{0,math.MaxUint32},"width":{0,math.MaxInt64},"height":{0,math.MaxInt64},"pixelWidth":{0,math.MaxInt64},"pixelHeight":{0,math.MaxInt64}} {if _,e:=runnerInt(m,key,bounds[0],bounds[1]);e!=nil{return v,e}}
   if _,e:=runnerDisplayNumber(m["refreshRate"],true,false);e!=nil{return v,e}
  }
 case "display-diagnostic-closed":
  if runnerExactFields(f,strings.Fields(base+" admitted completed unfinished overflow"))!=nil{return v,fmt.Errorf("display close fields")}
  if v.Admitted,err=integer("admitted",0,24);err!=nil{return v,err};if v.Completed,err=integer("completed",0,24);err!=nil{return v,err};if v.Unfinished,err=integer("unfinished",0,24);err!=nil{return v,err}
  if v.Overflow,err=runnerBool(f,"overflow");err!=nil{return v,err}
  if v.Completed+v.Unfinished!=v.Admitted{return v,fmt.Errorf("display closing counts")}
 default:return v,fmt.Errorf("display diagnostic stage")
 }
 return v,nil
}

type runnerDisplayLedger struct {
 Origin,Closed,Overflow bool
 Observations map[int]runnerDisplayDiagnostic
 Screens map[int]int
 Milestones map[string]bool
 Notifications int
}

func (l *runnerDisplayLedger) Add(v runnerDisplayDiagnostic)error {
 if l.Closed{return fmt.Errorf("display diagnostic after close")}
 if v.Stage=="display-diagnostic-origin" {
  if l.Origin{return fmt.Errorf("duplicate display origin")};l.Origin=true
  l.Observations=map[int]runnerDisplayDiagnostic{};l.Screens=map[int]int{};l.Milestones=map[string]bool{};return nil
 }
 if !l.Origin{return fmt.Errorf("display observation before origin")}
 switch v.Stage {
 case "display-observation":
  if l.Observations[v.Ordinal].Ordinal!=0{return fmt.Errorf("duplicate display ordinal")}
  if v.Trigger=="notification"{l.Notifications++;if l.Notifications>16{return fmt.Errorf("display notification overflow")}}else{if l.Milestones[v.Trigger]{return fmt.Errorf("duplicate display milestone")};l.Milestones[v.Trigger]=true}
  l.Observations[v.Ordinal]=v
 case "display-observation-screen":
  parent,exists:=l.Observations[v.Ordinal]
  if !exists||parent.Status!="complete"||v.Index!=l.Screens[v.Ordinal]||v.Index>=parent.Retained{return fmt.Errorf("display screen ordering/count")}
  l.Screens[v.Ordinal]++
 case "display-diagnostic-closed":
  if len(l.Observations)!=v.Admitted{return fmt.Errorf("display observation missing at close")}
  done,unfinished:=0,0
  for i:=1;i<=v.Admitted;i++ {
   value,exists:=l.Observations[i];if !exists||l.Screens[i]!=value.Retained{return fmt.Errorf("display retained observation incomplete")}
   if value.Status=="unfinished"{unfinished++}else{done++}
   if value.Status=="too-many-displays"&&!v.Overflow{return fmt.Errorf("display overflow not latched")}
  }
  if done!=v.Completed||unfinished!=v.Unfinished{return fmt.Errorf("display completion ledger mismatch")}
  l.Closed=true;l.Overflow=v.Overflow
 default:return fmt.Errorf("unknown display ledger stage")
 }
 return nil
}

func (l *runnerDisplayLedger) Complete()error {
 if !l.Origin||!l.Closed||l.Overflow{return fmt.Errorf("display diagnostics incomplete")}
 for _,v:=range l.Observations{if v.Status=="unfinished"||v.Status=="too-many-displays"{return fmt.Errorf("display observation incomplete")}}
 for _,name:=range strings.Fields(runnerDisplayMilestones){if !l.Milestones[name]{return fmt.Errorf("display startup milestone missing")}}
 return nil
}
