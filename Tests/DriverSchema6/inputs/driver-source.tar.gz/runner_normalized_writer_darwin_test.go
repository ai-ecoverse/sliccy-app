package integration

import (
 "context"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "hash"
 "io"
 "os"
 "path/filepath"
 "sync"
 "strings"
)

const runnerNormalizationStorageLimit = 48 << 20
const runnerNormalizationMemoryLimit = 32 << 20

type runnerNormalizationBudget struct {
 mu sync.Mutex
 Bytes,Memory,PeakMemory int64
}
func (b *runnerNormalizationBudget) reserveBytes(n int64)bool {
 b.mu.Lock();defer b.mu.Unlock()
 if n<0||n>runnerNormalizationStorageLimit-b.Bytes{return false};b.Bytes+=n;return true
}
func (b *runnerNormalizationBudget) reserveMemory(n int64)bool {
 b.mu.Lock();defer b.mu.Unlock()
 if n<0||n>runnerNormalizationMemoryLimit-b.Memory{return false};b.Memory+=n;if b.Memory>b.PeakMemory{b.PeakMemory=b.Memory};return true
}
func (b *runnerNormalizationBudget) releaseMemory(n int64){b.mu.Lock();defer b.mu.Unlock();b.Memory-=n;if b.Memory<0{panic("normalization memory accounting")}}

type runnerTraceReceipt struct {
 FirstRecord uint64 `json:"firstRecord"`
 LastRecord uint64 `json:"lastRecord"`
 Rows int `json:"rows"`
 Lost bool `json:"lost"`
 Pending int `json:"pending"`
 PrefixSHA256 string `json:"prefixSHA256"`
}
type runnerCaseEvidenceIndex struct {
 Schema int `json:"schema"`
 NormalizationVersion int `json:"normalizationVersion"`
 Case string `json:"case"`
 Path string `json:"path"`
 Bytes int64 `json:"bytes"`
 SHA256 string `json:"sha256"`
 Records uint64 `json:"records"`
 Jobs int `json:"jobs"`
 Snapshots int `json:"snapshots"`
 Owners int `json:"owners"`
 Phases int `json:"phases"`
 Failures []string `json:"failures"`
 EvidenceUnavailable bool `json:"evidenceUnavailable"`
 UnavailableReasons []string `json:"unavailableReasons"`
 BlockLaterCases bool `json:"blockLaterCases"`
 EvidenceComplete bool `json:"evidenceComplete"`
 Result string `json:"result"`
 NativeObservationSettled bool `json:"nativeObservationSettled"`
 DirectChildrenGone bool `json:"directChildrenGone"`
 RootsRemoved bool `json:"rootsRemoved"`
 ProtocolWorkersSettled bool `json:"protocolWorkersSettled"`
}

type runnerCaseEvidenceWriter struct {
 mu sync.Mutex
 file io.WriteCloser
 digest hash.Hash
 budget *runnerNormalizationBudget
 selected,path string
 seq uint64
 bytes int64
 operations map[string]int
 operationBytes int64
 operationPayload int64
 jobs map[string]runnerTraceReceipt
 snapshots map[int]uint64
 phases,owners int
 closed bool
 problem error
}

func newRunnerCaseEvidenceWriter(directory,selected,manifest,driver string,budget *runnerNormalizationBudget)(*runnerCaseEvidenceWriter,error) {
 if !runnerDiagnosticEnum(selected,"selected-window display-exclusion authorization-exclusion reciprocal-revoke active-stop hotkey-stop")||budget==nil{return nil,fmt.Errorf("normalization fixed case")}
 if !budget.reserveMemory(128<<10){return nil,fmt.Errorf("normalization fixed metadata reservation bound")}
 file,e:=os.OpenFile(filepath.Join(directory,"driver-evidence.v2.ndjson"),os.O_WRONLY|os.O_CREATE|os.O_EXCL,0600);if e!=nil{budget.releaseMemory(128<<10);return nil,e}
 writer:=&runnerCaseEvidenceWriter{file:file,digest:sha256.New(),budget:budget,selected:selected,path:selected+"/driver-evidence.v2.ndjson",operations:map[string]int{},jobs:map[string]runnerTraceReceipt{},snapshots:map[int]uint64{}}
 if e=writer.record("header",map[string]any{"case":selected,"version":2,"manifestSHA256":manifest,"driverSourceSHA256":driver});e!=nil{file.Close();budget.releaseMemory(128<<10);return nil,e}
 return writer,nil
}

func (w *runnerCaseEvidenceWriter) record(tag string,fields map[string]any)error {
 if w.problem!=nil{return w.problem};if w.closed{return fmt.Errorf("normalization writer closed")}
 fields["tag"]=tag;fields["sequence"]=w.seq+1
 if e:=runnerNormalizationJSONReservation(fields);e!=nil{w.problem=e;return e}
 if !w.budget.reserveMemory(4<<20){w.problem=fmt.Errorf("normalization record reservation bound");return w.problem}
 defer w.budget.releaseMemory(4<<20)
 raw,e:=json.Marshal(fields);if e!=nil{w.problem=e;return e};raw=append(raw,'\n')
 if len(raw)>1<<20{w.problem=fmt.Errorf("normalization record bound");return w.problem}
 if !w.budget.reserveBytes(int64(len(raw))){w.problem=fmt.Errorf("normalization storage overflow");return w.problem}
 n,e:=w.file.Write(raw)
 if n>0{w.digest.Write(raw[:n]);w.bytes+=int64(n)}
 if e!=nil||n!=len(raw){w.problem=fmt.Errorf("normalization sink short write");return w.problem}
 w.seq++
 return nil
}
func (w *runnerCaseEvidenceWriter) operation(value string)(int,error) {
 if id,exists:=w.operations[value];exists{return id,nil}
 if value==""||len(value)>256||len(w.operations)>=4096||w.operationPayload+int64(len(value))>1<<20{return 0,fmt.Errorf("normalization operation table bound")}
 charge:=int64(len(value)+64)
 if !w.budget.reserveMemory(charge){return 0,fmt.Errorf("normalization operation memory bound")}
 id:=len(w.operations)+1
 if e:=w.record("operation",map[string]any{"id":id,"value":value});e!=nil{w.budget.releaseMemory(charge);return 0,e}
 w.operations[value]=id;w.operationBytes+=charge;w.operationPayload+=int64(len(value))
 return id,nil
}

func (w *runnerCaseEvidenceWriter) writeSnapshot(snapshot runnerDiagnosticSnapshot)error {
 if snapshot.Sequence<1||snapshot.Sequence>78||w.snapshots[snapshot.Sequence]!=0||len(snapshot.Owners)>128||len(snapshot.Windows)>512{return fmt.Errorf("normalization snapshot cardinality")}
 if !w.budget.reserveMemory(4<<20){return fmt.Errorf("normalization snapshot encoder reservation bound")};defer w.budget.releaseMemory(4<<20)
 first:=w.seq+1
 for i,owner:=range snapshot.Owners {
  if e:=runnerNormalizationJSONReservation(owner);e!=nil{return e}
  raw,e:=runnerEncodeInlineOwner(owner);if e!=nil{return e}
  if e=w.record("owner",map[string]any{"snapshot":snapshot.Sequence,"index":i,"value":raw});e!=nil{return e};w.owners++
 }
 metadata:=snapshot;metadata.Owners=nil
 if e:=w.record("snapshot",map[string]any{"snapshot":snapshot.Sequence,"ownerFirstRecord":first,"ownerCount":len(snapshot.Owners),"ownersNil":snapshot.Owners==nil,"value":metadata});e!=nil{return e}
 w.snapshots[snapshot.Sequence]=w.seq
 return nil
}

func (w *runnerCaseEvidenceWriter) WriteJob(ctx context.Context,key string,trace *runnerNativeTrace,snapshot *runnerDiagnosticSnapshot)(runnerTraceReceipt,error) {
 w.mu.Lock();defer w.mu.Unlock()
 var receipt runnerTraceReceipt
 if w.closed||w.problem!=nil||w.jobs[key].FirstRecord!=0||key==""||len(key)>256{return receipt,fmt.Errorf("normalization job admission")}
 rows,lost,pending:=trace.Snapshot()
 class:="ordinary";if trace.capacity==runnerSnapshotTraceRows{class="snapshot"}
 return w.writeJobLocked(ctx,key,rows,lost,pending,class,snapshot)
}

func (w *runnerCaseEvidenceWriter) writeJobLocked(ctx context.Context,key string,rows []runnerNativePhase,lost bool,pending int,class string,snapshot *runnerDiagnosticSnapshot)(runnerTraceReceipt,error) {
 var receipt runnerTraceReceipt
 limit:=runnerOrdinaryTraceRows;if class=="snapshot"{limit=runnerSnapshotTraceRows}
 if len(w.jobs)>=256||w.jobs[key].FirstRecord!=0||key==""||len(key)>256||len(rows)>limit||pending<0||pending>len(rows)||class!="ordinary"&&class!="snapshot"{return receipt,fmt.Errorf("normalization job count/class bound")}
 const stagingReservation = 512<<10
 if !w.budget.reserveMemory(stagingReservation){w.problem=fmt.Errorf("normalization active job memory bound");return receipt,w.problem};defer w.budget.releaseMemory(stagingReservation)
 receipt=runnerTraceReceipt{FirstRecord:w.seq+1,Rows:len(rows),Lost:lost,Pending:pending}
 snapshotID:=0;if snapshot!=nil{snapshotID=snapshot.Sequence}
  if e:=w.record("job-begin",map[string]any{"key":key,"class":class,"rows":len(rows),"lost":lost,"pending":pending,"rowsNil":rows==nil,"snapshotSequence":snapshotID});e!=nil{return receipt,e}
 for first:=0;first<len(rows);first+=256 {
  if e:=ctx.Err();e!=nil{w.problem=fmt.Errorf("normalization job deadline");return receipt,w.problem}
  end:=min(first+256,len(rows));tuples:=make([][]any,0,end-first)
  for _,row:=range rows[first:end]{id,e:=w.operation(row.Operation);if e!=nil{w.problem=e;return receipt,e};tuple,e:=runnerPhaseTuple(row,id);if e!=nil{w.problem=e;return receipt,e};tuples=append(tuples,tuple)}
  if e:=w.record("phase-chunk",map[string]any{"key":key,"chunk":first/256,"firstRow":first,"rowCount":end-first,"rows":tuples});e!=nil{return receipt,e};w.phases+=end-first
 }
 if e:=ctx.Err();e!=nil{w.problem=fmt.Errorf("normalization job deadline");return receipt,w.problem}
 if snapshot!=nil{if e:=w.writeSnapshot(*snapshot);e!=nil{w.problem=e;return receipt,e}}
 if e:=ctx.Err();e!=nil{w.problem=fmt.Errorf("normalization sink deadline");return receipt,w.problem}
 receipt.LastRecord=w.seq;receipt.PrefixSHA256=hex.EncodeToString(w.digest.Sum(nil));w.jobs[key]=receipt
 return receipt,nil
}

func (w *runnerCaseEvidenceWriter) index(result runnerCaseResult,complete bool)runnerCaseEvidenceIndex {
 return runnerCaseEvidenceIndex{Schema:2,NormalizationVersion:2,Case:w.selected,Path:w.path,Bytes:w.bytes,SHA256:hex.EncodeToString(w.digest.Sum(nil)),Records:w.seq,Jobs:len(w.jobs),Snapshots:len(w.snapshots),Owners:w.owners,Phases:w.phases,EvidenceComplete:complete,Result:result.Result,NativeObservationSettled:result.NativeObservationSettled,DirectChildrenGone:result.DirectChildrenGone,RootsRemoved:result.RootsRemoved,ProtocolWorkersSettled:result.ProtocolWorkersSettled,Failures:runnerCloneStrings(result.Failures),EvidenceUnavailable:result.EvidenceUnavailable,UnavailableReasons:runnerCloneStrings(result.UnavailableReasons),BlockLaterCases:runnerBlocksLaterCases(result)}
}

func (w *runnerCaseEvidenceWriter) Commit(result runnerCaseResult)(runnerCaseEvidenceIndex,error) {
 if !w.mu.TryLock(){return runnerCaseEvidenceIndex{Schema:2,NormalizationVersion:2,Case:w.selected,Path:w.path,Result:"FAIL"},fmt.Errorf("normalization writer still active")}
 defer w.mu.Unlock()
 if w.closed{return w.index(result,false),fmt.Errorf("normalization writer closed")}
 defer func(){if !w.closed{w.file.Close()};w.closed=true;w.budget.releaseMemory(w.operationBytes+(128<<10));w.operations=nil}()
 if w.problem!=nil{return w.index(result,false),fmt.Errorf("normalization writer incomplete")}
 for key,rows:=range result.NativeEvidence.Phases {
  if w.jobs[key].FirstRecord!=0{continue}
  class:="ordinary";if strings.HasPrefix(key,"diagnostic-snapshot:"){class="snapshot"}
  if _,e:=w.writeJobLocked(context.Background(),key,rows,result.NativeEvidence.Lost[key],result.NativeEvidence.Pending[key],class,nil);e!=nil{return w.index(result,false),e}
 }
 snapshotRefs:=make([]uint64,0,len(result.DiagnosticSnapshots))
 for _,snapshot:=range result.DiagnosticSnapshots{if w.snapshots[snapshot.Sequence]==0{if e:=w.writeSnapshot(snapshot);e!=nil{return w.index(result,false),e}};snapshotRefs=append(snapshotRefs,w.snapshots[snapshot.Sequence])}
 if !w.budget.reserveMemory(4<<20){return w.index(result,false),fmt.Errorf("normalization case result reservation bound")};defer w.budget.releaseMemory(4<<20)
 detached:=result;detached.DiagnosticSnapshots=nil;detached.NativeEvidence.Phases=nil
 if e:=runnerNormalizationJSONReservation(detached);e!=nil{return w.index(result,false),e}
 raw,e:=json.Marshal(detached);if e!=nil{return w.index(result,false),e}
 if len(raw)>1<<20{return w.index(result,false),fmt.Errorf("normalization case result bound")}
 var fields map[string]json.RawMessage;if json.Unmarshal(raw,&fields)!=nil{return w.index(result,false),fmt.Errorf("normalization result fields")}
 delete(fields,"diagnosticSnapshots")
 var native map[string]json.RawMessage;if json.Unmarshal(fields["nativeEvidence"],&native)!=nil{return w.index(result,false),fmt.Errorf("normalization native result")};delete(native,"phases");fields["nativeEvidence"],_=json.Marshal(native)
 if e=runnerValidateNormalizedCaseFields(fields);e!=nil{return w.index(result,false),e}
 if e=w.record("result",map[string]any{"case":w.selected,"value":fields,"snapshotRecords":snapshotRefs,"snapshotsNil":result.DiagnosticSnapshots==nil,"phaseJobs":w.jobs,"phasesNil":result.NativeEvidence.Phases==nil});e!=nil{return w.index(result,false),e}
 prefix:=hex.EncodeToString(w.digest.Sum(nil));complete:=result.NativeObservationSettled
 for _,receipt:=range w.jobs{if receipt.Lost||receipt.Pending!=0{complete=false}}
 if e=w.record("footer",map[string]any{"prefixSHA256":prefix,"records":w.seq,"operations":len(w.operations),"jobs":len(w.jobs),"snapshots":len(w.snapshots),"owners":w.owners,"phases":w.phases,"evidenceComplete":complete,"outcome":result.Result});e!=nil{return w.index(result,false),e}
 if e=w.file.Close();e!=nil{w.closed=true;w.problem=e;return w.index(result,false),e};w.closed=true
 return w.index(result,complete),nil
}
