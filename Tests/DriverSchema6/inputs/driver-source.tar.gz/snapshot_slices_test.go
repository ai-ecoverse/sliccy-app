package integration

import (
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

type snapshotSlice struct {
	CPU        uint32 `json:"cpu"`
	Subtype    uint32 `json:"subtype"`
	Offset     uint64 `json:"offset"`
	Size       uint64 `json:"size"`
	Alignment  uint32 `json:"alignmentExponent"`
	CDHash     string `json:"cdhash"`
	FullCDHash string `json:"fullCDHash"`
}

func signedSnapshotSlices(raw []byte) ([]snapshotSlice, error) {
	fail := func() ([]snapshotSlice, error) {
		return nil, fmt.Errorf("unsupported or ambiguous signed Mach-O snapshot")
	}
	if len(raw) < 32 || len(raw) > 256<<20 {
		return fail()
	}
	var slices []snapshotSlice
	magic := binary.BigEndian.Uint32(raw[:4])
	if binary.LittleEndian.Uint32(raw[:4]) == 0xfeedfacf {
		slices = []snapshotSlice{{CPU: binary.LittleEndian.Uint32(raw[4:8]), Subtype: binary.LittleEndian.Uint32(raw[8:12]), Size: uint64(len(raw))}}
	} else {
		if magic != 0xcafebabe && magic != 0xcafebabf {
			return fail()
		}
		n := binary.BigEndian.Uint32(raw[4:8])
		if n != 2 {
			return fail()
		}
		step := 20
		if magic == 0xcafebabf {
			step = 32
		}
		end := 8 + int(n)*step
		if end > len(raw) {
			return fail()
		}
		for i := 0; i < int(n); i++ {
			entry := raw[8+i*step : 8+(i+1)*step]
			slice := snapshotSlice{CPU: binary.BigEndian.Uint32(entry[:4]), Subtype: binary.BigEndian.Uint32(entry[4:8])}
			var align uint32
			if step == 20 {
				slice.Offset = uint64(binary.BigEndian.Uint32(entry[8:12]))
				slice.Size = uint64(binary.BigEndian.Uint32(entry[12:16]))
				align = binary.BigEndian.Uint32(entry[16:20])
			} else {
				slice.Offset = binary.BigEndian.Uint64(entry[8:16])
				slice.Size = binary.BigEndian.Uint64(entry[16:24])
				align = binary.BigEndian.Uint32(entry[24:28])
				if binary.BigEndian.Uint32(entry[28:32]) != 0 {
					return fail()
				}
			}
			slice.Alignment = align
			if align > 31 || slice.Offset < uint64(end) || slice.Offset > uint64(len(raw)) || slice.Size < 32 || slice.Size > uint64(len(raw))-slice.Offset || slice.Offset%(uint64(1)<<align) != 0 {
				return fail()
			}
			for _, old := range slices {
				if old.CPU == slice.CPU || slice.Offset < old.Offset+old.Size && old.Offset < slice.Offset+slice.Size {
					return fail()
				}
			}
			slices = append(slices, slice)
		}
	}
	for i := range slices {
		slice := &slices[i]
		if slice.CPU != 0x0100000c && slice.CPU != 0x01000007 {
			return fail()
		}
		body := raw[slice.Offset : slice.Offset+slice.Size]
		u := binary.LittleEndian
		if u.Uint32(body[:4]) != 0xfeedfacf || u.Uint32(body[4:8]) != slice.CPU || u.Uint32(body[8:12]) != slice.Subtype || u.Uint32(body[12:16]) != 2 || u.Uint32(body[28:32]) != 0 {
			return fail()
		}
		n, cmdSize := u.Uint32(body[16:20]), u.Uint32(body[20:24])
		if n < 1 || n > 2048 || cmdSize > 1<<20 || uint64(cmdSize) > slice.Size-32 {
			return fail()
		}
		pos, limit := uint64(32), uint64(32)+uint64(cmdSize)
		var signature []byte
		for c := uint32(0); c < n; c++ {
			if pos+8 > limit {
				return fail()
			}
			cmd, size := u.Uint32(body[pos:pos+4]), u.Uint32(body[pos+4:pos+8])
			if size < 8 || size%8 != 0 || uint64(size) > limit-pos {
				return fail()
			}
			if cmd == 0x1d {
				if size != 16 || signature != nil {
					return fail()
				}
				off, length := uint64(u.Uint32(body[pos+8:pos+12])), uint64(u.Uint32(body[pos+12:pos+16]))
				if off < limit || off > slice.Size || length < 12 || length > slice.Size-off {
					return fail()
				}
				signature = body[off : off+length]
			}
			pos += uint64(size)
		}
		if pos != limit || signature == nil {
			return fail()
		}
		be := binary.BigEndian
		if be.Uint32(signature[:4]) != 0xfade0cc0 {
			return fail()
		}
		total, count := uint64(be.Uint32(signature[4:8])), uint64(be.Uint32(signature[8:12]))
		if total > uint64(len(signature)) || total < 12 || count == 0 || count > 32 || 12+count*8 > total {
			return fail()
		}
		seen := map[uint32]bool{}
		var ranges [][2]uint64
		for c := uint64(0); c < count; c++ {
			entry := signature[12+c*8 : 20+c*8]
			kind, off := be.Uint32(entry[:4]), uint64(be.Uint32(entry[4:8]))
			if seen[kind] || off < 12+count*8 || off+8 > total {
				return fail()
			}
			seen[kind] = true
			length := uint64(be.Uint32(signature[off+4 : off+8]))
			if length < 8 || length > total-off {
				return fail()
			}
			for _, old := range ranges {
				if off < old[1] && old[0] < off+length {
					return fail()
				}
			}
			ranges = append(ranges, [2]uint64{off, off + length})
			if kind == 0 || kind >= 0x1000 && kind <= 0x1005 {
				if slice.CDHash != "" || be.Uint32(signature[off:off+4]) != 0xfade0c02 || length < 44 || length > 1<<20 {
					return fail()
				}
				directory := signature[off : off+length]
				if directory[36] != 32 || directory[37] != 2 {
					return fail()
				}
				digest := sha256.Sum256(directory)
				slice.FullCDHash = hex.EncodeToString(digest[:])
				slice.CDHash = hex.EncodeToString(digest[:20])
			}
		}
		if slice.CDHash == "" {
			return fail()
		}
	}
	if len(slices) == 2 && slices[0].CDHash == slices[1].CDHash {
		return fail()
	}
	return slices, nil
}
func TestSnapshotParserRejectsMalformed(t *testing.T) {
	for _, raw := range [][]byte{nil, make([]byte, 32), {0xca, 0xfe, 0xba, 0xbe, 0, 0, 0, 2}} {
		if _, e := signedSnapshotSlices(raw); e == nil {
			t.Fatal("malformed snapshot accepted")
		}
	}
}
func TestSnapshotParserExactReleasedThin(t *testing.T) {
	path := os.Getenv("SLICC_RELEASE_PROOF_BINARY")
	if path == "" {
		t.Skip("verified release snapshot required")
	}
	raw, e := os.ReadFile(path)
	if e != nil {
		t.Fatal(e)
	}
	slices, e := signedSnapshotSlices(raw)
	if e != nil || len(slices) != 1 || slices[0].CPU != 0x0100000c || slices[0].Offset != 0 || slices[0].CDHash != "5da1a3199bd3f895bce2e53023c28ca1c33d249e" {
		t.Fatal("released thin CodeDirectory parser mismatch", e)
	}
	for _, index := range []int{0, 16, 20, 28} {
		changed := append([]byte(nil), raw...)
		for j := 0; j < 4; j++ {
			changed[index+j] = 0xff
		}
		if _, e := signedSnapshotSlices(changed); e == nil {
			t.Fatal("corrupt Mach-O header accepted")
		}
	}
}

func TestSnapshotParserFatLayoutValidation(t *testing.T) {
	path := os.Getenv("SLICC_RELEASE_PROOF_BINARY")
	if path == "" {
		t.Skip("release snapshots required")
	}
	arm, e := os.ReadFile(path)
	if e != nil {
		t.Fatal(e)
	}
	amd, e := os.ReadFile(filepath.Join(filepath.Dir(path), "slicc-darwin-amd64"))
	if e != nil {
		t.Fatal(e)
	}
	a, b := sha256.Sum256(arm), sha256.Sum256(amd)
	if hex.EncodeToString(a[:]) != "0055c051f48364dbf6d3744c637a06353305a392d06edbedd96bd6764adb5a73" || hex.EncodeToString(b[:]) != "9ff520697095ce930cc25d4a5e208a72eb82a072211fd7b9bbd6da2b9b78278e" {
		t.Fatal("wrong release fixture bytes")
	}
	armOff := 16384
	amdOff := (armOff + len(arm) + 16383) &^ 16383
	raw := make([]byte, amdOff+len(amd))
	be := binary.BigEndian
	be.PutUint32(raw[:4], 0xcafebabe)
	be.PutUint32(raw[4:8], 2)
	for i, entry := range []struct {
		body   []byte
		offset int
	}{{arm, armOff}, {amd, amdOff}} {
		at := 8 + i*20
		be.PutUint32(raw[at:at+4], binary.LittleEndian.Uint32(entry.body[4:8]))
		be.PutUint32(raw[at+4:at+8], binary.LittleEndian.Uint32(entry.body[8:12]))
		be.PutUint32(raw[at+8:at+12], uint32(entry.offset))
		be.PutUint32(raw[at+12:at+16], uint32(len(entry.body)))
		be.PutUint32(raw[at+16:at+20], 14)
		copy(raw[entry.offset:], entry.body)
	}
	slices, e := signedSnapshotSlices(raw)
	if e != nil || len(slices) != 2 || slices[0].Offset != uint64(armOff) || slices[1].Offset != uint64(amdOff) || slices[0].CDHash != "5da1a3199bd3f895bce2e53023c28ca1c33d249e" || slices[1].CDHash != "bf246edfa276fa4242db674e139a872270633673" {
		t.Fatal("fat parser did not retain per-slice identities", e)
	}
	for _, mutation := range []struct {
		at    int
		value uint32
	}{{4, 3}, {28, slices[0].CPU}, {36, uint32(armOff)}, {36, 0xfffffff0}, {40, 0xffffffff}, {24, 32}, {16, 32}, {12, 0xffffffff}} {
		old := be.Uint32(raw[mutation.at : mutation.at+4])
		be.PutUint32(raw[mutation.at:mutation.at+4], mutation.value)
		_, e := signedSnapshotSlices(raw)
		be.PutUint32(raw[mutation.at:mutation.at+4], old)
		if e == nil {
			t.Fatal("malformed/ambiguous fat header accepted", mutation.at)
		}
	}
	for i := 0; i < 72; i++ {
		raw[i] = 0
	}
	be.PutUint32(raw[:4], 0xcafebabf)
	be.PutUint32(raw[4:8], 2)
	for i, slice := range slices {
		at := 8 + i*32
		be.PutUint32(raw[at:at+4], slice.CPU)
		be.PutUint32(raw[at+4:at+8], slice.Subtype)
		be.PutUint64(raw[at+8:at+16], slice.Offset)
		be.PutUint64(raw[at+16:at+24], slice.Size)
		be.PutUint32(raw[at+24:at+28], 14)
	}
	wide, e := signedSnapshotSlices(raw)
	if e != nil || len(wide) != 2 || wide[0].CDHash != slices[0].CDHash || wide[1].CDHash != slices[1].CDHash {
		t.Fatal("FAT64 map mismatch", e)
	}
	be.PutUint32(raw[36:40], 1)
	if _, e := signedSnapshotSlices(raw); e == nil {
		t.Fatal("nonzero FAT64 reserved field accepted")
	}
	be.PutUint32(raw[36:40], 0)
	be.PutUint64(raw[16:24], ^uint64(0)-7)
	if _, e := signedSnapshotSlices(raw); e == nil {
		t.Fatal("FAT64 offset overflow accepted")
	}

}
