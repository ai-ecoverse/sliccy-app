package integration

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"regexp"

	"golang.org/x/sys/unix"
)

type snapshotFiles struct {
	Root            string
	Dir             int
	Original        *os.File
	OriginalInfo    unix.Stat_t
	ReplacementInfo unix.Stat_t
	Arm             []byte
	Intel           []byte
}

func sameSnapshotFile(a, b unix.Stat_t) bool {
	return a.Dev == b.Dev && a.Ino == b.Ino && a.Uid == b.Uid && a.Mode == b.Mode
}
func snapshotRead(file *os.File) ([]byte, unix.Stat_t, error) {
	var first, last unix.Stat_t
	if unix.Fstat(int(file.Fd()), &first) != nil || first.Mode&unix.S_IFMT != unix.S_IFREG || first.Uid != uint32(os.Getuid()) || first.Size < 1 || first.Size > 32<<20 || first.Mode&077 != 0 {
		return nil, first, fmt.Errorf("untrusted snapshot file")
	}
	raw := make([]byte, int(first.Size))
	if n, e := file.ReadAt(raw, 0); e != nil || n != len(raw) {
		return nil, first, fmt.Errorf("snapshot short read: %d/%d: %v", n, len(raw), e)
	}
	if unix.Fstat(int(file.Fd()), &last) != nil || !sameSnapshotFile(first, last) || first.Size != last.Size || first.Mtim != last.Mtim || first.Ctim != last.Ctim {
		return nil, first, fmt.Errorf("snapshot changed while read")
	}
	return raw, first, nil
}
func (s *snapshotFiles) open(name string) (*os.File, error) {
	if name != "candidate" && name != "baseline" && name != "replacement" {
		return nil, fmt.Errorf("unexpected fixed file")
	}
	fd, e := unix.Openat(s.Dir, name, unix.O_RDONLY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
	if e != nil {
		return nil, e
	}
	return os.NewFile(uintptr(fd), name), nil
}
func openSnapshotFiles(root string, arm, intel []byte) (s *snapshotFiles, err error) {
	if !regexp.MustCompile(`^/private/tmp/sliccy-snapshot\.[A-Za-z0-9]{8}$`).MatchString(root) || filepath.Clean(root) != root {
		return nil, fmt.Errorf("invalid owned staging path")
	}
	fd, e := unix.Open(root, unix.O_RDONLY|unix.O_DIRECTORY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
	if e != nil {
		return nil, e
	}
	s = &snapshotFiles{Root: root, Dir: fd, Arm: arm, Intel: intel}
	owned := s
	defer func() {
		if err != nil {
			owned.close()
		}
	}()
	var directory unix.Stat_t
	if unix.Fstat(fd, &directory) != nil || directory.Uid != uint32(os.Getuid()) || directory.Mode&0777 != 0700 {
		return nil, fmt.Errorf("invalid private staging owner")
	}
	s.Original, e = s.open("candidate")
	if e != nil {
		return nil, e
	}
	original, info, e := snapshotRead(s.Original)
	if e != nil || !bytes.Equal(original, arm) || info.Nlink != 2 || info.Dev != directory.Dev {
		return nil, fmt.Errorf("candidate differs from immutable release")
	}
	s.OriginalInfo = info
	baseline, e := s.open("baseline")
	if e != nil {
		return nil, e
	}
	defer baseline.Close()
	data, other, e := snapshotRead(baseline)
	if e != nil || !sameSnapshotFile(info, other) || !bytes.Equal(data, arm) {
		return nil, fmt.Errorf("baseline alias mismatch")
	}
	if len(intel) > 0 {
		replacement, e := s.open("replacement")
		if e != nil {
			return nil, e
		}
		defer replacement.Close()
		data, other, e := snapshotRead(replacement)
		if e != nil || other.Dev != directory.Dev || other.Ino == info.Ino || other.Nlink != 1 || !bytes.Equal(data, intel) {
			return nil, fmt.Errorf("replacement stage mismatch")
		}
		s.ReplacementInfo = other
	}
	return s, nil
}
func (s *snapshotFiles) close() {
	if s == nil {
		return
	}
	if s.Original != nil {
		_ = s.Original.Close()
		s.Original = nil
	}
	if s.Dir >= 0 {
		_ = unix.Close(s.Dir)
		s.Dir = -1
	}
}
func (s *snapshotFiles) observeChange(which string, completed bool) (map[string]any, error) {
	original, info, e := snapshotRead(s.Original)
	if e != nil || !sameSnapshotFile(info, s.OriginalInfo) {
		return nil, fmt.Errorf("retained original inode lost")
	}
	baseline, e := s.open("baseline")
	if e != nil {
		return nil, e
	}
	defer baseline.Close()
	alias, aliasInfo, e := snapshotRead(baseline)
	if e != nil || !sameSnapshotFile(info, aliasInfo) || !bytes.Equal(alias, original) {
		return nil, fmt.Errorf("baseline no longer original inode")
	}
	candidate, e := s.open("candidate")
	if e != nil {
		return nil, e
	}
	defer candidate.Close()
	current, currentInfo, e := snapshotRead(candidate)
	if e != nil {
		return nil, e
	}
	mutation := which == "snapshot-mutation"
	if !completed {
		if !sameSnapshotFile(currentInfo, s.OriginalInfo) || !bytes.Equal(current, s.Arm) || !bytes.Equal(original, s.Arm) {
			return nil, fmt.Errorf("denied operation changed snapshots")
		}
	} else if mutation {
		if !sameSnapshotFile(currentInfo, s.OriginalInfo) || len(current) != len(s.Arm) || len(current) <= 17947039 || current[17947039] != 1 || s.Arm[17947039] != 0 || !bytes.Equal(current[:17947039], s.Arm[:17947039]) || !bytes.Equal(current[17947040:], s.Arm[17947040:]) || !bytes.Equal(original, current) {
			return nil, fmt.Errorf("mutation was not exact XOR1")
		}
	} else {
		if !sameSnapshotFile(currentInfo, s.ReplacementInfo) || !bytes.Equal(current, s.Intel) || !bytes.Equal(original, s.Arm) || info.Nlink != 1 || currentInfo.Nlink != 1 {
			return nil, fmt.Errorf("replacement/old snapshot binding mismatch")
		}
	}
	parsed, e := signedSnapshotSlices(current)
	if e != nil || len(parsed) != 1 {
		return nil, fmt.Errorf("post-change snapshot parser failed")
	}
	expectedValid := !(completed && mutation)
	actualValid := validateStaticSlice(filepath.Join(s.Root, "candidate"), "ai.sliccy.slicc", parsed[0]) == nil
	if actualValid != expectedValid {
		return nil, fmt.Errorf("altered-file static validity unexpected")
	}
	if !mutation || !completed {
		originalSlices, e := signedSnapshotSlices(original)
		if e != nil || len(originalSlices) != 1 || validateStaticSlice(filepath.Join(s.Root, "baseline"), "ai.sliccy.slicc", originalSlices[0]) != nil {
			return nil, fmt.Errorf("retained original snapshot no longer valid")
		}
	}
	a, b := sha256.Sum256(original), sha256.Sum256(current)
	return map[string]any{"retainedOriginalSHA256": hex.EncodeToString(a[:]), "candidateSHA256": hex.EncodeToString(b[:]), "candidateStaticValid": actualValid, "sameOriginalInode": sameSnapshotFile(info, s.OriginalInfo), "oldAliasSameInode": sameSnapshotFile(info, aliasInfo), "candidateCPU": parsed[0].CPU, "candidateCDHash": parsed[0].CDHash, "completed": completed}, nil
}
