package integration

import (
	"fmt"
	"strings"
	"testing"
)

type returnedPIDTransition struct {
	Wrapped, Approach, Missed bool
	Distance                  int64
}

func inspectReturnedPID(previous *int, returned, target int) (returnedPIDTransition, error) {
	if target <= 2 || returned <= 0 || int64(returned) > 2147483647 || (previous != nil && (*previous <= 0 || int64(*previous) > 2147483647)) {
		return returnedPIDTransition{}, fmt.Errorf("invalid returned PID transition")
	}
	d := int64(target) - int64(returned)
	wrapped := previous != nil && returned < *previous
	return returnedPIDTransition{wrapped, (d > 0 && d <= 2000) || (wrapped && returned >= target), (wrapped && returned >= target) || (previous != nil && *previous < target && returned >= target), d}, nil
}

type hostedPIDSteeringLedger struct {
	Target       int
	Wraps        int
	Count        uint64
	Returned     int
	Previous     *int
	Rank         int
	Approaches   map[int]bool
	Misses       map[int]bool
	NeedApproach bool
	NeedMiss     bool
	SameWrap     int
	Below        *int
	Above        *int
	Records      []hostedPIDRow
}

func (s *hostedPIDSteeringLedger) Observe(row hostedPIDRow) error {
	if s.Approaches == nil {
		s.Approaches = map[int]bool{}
		s.Misses = map[int]bool{}
	}
	if row.Count == nil || row.ReturnedPID == nil || row.Wrap == nil || row.Distance == nil {
		return fmt.Errorf("missing returned-PID evidence")
	}
	tr, e := inspectReturnedPID(row.PreviousPID, *row.ReturnedPID, s.Target)
	if e != nil || tr.Distance != *row.Distance {
		return fmt.Errorf("returned-PID distance mismatch")
	}
	rank := map[string]int{"cycler-wrap": 1, "cycler-approach": 2, "cycler-missed": 3}[row.Stage]
	if rank == 0 {
		return fmt.Errorf("unknown steering record")
	}
	if *row.Count < s.Count || *row.Count == 0 {
		return fmt.Errorf("returned/reaped count moved backward")
	}
	same := *row.Count == s.Count
	if same {
		if s.Returned != *row.ReturnedPID || (s.Previous == nil) != (row.PreviousPID == nil) || (s.Previous != nil && *s.Previous != *row.PreviousPID) || rank <= s.Rank {
			return fmt.Errorf("same-return evidence order/identity mismatch")
		}
	} else {
		if s.NeedApproach || s.NeedMiss {
			return fmt.Errorf("missing required wrap hint/miss record")
		}
		s.Count = *row.Count
		s.Returned = *row.ReturnedPID
		s.Previous = row.PreviousPID
		s.Rank = 0
	}
	if row.PreviousPID == nil && (*row.Count != 1 || row.Stage != "cycler-approach" || *row.Wrap != 0) {
		return fmt.Errorf("missing actual previous endpoint")
	}
	if row.Stage == "cycler-wrap" {
		if same || !tr.Wrapped || *row.Wrap != s.Wraps+1 || *row.Wrap > 2 {
			return fmt.Errorf("invalid/extra returned-PID wrap")
		}
		if row.PreviousPID != nil {
			priorDistance := s.Target - *row.PreviousPID
			if priorDistance > 0 && (row.ClosestBelow == nil || *row.ClosestBelow > priorDistance) {
				return fmt.Errorf("finished traversal below minimum contradicts endpoint")
			}
			if priorDistance <= 0 && (row.ClosestAbove == nil || *row.ClosestAbove > -priorDistance) {
				return fmt.Errorf("finished traversal above minimum contradicts endpoint")
			}
		}
		s.Wraps = *row.Wrap
		s.NeedApproach = tr.Approach
		s.NeedMiss = tr.Missed
	} else {
		if *row.Wrap != s.Wraps || (tr.Wrapped && (!same || s.Rank == 0)) {
			return fmt.Errorf("hint without matching observed wrap")
		}
		if row.Stage == "cycler-approach" {
			if !tr.Approach || s.Approaches[s.Wraps] {
				return fmt.Errorf("invalid/duplicate proximity hint")
			}
			s.Approaches[s.Wraps] = true
			s.NeedApproach = false
		} else {
			if !tr.Missed || s.Misses[s.Wraps] || s.NeedApproach {
				return fmt.Errorf("invalid/duplicate target-missed record")
			}
			s.Misses[s.Wraps] = true
			s.NeedMiss = false
		}
		if tr.Distance > 0 && (row.ClosestBelow == nil || int64(*row.ClosestBelow) > tr.Distance) {
			return fmt.Errorf("current below minimum contradicts return")
		}
		if tr.Distance <= 0 && (row.ClosestAbove == nil || int64(*row.ClosestAbove) > -tr.Distance) {
			return fmt.Errorf("current above minimum contradicts return")
		}
	}
	s.Rank = rank
	s.Records = append(s.Records, row)
	return nil
}
func (s *hostedPIDSteeringLedger) Metrics(row hostedPIDRow) error {
	if row.Wraps == nil || *row.Wraps != s.Wraps || s.NeedApproach || s.NeedMiss {
		return fmt.Errorf("missing/incorrect wrap evidence")
	}
	if row.ClosestBelow != nil && *row.ClosestBelow >= s.Target {
		return fmt.Errorf("below minimum exceeds positive PID range")
	}
	if s.SameWrap == s.Wraps {
		if s.Below != nil && (row.ClosestBelow == nil || *row.ClosestBelow > *s.Below) {
			return fmt.Errorf("below minimum increased inside traversal")
		}
		if s.Above != nil && (row.ClosestAbove == nil || *row.ClosestAbove > *s.Above) {
			return fmt.Errorf("above minimum increased inside traversal")
		}
	}
	s.SameWrap = s.Wraps
	s.Below = row.ClosestBelow
	s.Above = row.ClosestAbove
	if row.Stage == "cycler-ended" && row.Reason == "near-target" && (row.ClosestBelow == nil || *row.ClosestBelow != 1) {
		return fmt.Errorf("CLI admission without actual target-minus-one minimum")
	}
	if row.Stage == "cycler-ended" && row.Reason == "wrap-limit" && (s.Wraps != 2 || !s.Misses[2]) {
		return fmt.Errorf("wrap limit without second target miss")
	}
	return nil
}
func TestHostedPIDFakeSpawnWrapCrossingFiresHint(t *testing.T) {
	target := 10000
	values := []int{99998, 10001, 99998, 8500, 9999}
	owned := 0
	next := 0
	spawn := func() int {
		if owned != 0 || next >= len(values) {
			t.Fatal("fake overlapping/extra spawn")
		}
		owned = values[next]
		next++
		return owned
	}
	reap := func(pid int) {
		if pid != owned {
			t.Fatal("fake waitpid identity mismatch")
		}
		owned = 0
	}
	var previous *int
	var transitions []returnedPIDTransition
	for range values {
		pid := spawn()
		reap(pid)
		tr, e := inspectReturnedPID(previous, pid, target)
		if e != nil {
			t.Fatal(e)
		}
		transitions = append(transitions, tr)
		copy := pid
		previous = &copy
	}
	if !transitions[1].Wrapped || !transitions[1].Approach || !transitions[1].Missed || transitions[1].Distance != -1 {
		t.Fatal("wrap stepping over target did not fire approach/miss hint")
	}
	if !transitions[3].Wrapped || !transitions[3].Approach || transitions[3].Missed || transitions[3].Distance != 1500 {
		t.Fatal("second wrap did not recognize below-target approach")
	}
	if *previous != target-1 || transitions[4].Distance != 1 || owned != 0 {
		t.Fatal("exact final returned/reaped target-minus-one not retained")
	}
}
func TestHostedPIDSteeringRequiresOrderedWrapHintsAndExactMinimum(t *testing.T) {
	integer := func(v int) *int { return &v }
	count := uint64(2)
	distance := int64(-1)
	wrap := hostedPIDRow{identityRow: identityRow{proofRow: proofRow{Stage: "cycler-wrap"}}, Count: &count, Wrap: integer(1), PreviousPID: integer(99998), ReturnedPID: integer(10001), Distance: &distance, ClosestAbove: integer(89998)}
	s := hostedPIDSteeringLedger{Target: 10000}
	if e := s.Observe(wrap); e != nil {
		t.Fatal(e)
	}
	if !s.NeedApproach || !s.NeedMiss {
		t.Fatal("actual wrap crossing did not require hints")
	}
	metrics := hostedPIDRow{identityRow: identityRow{proofRow: proofRow{Stage: "cycler-progress"}}, Wraps: integer(1), ClosestAbove: integer(1)}
	if s.Metrics(metrics) == nil {
		t.Fatal("missing wrap hints accepted")
	}
	approach := wrap
	approach.Stage = "cycler-approach"
	approach.ClosestAbove = integer(1)
	if e := s.Observe(approach); e != nil {
		t.Fatal(e)
	}
	missed := approach
	missed.Stage = "cycler-missed"
	if e := s.Observe(missed); e != nil {
		t.Fatal(e)
	}
	if e := s.Metrics(metrics); e != nil {
		t.Fatal(e)
	}
	ended := metrics
	ended.Stage = "cycler-ended"
	ended.Reason = "near-target"
	if s.Metrics(ended) == nil {
		t.Fatal("wrap crossing alone admitted replacement")
	}
	ended.ClosestBelow = integer(1)
	if e := s.Metrics(ended); e != nil {
		t.Fatal(e)
	}
	third := wrap
	third.Wrap = integer(3)
	newCount := uint64(3)
	third.Count = &newCount
	if s.Observe(third) == nil {
		t.Fatal("third wrap accepted")
	}
}

func TestHostedPIDReturnedRecordSchema(t *testing.T) {
	good := `{"schema":3,"case":"pid-reuse-hosted","capture":false,"stage":"cycler-wrap","elapsedMs":10,"wrap":1,"previousPID":99998,"returnedPID":10001,"distance":-1,"closestBelow":null,"closestAbove":89998,"count":2}`
	if _, e := decodeHostedPIDRow([]byte(good)); e != nil {
		t.Fatal(e)
	}
	for _, pair := range [][2]string{{`"wrap":1`, `"wrap":3`}, {`"previousPID":99998`, `"previousPID":null`}, {`"returnedPID":10001`, `"returnedPID":0`}, {`"closestBelow":null,`, ``}, {`"closestBelow":null`, `"closestBelow":0`}, {`"distance":-1`, `"distance":"-1"`}} {
		if _, e := decodeHostedPIDRow([]byte(strings.Replace(good, pair[0], pair[1], 1))); e == nil {
			t.Fatal("invalid returned-PID schema accepted")
		}
	}
}
