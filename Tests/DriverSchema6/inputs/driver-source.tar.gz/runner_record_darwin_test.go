package integration

import (
	"bytes"
	"encoding/json"
	"fmt"
	"testing"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
)

type runnerWireFrame struct {
	Frame               screen.Frame
	WidthCap, HeightCap int
	Limits              screen.Limits
}

func (w *runnerWireFrame) UnmarshalJSON(raw []byte) error {
	type frame screen.Frame
	var f frame
	var fields map[string]json.RawMessage
	if runnerStrict(raw, &f, 4096) != nil || json.Unmarshal(raw, &fields) != nil || runnerExactFields(fields, []string{"type", "v", "binding", "frameSeq", "capturedMonoMs", "width", "height", "codec"}) != nil {
		return fmt.Errorf("wrong capture header shape")
	}
	var binding map[string]json.RawMessage
	if json.Unmarshal(fields["binding"], &binding) != nil || runnerExactFields(binding, []string{"link", "session", "source", "grantEpoch", "sourceEpoch", "protectionEpoch"}) != nil {
		return fmt.Errorf("wrong binding shape")
	}
	if !runnerBindingValid(f.Binding) || f.Type != "frame" || f.V != 1 || f.Codec != "jpeg" || !runnerLimitsValid(w.Limits) {
		return screen.ErrProtocol
	}
	if seq, e := runnerCounter(f.Seq); e != nil || seq == 0 {
		return screen.ErrProtocol
	}
	if _, e := runnerCounter(f.Captured); e != nil {
		return screen.ErrProtocol
	}
	if f.Width < 1 || f.Height < 1 || f.Width > w.WidthCap || f.Height > w.HeightCap || f.Width > w.Limits.LongEdge || f.Height > w.Limits.LongEdge || int64(f.Width)*int64(f.Height) > int64(w.Limits.Pixels) {
		return screen.ErrSize
	}
	w.Frame = screen.Frame(f)
	return nil
}
func runnerJPEGMetadataFree(body []byte) bool {
	if len(body) < 4 || body[0] != 255 || body[1] != 216 {
		return false
	}
	at := 2
	entropy, scan := false, false
	for at < len(body) {
		if entropy {
			for at < len(body) && body[at] != 255 {
				at++
			}
			if at+1 >= len(body) {
				return false
			}
			next := at + 1
			for next < len(body) && body[next] == 255 {
				next++
			}
			if next >= len(body) {
				return false
			}
			marker := body[next]
			if marker == 0 || marker >= 208 && marker <= 215 {
				at = next + 1
				continue
			}
			entropy = false
		}
		if at >= len(body) || body[at] != 255 {
			return false
		}
		next := at + 1
		for next < len(body) && body[next] == 255 {
			next++
		}
		if next >= len(body) {
			return false
		}
		marker := body[next]
		at = next + 1
		if marker == 217 {
			return scan && at == len(body)
		}
		if marker >= 224 && marker <= 239 || marker == 254 || marker == 216 || marker == 0 || marker >= 208 && marker <= 215 || at+2 > len(body) {
			return false
		}
		size := int(body[at])<<8 | int(body[at+1])
		if size < 2 || at+size > len(body) {
			return false
		}
		at += size
		if marker == 218 {
			entropy = true
			scan = true
		}
	}
	return false
}

func TestRunnerRecordRejectsDimensionsAndNativeFieldsBeforeBodyAllocation(t *testing.T) {
	b := screen.Binding{Link: screen.ID(16), Session: screen.ID(16), Source: screen.ID(16), GrantEpoch: "1", SourceEpoch: "1", ProtectionEpoch: "1"}
	f := screen.Frame{Type: "frame", V: 1, Binding: b, Seq: "1", Captured: "1", Width: 256, Height: 256, Codec: "jpeg"}
	raw, _ := json.Marshal(f)
	makeHeader := func() *runnerWireFrame {
		return &runnerWireFrame{WidthCap: 256, HeightCap: 256, Limits: screen.DefaultLimits()}
	}
	if e := runnerStrict(raw, makeHeader(), 4096); e != nil {
		t.Fatal(e)
	}
	for _, bad := range [][]byte{
		bytes.Replace(raw, []byte(`"width":256`), []byte(`"width":257`), 1),
		bytes.Replace(raw, []byte(`"v":1`), []byte(`"v":1,"launch":""`), 1),
		bytes.Replace(raw, []byte(`"v":1`), []byte(`"v":1,"connection":""`), 1),
		bytes.Replace(raw, []byte(`"frameSeq":"1"`), []byte(`"frameSeq":"01"`), 1),
	} {
		if runnerStrict(bad, makeHeader(), 4096) == nil {
			t.Fatal("invalid header accepted before body")
		}
	}
	body := runnerSyntheticJPEG(t, false)
	if !runnerJPEGMetadataFree(body) {
		t.Fatal("generated fixture JPEG not metadata-free")
	}
	withAPP := append([]byte{255, 216, 255, 224, 0, 4, 0, 0}, body[2:]...)
	withLateAPP := append(append([]byte(nil), body[:len(body)-2]...), []byte{255, 224, 0, 4, 0, 0, 255, 217}...)
	if runnerJPEGMetadataFree(withLateAPP) {
		t.Fatal("metadata between scan and EOI admitted")
	}
	if runnerJPEGMetadataFree(withAPP) {
		t.Fatal("APP metadata admitted")
	}
}
