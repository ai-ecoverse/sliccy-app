package integration

import (
	"encoding/json"
	"testing"
)

func TestRunnerMetadataLedgerKeepsFirstCauseKindsAndRequiresChromePhases(t *testing.T) {
	ledger := runnerCaseMetadataLedger{}
	for _, kind := range []string{"stop", "inventory", "launcher-reap", "child-loss", "failure"} {
		row := runnerCaptureRow{Stage: "first-cause", Fields: map[string]json.RawMessage{"kind": runnerUnionJSON(kind)}}
		if err := ledger.Add(row); err != nil {
			t.Fatal(err)
		}
	}
	if err := ledger.Add(ledger.Causes["stop"]); err == nil {
		t.Fatal("ASSERTION:first-cause-duplicate")
	}
	for _, missing := range []string{"none", "phase", "profile", "rejected"} {
		t.Run(missing, func(t *testing.T) {
			state := runnerCaseMetadataLedger{}
			for _, label := range []string{"chrome-a-1", "chrome-a-2", "chrome-b-1", "chrome-b-2"} {
				for _, phase := range []string{"preflight", "initial-live", "live", "live-copy", "signal"} {
					if missing == "profile" && label == "chrome-b-2" || missing == "phase" && label == "chrome-b-2" && phase == "signal" {
						continue
					}
					status := int64(0)
					if missing == "rejected" && label == "chrome-b-2" && phase == "signal" {
						status = -1
					}
					row := runnerCaptureRow{Stage: "chrome-identity", Fields: map[string]json.RawMessage{"label": runnerUnionJSON(label), "phase": runnerUnionJSON(phase), "identityStatus": runnerUnionJSON(status), "strictStatus": runnerUnionJSON(-66999), "guestStatus": runnerUnionJSON(0)}}
					if err := state.Add(row); err != nil {
						t.Fatal(err)
					}
				}
			}
			err := state.CompleteChrome(true)
			if missing == "none" {
				if err != nil {
					t.Fatal("ASSERTION:chrome-phase-complete", err)
				}
			} else if err == nil {
				t.Fatal("ASSERTION:chrome-phase-missing-" + missing)
			}
			if err := state.CompleteChrome(false); err == nil {
				t.Fatal("unexpected browser evidence accepted for window-only case")
			}
		})
	}
}
