package integration

import (
 "fmt"
 "math"
)

// Bound by the source-contract gate to ScreenIndicator.proofPlace, NOT app rows.
const runnerIndicatorX = 64
const runnerIndicatorY = 512

type runnerIndicatorContract struct {
 Display independentRect `json:"display"`
 FloatingLevel int64 `json:"floatingLevel"`
}

func runnerIndicatorCandidate(processes map[int]runnerProcessFact, windows []independentWindow, contract runnerIndicatorContract) (independentWindow,error) {
 var zero independentWindow
 pid:=0
 for p,f:=range processes {
  if f.Label!="app" {continue}
  if pid!=0||!f.Code.Binding.Bound||f.Identity.PID!=int64(p) {return zero,fmt.Errorf("indicator independent app binding ambiguous")}
  pid=p
 }
 if pid<=0||contract.FloatingLevel==0||contract.Display.X!=0||contract.Display.Y!=0||contract.Display.Width<1024||contract.Display.Height<768 {
  return zero,fmt.Errorf("indicator source/platform contract unavailable")
 }
 var candidate independentWindow; count:=0
 for _,w:=range windows {
  if w.PID!=pid||!w.OnScreen||w.Layer!=contract.FloatingLevel||w.Rect.X!=runnerIndicatorX||w.Rect.Y!=runnerIndicatorY {continue}
  r:=w.Rect
  finite:=true
  for _,v:=range []float64{r.X,r.Y,r.Width,r.Height}{if math.IsNaN(v)||math.IsInf(v,0){finite=false}}
  if !finite||r.Width<=0||r.Height<=0||r.X+r.Width>contract.Display.Width||r.Y+r.Height>contract.Display.Height {return zero,fmt.Errorf("indicator observed geometry outside display")}
  candidate=w; count++
 }
 if count!=1||candidate.ID==0 {return zero,fmt.Errorf("indicator independent floating candidate missing/ambiguous")}
 return candidate,nil
}

func runnerIndicatorClaim(candidate independentWindow, claims []runnerWindowClaim) error {
 count:=0
 for _,claim:=range claims {
  if claim.Label!="app" {continue};count++
  if claim.PID!=candidate.PID||claim.ID!=candidate.ID||claim.Rect!=candidate.Rect||claim.Layer!=candidate.Layer {
   return fmt.Errorf("indicator app claim disagrees with independent floating candidate")
  }
 }
 if count!=1{return fmt.Errorf("indicator paired claim missing/ambiguous")};return nil
}

func runnerCheckControllerOperands(checks ...runnerControllerOperand) (string,error) {
 for _,check:=range checks {if err:=check.Check();err!=nil{return check.Name,err}}
 return "",nil
}
type runnerControllerOperand struct {Name string;Check func()error}

