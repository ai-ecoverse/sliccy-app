package integration

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"github.com/ai-ecoverse/slicc-cli/internal/link"
	"io"
	"math"
	"math/big"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
)

type handoffRow struct {
	identityRow
	Verification json.RawMessage `json:"verification,omitempty"`
	FrameSeq     *screen.Counter `json:"frameSeq,omitempty"`
}

type handoffReports struct {
	lane     string
	count    int
	seen     map[string]bool
	baseline bool
	refused  bool
	complete bool
}

func uniqueProofJSON(raw []byte) bool {
	d := json.NewDecoder(bytes.NewReader(raw))
	var visit func() bool
	visit = func() bool {
		token, e := d.Token()
		if e != nil {
			return false
		}
		delim, ok := token.(json.Delim)
		if !ok {
			return true
		}
		if delim != '{' && delim != '[' {
			return false
		}
		names := map[string]bool{}
		for d.More() {
			if delim == '{' {
				key, e := d.Token()
				if e != nil {
					return false
				}
				name, ok := key.(string)
				if !ok || names[name] {
					return false
				}
				names[name] = true
			}
			if !visit() {
				return false
			}
		}
		end, e := d.Token()
		return e == nil && (delim == '{' && end == json.Delim('}') || delim == '[' && end == json.Delim(']'))
	}
	if !visit() {
		return false
	}
	_, e := d.Token()
	return e == io.EOF
}

func (p *handoffReports) accept(raw []byte) error {
	fail := func() error { return fmt.Errorf("invalid/incomplete verifier observation") }
	if len(raw) > 4096 || !uniqueProofJSON(raw) || p.complete || p.count >= 5 {
		return fail()
	}
	var r screen.ProofReport
	d := json.NewDecoder(bytes.NewReader(raw))
	d.DisallowUnknownFields()
	if d.Decode(&r) != nil {
		return fail()
	}
	var fields map[string]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil {
		return fail()
	}
	required := []string{"schema", "event", "seq", "stage", "tokenMatched", "pidAgreed", "uidAgreed", "lost"}
	for _, k := range required {
		if _, ok := fields[k]; !ok {
			return fail()
		}
	}
	if r.Schema != 1 || r.Event != screen.ProofEvent || r.Seq != p.count+1 || r.Lost || string(fields["lost"]) != "false" {
		return fail()
	}
	if r.Stage == "complete" {
		if len(fields) != 8 || r.TokenMatched != nil || r.PIDAgreed != nil || r.UIDAgreed != nil {
			return fail()
		}
		p.complete = true
	} else {
		if r.Stage != "check" || len(fields) != 10 || (r.Lane != "safety" && r.Lane != "frames") || (r.Outcome != "accepted" && r.Outcome != "refused") {
			return fail()
		}
		key := r.Lane + "/" + r.Outcome
		if p.seen == nil {
			p.seen = map[string]bool{}
		}
		if p.seen[key] {
			return fail()
		}
		p.seen[key] = true
		yes := func(b *bool) bool { return b != nil && *b }
		lane := p.lane
		if lane == "" {
			lane = "safety"
		}
		if r.Lane == lane && r.Outcome == "accepted" && yes(r.TokenMatched) && yes(r.PIDAgreed) && yes(r.UIDAgreed) {
			p.baseline = true
		}
		if r.Lane == lane && r.Outcome == "refused" && r.TokenMatched != nil && !*r.TokenMatched {
			p.refused = true
		}
	}
	p.count++
	return nil
}

func TestSignedSafetyHandoff(t *testing.T) { runSignedHandoff(t, "safety-handoff") }
func TestSignedFrameHandoff(t *testing.T)  { runSignedHandoff(t, "frame-handoff") }
func runSignedHandoff(t *testing.T, which string) {
	executable := os.Getenv("SLICCY_SIGNED_PROOF_APP")
	if executable == "" {
		t.Skip("CI-signed safety handoff fixture required")
	}
	evidence := os.Getenv("SLICCY_PROOF_EVIDENCE")
	helper := os.Getenv("SLICCY_SIGNED_PROOF_HELPER")
	appHash := os.Getenv("SLICCY_SIGNED_APP_CDHASH")
	helperHash := os.Getenv("SLICCY_SIGNED_HELPER_CDHASH")
	if evidence == "" || helper == "" || len(appHash) != 40 || len(helperHash) != 40 {
		t.Fatal("verified immutable manifest required")
	}
	gate := make(chan struct{})
	var page *link.Link
	var join string
	var states <-chan observedProofState
	var generated *generatedFramePage
	var generatedStates <-chan generatedStateFact
	var frames <-chan generatedFrameFact
	var frameErrors <-chan string
	var opened <-chan time.Time
	if which == "frame-handoff" {
		generated = newGeneratedFramePage(t, gate)
		page, join = generated.Page, generated.Join
		generatedStates, frames, frameErrors = generated.States, generated.Frames, generated.Errors
		opened = generated.Opened
	} else {
		page, join, states = proofPageControlled(t, gate)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 35*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, executable, "--screen-proof", "--case", which)
	cmd.Env = proofEnvironment(t)
	var input io.WriteCloser
	if which == "frame-handoff" {
		var err error
		input, err = cmd.StdinPipe()
		if err != nil {
			t.Fatal("baseline coordination pipe unavailable")
		}
		defer input.Close()
	} else {
		cmd.Stdin = strings.NewReader(join + "\n")
	}
	stdout, e := cmd.StdoutPipe()
	if e != nil {
		t.Fatal("stdout pipe unavailable")
	}
	stderr := &proofRows{}
	cmd.Stderr = stderr
	start := time.Now()
	if cmd.Start() != nil {
		t.Fatal("signed fixture launch failed")
	}
	if input != nil {
		if _, err := io.WriteString(input, join+"\n"); err != nil {
			cancel()
			_ = cmd.Wait()
			t.Fatal("fixture join delivery failed")
		}
	}
	parentEvents, stopParent, e := watchProofExec(cmd.Process.Pid)
	if e != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("parent monitor unavailable")
	}
	defer stopParent()
	incoming := make(chan handoffRow, 64)
	done := make(chan struct{})
	output := &proofRows{}
	var readErr, runErr error
	go func() {
		scanner := bufio.NewScanner(stdout)
		scanner.Buffer(make([]byte, 4096), 4096)
		for scanner.Scan() {
			raw := append([]byte(nil), scanner.Bytes()...)
			_, _ = output.Write(append(raw, '\n'))
			var row handoffRow
			d := json.NewDecoder(bytes.NewReader(raw))
			d.DisallowUnknownFields()
			if !uniqueProofJSON(raw) || d.Decode(&row) != nil {
				readErr = fmt.Errorf("invalid outer metadata")
				continue
			}
			row.At = time.Now()
			select {
			case incoming <- row:
			default:
				readErr = fmt.Errorf("outer queue exceeded")
			}
		}
		if scanner.Err() != nil {
			readErr = fmt.Errorf("metadata read failed")
		}
		close(incoming)
		runErr = cmd.Wait()
		close(done)
	}()
	var failures []string
	fail := func(s string) { failures = append(failures, s) }
	rows := map[string]handoffRow{}
	allowed := map[string]bool{}
	for _, s := range strings.Fields("child-started lanes-authenticated heartbeat-ready synthetic-link-observed cli-verification handoff-helper-started handoff-helper-ready handoff-control-sent handoff-control-echoed handoff-send-started handoff-record-transferred handoff-helper-received handoff-helper-write-started handoff-helper-written handoff-helper-held handoff-helper-complete handoff-association-lost handoff-helper-reaped handoff-observation-ended child-gate-invalidated child-authority-invalidated child-exit-reaped terminal cli-verification-inconclusive generated-source-verified synthetic-grant-requested synthetic-granted synthetic-baseline-submitted synthetic-baseline-confirmed") {
		allowed[s] = true
	}
	var reports handoffReports
	if which == "frame-handoff" {
		reports.lane = "frames"
	}
	var decodedBaselineAt, baselineAckAt time.Time
	frameCount := 0
	lateFrames := 0
	var baselineControl frameBaselineController
	var decodedSequence uint64
	var submitted uint64
	var requestTimes []map[string]any
	var retry <-chan time.Time
	var retryTimer *time.Timer
	defer func() {
		if retryTimer != nil {
			retryTimer.Stop()
		}
	}()
	nextRequest := func() {
		now := time.Now()
		n, err := baselineControl.next(now)
		if err != nil {
			fail("baseline request budget exhausted")
			retry = nil
			_ = input.Close()
			return
		}
		generated.mu.Lock()
		generated.requested = n
		generated.mu.Unlock()
		requestTimes = append(requestTimes, map[string]any{"frameSeq": n, "requestedMs": now.Sub(start).Seconds() * 1000})
		if _, err = io.WriteString(input, "frame-next\n"); err != nil {
			fail("baseline request delivery failed")
			retry = nil
			return
		}
		if retryTimer == nil {
			retryTimer = time.NewTimer(time.Second)
		} else {
			retryTimer.Reset(time.Second)
		}
		retry = retryTimer.C
	}

	var releaseAt, refusalAt, childExitAt, helperExitAt time.Time
	var baseline *big.Int
	var stateEvidence []map[string]any
	var childEvents, helperEvents <-chan proofExecEvent
	var stopChild, stopHelper func()
	var appVerified, helperVerified bool
	process := func(row handoffRow) {
		if row.Schema != 2 || row.Case != which || row.Capture == nil || *row.Capture || !allowed[row.Stage] || math.IsNaN(row.Elapsed) || math.IsInf(row.Elapsed, 0) || row.Elapsed < 0 || row.Elapsed > row.At.Sub(start).Seconds()*1000 {
			fail("invalid outer schema/timing")
			return
		}
		if row.Duration != nil {
			fail("unexpected duration field")
		}
		if row.PID != nil && (row.Stage != "child-started" && row.Stage != "handoff-helper-started" || *row.PID <= 0) {
			fail("unexpected PID field")
		}
		seqStage := row.Stage == "synthetic-baseline-submitted" || row.Stage == "synthetic-baseline-confirmed" || row.Stage == "handoff-record-transferred"
		if which == "frame-handoff" && seqStage {
			if row.FrameSeq == nil {
				fail("required frame sequence missing")
				return
			}
			n, err := row.FrameSeq.Value()
			if err != nil || n == 0 || n > 6 {
				fail("invalid bounded frame sequence")
				return
			}
			if row.Stage == "synthetic-baseline-submitted" {
				if n != submitted+1 || n > baselineControl.attempts || n > 5 {
					fail("baseline submission sequence disagrees with requests")
				}
				submitted = n
			}
			if row.Stage == "synthetic-baseline-confirmed" {
				if !baselineControl.confirmed || n != decodedSequence || n != submitted {
					fail("confirmed baseline sequence mismatch")
				}
			}
			if row.Stage == "handoff-record-transferred" {
				if !baselineControl.confirmed || n != decodedSequence+1 {
					fail("transferred sequence not exact next")
				}
			}
		} else if row.FrameSeq != nil {
			fail("unexpected frame sequence field")
		}
		if row.Stage == "cli-verification" {
			if row.Reason != "" || row.PID != nil || reports.accept(row.Verification) != nil {
				fail("invalid verifier evidence")
			}
			return
		}
		if len(row.Verification) > 0 {
			fail("unexpected nested verification")
		}
		if _, ok := rows[row.Stage]; ok && row.Stage != "synthetic-link-observed" && row.Stage != "synthetic-baseline-submitted" {
			fail("duplicate outer milestone")
		}
		rows[row.Stage] = row
		if row.Stage == "cli-verification-inconclusive" {
			fail("app observer inconclusive")
		}
		if row.Stage == "child-started" {
			if row.PID == nil || *row.PID == cmd.Process.Pid {
				fail("invalid owned CLI PID")
				return
			}
			var err error
			childEvents, stopChild, err = watchProofExec(*row.PID)
			if err != nil {
				fail("CLI kernel monitor unavailable")
			}
		}
		if row.Stage == "lanes-authenticated" {
			digest, err := inspectProofImage(cmd.Process.Pid, executable, appHash, "ai.sliccy.mac", "ai.sliccy.proof-helper")
			appVerified = err == nil && digest == appHash
			if !appVerified {
				fail("live signed app verification failed")
			}
		}
		if row.Stage == "heartbeat-ready" && releaseAt.IsZero() {
			releaseAt = time.Now()
			close(gate)
		}
		if row.Stage == "handoff-helper-started" {
			if !reports.baseline {
				fail("helper started before true safety baseline")
			}
			if row.PID == nil || *row.PID == cmd.Process.Pid || rows["child-started"].PID == nil || *row.PID == *rows["child-started"].PID {
				fail("invalid helper PID")
				return
			}
			var err error
			helperEvents, stopHelper, err = watchProofExec(*row.PID)
			if err != nil {
				fail("helper kernel monitor unavailable")
			}
		}
		if row.Stage == "handoff-helper-written" && rows["handoff-helper-started"].PID != nil {
			digest, err := inspectProofHelper(*rows["handoff-helper-started"].PID, helper, helperHash)
			helperVerified = err == nil && digest == helperHash
			if !helperVerified {
				fail("live helper role/hash verification failed")
			}
		}
	}
	observeState := func(state observedProofState) {
		seq, ok := new(big.Int).SetString(state.Seq, 10)
		if !ok || (len(state.Caps) != 0 && which != "frame-handoff") {
			fail("invalid/active state")
			return
		}
		stateEvidence = append(stateEvidence, map[string]any{"seq": state.Seq, "reason": state.Reason, "receivedMs": state.At.Sub(start).Seconds() * 1000})
		if baseline == nil && ((which == "safety-handoff" && state.Reason == "awaiting-consent") || (which == "frame-handoff" && state.Reason == "active")) {
			baseline = new(big.Int).Set(seq)
		}
		if baseline != nil && seq.Cmp(baseline) > 0 && state.Reason == "peer-lost" && refusalAt.IsZero() {
			refusalAt = state.At
		}
	}
	readRows := incoming
	finished := false
	for !finished {
		select {
		case row, ok := <-readRows:
			if ok {
				process(row)
			} else {
				readRows = nil
			}
		case state := <-states:
			observeState(state)
		case state := <-generatedStates:
			observeState(observedProofState{Seq: string(state.State.Seq), Caps: state.State.Caps, Reason: state.State.Reason, At: state.At})
		case <-opened:
			opened = nil
			baselineControl.opened = true
			nextRequest()
		case <-retry:
			nextRequest()
		case frame := <-frames:
			n, err := frame.Sequence.Value()
			if err != nil {
				fail("invalid decoded sequence")
				continue
			}
			accepted, err := baselineControl.observe(n, time.Now())
			if err != nil {
				fail("unexpected decoded baseline sequence/lifetime")
				continue
			}
			if !accepted {
				lateFrames++
				continue
			}
			frameCount++
			decodedSequence = n
			decodedBaselineAt = frame.At
			if retryTimer != nil {
				retryTimer.Stop()
			}
			retry = nil
			baselineAckAt = time.Now()
			if _, err := io.WriteString(input, "frame-baseline\n"); err != nil {
				baselineAckAt = time.Time{}
				fail("baseline acknowledgement delivery failed")
			}
		case reason := <-frameErrors:
			fail(reason)
		case event := <-parentEvents:
			if event.Err != nil || event.Exec {
				fail("original app identity/liveness monitor failed")
			}
			if event.Exit {
				parentEvents = nil
			}
		case event := <-childEvents:
			if event.Err != nil || event.Exec {
				fail("CLI kernel identity monitor failed")
			}
			if event.Exit {
				childExitAt = event.At
				childEvents = nil
			}
		case event := <-helperEvents:
			if event.Err != nil || event.Exec {
				fail("helper kernel identity monitor failed")
			}
			if event.Exit {
				helperExitAt = event.At
				helperEvents = nil
			}
		case <-done:
			for row := range incoming {
				process(row)
			}
			finished = true
		}
	}
	collectExit := func(events <-chan proofExecEvent, at *time.Time) {
		if events == nil || !at.IsZero() {
			return
		}
		select {
		case event := <-events:
			if event.Exit && event.Err == nil && !event.Exec {
				*at = event.At
			} else {
				fail("final kernel event invalid")
			}
		case <-time.After(time.Second):
			fail("kernel exit missing")
		}
	}
	collectExit(childEvents, &childExitAt)
	collectExit(helperEvents, &helperExitAt)
	if stopChild != nil {
		stopChild()
	}
	if stopHelper != nil {
		stopHelper()
	}
	if readErr != nil || output.overflow || stderr.overflow || runErr != nil {
		fail("diagnostic read/bounds/process failure")
	}
	if strings.Contains(string(output.data), join) {
		fail("synthetic URL disclosed")
	}
	required := strings.Fields("child-started lanes-authenticated heartbeat-ready synthetic-link-observed handoff-helper-started handoff-helper-ready handoff-control-sent handoff-control-echoed handoff-send-started handoff-record-transferred handoff-helper-received handoff-helper-write-started handoff-helper-written handoff-helper-held handoff-helper-complete handoff-association-lost handoff-helper-reaped handoff-observation-ended child-exit-reaped terminal")
	for _, s := range required {
		if _, ok := rows[s]; !ok {
			fail("missing " + s)
		}
	}
	order := strings.Fields("handoff-helper-started handoff-helper-ready handoff-control-sent handoff-control-echoed handoff-send-started handoff-record-transferred handoff-helper-received handoff-helper-write-started handoff-helper-written handoff-helper-held handoff-helper-complete handoff-helper-reaped handoff-observation-ended child-exit-reaped terminal")
	for i := 1; i < len(order); i++ {
		if rows[order[i]].Elapsed < rows[order[i-1]].Elapsed {
			fail("milestone order violation")
		}
	}
	if !reports.baseline || !reports.refused || !reports.complete {
		fail("kernel-owner refusal/completeness not established")
	}
	if !appVerified || !helperVerified || childExitAt.IsZero() || helperExitAt.IsZero() {
		fail("live identities or kernel exits unavailable")
	}
	sent, echoed, attack := rows["handoff-control-sent"], rows["handoff-control-echoed"], rows["handoff-send-started"]
	lost, written := rows["handoff-association-lost"], rows["handoff-helper-written"]
	if attack.Elapsed-sent.Elapsed < 0 || attack.Elapsed-sent.Elapsed > 750 || attack.Elapsed-echoed.Elapsed < 0 || attack.Elapsed-echoed.Elapsed > 100 || written.Elapsed-sent.Elapsed > 750 {
		fail("fresh otherwise-current traffic not established")
	}
	if lost.Reason != "peer-lost" || lost.Elapsed-attack.Elapsed < 0 || lost.Elapsed-attack.Elapsed > 500 {
		fail("native loss timing/reason failed")
	}
	lower := releaseAt.Add(-time.Duration(rows["synthetic-link-observed"].Elapsed * 1e6))
	if lower.Before(start) {
		lower = start
	}
	upperDelay := refusalAt.Sub(lower.Add(time.Duration(attack.Elapsed * 1e6)))
	if releaseAt.IsZero() || refusalAt.IsZero() || baseline == nil || upperDelay < 0 || upperDelay > 500*time.Millisecond {
		fail("independent refusal bound unavailable")
	}
	if !refusalAt.Before(lower.Add(time.Duration((sent.Elapsed + 1500) * 1e6))) {
		fail("lease expiry not excluded")
	}
	if rows["handoff-observation-ended"].Elapsed-rows["handoff-record-transferred"].Elapsed < 2500 || rows["handoff-helper-held"].Elapsed-written.Elapsed < 2000 {
		fail("held observation interval incomplete")
	}
	if rows["handoff-observation-ended"].Reason != "elapsed" || rows["handoff-helper-reaped"].Reason != "complete" || rows["terminal"].Reason != "handoff-observation-complete" {
		fail("observation/cleanup outcome incomplete")
	}
	if childExitAt.Before(rows["handoff-observation-ended"].At) {
		fail("CLI exited before observation ended")
	}

	if which == "frame-handoff" {
		select {
		case <-generated.Done:
		case <-time.After(time.Second):
			fail("frame consumer did not finish after native refusal")
		}
		for _, stage := range strings.Fields("generated-source-verified synthetic-grant-requested synthetic-granted synthetic-baseline-submitted synthetic-baseline-confirmed") {
			if _, ok := rows[stage]; !ok {
				fail("missing " + stage)
			}
		}
		if rows["generated-source-verified"].Elapsed >= rows["child-started"].Elapsed {
			fail("generated source not verified before child launch")
		}
		if !baselineControl.confirmed || decodedSequence == 0 || submitted != decodedSequence || frameCount != 1 || decodedBaselineAt.IsZero() || baselineAckAt.Before(decodedBaselineAt) || baselineAckAt.After(rows["synthetic-baseline-confirmed"].At) || baselineAckAt.After(rows["handoff-helper-started"].At) {
			fail("causal decoded baseline acknowledgement missing")
		}
		if written.Elapsed-attack.Elapsed > 100 {
			fail("transferred frame freshness bound exceeded")
		}
		for {
			select {
			case reason := <-frameErrors:
				fail(reason)
			case <-frames:
				fail("extra frame delivered")
			default:
				goto drainedFrames
			}
		}
	drainedFrames:
	}
	hello, ok := page.PeerHello()
	if !ok || hello.Version != "1.59.0" {
		fail("real release Pion HELLO unavailable")
	}
	facts := map[string]any{"case": which, "capture": false, "failures": failures, "appLiveVerified": appVerified, "helperLiveVerified": helperVerified, "cliKernelExit": !childExitAt.IsZero(), "helperKernelExit": !helperExitAt.IsZero(), "verifierReports": reports.count, "requiredLaneBaselineAllTrue": reports.baseline, "requiredLaneTokenMismatch": reports.refused, "observerComplete": reports.complete, "independentRefusalUpperMs": upperDelay.Seconds() * 1000, "states": stateEvidence, "fullFrameHandoffProven": which == "frame-handoff" && len(failures) == 0, "decodedBaselineCount": frameCount, "baselineAcknowledged": !baselineAckAt.IsZero(), "decodedSequence": decodedSequence, "baselineRequests": baselineControl.attempts, "lateFramesDiscarded": lateFrames, "requestTimes": requestTimes, "controlledHubReleaseMs": releaseAt.Sub(start).Seconds() * 1000, "earliestClockOriginMs": lower.Sub(start).Seconds() * 1000, "earliestLeaseExpiryMs": lower.Add(time.Duration((sent.Elapsed+1500)*1e6)).Sub(start).Seconds() * 1000}
	raw, _ := json.MarshalIndent(facts, "", "  ")
	for name, data := range map[string][]byte{"milestones.ndjson": output.data, "driver-observations.json": append(raw, '\n'), "stderr.txt": stderr.data} {
		if os.WriteFile(filepath.Join(evidence, name), data, 0600) != nil {
			t.Fatal("private evidence write failed")
		}
	}
	if len(failures) > 0 {
		t.Fatal(failures)
	}
	t.Logf("signed %s PASS", which)
}
