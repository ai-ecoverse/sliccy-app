package integration

import (
	"strings"
	"testing"
)

func TestRunnerUnionRequiresEveryIndependentOwnerAndProtectsSecurityAgent(t *testing.T) {
	makeFixture:=func()([]runnerUnionOwnerClaim,[]runnerUnionWindowClaim,map[int]runnerUnionOwnerFact,[]independentWindow,map[uint32]independentWindow,[]runnerWindowClaim,runnerInventoryCounts){
		var owners []runnerUnionOwnerClaim;var windows []runnerUnionWindowClaim;facts:=map[int]runnerUnionOwnerFact{};var actual []independentWindow;var sc []runnerWindowClaim;supplemental:=map[uint32]independentWindow{}
		for i,role:=range []string{"ai.sliccy.proof-helper","ai.sliccy.mac","com.apple.SecurityAgent","com.apple.dock"}{
			pid:=10+i;kind:=[]string{"allowed","app","authorization","system"}[i];label:=[]string{"allowed","app","authorization","dock"}[i];identifier:=strings.Repeat("1",40)
			bsd:=runnerBSDValue{PID:int64(pid),Parent:1,Effective:501,Real:501,Saved:501,Seconds:20,Microseconds:1}
			fact:=runnerUnionOwnerFact{Label:label,Identifier:role,Hash:identifier,BSD:bsd,CodeBound:true,Platform:i>=2}
			facts[pid]=fact
			claim:=runnerUnionOwnerClaim{PID:pid,Parent:1,UID:501,Seconds:20,Microseconds:1,Identifier:role,Hash:identifier,Apple:i>=2,Verified:true}
			if i>=2{r,s:=uint32(501),uint32(501);claim.Real=&r;claim.Saved=&s}
			owners=append(owners,claim)
			rect:=independentRect{X:float64(100*i),Y:100,Width:100,Height:100};id:=uint32(i+1)
			window:=runnerUnionWindowClaim{ID:id,PID:pid,Identifier:role,Kind:kind,InCG:i!=3,InSCK:true,Selectable:i==0,Rect:rect}
			windows=append(windows,window)
			observed:=independentWindow{ID:id,PID:pid,Rect:rect,OnScreen:i!=3}
			if i==3{supplemental[id]=observed}else{actual=append(actual,observed)}
			sc=append(sc,runnerWindowClaim{Label:label,PID:pid,ID:id,Rect:rect,Profile:"none"})
		}
		return owners,windows,facts,actual,supplemental,sc,runnerInventoryCounts{4,4}
	}
	o,w,f,a,s,sc,n:=makeFixture()
	if e:=matchRunnerUnion(o,w,f,a,s,sc,n);e!=nil{t.Fatalf("ASSERTION:complete-union-control %v",e)}
	for i:=range a{a[i].TitleVisible=true;a[i].Title="diagnostic text has no authority"}
	if e:=matchRunnerUnion(o,w,f,a,s,sc,n);e!=nil{t.Fatalf("ASSERTION:union-titles-diagnostic %v",e)}
	for _,mode:=range []string{"unknown-owner","missing-window","wrong-owner","wrong-bounds","missing-signature","nonplatform-agent","agent-selected","agent-api-gap","system-selected","missing-system-witness","wrong-system-witness","owner-uid","owner-start","owner-hash","owner-role","apple-marker","owner-unverified","duplicate-window","duplicate-owner","sc-omission","sc-duplicate","sc-wrong-label","sc-owner-count","api-claim"}{
		o,w,f,a,s,sc,n=makeFixture()
		switch mode{
		case "unknown-owner":a=append(a,independentWindow{ID:90,PID:99,Rect:independentRect{0,0,1,1},OnScreen:true})
		case "missing-window":a=append(a,independentWindow{ID:90,PID:10,Rect:independentRect{0,0,1,1},OnScreen:true})
		case "wrong-owner":a[0].PID=11
		case "wrong-bounds":a[0].Rect.X++
		case "missing-signature":v:=f[12];v.CodeBound=false;f[12]=v
		case "nonplatform-agent":v:=f[12];v.Platform=false;f[12]=v
		case "agent-selected":w[2].Selectable=true
		case "agent-api-gap":w[2].InSCK=false;sc=sc[:2];n.Processes=2;n.Windows=2
		case "system-selected":w[3].Selectable=true
		case "missing-system-witness":delete(s,4)
		case "wrong-system-witness":v:=s[4];v.PID=10;s[4]=v
		case "owner-uid":o[0].UID++
		case "owner-start":o[0].Seconds++
		case "owner-hash":o[0].Hash=strings.Repeat("2",40)
		case "owner-role":o[0].Identifier="ai.sliccy.mac"
		case "apple-marker":o[2].Apple=false
		case "owner-unverified":o[0].Verified=false
		case "duplicate-window":w=append(w,w[0])
		case "duplicate-owner":o=append(o,o[0])
		case "sc-omission":sc=sc[:3];n.Windows=3
		case "sc-duplicate":sc[1]=sc[0]
		case "sc-wrong-label":sc[2].Label="allowed"
		case "sc-owner-count":n.Processes=3
		case "api-claim":w[0].InCG=false
		}
		if matchRunnerUnion(o,w,f,a,s,sc,n)==nil{t.Errorf("ASSERTION:union-refuse-%s",mode)}
	}
}
