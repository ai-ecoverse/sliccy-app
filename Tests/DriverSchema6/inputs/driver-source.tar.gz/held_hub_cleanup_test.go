package integration

import (
	"context"
	"io"
	"net"
	"net/http"
	"testing"
	"time"
)

func TestHeldHubCleanupReleasesPendingRequest(t *testing.T) {
	gate := make(chan struct{})
	h := newFakeHub(t)
	h.proofGate = gate
	active := make(chan struct{}, 1)
	h.srv.Config.ConnState = func(_ net.Conn, state http.ConnState) {
		if state == http.StateActive {
			select {
			case active <- struct{}{}:
			default:
			}
		}
	}
	done := make(chan struct{})
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	t.Cleanup(cancel)
	go func() {
		defer close(done)
		req, e := http.NewRequestWithContext(ctx, http.MethodGet, h.srv.URL, nil)
		if e != nil {
			return
		}
		response, e := http.DefaultClient.Do(req)
		if e == nil {
			_, _ = io.Copy(io.Discard, response.Body)
			_ = response.Body.Close()
		}
	}()
	select {
	case <-active:
	case <-time.After(time.Second):
		t.Fatal("held request did not enter server")
	}
	t.Cleanup(func() {
		select {
		case <-done:
		case <-time.After(time.Second):
			t.Error("pending request did not finish after gate release")
		}
	})
	t.Cleanup(func() { close(gate) })
}
