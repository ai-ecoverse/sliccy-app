package integration

import (
	"fmt"
 "io"
	"testing"
	"time"
)

type runnerClockBound struct {
	Lower, Upper time.Time
	Valid        bool
}

func boundRunnerClock(sent, received time.Time, eventMs float64) (runnerClockBound, error) {
	if sent.IsZero() || received.Before(sent) || !finiteNonnegative(eventMs) || eventMs > float64(runnerCaseAbsoluteBudget/time.Millisecond) {
		return runnerClockBound{}, fmt.Errorf("invalid causal marker clock")
	}
	delta := time.Duration(eventMs * float64(time.Millisecond))
	return runnerClockBound{sent.Add(-delta), received.Add(-delta), true}, nil
}
func (b runnerClockBound) latencyUpper(at time.Time, eventMs float64) (time.Duration, error) {
	if !b.Valid || !finiteNonnegative(eventMs) || eventMs > float64(runnerCaseAbsoluteBudget/time.Millisecond) {
		return 0, fmt.Errorf("missing causal clock bound")
	}
	value := at.Sub(b.Lower.Add(time.Duration(eventMs * float64(time.Millisecond))))
	if value < 0 {
		return 0, fmt.Errorf("wire result preceded earliest possible request")
	}
	return value, nil
}
func TestRunnerClockUsesCausalLowerBoundRatherThanLateRowDelivery(t *testing.T) {
	epoch := time.Unix(100, 0)
	sent := epoch.Add(time.Second)
	received := sent.Add(100 * time.Millisecond)
	bound, e := boundRunnerClock(sent, received, 1000)
	if e != nil {
		t.Fatal(e)
	}
	measured, e := bound.latencyUpper(epoch.Add(2600*time.Millisecond), 1100)
	if e != nil || measured != 1500*time.Millisecond {
		t.Fatal("wrong worst-case causal latency", measured, e)
	}
	delayed, e := boundRunnerClock(sent, received.Add(time.Second), 1000)
	if e != nil {
		t.Fatal(e)
	}
	again, e := delayed.latencyUpper(epoch.Add(2600*time.Millisecond), 1100)
	if e != nil || again != measured {
		t.Fatal("late delivery falsely improved latency proof", again, e)
	}
	if _, e := (runnerClockBound{}).latencyUpper(epoch, 0); e == nil {
		t.Fatal("missing marker bound accepted")
	}
}

func runnerWireStopLatency(selected string, clock runnerClockBound, at time.Time, appEvent float64, viewerSent time.Time) (time.Duration, error) {
	if selected == "reciprocal-revoke" {
		if viewerSent.IsZero() || at.Before(viewerSent) {
			return 0, fmt.Errorf("wire invalidation preceded remote request")
		}
		return at.Sub(viewerSent), nil
	}
	return clock.latencyUpper(at, appEvent)
}
func TestRunnerReciprocalWireResetCanPrecedeAppRevokeObservation(t *testing.T) {
	epoch := time.Unix(100, 0)
	clock := runnerClockBound{Lower: epoch, Upper: epoch.Add(time.Millisecond), Valid: true}
	elapsed, e := runnerWireStopLatency("reciprocal-revoke", clock, epoch.Add(1100*time.Millisecond), 1200, epoch.Add(time.Second))
	if e != nil || elapsed != 100*time.Millisecond {
		t.Fatal("node-first invalidation was incorrectly timed from later app receipt", e)
	}
	if _, e := runnerWireStopLatency("reciprocal-revoke", clock, epoch, 0, epoch.Add(time.Second)); e == nil {
		t.Fatal("pre-request reset accepted")
	}
}


type runnerClockExchange struct {
 Before,After,Received time.Time
 EventMS float64
}

func (e runnerClockExchange) Bound()(runnerClockBound,error) {
 if e.Before.IsZero()||e.After.Before(e.Before) {return runnerClockBound{},fmt.Errorf("clock write bracket invalid")}
 return boundRunnerClock(e.Before,e.Received,e.EventMS)
}

func intersectRunnerClocks(old,next runnerClockBound)(runnerClockBound,error) {
 if !next.Valid {return runnerClockBound{},fmt.Errorf("new clock interval unavailable")}
 if !old.Valid {return next,nil}
 if old.Upper.Before(old.Lower)||next.Upper.Before(next.Lower) {return runnerClockBound{},fmt.Errorf("clock interval inverted")}
 lower,upper:=old.Lower,old.Upper
 if next.Lower.After(lower){lower=next.Lower}
 if next.Upper.Before(upper){upper=next.Upper}
 if upper.Before(lower){return runnerClockBound{},fmt.Errorf("causal clock intervals disagree")}
 return runnerClockBound{Lower:lower,Upper:upper,Valid:true},nil
}

func runnerWriteClockAnchor(w io.Writer)(exchange runnerClockExchange,err error) {
 exchange.Before=time.Now()
 n,err:=io.WriteString(w,"runner-clock-anchor\n")
 exchange.After=time.Now()
 if err==nil&&n!=len("runner-clock-anchor\n"){err=io.ErrShortWrite}
 return exchange,err
}
