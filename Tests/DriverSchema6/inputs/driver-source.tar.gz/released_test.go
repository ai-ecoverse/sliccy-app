package integration

import (
	"context"
	"encoding/json"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/link"
	"github.com/pion/webrtc/v4"
)

type observedProofState struct {
	Seq    string    `json:"stateSeq"`
	Caps   []string  `json:"caps"`
	Reason string    `json:"reason"`
	At     time.Time `json:"-"`
}

func proofPage(t *testing.T) (*link.Link, string) {
	t.Helper()
	page, join, _ := proofPageWithStates(t)
	return page, join
}
func proofPageWithStates(t *testing.T) (*link.Link, string, <-chan observedProofState) {
	return proofPageControlled(t, nil)
}
func proofPageControlled(t *testing.T, gate <-chan struct{}) (*link.Link, string, <-chan observedProofState) {
	return proofPageUsing(t, gate, nil)
}
func proofPageUsing(t *testing.T, gate <-chan struct{}, handler link.Handler) (*link.Link, string, <-chan observedProofState) {
	return proofPageUsingHub(t, gate, handler, nil)
}
func proofPageUsingHub(t *testing.T, gate <-chan struct{}, handler link.Handler, configure func(*fakeHub)) (*link.Link, string, <-chan observedProofState) {
	t.Helper()
	states := make(chan observedProofState, 16)
	api := link.NewAPI(link.APIOptions{Loopback: true})
	pc, err := api.NewPeerConnection(webrtc.Configuration{})
	if err != nil {
		t.Fatal("fixture peer allocation failed")
	}
	if handler == nil {
		handler = func(s *link.Stream) {
			var state observedProofState
			if json.Unmarshal(s.OpenPayload(), &state) != nil || len(state.Caps) != 0 {
				t.Error("diagnostic received an invalid or active grant")
				_ = s.Reset("EACCES")
				return
			}
			state.At = time.Now()
			select {
			case states <- state:
			default:
				t.Error("unbounded diagnostic state")
				_ = s.Reset("EBUSY")
				return
			}
			_ = s.Accept(nil)
			_ = s.CloseWrite()
		}
	}
	page, err := link.New(pc, link.RolePage, link.Options{Hello: link.Hello{Caps: []string{"screen-state"}}, Handlers: map[string]link.Handler{"screen-state": handler}})
	if err != nil {
		t.Fatal("fixture link allocation failed")
	}
	t.Cleanup(func() { _ = page.Close() })
	offer, err := pc.CreateOffer(nil)
	if err != nil {
		t.Fatal("fixture offer failed")
	}
	gathered := webrtc.GatheringCompletePromise(pc)
	if pc.SetLocalDescription(offer) != nil {
		t.Fatal("fixture local description failed")
	}
	select {
	case <-gathered:
	case <-time.After(10 * time.Second):
		t.Fatal("fixture gathering deadline")
	}
	h := newFakeHub(t)
	if configure != nil {
		configure(h)
	}
	h.proofGate = gate
	tr := h.addTray("nativeproof")
	h.with(func() {
		tr.OfferSDP = pc.LocalDescription().SDP
		tr.IceServers = []map[string]any{}
		tr.OnFollower = func(action string, _ *hubBootstrap, body map[string]any) {
			switch action {
			case "answer":
				answer, _ := body["answer"].(map[string]any)
				sdp, _ := answer["sdp"].(string)
				if pc.SetRemoteDescription(webrtc.SessionDescription{Type: webrtc.SDPTypeAnswer, SDP: sdp}) != nil {
					t.Error("fixture answer rejected")
				}
			case "ice-candidate":
				raw, err := json.Marshal(body["candidate"])
				var candidate webrtc.ICECandidateInit
				if err != nil || json.Unmarshal(raw, &candidate) != nil || pc.AddICECandidate(candidate) != nil {
					t.Error("fixture candidate rejected")
				}
			}
		}
	})
	return page, h.joinURL(tr), states
}

func proofEnvironment(t *testing.T) []string {
	t.Helper()
	home := t.TempDir()
	tmp := filepath.Join(home, "tmp")
	if os.Mkdir(tmp, 0700) != nil {
		t.Fatal("fixture storage unavailable")
	}
	return []string{"HOME=" + home, "TMPDIR=" + tmp, "PATH=/usr/bin:/bin:/usr/sbin:/sbin", "SLICC_NO_TELEMETRY=1", "SLICC_NO_UPDATE_CHECK=1"}
}

func TestReleasedCLIOnlyLoopbackFixture(t *testing.T) {
	binary := os.Getenv("SLICC_RELEASE_PROOF_BINARY")
	if binary == "" {
		t.Fatal("released CLI locator required")
	}
	page, join := proofPage(t)
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, binary, "-", "follow", "--name", "native-proof-fixture")
	cmd.Env = proofEnvironment(t)
	cmd.Stdin = strings.NewReader(join + "\n")
	cmd.Stdout = io.Discard
	cmd.Stderr = io.Discard
	if cmd.Start() != nil {
		t.Fatal("released CLI launch failed")
	}
	done := make(chan error, 1)
	go func() { done <- cmd.Wait() }()
	t.Cleanup(func() { cancel(); <-done })
	select {
	case <-page.Ready():
	case <-page.Done():
		t.Fatal("fixture link failed before HELLO")
	case <-ctx.Done():
		t.Fatal("released CLI did not establish loopback link")
	}
	hello, ok := page.PeerHello()
	if !ok || hello.Version != "1.58.1" {
		t.Fatal("fixture did not receive released CLI HELLO")
	}
	t.Log("unchanged released CLI established local Pion link; no browser, native grant, or image stream")
}
