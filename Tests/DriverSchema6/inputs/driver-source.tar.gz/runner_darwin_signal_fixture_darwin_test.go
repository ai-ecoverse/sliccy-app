package integration
import (
 "bufio"
 "bytes"
 "encoding/json"
 "encoding/hex"
 "crypto/sha256"
 "os"
 "syscall"
 "testing"
)
func TestRunnerFoundationSignalRecordsUseDarwinConstants(t *testing.T){
 data,err:=os.ReadFile(os.Getenv("SLICCY_RECEIPT_FIXTURE"));if err!=nil{t.Fatal(err)}
 names:=map[int64]string{int64(syscall.SIGCONT):"SIGCONT",int64(syscall.SIGTERM):"SIGTERM",int64(syscall.SIGKILL):"SIGKILL"}
 expected:=map[int64]bool{int64(syscall.SIGCONT):false,int64(syscall.SIGTERM):false,int64(syscall.SIGKILL):false}
 scanner:=bufio.NewScanner(bytes.NewReader(data));scanner.Buffer(make([]byte,4096),4096)
 for scanner.Scan(){
  var fields map[string]json.RawMessage;if json.Unmarshal(scanner.Bytes(),&fields)!=nil{t.Fatal("fixture JSON invalid")}
  var site string;_ = json.Unmarshal(fields["site"],&site);if site!="child-signal"{continue}
  var compared map[string]json.RawMessage;if json.Unmarshal(fields["compared"],&compared)!=nil{t.Fatal("signal comparison unavailable")}
  signal,err:=runnerInt(compared,"signal",-2147483648,2147483647);if err!=nil{t.Fatal(err)}
  if _,ok:=expected[signal];!ok{t.Fatal("fixture emitted unrecognized platform signal")}
  row,err:=decodeRunnerCaptureRow(scanner.Bytes())
  if err!=nil||row.Receipt==nil||row.Receipt.Code==nil||!row.Receipt.Code.Passed{t.Fatalf("ASSERTION:darwin-signal-encoder-parser-%s %v",names[signal],err)}
  expected[signal]=true
 }
 if scanner.Err()!=nil {t.Fatal(scanner.Err())}
 for signal,seen:=range expected{if !seen{t.Fatalf("ASSERTION:darwin-signal-complete-%s",names[signal])}}
}
func TestRunnerDarwinStopSignalsAreNotContinueReceipts(t *testing.T){
 data,err:=os.ReadFile(os.Getenv("SLICCY_RECEIPT_FIXTURE"));if err!=nil{t.Fatal(err)}
 scanner:=bufio.NewScanner(bytes.NewReader(data));scanner.Buffer(make([]byte,4096),4096)
 var original map[string]json.RawMessage
 for scanner.Scan(){var fields map[string]json.RawMessage;if json.Unmarshal(scanner.Bytes(),&fields)!=nil{t.Fatal("invalid fixture")};var site string;_ = json.Unmarshal(fields["site"],&site);if site=="child-signal"{original=fields;break}}
 if original==nil{t.Fatal("actual Foundation signal receipt missing")}
 for _,signal:=range []syscall.Signal{syscall.SIGSTOP,syscall.SIGTSTP}{
  fields:=map[string]json.RawMessage{};for k,v:=range original{fields[k]=append([]byte(nil),v...)}
  var compared map[string]json.RawMessage;if json.Unmarshal(fields["compared"],&compared)!=nil{t.Fatal("comparison fixture missing")}
  compared["signal"],_=json.Marshal(int(signal));fields["compared"],_=json.Marshal(compared)
  core:=map[string]json.RawMessage{};for _,key:=range []string{"role","site","passed","step","statuses","selected","compared"}{core[key]=fields[key]}
  canonical,err:=runnerReceiptCanonical(core);if err!=nil{t.Fatal(err)};digest:=sha256.Sum256(canonical);fields["receiptKey"],_=json.Marshal(hex.EncodeToString(digest[:]))
  raw,err:=json.Marshal(fields);if err!=nil{t.Fatal(err)}
  if _,err:=decodeRunnerCaptureRow(raw);err==nil{t.Fatalf("ASSERTION:darwin-stop-signal-refused-%d",signal)}
 }
}
