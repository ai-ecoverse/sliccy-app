package integration

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestSignedRunnerCapture(t *testing.T) {
	root, app, manifest := os.Getenv("SLICC_RUNNER_PROOF_ROOT"), os.Getenv("SLICCY_SIGNED_PROOF_APP"), os.Getenv("SLICCY_CAPTURE_MANIFEST")
	if root == "" || app == "" || manifest == "" {
		t.Fatal("fixed reviewed capture artifact and private evidence locators required")
	}
	if runnerPlacement() != nil || runnerRequireEvidenceRoot(root) != nil {
		t.Fatal("reviewed isolated hosted capture context required")
	}
	if os.Getenv("GH_TOKEN") != "" || os.Getenv("GITHUB_TOKEN") != "" {
		t.Fatal("artifact download credentials must not reach driver")
	}
	preflightCtx, preflightCancel := context.WithTimeout(context.Background(), 5*time.Second)
	version, e := exec.CommandContext(preflightCtx, "/usr/bin/sw_vers", "-productVersion").Output()
	preflightCancel()
	if e != nil || strings.TrimSpace(string(version)) != os.Getenv("SLICCY_RUNNER_OS_VERSION") || !strings.HasPrefix(strings.TrimSpace(string(version)), "27.") {
		t.Fatal("actual hosted macOS27 version not independently established")
	}
	if _, e := runnerArtifactHashes(app, manifest); e != nil {
		t.Fatal("fixed build13 immutable fixture mismatch")
	}
	suite, cancel := context.WithTimeout(context.Background(), 450*time.Second)
	defer cancel()
	budget := &runnerImageBudget{}
	var results []runnerCaseResult
	dirty := false
	for _, selected := range []string{"selected-window", "display-exclusion", "authorization-exclusion", "reciprocal-revoke", "active-stop", "hotkey-stop"} {
		t.Run(selected, func(t *testing.T) {
			if suite.Err() != nil || dirty {
				result := runnerCaseResult{Schema: 1, Case: selected, Result: "FAILED_TO_DEMONSTRATE", Failures: []string{"suite deadline exhausted or prior cleanup unconfirmed; no launch"}}
				results = append(results, result)
				t.Error("runner case not demonstrated; private evidence retained")
				return
			}
			result := runRunnerCaptureCase(t, suite, selected, app, manifest, root, budget)
			if runnerBlocksLaterCases(result) {
				dirty = true
			}
			results = append(results, result)
			if result.Result != "PASS" {
				t.Error("runner case did not pass; inspect sealed private evidence")
			}
		})
	}
	summary := map[string]any{"schema": 1, "sourceCommit": "91c1b3ef7aae7a4f2581a2ca6631a740d5556755", "signedRun": uint64(41926563094), "version": "0.1.0", "build": "11", "cliVersion": "1.59.0", "cases": results, "productionEnabled": false, "extraCaptureClasses": map[string]string{"System Settings": "UNTESTED", "TCC-specific prompts": "UNTESTED", "password-specific surfaces": "UNTESTED"}, "proofScope": "fixed synthetic hosted surfaces and explicitly observed classes only", "artifactUnchanged": true}
	if _, e := runnerArtifactHashes(app, manifest); e != nil {
		summary["artifactUnchanged"] = false
		t.Error("immutable fixture changed during suite")
	}
	if e := runnerSaveJSON(filepath.Join(root, "capture-suite.json"), summary); e != nil {
		t.Fatal("private suite summary write failed")
	}
	if suite.Err() != nil {
		t.Error("capture suite exceeded fixed deadline")
	}
}
func TestRunnerEntryRejectsLocalBeforeAnyWindowOrAppOperation(t *testing.T) {
	if e := runnerPlacement(); e == nil && os.Getenv("GITHUB_ACTIONS") != "true" {
		t.Fatal("local placement accepted")
	}
	for _, path := range []string{"", "relative", "/private/tmp/../tmp/untrusted"} {
		if e := runnerRequireEvidenceRoot(path); e == nil {
			t.Fatal(fmt.Sprintf("invalid evidence root accepted: %q", path))
		}
	}
}
