package integration

import (
	"fmt"
	"html"
	"io"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

type fixedProofPage struct {
	Path    string          `json:"path"`
	Profile string          `json:"profile"`
	Title   string          `json:"title"`
	RGB     [3]int          `json:"sRGB"`
	Rect    independentRect `json:"rectCGPoints"`
}

var fixedProofPageCatalog = [4]fixedProofPage{
	{"/screen-proof/host-a-1", "a-1", "Sliccy proof host A1", [3]int{224, 32, 192}, independentRect{416, 64, 288, 224}},
	{"/screen-proof/host-a-2", "a-2", "Sliccy proof host A2", [3]int{24, 200, 208}, independentRect{720, 64, 288, 224}},
	{"/screen-proof/host-b-1", "b-1", "Sliccy proof host B1", [3]int{248, 120, 24}, independentRect{416, 320, 288, 224}},
	{"/screen-proof/host-b-2", "b-2", "Sliccy proof host B2", [3]int{128, 64, 224}, independentRect{720, 320, 288, 224}},
}

type fixedProofPages struct {
	host      string
	mu        sync.Mutex
	requests  int
	delivered map[string]int
 deliveries []runnerPageDelivery
}

func newFixedProofPages(origin string) (*fixedProofPages, error) {
	u, e := url.Parse(origin)
	if e != nil || u.Scheme != "http" || u.Hostname() != "127.0.0.1" || u.User != nil || u.Path != "" || u.RawQuery != "" || u.ForceQuery || u.Fragment != "" {
		return nil, fmt.Errorf("exact loopback origin required")
	}
	_, port, e := net.SplitHostPort(u.Host)
	if e != nil {
		return nil, e
	}
	n, e := strconv.Atoi(port)
	if e != nil || n < 1 || n > 65535 || (n >= 9222 && n <= 9229) {
		return nil, fmt.Errorf("unapproved loopback port")
	}
	return &fixedProofPages{host: u.Host, delivered: map[string]int{}}, nil
}
func fixedProofHTML(page fixedProofPage) string {
	return fmt.Sprintf("<!doctype html><html><head><meta charset=utf-8><title>%s</title><style>html,body{margin:0;min-height:100%%;background:rgb(%d,%d,%d);color:white;font:16px monospace}h1{margin:16px;font:inherit}</style></head><body><h1>%s</h1></body></html>", html.EscapeString(page.Title), page.RGB[0], page.RGB[1], page.RGB[2], html.EscapeString(page.Title))
}
func (p *fixedProofPages) serve(w http.ResponseWriter, r *http.Request) bool {
	if !strings.HasPrefix(r.URL.Path, "/screen-proof/") {
		return false
	}
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
	w.Header().Set("Referrer-Policy", "no-referrer")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	if r.Method != http.MethodGet && r.Method != http.MethodHead {
		w.WriteHeader(http.StatusMethodNotAllowed)
		return true
	}
	if r.Host != p.host || r.URL.IsAbs() || r.URL.RawPath != "" || r.URL.RawQuery != "" || r.URL.ForceQuery || r.URL.Fragment != "" || r.ContentLength > 0 || len(r.TransferEncoding) > 0 {
		w.WriteHeader(http.StatusBadRequest)
		return true
	}
	var page *fixedProofPage
	for i := range fixedProofPageCatalog {
		if r.URL.Path == fixedProofPageCatalog[i].Path {
			page = &fixedProofPageCatalog[i]
			break
		}
	}
	if page == nil {
		w.WriteHeader(http.StatusNotFound)
		return true
	}
	p.mu.Lock()
	p.requests++
	allowed := p.requests <= 64
	p.mu.Unlock()
	if !allowed {
		w.WriteHeader(http.StatusTooManyRequests)
		return true
	}
	body := fixedProofHTML(*page)
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Content-Length", strconv.Itoa(len(body)))
	w.WriteHeader(http.StatusOK)
	if r.Method == http.MethodGet {
		n, e := io.WriteString(w, body)
		if e == nil && n == len(body) {
			p.mu.Lock()
			p.delivered[page.Path]++
 p.deliveries=append(p.deliveries,runnerPageDelivery{Path:page.Path,At:time.Now()})
			p.mu.Unlock()
		}
	}
	return true
}
func (h *fakeHub) enableFixedProofPages() (*fixedProofPages, error) {
	p, e := newFixedProofPages(h.srv.URL)
	if e != nil {
		return nil, e
	}
	h.mu.Lock()
	h.proofPages = p
	h.mu.Unlock()
	return p, nil
}
func TestRunnerStaticPagesBypassHeldJoinWithoutLeakingCapability(t *testing.T) {
	h := newFakeHub(t)
	gate := make(chan struct{})
	h.proofGate = gate
	t.Cleanup(func() { close(gate) })
	pages, e := h.enableFixedProofPages()
	if e != nil {
		t.Fatal(e)
	}
	tray := h.addTray("static")
	join := h.joinURL(tray)
	client := &http.Client{Timeout: time.Second}
	for _, page := range fixedProofPageCatalog {
		res, e := client.Get(h.srv.URL + page.Path)
		if e != nil {
			t.Fatal("fixed page blocked on held join", e)
		}
		body, e := io.ReadAll(io.LimitReader(res.Body, 4096))
		_ = res.Body.Close()
		if e != nil || res.StatusCode != 200 || string(body) != fixedProofHTML(page) || strings.Contains(string(body), tray.Token) || strings.Contains(string(body), join) {
			t.Fatal("wrong or capability-bearing static page")
		}
		if res.Header.Get("Referrer-Policy") != "no-referrer" || !strings.Contains(res.Header.Get("Content-Security-Policy"), "default-src 'none'") {
			t.Fatal("page unexpectedly permits external content")
		}
	}
	if len(h.requestLog()) != 0 {
		t.Fatal("static page request logged as join traffic")
	}
	pages.mu.Lock()
	defer pages.mu.Unlock()
	for _, page := range fixedProofPageCatalog {
		if pages.delivered[page.Path] != 1 {
			t.Fatal("fixed GET not tracked separately")
		}
	}
}
func TestRunnerStaticPagesRejectUnfixedRequestsAndBoundAdmission(t *testing.T) {
	h := newFakeHub(t)
	p, e := h.enableFixedProofPages()
	if e != nil {
		t.Fatal(e)
	}
	client := &http.Client{Timeout: time.Second}
	for _, tc := range []struct {
		method, path string
		status       int
	}{{"GET", "/screen-proof/unknown", 404}, {"POST", "/screen-proof/host-a-1", 405}, {"GET", "/screen-proof/host-a-1?secret=forbidden", 400}, {"GET", "/screen-proof/%68ost-a-1", 400}, {"HEAD", "/screen-proof/host-a-1", 200}} {
		req, e := http.NewRequest(tc.method, h.srv.URL+tc.path, nil)
		if e != nil {
			t.Fatal(e)
		}
		res, e := client.Do(req)
		if e != nil {
			t.Fatal(e)
		}
		_ = res.Body.Close()
		if res.StatusCode != tc.status {
			t.Fatal("unfixed request admitted", tc.path, res.StatusCode)
		}
	}
	for i := 0; i < 64; i++ {
		res, e := client.Get(h.srv.URL + fixedProofPageCatalog[0].Path)
		if e != nil {
			t.Fatal(e)
		}
		_ = res.Body.Close()
		want := 200
		if i == 63 {
			want = 429
		}
		if res.StatusCode != want {
			t.Fatal("fixed-page admission budget wrong", i, res.StatusCode)
		}
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.delivered[fixedProofPageCatalog[0].Path] != 63 {
		t.Fatal("HEAD counted as delivered page")
	}
	for _, origin := range []string{"https://127.0.0.1:10001", "http://localhost:10001", "http://127.0.0.1:9222", "http://127.0.0.1:10001/join/token", "http://user@127.0.0.1:10001", "http://127.0.0.1:10001?token=x"} {
		if _, e := newFixedProofPages(origin); e == nil {
			t.Fatal("non-origin/non-loopback accepted")
		}
	}
}


type runnerPageDelivery struct {Path string `json:"path"`;At time.Time `json:"at"`}
func(p *fixedProofPages) deliverySnapshot()[]runnerPageDelivery {p.mu.Lock();defer p.mu.Unlock();return append([]runnerPageDelivery(nil),p.deliveries...)}
