package integration

import (
	"encoding/json"
	"fmt"
	"math"
	"strings"
)

type runnerUnionOwnerClaim struct {
	PID, Parent                  int
	UID                          uint32
	Seconds, Microseconds        uint64
	Identifier, Hash             string
	Apple, Verified, SysctlBound bool
	Real, Saved                  *uint32
}

type runnerUnionWindowClaim struct {
	ID                      uint32
	PID                     int
	Identifier, Kind        string
	InCG, InSCK, Selectable bool
	Layer                   int64
	Rect                    independentRect
}

type runnerUnionOwnerFact struct {
	Label, Identifier, Hash string
	BSD                     runnerBSDValue
	CodeBound, Platform     bool
	Before, After           runnerBSDReceipt
}

func runnerDecodeUnionOwner(row runnerCaptureRow) (runnerUnionOwnerClaim, error) {
	var v runnerUnionOwnerClaim
	f := row.Fields
	if row.Stage != "inventory-owner" {
		return v, fmt.Errorf("not an inventory owner")
	}
	number := func(key string, low, high int64) (int64, error) { return runnerInt(f, key, low, high) }
	pid, e := number("pid", 1, math.MaxInt32)
	if e != nil {
		return v, e
	}
	v.PID = int(pid)
	parent, e := number("parent", 0, math.MaxInt32)
	if e != nil {
		return v, e
	}
	v.Parent = int(parent)
	uid, e := number("uid", 0, math.MaxUint32)
	if e != nil {
		return v, e
	}
	v.UID = uint32(uid)
	if v.Seconds, e = runnerReceiptCounter(f["startSeconds"]); e != nil || v.Seconds == 0 {
		return v, fmt.Errorf("invalid owner start")
	}
	micros, e := number("startMicroseconds", 0, 999999)
	if e != nil {
		return v, e
	}
	v.Microseconds = uint64(micros)
	if v.Identifier, e = runnerText(f, "identifier"); e != nil {
		return v, e
	}
	if v.Hash, e = runnerText(f, "cdHash"); e != nil || !runnerHexHash(v.Hash) {
		return v, fmt.Errorf("invalid owner hash")
	}
	if v.Apple, e = runnerBool(f, "appleAnchored"); e != nil {
		return v, e
	}
	if v.Verified, e = runnerBool(f, "verified"); e != nil {
		return v, e
	}
	if v.SysctlBound, e = runnerBool(f, "sysctlBound"); e != nil {
		return v, e
	}
	for key, target := range map[string]**uint32{"realUID": &v.Real, "savedUID": &v.Saved} {
		if string(f[key]) != "null" {
			n, err := number(key, 0, math.MaxUint32)
			if err != nil {
				return v, err
			}
			value := uint32(n)
			*target = &value
		}
	}
	return v, nil
}

func runnerDecodeUnionWindow(row runnerCaptureRow) (runnerUnionWindowClaim, error) {
	var v runnerUnionWindowClaim
	f := row.Fields
	if row.Stage != "inventory-window" {
		return v, fmt.Errorf("not an inventory window")
	}
	id, e := runnerInt(f, "windowID", 1, math.MaxUint32)
	if e != nil {
		return v, e
	}
	v.ID = uint32(id)
	pid, e := runnerInt(f, "pid", 1, math.MaxInt32)
	if e != nil {
		return v, e
	}
	v.PID = int(pid)
	if v.Identifier, e = runnerText(f, "identifier"); e != nil {
		return v, e
	}
	if v.Kind, e = runnerText(f, "kind"); e != nil {
		return v, e
	}
	if v.InCG, e = runnerBool(f, "inCG"); e != nil {
		return v, e
	}
	if v.InSCK, e = runnerBool(f, "inSCK"); e != nil {
		return v, e
	}
	if v.Selectable, e = runnerBool(f, "selectable"); e != nil {
		return v, e
	}
	if v.Layer, e = runnerInt(f, "layer", math.MinInt32, math.MaxInt32); e != nil {
		return v, e
	}
	if v.Rect, e = runnerGeometry(f["rect"]); e != nil {
		return v, e
	}
	return v, nil
}

func runnerSystemRole(role string) bool {
	return runnerOneOf(role, "com.apple.WindowManager com.apple.dock com.apple.finder com.apple.WindowServer")
}

func runnerUnionKind(f runnerUnionOwnerFact) (string, error) {
	if !f.CodeBound || f.BSD.PID <= 0 || f.BSD.Seconds == 0 || !runnerHexHash(f.Hash) {
		return "", fmt.Errorf("unbound independent owner")
	}
	if runnerSystemRole(f.Identifier) {
		if !f.Platform {
			return "", fmt.Errorf("system owner lacks Apple platform identity")
		}
		if f.Identifier == "com.apple.WindowServer" {
			selected, e := runnerBSDReceiptPair(f.Before, f.After)
			if e != nil || !runnerBSDEqual(selected, &f.BSD) {
				return "", fmt.Errorf("WindowServer stable controlled identity missing")
			}
		}
		return "system", nil
	}
	if f.Identifier == "com.apple.SecurityAgent" {
		if !f.Platform {
			return "", fmt.Errorf("authorization owner is not platform code")
		}
		return "authorization", nil
	}
	if f.Identifier == "ai.sliccy.mac" && f.Label == "app" {
		return "app", nil
	}
	if f.Identifier == "ai.sliccy.proof-helper" && f.Label == "allowed" {
		return "allowed", nil
	}
	if f.Identifier == "com.google.Chrome" && runnerOneOf(f.Label, "chrome-a-1 chrome-a-2 chrome-b-1 chrome-b-2") {
		return f.Label, nil
	}
	return "", fmt.Errorf("unclassified independent on-screen owner")
}

func matchRunnerUnion(owners []runnerUnionOwnerClaim, windows []runnerUnionWindowClaim, facts map[int]runnerUnionOwnerFact, actual []independentWindow, supplemental map[uint32]independentWindow, scClaims []runnerWindowClaim, counts runnerInventoryCounts) error {
	if len(owners) < 1 || len(owners) > 128 || len(windows) < 1 || len(windows) > 128 || len(actual) > 512 {
		return fmt.Errorf("union inventory bound")
	}
	ownerByPID := map[int]runnerUnionOwnerClaim{}
	for _, claim := range owners {
		fact, exists := facts[claim.PID]
		if !exists || claim.PID <= 0 || ownerByPID[claim.PID].PID != 0 {
			return fmt.Errorf("missing/duplicate independent union owner")
		}
		if _, e := runnerUnionKind(fact); e != nil {
			return e
		}
		bsd := fact.BSD
		apple := strings.HasPrefix(fact.Identifier, "com.apple.")
		if claim.Identifier != fact.Identifier || claim.Hash != fact.Hash || claim.PID != int(bsd.PID) || claim.Parent != int(bsd.Parent) || claim.UID != bsd.Effective || claim.Seconds != bsd.Seconds || claim.Microseconds != bsd.Microseconds || !claim.Verified || claim.Apple != apple || claim.SysctlBound != (fact.Identifier == "com.apple.WindowServer") {
			return fmt.Errorf("owner claim disagrees with independent signed/kernel identity")
		}
		if apple && (claim.Real == nil || claim.Saved == nil) {
			return fmt.Errorf("Apple owner credential evidence missing")
		}
		if claim.Real != nil && *claim.Real != bsd.Real || claim.Saved != nil && *claim.Saved != bsd.Saved {
			return fmt.Errorf("owner real/saved credential mismatch")
		}
		ownerByPID[claim.PID] = claim
	}
	actualByID := map[uint32]independentWindow{}
	for _, window := range actual {
		if window.ID == 0 || window.PID < 1 || !window.OnScreen {
			return fmt.Errorf("invalid independent on-screen window")
		}
		if _, duplicate := actualByID[window.ID]; duplicate {
			return fmt.Errorf("duplicate independent window ID")
		}
		if _, known := ownerByPID[window.PID]; !known {
			return fmt.Errorf("unknown on-screen owner omitted from full union")
		}
		actualByID[window.ID] = window
	}
	byID := map[uint32]runnerUnionWindowClaim{}
	seenOwner := map[int]bool{}
	sck := map[uint32]runnerUnionWindowClaim{}
	for _, claim := range windows {
		owner, exists := ownerByPID[claim.PID]
		if !exists || claim.Identifier != owner.Identifier || byID[claim.ID].ID != 0 || !claim.InCG && !claim.InSCK {
			return fmt.Errorf("unattributed/duplicate union window")
		}
		kind, e := runnerUnionKind(facts[claim.PID])
		if e != nil || claim.Kind != kind || claim.Selectable != (kind == "allowed") {
			return fmt.Errorf("recognition/selection classification mismatch")
		}
		if kind != "system" && (!claim.InCG || !claim.InSCK) {
			return fmt.Errorf("protected or selectable owner API completeness missing")
		}
		window, inCG := actualByID[claim.ID]
		if inCG != claim.InCG {
			return fmt.Errorf("CG membership claim mismatch")
		}
		if !inCG {
			var found bool
			window, found = supplemental[claim.ID]
			if !found || window.ID != claim.ID {
				return fmt.Errorf("SCK-only window has no independent CG metadata witness")
			}
		}
		if window.PID != claim.PID || window.Rect != claim.Rect || window.Layer != claim.Layer {
			return fmt.Errorf("actual union PID/bounds/layer mismatch")
		}
		for _, previous := range byID {
			if previous.PID == claim.PID && previous.Rect == claim.Rect {
				return fmt.Errorf("ambiguous owner/bounds across window IDs")
			}
		}
		byID[claim.ID] = claim
		seenOwner[claim.PID] = true
		if claim.InSCK {
			sck[claim.ID] = claim
		}
	}
	if len(seenOwner) != len(ownerByPID) {
		return fmt.Errorf("owner has no union window")
	}
	for id := range actualByID {
		if byID[id].ID == 0 {
			return fmt.Errorf("actual on-screen window missing from union")
		}
	}
	if len(scClaims) != len(sck) || counts.Windows != len(sck) {
		return fmt.Errorf("SCK object count differs from complete union")
	}
	sckPIDs, seen := map[int]bool{}, map[uint32]bool{}
	for _, claim := range scClaims {
		window, exists := sck[claim.ID]
		if !exists || seen[claim.ID] || window.PID != claim.PID || window.Rect != claim.Rect || window.Layer != claim.Layer {
			return fmt.Errorf("SCK object window witness mismatch")
		}
		label, profile := window.Kind, "none"
		if label == "system" {
			label = map[string]string{"com.apple.WindowManager": "window-manager", "com.apple.dock": "dock", "com.apple.finder": "finder", "com.apple.WindowServer": "window-server"}[window.Identifier]
		}
		if strings.HasPrefix(label, "chrome-") {
			profile = strings.TrimPrefix(label, "chrome-")
		}
		if claim.Label != label || claim.Profile != profile {
			return fmt.Errorf("SCK object role/profile mismatch")
		}
		seen[claim.ID] = true
		sckPIDs[claim.PID] = true
	}
	if counts.Processes != len(sckPIDs) {
		return fmt.Errorf("SCK owner count mismatch")
	}
	return nil
}

func runnerUnionJSON(value any) json.RawMessage { raw, _ := json.Marshal(value); return raw }
