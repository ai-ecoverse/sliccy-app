package integration

import (
	"bytes"
	"encoding/binary"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
)

func TestRunnerArgumentsRetainOnlyFixedArgvAndOwnedTemporaryRoot(t *testing.T) {
	makeArgs := func(count int, argv []string) []byte {
		data := make([]byte, 4)
		binary.LittleEndian.PutUint32(data, uint32(count))
		data = append(data, []byte("/fixed/executable\x00\x00")...)
		for _, arg := range argv {
			data = append(data, []byte(arg)...)
			data = append(data, 0)
		}
		return append(data, []byte("IGNORED=not-retained\x00TMPDIR=/private/tmp/sliccy-runner.abcdefgh/tmp/\x00\x00")...)
	}
	args, tmp, e := parseRunnerArguments(makeArgs(2, []string{"fixed", "--owned"}))
	if e != nil || len(args) != 2 || args[1] != "--owned" || tmp != "/private/tmp/sliccy-runner.abcdefgh/tmp/" {
		t.Fatal("bounded argv parse failed", e)
	}
	for _, bad := range [][]byte{makeArgs(65, nil), append([]byte{2, 0, 0, 0}, []byte("/fixed/executable\x00\x00only\x00")...), []byte{1, 2}, bytes.Repeat([]byte{1}, 262145)} {
		if _, _, e := parseRunnerArguments(bad); e == nil {
			t.Fatal("malformed kernel arguments accepted")
		}
	}
	root := filepath.Join("/private/tmp", "sliccy-runner."+screen.ID(6))
	if os.Mkdir(root, 0700) != nil {
		t.Fatal("owned fixture root unavailable")
	}
	defer os.RemoveAll(root)
	for _, name := range []string{"tmp", "config"} {
		if os.Mkdir(filepath.Join(root, name), 0700) != nil {
			t.Fatal("owned fixture child unavailable")
		}
	}
	origin := "http://127.0.0.1:20001"
	good := []string{"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "--user-data-dir=" + filepath.Join(root, "config/chrome-a"), "--no-first-run", "--no-default-browser-check", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--disable-default-apps", "--window-position=416,64", "--window-size=288,224", "--app=" + origin + "/screen-proof/host-a-1"}
	if got, e := runnerChromeArguments(good, filepath.Join(root, "tmp"), "chrome-a", origin); e != nil || got != root {
		t.Fatal(e)
	}
	bad := append([]string(nil), good...)
	bad[1] += "-other"
	if _, e := runnerChromeArguments(bad, filepath.Join(root, "tmp"), "chrome-a", origin); e == nil {
		t.Fatal("wrong browser profile accepted")
	}
	if _, e := runnerOwnedRoot("/private/tmp/unowned/tmp"); e == nil {
		t.Fatal("unowned root accepted")
	}
}
func TestRunnerMetadataLossAbortsBeforeWaitAndRetainsFinalRows(t *testing.T) {
	terminal := `{"schema":6,"case":"selected-window","capture":true,"elapsedMs":1,"eventElapsedMs":1,"stage":"terminal","outcome":"failed-to-demonstrate","reason":"permission-unavailable"}`
	input := terminal + "\n" + terminal + "\n"
	rows := make(chan runnerIncoming, 8)
	finished := make(chan runnerReadResult, 1)
	var aborts atomic.Int32
	readRunnerRows(strings.NewReader(input), &exec.Cmd{}, "selected-window", rows, finished, func() { aborts.Add(1) })
	result := <-finished
	if result.err == nil || aborts.Load() != 1 || len(result.raw) != len(input) {
		t.Fatal("observer loss did not retire immediately and retain bounded rows")
	}
	count := 0
	for range rows {
		count++
	}
	if count != 1 {
		t.Fatal("post-terminal row admitted")
	}
	rows = make(chan runnerIncoming, 8)
	finished = make(chan runnerReadResult, 1)
	aborts.Store(0)
	readRunnerRows(strings.NewReader(terminal+"\n"), &exec.Cmd{}, "selected-window", rows, finished, func() { aborts.Add(1) })
	result = <-finished
	if result.err != nil || aborts.Load() != 0 || result.runErr == nil {
		t.Fatal("synthetic no-process status was confused with metadata loss")
	}
	if len(rows) != 1 {
		t.Fatal("final buffered terminal row was lost")
	}
}

func TestRunnerCleanupDoesNotReadUnrelatedProcessArguments(t *testing.T) {
	app := "/private/tmp/proof/Sliccy.app/Contents/MacOS/Sliccy"
	for _, path := range []string{"/usr/local/bin/Runner.Worker", "/usr/bin/python3", "/Applications/Other.app/Contents/MacOS/Other", "/Applications/Google Chrome.app-malicious/Contents/MacOS/Google Chrome"} {
		if runnerCleanupCandidate(path, app) {
			t.Fatal("unrelated process arguments would be read")
		}
	}
	if !runnerCleanupCandidate("/Applications/Google Chrome.app/Contents/Frameworks/Chrome Helper.app/Contents/MacOS/Chrome Helper", app) {
		t.Fatal("owned Chrome helper cleanup inventory unavailable")
	}
}
