package integration

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
	"golang.org/x/sys/unix"
)

type hostedPIDManifest struct {
	Schema     int                        `json:"schema"`
	Source     string                     `json:"sourceCommit"`
	Version    string                     `json:"version"`
	Build      string                     `json:"build"`
	Identifier string                     `json:"identifier"`
	Team       string                     `json:"team"`
	Executable hostedPIDBinary            `json:"executable"`
	Empty      bool                       `json:"emptyEntitlements"`
	Plist      string                     `json:"infoPlistSHA256"`
	Resources  map[string]hostedPIDBinary `json:"resources"`
	Case       string                     `json:"case"`
	Capture    bool                       `json:"capture"`
	Production bool                       `json:"productionEnabled"`
	Trials     bool                       `json:"nativeTrialsPerformed"`
}
type hostedPIDBinary struct {
	Architecture string `json:"architecture"`
	SHA256       string `json:"sha256"`
	CDHash       string `json:"CDHash"`
	Full         string `json:"codeDirectorySHA256"`
}
type hostedPIDChild struct {
	PID         int
	Kernel      kernelImageObservation
	Events      <-chan proofExecEvent
	Stop        func()
	Ready       bool
	Invalidated bool
	Reaped      bool
	KernelExit  bool
}

func TestSignedHostedPIDReuse(t *testing.T) {
	executable := os.Getenv("SLICCY_SIGNED_PROOF_APP")
	if executable == "" {
		t.Skip("signed hosted-only build10 required")
	}
	host := map[string]string{}
	for _, key := range strings.Fields("GITHUB_ACTIONS GITHUB_REPOSITORY GITHUB_EVENT_NAME GITHUB_REF SLICCY_RUNNER_ENVIRONMENT") {
		host[key] = os.Getenv(key)
	}
	version, e := unix.Sysctl("kern.osproductversion")
	if e != nil || hostedPIDPlacement(host, version, runtime.GOARCH) != nil {
		t.Fatal("hosted-only gate refused before app launch")
	}
	evidence := os.Getenv("SLICCY_PROOF_EVIDENCE")
	manifestPath := os.Getenv("SLICCY_HOSTED_PID_MANIFEST")
	if evidence == "" || manifestPath == "" {
		t.Fatal("fixed signed manifest and private evidence required")
	}
	raw, e := os.ReadFile(manifestPath)
	var manifest hostedPIDManifest
	if e != nil || screen.Strict(raw, &manifest, 65536) != nil || manifest.Schema != 1 || manifest.Source != "4b00c6a77536c52eea4ef3ae3fd133fe0a7fd8a7" || manifest.Version != "0.1.0" || manifest.Build != "10" || manifest.Identifier != "ai.sliccy.mac" || manifest.Team != "S8LB56P782" || !manifest.Empty || manifest.Case != "pid-reuse-hosted" || manifest.Capture || manifest.Production || manifest.Trials || len(manifest.Resources) != 1 {
		t.Fatal("fixed hosted PID manifest invalid")
	}
	contents := filepath.Dir(filepath.Dir(executable))
	cli := filepath.Join(contents, "Resources/slicc")
	resource := manifest.Resources["slicc"]
	if resource.SHA256 != snapshotArmHash || resource.CDHash != snapshotArmCD || resource.Architecture != "arm64" || manifest.Executable.Architecture != "arm64" {
		t.Fatal("unchanged released arm64 CLI required")
	}
	expected := map[string]string{executable: manifest.Executable.SHA256, cli: resource.SHA256, filepath.Join(contents, "Info.plist"): manifest.Plist}
	for path, want := range expected {
		data, e := os.ReadFile(path)
		h := sha256.Sum256(data)
		if e != nil || hex.EncodeToString(h[:]) != want {
			t.Fatal("immutable artifact hash mismatch")
		}
		if path == filepath.Join(contents, "Info.plist") {
			continue
		}
		slices, e := signedSnapshotSlices(data)
		role := "ai.sliccy.slicc"
		cd, full := resource.CDHash, resource.Full
		if path == executable {
			role = "ai.sliccy.mac"
			cd, full = manifest.Executable.CDHash, manifest.Executable.Full
		}
		if e != nil || len(slices) != 1 || slices[0].CPU != 0x0100000c || slices[0].CDHash != cd || slices[0].FullCDHash != full || validateStaticSlice(path, role, slices[0]) != nil {
			t.Fatal("strict native artifact/slice mismatch")
		}
	}
	gate := make(chan struct{})
	_, join, _ := proofPageControlled(t, gate)
	t.Cleanup(func() { close(gate) })
	ctx, cancel := context.WithTimeout(context.Background(), 970*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, executable, "--screen-runner-proof", "--case", "pid-reuse-hosted")
	cmd.Env = proofEnvironment(t)
	for _, key := range strings.Fields("GITHUB_ACTIONS GITHUB_REPOSITORY GITHUB_EVENT_NAME GITHUB_REF SLICCY_RUNNER_ENVIRONMENT") {
		cmd.Env = append(cmd.Env, key+"="+host[key])
	}
	input, e := cmd.StdinPipe()
	if e != nil {
		t.Fatal(e)
	}
	defer input.Close()
	stdout, e := cmd.StdoutPipe()
	if e != nil {
		t.Fatal(e)
	}
	stderr := &proofRows{}
	cmd.Stderr = stderr
	began := time.Now()
	if cmd.Start() != nil {
		t.Fatal("fixed hosted caller failed to launch")
	}
	if _, e = io.WriteString(input, join+"\n"); e != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("private join write failed")
	}
	parentEvents, stopParent, e := watchProofExec(cmd.Process.Pid)
	if e != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("parent exec observer unavailable")
	}
	defer stopParent()
	incoming := make(chan hostedPIDRow, 128)
	done := make(chan struct{})
	output := &proofRows{}
	var readErr, runErr error
	go func() {
		scanner := bufio.NewScanner(stdout)
		scanner.Buffer(make([]byte, 4096), 4096)
		for scanner.Scan() {
			line := append([]byte(nil), scanner.Bytes()...)
			_, _ = output.Write(append(line, '\n'))
			r, e := decodeHostedPIDRow(line)
			if e != nil {
				readErr = e
				continue
			}
			r.At = time.Now()
			select {
			case incoming <- r:
			default:
				readErr = fmt.Errorf("hosted metadata queue exceeded")
			}
		}
		if scanner.Err() != nil {
			readErr = scanner.Err()
		}
		close(incoming)
		runErr = cmd.Wait()
		close(done)
	}()
	failures := []string{}
	missing := []string{}
	fail := func(s string) { failures = append(failures, s) }
	incomplete := func(s string) { missing = append(missing, s) }
	rows := map[string]hostedPIDRow{}
	children := map[int]*hostedPIDChild{}
	samples := map[string]kernelImageObservation{}
	lastElapsed := -1.0
	progressAt := -1.0
	var previousSpawned, previousReaped uint64
	previousCPU, previousWall := 0.0, 0.0
	originalMarker, replacementMarker, resultMarker := false, false, false
	appVerified := false
	steering := hostedPIDSteeringLedger{}
	live := func(child *hostedPIDChild, label string) bool {
		if child == nil {
			fail("live sample without owned child")
			return false
		}
		before, e := inspectOwnedKernelImage(child.PID, cmd.Process.Pid)
		if e != nil || before.CPU != 0x0100000c || before.Offset != 0 || before.CDHash != snapshotArmCD || before.Identity != child.Kernel.Identity {
			incomplete(label + " live native kernel identity unavailable")
			return false
		}
		cd, e := inspectProofImage(child.PID, cli, snapshotArmCD, "ai.sliccy.slicc", "ai.sliccy.mac")
		after, again := inspectOwnedKernelImage(child.PID, cmd.Process.Pid)
		if e != nil || again != nil || cd != snapshotArmCD || before != after {
			fail(label + " real live role/hash/incarnation control failed")
			return false
		}
		samples[label] = before
		return true
	}
	marker := func(value string) {
		if _, e := io.WriteString(input, value+"\n"); e != nil {
			fail("fixed observation marker write failed")
		}
	}
	process := func(row hostedPIDRow) {
		if row.Elapsed < lastElapsed || row.Elapsed > 950000 || row.Elapsed > row.At.Sub(began).Seconds()*1000 {
			fail("hosted timing bound/ordering failed")
		}
		lastElapsed = row.Elapsed
		key := row.Stage
		if row.Attempt != nil {
			key += fmt.Sprintf("/%d", *row.Attempt)
		}
		if row.Stage != "cycler-progress" && row.Stage != "cycler-wrap" && row.Stage != "cycler-approach" && row.Stage != "cycler-missed" {
			if _, ok := rows[key]; ok {
				fail("duplicate hosted stage/attempt")
				return
			}
			rows[key] = row
		}
		if row.Stage == "runner-preflight" {
			if row.PID == nil || *row.PID != cmd.Process.Pid || row.Hosted == nil || !*row.Hosted || row.OSMajor == nil || *row.OSMajor != 27 || row.Architecture != "arm64" {
				fail("runner preflight metadata mismatch")
			}
			k, e := inspectOwnedKernelImage(cmd.Process.Pid, os.Getpid())
			cd, trust := inspectProofImage(cmd.Process.Pid, executable, manifest.Executable.CDHash, "ai.sliccy.mac", "ai.sliccy.proof-helper")
			appVerified = e == nil && trust == nil && cd == manifest.Executable.CDHash && k.CPU == 0x0100000c && k.CDHash == manifest.Executable.CDHash
			if !appVerified {
				fail("real signed native parent control failed")
			}
			samples["app"] = k
			return
		}
		if row.Stage == "cycler-started" {
			if row.MaximumSeconds == nil || *row.MaximumSeconds != 900 || row.MaximumWraps == nil || *row.MaximumWraps != 2 || row.ApproachDistance == nil || *row.ApproachDistance != 2000 || children[0] == nil || !children[0].Reaped || !children[0].KernelExit || !originalMarker {
				fail("cycler before original invalidation/reap/observation")
			}
			return
		}
		if row.Stage == "cycler-wrap" || row.Stage == "cycler-approach" || row.Stage == "cycler-missed" {
			if rows["cycler-started"].Stage == "" || row.Count == nil || *row.Count < previousReaped {
				fail("returned-PID event before cycle or behind reaped metrics")
			}
			if e := steering.Observe(row); e != nil {
				fail("returned-PID steering evidence invalid: " + e.Error())
			}
			return
		}
		if row.Stage == "cycler-progress" || row.Stage == "cycler-ended" {
			if e := steering.Metrics(row); e != nil {
				fail("returned-PID traversal metrics invalid: " + e.Error())
			}
			if rows["cycler-started"].Stage == "" || *row.Count != *row.Reaped || *row.Spawned != *row.Reaped || *row.Spawned < previousSpawned || *row.Reaped < previousReaped || *row.CPU < previousCPU || *row.Wall < previousWall {
				fail("serial lifecycle/CPU metrics invalid")
			}
			previousSpawned, previousReaped = *row.Spawned, *row.Reaped
			previousCPU, previousWall = *row.CPU, *row.Wall
			if row.Stage == "cycler-progress" {
				if progressAt >= 0 && row.Elapsed-progressAt < 10000 {
					fail("progress metadata rate exceeded")
				}
				progressAt = row.Elapsed
			}
			if row.Stage == "cycler-ended" && (*row.CPU > *row.Wall || *row.Wall > 903000) {
				fail("final CPU or churn time bound exceeded")
			}
			if row.Stage == "cycler-ended" && row.Reason != "near-target" {
				incomplete("cycler did not reach scheduling hint")
			}
			return
		}
		if row.Stage == "cycler-failed" {
			incomplete("cycler lifecycle/accounting failed: " + row.Reason)
			return
		}
		if row.Stage == "owned-cleanup-complete" {
			if *row.Spawned != *row.Reaped || *row.Spawned != previousSpawned || *row.Reaped != previousReaped {
				fail("cycler final cleanup totals mismatch")
			}
			for _, child := range children {
				if !child.Reaped || !child.KernelExit || !child.Invalidated {
					fail("owned child cleanup incomplete")
				}
			}
			return
		}
		if row.Stage == "terminal" {
			return
		}
		if row.Attempt == nil || row.PID == nil {
			fail("stage lacks fixed owned child")
			return
		}
		attempt := *row.Attempt
		if row.Stage == "pid-reuse-original-started" || row.Stage == "pid-reuse-attempt-started" {
			if (attempt == 0 && (row.Stage != "pid-reuse-original-started" || len(children) != 0)) || (attempt == 1 && (row.Stage != "pid-reuse-attempt-started" || children[0] == nil || !children[0].Reaped || !children[0].KernelExit || rows["cycler-ended"].Reason != "near-target")) {
				fail("replacement admission/order invalid")
			}
			child := &hostedPIDChild{PID: *row.PID}
			var e error
			child.Kernel, e = inspectOwnedKernelImage(child.PID, cmd.Process.Pid)
			if e != nil {
				incomplete("spawn live kernel observation unavailable")
			}
			child.Events, child.Stop, e = watchProofExec(child.PID)
			if e != nil {
				fail("owned child monitor unavailable")
			}
			children[attempt] = child
			if attempt == 0 {
				steering.Target = child.PID
			}
			return
		}
		child := children[attempt]
		if child == nil || child.PID != *row.PID {
			fail("child stage identity mismatch")
			return
		}
		switch row.Stage {
		case "lanes-authenticated":
		case "heartbeat-ready":
			if rows[fmt.Sprintf("lanes-authenticated/%d", attempt)].Stage == "" {
				fail("heartbeat before actual lanes")
			}
			child.Ready = true
		case "pid-reuse-original-live-positive":
			if attempt != 0 || !child.Ready || !live(child, "original") {
				fail("original positive control unavailable")
			}
			originalMarker = true
			marker("pid-original-observed")
		case "pid-reuse-original-observed":
			if attempt != 0 || !originalMarker {
				fail("original observation ordering")
			}
		case "pid-reuse-candidate-live-positive":
			if attempt != 1 || !child.Ready || !live(child, "candidate") {
				incomplete("candidate positive control unavailable")
			}
		case "token-incarnation-compared":
			if attempt != 1 || !*row.PrefixEqual || !*row.VersionDifferent {
				fail("exact credential prefix/new token version not established")
			}
		case "pid-reuse-observed":
			old := children[0]
			if old == nil || attempt != 1 || child.PID != old.PID || child.Kernel.Identity.Unique == old.Kernel.Identity.Unique || child.Kernel.Identity.Version == old.Kernel.Identity.Version || !old.KernelExit || !old.Reaped || rows["token-incarnation-compared/1"].Stage == "" || !live(child, "reuse-before") {
				fail("literal PID reuse/new incarnation not independently established")
			}
			replacementMarker = true
			marker("pid-replacement-observed")
		case "pid-reuse-current-token-positive":
			if !replacementMarker || !live(child, "current-before-old-call") {
				incomplete("current positive before old lookup unavailable")
			}
		case "pid-reuse-old-token-refused":
			if rows["pid-reuse-current-token-positive/1"].Stage == "" || !live(child, "old-refusal-after") {
				incomplete("saved-token refusal lacks live positive bracket")
			}
		case "pid-reuse-current-token-rechecked", "pid-reuse-observation-ended":
			hostedPIDObservationBoundary(row.Stage, &resultMarker, rows["pid-reuse-old-token-refused/1"].Stage != "", func(label string) bool { return live(child, label) }, marker, incomplete)
		case "pid-reuse-near-target-missed":
			incomplete("one replacement missed the numeric PID")
		case "pid-reuse-gate-invalidated":
			child.Invalidated = *row.Invalidated
			if !child.Invalidated {
				incomplete("native gate not established/invalidated")
			}
		case "pid-reuse-child-reaped":
			if !child.Invalidated {
				fail("reap before gate invalidation")
			}
			child.Reaped = true
			if child.Events != nil {
				select {
				case event := <-child.Events:
					child.KernelExit = event.Exit && !event.Exec && event.Err == nil
				case <-time.After(time.Second):
				}
			}
			if !child.KernelExit {
				fail("owned child actual kernel exit missing")
			}
			if child.Stop != nil {
				child.Stop()
				child.Stop = nil
			}
		}
	}
	finished := false
	for !finished {
		select {
		case row, ok := <-incoming:
			if ok {
				process(row)
			} else {
				incoming = nil
			}
		case event := <-parentEvents:
			if event.Err != nil || event.Exec {
				fail("unexpected parent exec/monitor error")
			}
			if event.Exit {
				parentEvents = nil
			}
		case <-done:
			if incoming != nil {
				for row := range incoming {
					process(row)
				}
			}
			finished = true
		}
	}
	for _, child := range children {
		if child.Stop != nil {
			child.Stop()
		}
		if !child.KernelExit || !child.Reaped || !child.Invalidated {
			fail("owned native child cleanup missing")
		}
	}
	if readErr != nil || output.overflow || stderr.overflow || strings.Contains(string(output.data), join) {
		fail("strict/bounded/private metadata failure")
	}
	for path, want := range expected {
		raw, e := os.ReadFile(path)
		h := sha256.Sum256(raw)
		if e != nil || hex.EncodeToString(h[:]) != want {
			fail("immutable signed artifact changed")
		}
	}
	terminal := rows["terminal"]
	if !appVerified || !originalMarker || !replacementMarker || !resultMarker || len(children) != 2 || rows["pid-reuse-observation-ended/1"].Stage == "" || rows["owned-cleanup-complete"].Stage == "" {
		incomplete("required independent reuse/token/cleanup sequence incomplete")
	}
	if terminal.Outcome != "complete" || terminal.Reason != "pid-reuse-confirmed" {
		incomplete("fixture did not demonstrate reuse")
	}
	if terminal.Outcome == "failed" {
		fail("fixture reported failure: " + terminal.Reason)
	}
	if runErr != nil && terminal.Outcome == "complete" {
		fail("successful terminal with unsuccessful exit")
	}
	result := "PASS"
	if len(missing) > 0 {
		result = "FAILED_TO_DEMONSTRATE"
	}
	if len(failures) > 0 {
		result = "FAIL"
	}
	facts := map[string]any{"result": result, "case": "pid-reuse-hosted", "capture": false, "failures": failures, "missingEvidence": missing, "kernelSamples": samples, "originalMarker": originalMarker, "replacementMarker": replacementMarker, "resultMarker": resultMarker, "sourceCommit": manifest.Source, "appReportedCleanup": rows["owned-cleanup-complete"].Stage != "", "cyclerSpawned": previousSpawned, "cyclerReaped": previousReaped, "cyclerCPUMs": previousCPU, "cyclerWallMs": previousWall, "steeringWraps": steering.Wraps, "steeringRecords": steering.Records, "instantaneousCoreLimitClaimed": false, "independentStagingDeletionClaimed": false}
	data, _ := json.MarshalIndent(facts, "", "  ")
	for name, raw := range map[string][]byte{"driver-observations.json": append(data, '\n'), "milestones.ndjson": output.data, "stderr.txt": stderr.data} {
		if os.WriteFile(filepath.Join(evidence, name), raw, 0600) != nil {
			t.Fatal("private hosted evidence write failed")
		}
	}
	if result != "PASS" {
		t.Fatalf("%s: failures=%v missing=%v", result, failures, missing)
	}
	t.Log("literal same PID/new kernel incarnation and saved-token refusal PASS")
}

func hostedPIDObservationBoundary(stage string, resultMarker *bool, oldRefused bool, live func(string) bool, marker func(string), incomplete func(string)) {
	switch stage {
	case "pid-reuse-current-token-rechecked":
		if !oldRefused || !live("current-after-old-call") {
			incomplete("current positive after old lookup unavailable")
		}
		*resultMarker = true
		marker("pid-result-observed")
	case "pid-reuse-observation-ended":
		if !*resultMarker {
			incomplete("result observation marker missing")
		}
	}
}
