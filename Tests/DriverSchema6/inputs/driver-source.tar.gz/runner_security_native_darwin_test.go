package integration

import (
	"fmt"
	"math"
	"os"
	"runtime"
	"unsafe"

	"github.com/ebitengine/purego"
)

type runnerNativeCodeCall struct {
	Operation string
	Flags uint32
	Status int32
	ValuePresent bool
}

type runnerSecurityContext struct {
	cf,sec,system,proc uintptr
	owned []uintptr
	calls []runnerNativeCodeCall
	lost bool
	pid int
	guest,bundle uintptr
	rules map[string]uintptr
	statics map[runnerFileSlice]uintptr
	release func(uintptr)
	typeID func(uintptr)uint64
	dictionaryType,numberType,dataType,stringType,urlType func()uint64
	stringCreate func(uintptr,*byte,uint32)uintptr
	stringLength func(uintptr)int64
	stringGet func(uintptr,*byte,int64,uint32)bool
	numberCreate func(uintptr,int32,unsafe.Pointer)uintptr
	numberGet func(uintptr,int32,unsafe.Pointer)bool
	numberFloat func(uintptr)bool
	dictionaryCreate func(uintptr,*uintptr,*uintptr,int64,uintptr,uintptr)uintptr
	dictionaryGet func(uintptr,uintptr)uintptr
	dataLength func(uintptr)int64
	dataBytes func(uintptr)*byte
	urlCreate func(uintptr,*byte,int64,bool)uintptr
	urlPath func(uintptr,int64)uintptr
	guestCopy func(uintptr,uintptr,uint32,*uintptr)int32
	copyStatic func(uintptr,uint32,*uintptr)int32
	staticCreate func(uintptr,uint32,*uintptr)int32
	staticAttributes func(uintptr,uint32,uintptr,*uintptr)int32
	requirementCreate func(uintptr,uint32,*uintptr)int32
	guestCheck,staticCheck func(uintptr,uint32,uintptr)int32
	information func(uintptr,uint32,*uintptr)int32
	csops func(int32,uint32,*byte,uint64)int32
	pidpath func(int32,*byte,uint32)int32
	errorPointer func()*int32
	keyCallbacks,valueCallbacks uintptr
}

func openRunnerSecurityContext(pid int)(c *runnerSecurityContext,err error){
	if runnerPlacement()!=nil||os.Geteuid()==0||pid<1||pid>math.MaxInt32{return nil,fmt.Errorf("hosted fixed identity context required")}
	c=&runnerSecurityContext{pid:pid,rules:map[string]uintptr{},statics:map[runnerFileSlice]uintptr{}}
	defer func(){if recover()!=nil{err=fmt.Errorf("Security adapter symbol/ABI unavailable")};if err!=nil{c.close();c=nil}}()
	for path,target:=range map[string]*uintptr{"/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation":&c.cf,"/System/Library/Frameworks/Security.framework/Security":&c.sec,"/usr/lib/libSystem.B.dylib":&c.system,"/usr/lib/libproc.dylib":&c.proc}{handle,e:=purego.Dlopen(path,purego.RTLD_NOW|purego.RTLD_LOCAL);if e!=nil{return c,e};*target=handle}
	if err=c.bindCoreFoundation();err!=nil{return c,err}
	for _,entry:=range []struct{name string;fn any}{{"SecCodeCopyGuestWithAttributes",&c.guestCopy},{"SecCodeCopyStaticCode",&c.copyStatic},{"SecStaticCodeCreateWithPath",&c.staticCreate},{"SecStaticCodeCreateWithPathAndAttributes",&c.staticAttributes},{"SecRequirementCreateWithString",&c.requirementCreate},{"SecCodeCheckValidity",&c.guestCheck},{"SecStaticCodeCheckValidity",&c.staticCheck},{"SecCodeCopySigningInformation",&c.information}}{purego.RegisterLibFunc(entry.fn,c.sec,entry.name)}
	purego.RegisterLibFunc(&c.csops,c.system,"csops");purego.RegisterLibFunc(&c.errorPointer,c.system,"__error");purego.RegisterLibFunc(&c.pidpath,c.proc,"proc_pidpath")
	return c,nil
}

func(c *runnerSecurityContext)close(){
	if c.release!=nil{for i:=len(c.owned)-1;i>=0;i--{c.release(c.owned[i])}}
	c.owned=nil
	for _,handle:=range []uintptr{c.proc,c.system,c.sec,c.cf}{if handle!=0{purego.Dlclose(handle)}}
}

func(c *runnerSecurityContext)record(operation string,flags uint32,status int32,present bool){if len(c.calls)<128{c.calls=append(c.calls,runnerNativeCodeCall{operation,flags,status,present})}else{c.lost=true}}
func(c *runnerSecurityContext)retain(v uintptr)(uintptr,error){if v==0{return 0,fmt.Errorf("native retained reference missing")};if len(c.owned)>=128{c.lost=true;c.release(v);return 0,fmt.Errorf("native retained-reference bound")};c.owned=append(c.owned,v);return v,nil}
func(c *runnerSecurityContext)symbol(name string)(uintptr,error){v,e:=readProofExport(c.sec,name);if e!=nil||v==0{return 0,fmt.Errorf("required Security export missing: %s",name)};return v,nil}
func(c *runnerSecurityContext)text(value string)(uintptr,error){raw:=append([]byte(value),0);v:=c.stringCreate(0,&raw[0],0x08000100);runtime.KeepAlive(raw);if v==0{return 0,fmt.Errorf("CF string construction failed")};return v,nil}
func(c *runnerSecurityContext)lookup(dictionary uintptr,key string)(uintptr,error){if dictionary==0||c.typeID(dictionary)!=c.dictionaryType(){return 0,fmt.Errorf("information dictionary type")};k,e:=c.text(key);if e!=nil{return 0,e};defer c.release(k);return c.dictionaryGet(dictionary,k),nil}
func(c *runnerSecurityContext)readString(value uintptr)(string,error){if value==0||c.typeID(value)!=c.stringType()||c.stringLength(value)<1||c.stringLength(value)>4096{return "",fmt.Errorf("CF string type/length")};buf:=make([]byte,16385);if !c.stringGet(value,&buf[0],int64(len(buf)),0x08000100){return "",fmt.Errorf("CF string conversion")};for i,b:=range buf{if b==0{return string(buf[:i]),nil}};return "",fmt.Errorf("CF string termination")}
func(c *runnerSecurityContext)readNumber(value uintptr)(int64,error){var n int64;if value==0||c.typeID(value)!=c.numberType()||c.numberFloat(value)||!c.numberGet(value,4,unsafe.Pointer(&n)){return 0,fmt.Errorf("CF number type/value")};return n,nil}
func(c *runnerSecurityContext)readData(value uintptr,low,high int)([]byte,error){if value==0||c.typeID(value)!=c.dataType(){return nil,fmt.Errorf("CF data type")};n:=c.dataLength(value);p:=c.dataBytes(value);if n<int64(low)||n>int64(high)||p==nil{return nil,fmt.Errorf("CF data size/pointer")};return append([]byte(nil),unsafe.Slice(p,int(n))...),nil}

func(c *runnerSecurityContext)rule(text string)(uintptr,error){if value:=c.rules[text];value!=0{return value,nil};source,e:=c.text(text);if e!=nil{return 0,e};defer c.release(source);var value uintptr;status:=c.requirementCreate(source,0,&value);c.record("SecRequirementCreateWithString",0,status,value!=0);if status!=0||value==0{if value!=0{c.release(value)};return 0,fmt.Errorf("requirement creation status=%d nonnull=%t",status,value!=0)};retained,e:=c.retain(value);if e==nil{c.rules[text]=retained};return retained,e}

func(c *runnerSecurityContext)ensureGuest()(uintptr,error){
	if c.guest!=0{return c.guest,nil}
	key,e:=c.symbol("kSecGuestAttributePid");if e!=nil{return 0,e};pid:=int32(c.pid);number:=c.numberCreate(0,3,unsafe.Pointer(&pid));if number==0{return 0,fmt.Errorf("PID CFNumber unavailable")};defer c.release(number)
	attributes:=c.dictionaryCreate(0,&key,&number,1,c.keyCallbacks,c.valueCallbacks);if attributes==0{return 0,fmt.Errorf("PID CFDictionary unavailable")};defer c.release(attributes)
	var guest uintptr;status:=c.guestCopy(0,attributes,0,&guest);c.record("SecCodeCopyGuestWithAttributes",0,status,guest!=0)
	if status!=0||guest==0{if guest!=0{c.release(guest)};return 0,fmt.Errorf("guest lookup status=%d nonnull=%t",status,guest!=0)}
	c.guest,e=c.retain(guest);return c.guest,e
}

func(c *runnerSecurityContext)guestStatic()(uintptr,error){guest,e:=c.ensureGuest();if e!=nil{return 0,e};var value uintptr;status:=c.copyStatic(guest,0,&value);c.record("SecCodeCopyStaticCode",0,status,value!=0);if status!=0||value==0{if value!=0{c.release(value)};return 0,fmt.Errorf("guest-static status=%d nonnull=%t",status,value!=0)};return value,nil}

func(c *runnerSecurityContext)readInformation(code uintptr)(v runnerCodeInformation,err error){
	var information uintptr;status:=c.information(code,3,&information);c.record("SecCodeCopySigningInformation",3,status,information!=0)
	if status!=0||information==0{if information!=0{c.release(information)};return v,fmt.Errorf("signing information status=%d nonnull=%t",status,information!=0)};defer c.release(information)
	get:=func(name string)(uintptr,error){key,e:=c.symbol(name);if e!=nil{return 0,e};if c.typeID(information)!=c.dictionaryType(){return 0,fmt.Errorf("signing information is not a dictionary")};return c.dictionaryGet(information,key),nil}
	key,e:=get("kSecCodeInfoUnique");if e!=nil{return v,e};if v.Hash,e=c.readData(key,20,20);e!=nil{return v,fmt.Errorf("information-unique: %w",e)}
	key,e=get("kSecCodeInfoDigestAlgorithm");if e!=nil{return v,e};if v.Type,e=c.readNumber(key);e!=nil||v.Type<1||v.Type>4{return v,fmt.Errorf("information-digest-type: %v",e)}
	key,e=get("kSecCodeInfoIdentifier");if e!=nil{return v,e};if v.Identifier,e=c.readString(key);e!=nil{return v,fmt.Errorf("information-identifier: %w",e)}
	key,e=get("kSecCodeInfoMainExecutable");if e!=nil{return v,e};if key==0||c.typeID(key)!=c.urlType(){return v,fmt.Errorf("information-main-executable-url")};path:=c.urlPath(key,0);if path==0{return v,fmt.Errorf("information-url-path")};defer c.release(path);if v.Path,e=c.readString(path);e!=nil{return v,e}
	full,e:=c.lookup(information,"cdhashes-full");if e!=nil||full==0||c.typeID(full)!=c.dictionaryType(){return v,fmt.Errorf("information-full-hash-map")}
	kind:=v.Type;number:=c.numberCreate(0,4,unsafe.Pointer(&kind));if number==0{return v,fmt.Errorf("information-hash-type-key")};defer c.release(number)
	if v.Full,e=c.readData(c.dictionaryGet(full,number),20,64);e!=nil{return v,fmt.Errorf("information-full-hash: %w",e)}
	offset,e:=c.lookup(information,"CodeOffset");if e!=nil{return v,e};if offset!=0{n,e:=c.readNumber(offset);if e!=nil||n<0{return v,fmt.Errorf("information-code-offset")};value:=uint64(n);v.Offset=&value}
	return v,nil
}

func(c *runnerSecurityContext)explicit(path string,slice runnerFileSlice)(uintptr,error){
	if path==""{return 0,fmt.Errorf("explicit-static path unavailable")};if v:=c.statics[slice];v!=0{return v,nil}
	urlBytes:=[]byte(path);url:=c.urlCreate(0,&urlBytes[0],int64(len(urlBytes)),false);runtime.KeepAlive(urlBytes);if url==0{return 0,fmt.Errorf("explicit-static URL creation")};defer c.release(url)
	cpu,sub:=slice.CPU,slice.Subtype;keys:=[2]uintptr{};var e error
	if keys[0],e=c.symbol("kSecCodeAttributeArchitecture");e!=nil{return 0,e};if keys[1],e=c.symbol("kSecCodeAttributeSubarchitecture");e!=nil{return 0,e}
	values:=[2]uintptr{c.numberCreate(0,3,unsafe.Pointer(&cpu)),c.numberCreate(0,3,unsafe.Pointer(&sub))};for _,v:=range values{if v==0{return 0,fmt.Errorf("explicit-static signed CPU attributes")};defer c.release(v)}
	attributes:=c.dictionaryCreate(0,&keys[0],&values[0],2,c.keyCallbacks,c.valueCallbacks);if attributes==0{return 0,fmt.Errorf("explicit-static dictionary construction")};defer c.release(attributes)
	var code uintptr;status:=c.staticAttributes(url,0,attributes,&code);c.record("SecStaticCodeCreateWithPathAndAttributes",0,status,code!=0)
	if status!=0||code==0{if code!=0{c.release(code)};return 0,fmt.Errorf("explicit-static status=%d nonnull=%t",status,code!=0)}
	code,e=c.retain(code);if e==nil{c.statics[slice]=code};return code,e
}

func(c *runnerSecurityContext)chromeBundle()(uintptr,error){if c.bundle!=0{return c.bundle,nil};raw:=[]byte("/Applications/Google Chrome.app");url:=c.urlCreate(0,&raw[0],int64(len(raw)),true);runtime.KeepAlive(raw);if url==0{return 0,fmt.Errorf("fixed Chrome bundle URL")};defer c.release(url);var code uintptr;status:=c.staticCreate(url,0,&code);c.record("SecStaticCodeCreateWithPath-Chrome",0,status,code!=0);if status!=0||code==0{if code!=0{c.release(code)};return 0,fmt.Errorf("Chrome bundle static lookup status=%d",status)};var e error;c.bundle,e=c.retain(code);return c.bundle,e}

func(c *runnerSecurityContext)kernel()(v runnerKernelCode,err error){
	runtime.LockOSThread();defer runtime.UnlockOSThread()
	pointer:=c.errorPointer();if pointer==nil{return v,fmt.Errorf("kernel errno facility unavailable")}
	var path [4096]byte;*pointer=0;n:=c.pidpath(int32(c.pid),&path[0],4096);e:=*pointer;c.record("proc_pidpath",0,n,n>0)
	if n<1||n>=4096{return v,fmt.Errorf("kernel path count=%d errno=%d",n,e)};terminated:=false;for i,b:=range path{if b==0{v.Path=string(path[:i]);terminated=true;break}};if !terminated||v.Path==""{return v,fmt.Errorf("kernel path termination")}
	*pointer=0;status:=c.csops(int32(c.pid),5,&v.Hash[0],20);e=*pointer;c.record("csops-CDHASH",5,status,status==0);if status!=0{return v,fmt.Errorf("kernel CDHash status=%d errno=%d",status,e)}
	var flags [4]byte;*pointer=0;status=c.csops(int32(c.pid),0,&flags[0],4);e=*pointer;c.record("csops-STATUS",0,status,status==0);if status!=0{return v,fmt.Errorf("kernel status status=%d errno=%d",status,e)}
	v.Flags=uint32(flags[0])|uint32(flags[1])<<8|uint32(flags[2])<<16|uint32(flags[3])<<24
	return v,nil
}

func(c *runnerSecurityContext)operations(role,path string)runnerIndependentCodeOps{
	validity:=func(kind string,flags uint32,ruleText string,code func()(uintptr,error),check func(uintptr,uint32,uintptr)int32)int32{rule,e:=c.rule(ruleText);if e!=nil{return -1};object,e:=code();if e!=nil{return -1};status:=check(object,flags,rule);c.record(kind,flags,status,true);return status}
	return runnerIndependentCodeOps{
		BSD:func(phase string)(runnerBSDReceipt,error){r,e:=runnerObserveBSD(c.pid);r.Role=role;r.Phase=phase;return r,e},
		Kernel:func()(runnerKernelCode,error){v,e:=c.kernel();if e==nil&&path==""{path=v.Path};return v,e},
		GuestValidity:func(flags uint32,rule string)int32{return validity("SecCodeCheckValidity",flags,rule,c.ensureGuest,c.guestCheck)},
		GuestStaticValidity:func(flags uint32,rule string)int32{object,e:=c.guestStatic();if e!=nil{return -1};defer c.release(object);return validity("SecStaticCodeCheckValidity-guest",flags,rule,func()(uintptr,error){return object,nil},c.staticCheck)},
		ChromeBundleValidity:func(flags uint32,rule string)int32{return validity("SecStaticCodeCheckValidity-Chrome",flags,rule,c.chromeBundle,c.staticCheck)},
		LiveInformation:func()(runnerCodeInformation,error){object,e:=c.guestStatic();if e!=nil{return runnerCodeInformation{},e};defer c.release(object);return c.readInformation(object)},
		Open:runnerOpenFileSnapshot,
		ExplicitInformation:func(slice runnerFileSlice)(runnerCodeInformation,error){code,e:=c.explicit(path,slice);if e!=nil{return runnerCodeInformation{},e};return c.readInformation(code)},
		ExplicitValidity:func(slice runnerFileSlice,flags uint32,rule string)int32{return validity("SecStaticCodeCheckValidity-selected",flags,rule,func()(uintptr,error){return c.explicit(path,slice)},c.staticCheck)},
	}
}


type runnerNativeBindingObservation struct {
	Binding runnerIndependentCodeFact
	Calls []runnerNativeCodeCall
	AdapterError string
	DiagnosticLoss bool
}

func observeRunnerNativeBinding(pid int,role,path,pin string)(observation runnerNativeBindingObservation,err error){
	context,e:=openRunnerSecurityContext(pid)
	if e!=nil{observation.AdapterError=e.Error();return observation,e}
	defer func(){
		if recover()!=nil{err=fmt.Errorf("independent Security adapter panic/ABI unavailable");observation.Binding.Bound=false}
		observation.Calls=append([]runnerNativeCodeCall(nil),context.calls...)
		observation.DiagnosticLoss=context.lost
		if context.lost{err=fmt.Errorf("independent native diagnostics exceeded fixed bound");observation.Binding.Bound=false}
		if err!=nil{observation.AdapterError=err.Error()}
		context.close()
	}()
	observation.Binding,err=bindRunnerIndependentCode(pid,role,path,pin,context.operations(role,path))
	return observation,err
}

func(c *runnerSecurityContext)bindCoreFoundation()error{
	for _,entry:=range []struct{name string;fn any}{{"CFRelease",&c.release},{"CFGetTypeID",&c.typeID},{"CFDictionaryGetTypeID",&c.dictionaryType},{"CFNumberGetTypeID",&c.numberType},{"CFDataGetTypeID",&c.dataType},{"CFStringGetTypeID",&c.stringType},{"CFURLGetTypeID",&c.urlType},{"CFStringCreateWithCString",&c.stringCreate},{"CFStringGetLength",&c.stringLength},{"CFStringGetCString",&c.stringGet},{"CFNumberCreate",&c.numberCreate},{"CFNumberGetValue",&c.numberGet},{"CFNumberIsFloatType",&c.numberFloat},{"CFDictionaryCreate",&c.dictionaryCreate},{"CFDictionaryGetValue",&c.dictionaryGet},{"CFDataGetLength",&c.dataLength},{"CFDataGetBytePtr",&c.dataBytes},{"CFURLCreateFromFileSystemRepresentation",&c.urlCreate},{"CFURLCopyFileSystemPath",&c.urlPath}}{purego.RegisterLibFunc(entry.fn,c.cf,entry.name)}
	var err error
	if c.keyCallbacks,err=purego.Dlsym(c.cf,"kCFTypeDictionaryKeyCallBacks");err!=nil{return err}
	if c.valueCallbacks,err=purego.Dlsym(c.cf,"kCFTypeDictionaryValueCallBacks");err!=nil{return err}
	return nil
}
