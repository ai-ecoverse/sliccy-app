package integration

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type reuseRow struct {
	proofRow
	Case          string    `json:"case"`
	PID           *int      `json:"pid,omitempty"`
	Attempt       *int      `json:"attempt,omitempty"`
	BudgetElapsed *float64  `json:"budgetElapsedMs,omitempty"`
	At            time.Time `json:"-"`
}
type reuseChild struct {
	PID         int
	Identity    ownedIncarnation
	Events      <-chan proofExecEvent
	Stop        func()
	Started     reuseRow
	Positive    bool
	Invalidated *reuseRow
	Reaped      *reuseRow
	ExitAt      time.Time
}

func TestSignedPIDReuse(t *testing.T) {
	executable := os.Getenv("SLICCY_SIGNED_PROOF_APP")
	if executable == "" {
		t.Skip("CI-signed PID-reuse fixture required")
	}
	evidence := os.Getenv("SLICCY_PROOF_EVIDENCE")
	appHash := os.Getenv("SLICCY_SIGNED_APP_CDHASH")
	if evidence == "" || len(appHash) != 40 {
		t.Fatal("verified signed manifest required")
	}
	closedGate := make(chan struct{})
	_, join, _ := proofPageControlled(t, closedGate)
	t.Cleanup(func() { close(closedGate) })
	ctx, cancel := context.WithTimeout(context.Background(), 35*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, executable, "--screen-proof", "--case", "pid-reuse")
	cmd.Env = proofEnvironment(t)
	input, e := cmd.StdinPipe()
	if e != nil {
		t.Fatal("stdin unavailable")
	}
	defer input.Close()
	stdout, e := cmd.StdoutPipe()
	if e != nil {
		t.Fatal("stdout unavailable")
	}
	stderr := &proofRows{}
	cmd.Stderr = stderr
	start := time.Now()
	if cmd.Start() != nil {
		t.Fatal("signed PID case launch failed")
	}
	if _, e = io.WriteString(input, join+"\n"); e != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("loopback join unavailable")
	}
	parentEvents, stopParent, e := watchProofExec(cmd.Process.Pid)
	if e != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("parent monitor unavailable")
	}
	defer stopParent()
	incoming := make(chan reuseRow, 256)
	done := make(chan struct{})
	output := &proofRows{}
	var readErr, runErr error
	go func() {
		scanner := bufio.NewScanner(stdout)
		scanner.Buffer(make([]byte, 4096), 4096)
		for scanner.Scan() {
			raw := append([]byte(nil), scanner.Bytes()...)
			_, _ = output.Write(append(raw, '\n'))
			var row reuseRow
			d := json.NewDecoder(bytes.NewReader(raw))
			d.DisallowUnknownFields()
			if !uniqueProofJSON(raw) || d.Decode(&row) != nil {
				readErr = fmt.Errorf("invalid reuse metadata")
				continue
			}
			row.At = time.Now()
			select {
			case incoming <- row:
			default:
				readErr = fmt.Errorf("reuse metadata queue exceeded")
			}
		}
		if scanner.Err() != nil {
			readErr = fmt.Errorf("reuse metadata read failed")
		}
		close(incoming)
		runErr = cmd.Wait()
		close(done)
	}()
	var failures []string
	fail := func(reason string) { failures = append(failures, reason) }
	children := map[int]*reuseChild{}
	rows := map[string]reuseRow{}
	liveAttempt := -1
	attemptCount := 0
	originalPID := 0
	var original ownedIncarnation
	var originalAckAt time.Time
	reusedAttempt := -1
	appVerified := false
	allowed := map[string]bool{}
	for _, stage := range strings.Fields("pid-reuse-original-started pid-reuse-original-live-positive pid-reuse-original-observed pid-reuse-gate-invalidated pid-reuse-child-reaped pid-reuse-attempt-started pid-reuse-candidate-live-positive pid-reuse-observed pid-reuse-old-token-refused pid-reuse-current-token-rechecked pid-reuse-observation-ended pid-reuse-budget-ended terminal") {
		allowed[stage] = true
	}
	cli := filepath.Join(filepath.Dir(filepath.Dir(executable)), "Resources", "slicc")
	liveCheck := func(child *reuseChild) bool {
		first, err := inspectOwnedIncarnation(child.PID, cmd.Process.Pid)
		if err != nil {
			fail("live owned incarnation unavailable")
			return false
		}
		hash, err := inspectProofImage(child.PID, cli, "5da1a3199bd3f895bce2e53023c28ca1c33d249e", "ai.sliccy.slicc", "ai.sliccy.mac")
		last, second := inspectOwnedIncarnation(child.PID, cmd.Process.Pid)
		if err != nil || second != nil || hash != "5da1a3199bd3f895bce2e53023c28ca1c33d249e" || first != last || first != child.Identity {
			fail("live same-role/hash/incarnation control failed")
			return false
		}
		return true
	}
	process := func(row reuseRow) {
		if row.Schema != 2 || row.Case != "pid-reuse" || row.Capture == nil || *row.Capture || !allowed[row.Stage] || math.IsNaN(row.Elapsed) || math.IsInf(row.Elapsed, 0) || row.Elapsed < 0 || row.Elapsed > row.At.Sub(start).Seconds()*1000 || row.Duration != nil {
			fail("invalid reuse schema/timing")
			return
		}
		if row.Stage == "terminal" {
			if row.Attempt != nil || row.PID != nil || row.BudgetElapsed != nil {
				fail("terminal contains child metadata")
			}
			if _, exists := rows[row.Stage]; exists {
				fail("duplicate terminal")
			}
			rows[row.Stage] = row
			return
		}
		if row.Attempt == nil || *row.Attempt < 0 || *row.Attempt > 32 {
			fail("invalid attempt budget")
			return
		}
		attempt := *row.Attempt
		key := fmt.Sprintf("%s/%d", row.Stage, attempt)
		if _, exists := rows[key]; exists {
			fail("duplicate attempt stage")
		}
		rows[key] = row
		if row.Stage == "pid-reuse-budget-ended" {
			if row.PID != nil || row.BudgetElapsed == nil || math.IsNaN(*row.BudgetElapsed) || math.IsInf(*row.BudgetElapsed, 0) || *row.BudgetElapsed < 0 || *row.BudgetElapsed > 18000 || attempt != attemptCount || liveAttempt != -1 {
				fail("invalid budget outcome")
			}
			rows[row.Stage] = row
			return
		}
		if row.BudgetElapsed != nil {
			fail("unexpected budget metadata")
		}
		if row.Stage == "pid-reuse-original-started" || row.Stage == "pid-reuse-attempt-started" {
			if row.PID == nil || *row.PID <= 0 || *row.PID == cmd.Process.Pid || liveAttempt != -1 {
				fail("missing/overlapping owned child")
				return
			}
			if attempt == 0 {
				if row.Stage != "pid-reuse-original-started" || len(children) != 0 {
					fail("original attempt invalid")
				}
				originalPID = *row.PID
			} else {
				if row.Stage != "pid-reuse-attempt-started" || attempt != attemptCount+1 || children[0] == nil || children[0].Reaped == nil {
					fail("replacement sequence/reap invalid")
				}
				attemptCount = attempt
			}
			child := &reuseChild{PID: *row.PID, Started: row}
			var err error
			child.Identity, err = inspectOwnedIncarnation(child.PID, cmd.Process.Pid)
			if err != nil {
				fail("independent child identity unavailable")
			}
			child.Events, child.Stop, err = watchProofExec(child.PID)
			if err != nil {
				fail("owned child exit monitor unavailable")
			}
			children[attempt] = child
			liveAttempt = attempt
			if attempt == 0 {
				original = child.Identity
				hash, err := inspectProofImage(cmd.Process.Pid, executable, appHash, "ai.sliccy.mac", "ai.sliccy.proof-helper")
				appVerified = err == nil && hash == appHash
				if !appVerified {
					fail("signed parent live control failed")
				}
			}
			return
		}
		child := children[attempt]
		if child == nil {
			fail("stage without owned child")
			return
		}
		if row.Stage == "pid-reuse-gate-invalidated" || row.Stage == "pid-reuse-child-reaped" {
			if row.PID != nil {
				fail("unexpected PID on cleanup stage")
			}
			if row.Stage == "pid-reuse-gate-invalidated" {
				if row.Reason != "invalidated" {
					fail("paired output gate invalidation missing")
				}
				copy := row
				child.Invalidated = &copy
			} else {
				if child.Invalidated == nil || child.Invalidated.Elapsed > row.Elapsed || !child.Positive {
					fail("reap before paired invalidation/live control")
				}
				copy := row
				child.Reaped = &copy
				liveAttempt = -1
				if child.Events != nil {
					select {
					case event := <-child.Events:
						if event.Err != nil || event.Exec || !event.Exit {
							fail("invalid owned CLI terminal event")
						} else {
							child.ExitAt = event.At
						}
					case <-time.After(time.Second):
						fail("owned CLI exit event missing")
					}
				}
				if child.Stop != nil {
					child.Stop()
					child.Stop = nil
				}
			}
			return
		}
		if row.PID == nil || *row.PID != child.PID {
			fail("child metadata PID mismatch")
			return
		}
		switch row.Stage {
		case "pid-reuse-original-live-positive":
			if attempt != 0 || !liveCheck(child) {
				return
			}
			child.Positive = true
			originalAckAt = time.Now()
			if _, e := io.WriteString(input, "pid-original-observed\n"); e != nil {
				fail("original observation marker failed")
			}
		case "pid-reuse-original-observed":
			if attempt != 0 || originalAckAt.IsZero() || originalAckAt.After(row.At) {
				fail("original observation not causal")
			}
		case "pid-reuse-candidate-live-positive":
			if attempt == 0 {
				fail("candidate positive used for original")
			}
			child.Positive = true
		case "pid-reuse-observed":
			if child.PID != originalPID || child.Identity.Unique == original.Unique || child.Identity.Version == original.Version || row.Reason != "new-incarnation" || !child.Positive || !liveCheck(child) {
				fail("actual numeric PID reuse/new-incarnation not proved")
				return
			}
			reusedAttempt = attempt
		case "pid-reuse-old-token-refused", "pid-reuse-current-token-rechecked":
			if reusedAttempt != attempt || !liveCheck(child) {
				fail("reuse verifier outcome without live controls")
			}
		case "pid-reuse-observation-ended":
			prior := rows[fmt.Sprintf("pid-reuse-current-token-rechecked/%d", attempt)]
			if reusedAttempt != attempt || row.Reason != "elapsed" || row.Elapsed-prior.Elapsed < 2000 || !liveCheck(child) {
				fail("reuse hold/current control incomplete")
			}
		default:
			fail("unexpected owned child stage")
		}
	}
	readRows := incoming
	finished := false
	for !finished {
		select {
		case row, ok := <-readRows:
			if ok {
				process(row)
			} else {
				readRows = nil
			}
		case event := <-parentEvents:
			if event.Err != nil || event.Exec {
				fail("original app identity monitor failed")
			}
			if event.Exit {
				parentEvents = nil
			}
		case <-done:
			for row := range incoming {
				process(row)
			}
			finished = true
		}
	}
	for _, child := range children {
		if child.Stop != nil {
			child.Stop()
		}
		if child.Reaped == nil || child.ExitAt.IsZero() {
			fail("owned cleanup incomplete")
		}
	}
	if readErr != nil || output.overflow || stderr.overflow {
		fail("reuse metadata bounds/read failure")
	}
	if strings.Contains(string(output.data), join) {
		fail("synthetic join disclosed")
	}
	terminal := rows["terminal"]
	result := "FAIL"
	if len(failures) == 0 && reusedAttempt >= 1 && terminal.Reason == "pid-reuse-confirmed" && cmd.ProcessState.ExitCode() == 0 && runErr == nil {
		for _, stage := range strings.Fields("pid-reuse-observed pid-reuse-old-token-refused pid-reuse-current-token-rechecked pid-reuse-observation-ended") {
			if _, ok := rows[fmt.Sprintf("%s/%d", stage, reusedAttempt)]; !ok {
				fail("missing reuse verifier outcome")
			}
		}
		if len(failures) == 0 {
			result = "PASS"
		}
	} else if len(failures) == 0 && reusedAttempt == -1 && terminal.Reason == "pid-reuse-not-observed" && cmd.ProcessState.ExitCode() == 2 {
		budget, ok := rows["pid-reuse-budget-ended"]
		if !ok || !(budget.Reason == "time-limit" || budget.Reason == "attempt-limit") || (budget.Reason == "attempt-limit" && attemptCount != 32) {
			fail("no bounded non-reuse outcome")
		} else {
			result = "FAILED_TO_DEMONSTRATE"
		}
	} else {
		fail("signed case failed or inconsistent terminal")
	}
	facts := map[string]any{"result": result, "case": "literal-pid-reuse", "failures": failures, "replacementAttempts": attemptCount, "actualReusedAttempt": reusedAttempt, "originalIndependentlyObserved": !originalAckAt.IsZero(), "appLiveVerified": appVerified, "allChildrenReaped": liveAttempt == -1, "capture": false, "networkLinkAcceptanceClaimed": false, "sameRoleHashControlsRequired": true, "budget": rows["pid-reuse-budget-ended"]}
	raw, _ := json.MarshalIndent(facts, "", "  ")
	for name, data := range map[string][]byte{"milestones.ndjson": output.data, "driver-observations.json": append(raw, '\n'), "stderr.txt": stderr.data} {
		if os.WriteFile(filepath.Join(evidence, name), data, 0600) != nil {
			t.Fatal("private reuse evidence write failed")
		}
	}
	if len(failures) > 0 {
		t.Fatal(failures)
	}
	if result != "PASS" {
		t.Fatal("FAILED TO DEMONSTRATE literal PID reuse within fixed bounds")
	}
	t.Log("literal PID reuse PASS with independent new-incarnation observation and real verifier controls")
}
