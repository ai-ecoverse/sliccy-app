package integration

import "fmt"

type runnerCaseMetadataLedger struct {
 Display runnerDisplayLedger
 RefusalAttempts map[int64]bool
	Causes map[string]runnerCaptureRow
	Chrome map[string]map[string]bool
}

func (l *runnerCaseMetadataLedger) Add(row runnerCaptureRow) error {
 if row.DisplayDiagnostic!=nil {return l.Display.Add(*row.DisplayDiagnostic)}
 if row.Stage=="terminal" {if outcome,e:=runnerText(row.Fields,"outcome");e==nil&&outcome=="complete" {if e=l.Display.Complete();e!=nil{return e}}}

 if row.Refusal!=nil {
  if l.RefusalAttempts==nil {l.RefusalAttempts=map[int64]bool{}}
  if l.RefusalAttempts[row.Refusal.Attempt] {return fmt.Errorf("duplicate inventory refusal attempt")}
  l.RefusalAttempts[row.Refusal.Attempt]=true
 }

	if row.Stage == "first-cause" {
		kind, err := runnerText(row.Fields, "kind")
		if err != nil {
			return err
		}
		if l.Causes == nil {
			l.Causes = map[string]runnerCaptureRow{}
		}
		if len(l.Causes) >= 5 || l.Causes[kind].Stage != "" {
			return fmt.Errorf("duplicate/overflow first-cause kind")
		}
		l.Causes[kind] = row
	}
	if row.Stage == "chrome-identity" {
		label, err := runnerText(row.Fields, "label")
		if err != nil {
			return err
		}
		phase, err := runnerText(row.Fields, "phase")
		if err != nil {
			return err
		}
		identity, e1 := runnerInt(row.Fields, "identityStatus", -2147483648, 2147483647)
		strict, e2 := runnerInt(row.Fields, "strictStatus", -2147483648, 2147483647)
		guest, e3 := runnerInt(row.Fields, "guestStatus", -2147483648, 2147483647)
		if e1 != nil || e2 != nil || e3 != nil {
			return fmt.Errorf("Chrome metadata status missing")
		}
		if l.Chrome == nil {
			l.Chrome = map[string]map[string]bool{}
		}
		if l.Chrome[label] == nil {
			l.Chrome[label] = map[string]bool{}
		}
		if identity == 0 && guest == 0 && (strict == 0 || strict == -66999) {
			l.Chrome[label][phase] = true
		}
	}
	return nil
}

func (l *runnerCaseMetadataLedger) CompleteChrome(display bool) error {
	if !display {
		if len(l.Chrome) != 0 {
			return fmt.Errorf("unexpected browser fixture in window-only case")
		}
		return nil
	}
	for _, label := range []string{"chrome-a-1", "chrome-a-2", "chrome-b-1", "chrome-b-2"} {
		for _, phase := range []string{"preflight", "initial-live", "live", "live-copy", "signal"} {
			if !l.Chrome[label][phase] {
				return fmt.Errorf("mandatory Chrome accepted phase missing")
			}
		}
	}
	return nil
}
