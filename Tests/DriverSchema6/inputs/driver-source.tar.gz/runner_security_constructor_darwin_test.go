package integration

import (
	"bytes"
	"fmt"
	"os"
	"runtime"
	"strconv"
	"strings"
	"testing"
	"unsafe"

	"github.com/ebitengine/purego"
)

func TestRunnerNativeCFConstructorsUseExactAttributesAndTypedInformation(t *testing.T) {
	if os.Getenv("RUNNER_ENVIRONMENT") != "github-hosted" || os.Getenv("GITHUB_REF") != "refs/heads/proof/independent-driver-schema6-v1" || runtime.GOARCH != "arm64" {
		t.Skip("hosted constructor-only component gate")
	}
	for _, role := range []string{"ai.sliccy.mac", "com.google.Chrome"} {
		t.Run(role, func(t *testing.T) {
			c := &runnerSecurityContext{trace: newRunnerNativeTrace(), pid: 42, rules: map[string]uintptr{}, statics: map[runnerFileSlice]uintptr{}}
			var e error
			c.cf, e = purego.Dlopen("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation", purego.RTLD_NOW|purego.RTLD_LOCAL)
			if e != nil {
				t.Fatal(e)
			}
			c.sec, e = purego.Dlopen("/System/Library/Frameworks/Security.framework/Security", purego.RTLD_NOW|purego.RTLD_LOCAL)
			if e != nil {
				t.Fatal(e)
			}
			if e = c.bindCoreFoundation(); e != nil {
				t.Fatal(e)
			}
			t.Cleanup(c.close)
			keep := func(v uintptr) uintptr {
				value, e := c.retain(v)
				if e != nil {
					t.Fatal(e)
				}
				return value
			}
			text := func(value string) uintptr {
				v, e := c.text(value)
				if e != nil {
					t.Fatal(e)
				}
				return keep(v)
			}
			var dataCreate func(uintptr, *byte, int64) uintptr
			var dictCount func(uintptr) int64
			purego.RegisterLibFunc(&dataCreate, c.cf, "CFDataCreate")
			purego.RegisterLibFunc(&dictCount, c.cf, "CFDictionaryGetCount")
			data := func(value []byte) uintptr {
				v := dataCreate(0, &value[0], int64(len(value)))
				runtime.KeepAlive(value)
				return keep(v)
			}
			number := func(value int64) uintptr { return keep(c.numberCreate(0, 4, unsafe.Pointer(&value))) }
			dictionary := func(values map[uintptr]uintptr, retain bool) uintptr {
				var keys, items []uintptr
				for k, v := range values {
					keys = append(keys, k)
					items = append(items, v)
				}
				d := c.dictionaryCreate(0, &keys[0], &items[0], int64(len(keys)), c.keyCallbacks, c.valueCallbacks)
				if d == 0 {
					t.Fatal("CFDictionary construction")
				}
				if retain {
					return keep(d)
				}
				return d
			}
			symbol := func(name string) uintptr {
				v, e := c.symbol(name)
				if e != nil {
					t.Fatal(e)
				}
				return v
			}
			url := func(path string) uintptr {
				raw := []byte(path)
				v := c.urlCreate(0, &raw[0], int64(len(raw)), false)
				runtime.KeepAlive(raw)
				return keep(v)
			}
			readText := func(v uintptr) string {
				s, e := c.readString(v)
				if e != nil {
					t.Fatal(e)
				}
				return s
			}
			newCode := func(value string) uintptr {
				v, e := c.text(value)
				if e != nil {
					t.Fatal(e)
				}
				return v
			}
			var actualFlags []uint32
			var actualSlices []runnerFileSlice
			c.requirementCreate = func(source uintptr, flags uint32, out *uintptr) int32 {
				if flags != 0 {
					t.Fatal("ASSERTION:native-rule-flags")
				}
				*out = newCode(readText(source))
				return 0
			}
			c.guestCopy = func(host, attributes uintptr, flags uint32, out *uintptr) int32 {
				pid, e := c.readNumber(c.dictionaryGet(attributes, symbol("kSecGuestAttributePid")))
				if e != nil || pid != 42 || host != 0 || flags != 0 || dictCount(attributes) != 1 {
					t.Fatal("ASSERTION:native-guest-attributes")
				}
				*out = newCode("guest")
				return 0
			}
			c.copyStatic = func(guest uintptr, flags uint32, out *uintptr) int32 {
				if readText(guest) != "guest" || flags != 0 {
					t.Fatal("ASSERTION:native-copy-static")
				}
				*out = newCode("guest-static")
				return 0
			}
			c.staticAttributes = func(path uintptr, flags uint32, attributes uintptr, out *uintptr) int32 {
				if flags != 0 || dictCount(attributes) != 2 {
					t.Fatal("ASSERTION:native-explicit-attribute-count")
				}
				cpu, e := c.readNumber(c.dictionaryGet(attributes, symbol("kSecCodeAttributeArchitecture")))
				if e != nil {
					t.Fatal(e)
				}
				sub, e := c.readNumber(c.dictionaryGet(attributes, symbol("kSecCodeAttributeSubarchitecture")))
				if e != nil {
					t.Fatal(e)
				}
				if cpu != 16777228 || sub != 0 && sub != 2 && sub != -2147483646 {
					t.Fatal("ASSERTION:native-explicit-cpu-subtype")
				}
				copyPath := c.urlPath(path, 0)
				if copyPath == 0 {
					t.Fatal("CFURL path")
				}
				actual := readText(copyPath)
				c.release(copyPath)
				if actual != "/fixture/Executable" {
					t.Fatal("ASSERTION:native-explicit-path")
				}
				offset := uint64(0)
				if sub == 2 {
					offset = 4096
				}
				if sub == -2147483646 {
					offset = 16384
				}
				actualSlices = append(actualSlices, runnerFileSlice{CPU: int32(cpu), Subtype: int32(sub), Offset: offset, Size: 4096})
				*out = newCode("slice:" + strconv.FormatInt(sub, 10))
				return 0
			}
			c.staticCreate = func(path uintptr, flags uint32, out *uintptr) int32 {
				value := c.urlPath(path, 0)
				actual := readText(value)
				c.release(value)
				if flags != 0 || actual != "/Applications/Google Chrome.app" {
					t.Fatal("ASSERTION:native-chrome-fixed-bundle")
				}
				*out = newCode("bundle")
				return 0
			}
			c.guestCheck = func(code uintptr, flags uint32, rule uintptr) int32 {
				actualFlags = append(actualFlags, flags)
				if readText(code) != "guest" {
					t.Fatal("ASSERTION:native-live-code")
				}
				expected, _ := runnerReceiptRequirement(role)
				if readText(rule) != expected {
					return -67050
				}
				return 0
			}
			c.staticCheck = func(code uintptr, flags uint32, rule uintptr) int32 {
				actualFlags = append(actualFlags, flags)
				if !runnerOneOf(readText(code), "guest-static bundle slice:0 slice:2") {
					t.Fatal("ASSERTION:native-static-code")
				}
				expected, _ := runnerReceiptRequirement(role)
				if readText(rule) != expected {
					return -67050
				}
				return 0
			}
			informationMode := "normal"
			c.information = func(code uintptr, flags uint32, out *uintptr) int32 {
				phases, _, _ := c.trace.Snapshot()
				if len(phases) == 0 || phases[len(phases)-1].Phase != "entered" || phases[len(phases)-1].Operation != "SecCodeCopySigningInformation" {
					t.Fatal("ASSERTION:native-phase-before-call")
				}
				if flags != 3 {
					t.Fatal("ASSERTION:native-information-flags")
				}
				tag := readText(code)
				kind, offset := int64(2), int64(0)
				if tag == "slice:2" {
					kind = 3
					offset = 4096
				}
				hash, full := bytes.Repeat([]byte{1}, 20), bytes.Repeat([]byte{1}, 32)
				if informationMode == "short-full" {
					full = full[:19]
				}
				kindValue := number(kind)
				if informationMode == "numeric-bool" {
					v, e := readProofExport(c.cf, "kCFBooleanTrue")
					if e != nil {
						t.Fatal(e)
					}
					kindValue = v
				}
				if informationMode == "floating-type" {
					value := float64(kind)
					kindValue = keep(c.numberCreate(0, 6, unsafe.Pointer(&value)))
				}
				fullMap := dictionary(map[uintptr]uintptr{number(kind): data(full)}, true)
				values := map[uintptr]uintptr{symbol("kSecCodeInfoUnique"): data(hash), symbol("kSecCodeInfoDigestAlgorithm"): kindValue, symbol("kSecCodeInfoIdentifier"): text(role), symbol("kSecCodeInfoMainExecutable"): url("/fixture/Executable"), text("cdhashes-full"): fullMap, text("CodeOffset"): number(offset)}
				*out = dictionary(values, false)
				return 0
			}
			fake := newRunnerFakeCode(role)
			ops := c.operations(role, "/fixture/Executable")
			ops.BSD = fake.ops.BSD
			ops.Kernel = fake.ops.Kernel
			ops.Open = fake.ops.Open
			fact, e := bindRunnerIndependentCode(42, role, "/fixture/Executable", "", ops)
			if e != nil || !fact.Bound || len(actualSlices) != 2 || actualSlices[0].Subtype != 0 || actualSlices[1].Subtype != 2 {
				t.Fatalf("ASSERTION:native-constructor-routing %v", e)
			}
			if len(actualFlags) != len(fact.Statuses) {
				t.Fatal("ASSERTION:native-actual-validity-count")
			}
			for i, flags := range actualFlags {
				if flags != fact.Statuses[i].Flags {
					t.Fatal("ASSERTION:native-actual-validity-flags")
				}
			}
			signed := runnerFileSlice{CPU: 16777228, Subtype: -2147483646, Offset: 16384, Size: 4096}
			if _, e := c.explicit("/fixture/Executable", signed); e != nil || actualSlices[len(actualSlices)-1].Subtype != signed.Subtype {
				t.Fatal("ASSERTION:native-signed-subtype", e)
			}
			for _, name := range []string{"kCFBooleanTrue", "kCFBooleanFalse"} {
				value, e := readProofExport(c.cf, name)
				if e != nil {
					t.Fatal(e)
				}
				if _, e := c.readNumber(value); e == nil {
					t.Fatal("ASSERTION:native-boolean-number")
				}
			}
			for _, mode := range []string{"numeric-bool", "floating-type", "short-full"} {
				informationMode = mode
				value, e := ops.LiveInformation()
				if e == nil {
					t.Errorf("ASSERTION:native-typed-information-%s type=%d", mode, value.Type)
				}
			}
			phases, lost, pending := c.trace.Snapshot()
			if lost || pending != 0 || len(phases) == 0 {
				t.Fatal("ASSERTION:native-phase-completeness")
			}
			pairs := map[uint64][]runnerNativePhase{}
			for _, phase := range phases {
				pairs[phase.Ordinal] = append(pairs[phase.Ordinal], phase)
			}
			for _, pair := range pairs {
				if len(pair) != 2 || pair[0].Phase != "entered" || pair[1].Phase != "completed" || pair[0].Operation != pair[1].Operation || pair[0].PID != 42 || pair[1].ElapsedMS < pair[0].ElapsedMS {
					t.Fatal("ASSERTION:native-phase-pair")
				}
			}
			for _, call := range c.calls {
				if strings.Contains(call.Operation, "csops") || call.Operation == "proc_pidpath" {
					t.Fatal(fmt.Sprintf("unexpected native query: %s", call.Operation))
				}
			}
		})
	}
}
