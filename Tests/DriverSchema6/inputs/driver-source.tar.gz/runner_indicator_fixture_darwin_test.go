package integration

import (
 "fmt"
 "math"
 "testing"
)

func TestRunnerIndicatorUsesIndependentFloatingGeometry(t *testing.T) {
 for _,width:=range []float64{359,410} {
  facts,windows:=runnerPresenceFixture();windows[0].Rect.Width=width
  contract:=runnerIndicatorContract{independentRect{0,0,1024,768},7}
  candidate,err:=runnerIndicatorCandidate(facts,windows,contract)
  if err!=nil||candidate!=windows[0]{t.Fatalf("ASSERTION:indicator-independent-content-geometry %v",err)}
  claim:=runnerWindowClaim{Label:"app",PID:candidate.PID,ID:candidate.ID,Rect:candidate.Rect,Layer:candidate.Layer}
  if runnerIndicatorClaim(candidate,[]runnerWindowClaim{claim})!=nil{t.Fatal("ASSERTION:indicator-paired-positive")}
  claim.Rect.Width++
  if runnerIndicatorClaim(candidate,[]runnerWindowClaim{claim})==nil{t.Fatal("ASSERTION:indicator-paired-mismatch")}
 }
}

func TestRunnerIndicatorRejectsMissingAmbiguousOrUnboundCandidate(t *testing.T) {
 for _,name:=range []string{"pid","layer","duplicate","offscreen","nonfinite","bounds","role","claim-missing","claim-duplicate"} {
  t.Run(name,func(t *testing.T){
   facts,windows:=runnerPresenceFixture();contract:=runnerIndicatorContract{independentRect{0,0,1024,768},7}
   claim:=runnerWindowClaim{Label:"app",PID:windows[0].PID,ID:windows[0].ID,Rect:windows[0].Rect,Layer:windows[0].Layer}
   switch name {
   case "pid":windows[0].PID=999
   case "layer":windows[0].Layer=0
   case "duplicate":w:=windows[0];w.ID=999;windows=append(windows,w)
   case "offscreen":windows[0].OnScreen=false
   case "nonfinite":windows[0].Rect.Width=math.NaN()
   case "bounds":windows[0].Rect.Width=2000
   case "role":f:=facts[100];f.Code.Binding.Bound=false;facts[100]=f
   }
   candidate,err:=runnerIndicatorCandidate(facts,windows,contract)
   if name=="claim-missing" {err=runnerIndicatorClaim(candidate,nil)}
   if name=="claim-duplicate" {err=runnerIndicatorClaim(candidate,[]runnerWindowClaim{claim,claim})}
   if err==nil{t.Fatalf("ASSERTION:indicator-refuses-%s",name)}
  })
 }
}

func TestRunnerControllerRetainsFirstIndividualOperand(t *testing.T) {
 for _,failed:=range []string{"query","union","presence","indicator-pair"} {
  called:=[]string{};sentinel:=fmt.Errorf("specific-%s",failed);checks:=[]runnerControllerOperand{}
  for _,name:=range []string{"query","union","presence","indicator-pair"} {
   name:=name
   checks=append(checks,runnerControllerOperand{name,func()error{called=append(called,name);if name==failed{return sentinel};return nil}})
  }
  stage,err:=runnerCheckControllerOperands(checks...)
  if stage!=failed||err!=sentinel||called[len(called)-1]!=failed{t.Fatal("ASSERTION:controller-first-operand-error")}
 }
}
