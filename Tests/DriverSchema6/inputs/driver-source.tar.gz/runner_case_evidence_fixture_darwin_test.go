package integration

import (
	"encoding/json"
	"testing"
)

func TestRunnerUnavailableEvidenceCannotBecomePassFromContradictoryComplete(t *testing.T) {
	for _, name := range []string{"valid", "screen-refused", "host-refused", "listen-refused", "post-refused", "surface-unavailable", "prior-unavailable-then-valid-preflight"} {
		t.Run(name, func(t *testing.T) {
			selected := "selected-window"
			if name == "listen-refused" || name == "post-refused" {
				selected = "hotkey-stop"
			}
			result := runnerCaseResult{Case: selected, Result: "FAIL"}
			preflight := map[string]any{"stage": "runner-preflight", "screenCapture": true, "listenEvent": true, "postEvent": true, "hosted": true, "osMajor": 27, "architecture": "arm64"}
			if name == "screen-refused" || name == "prior-unavailable-then-valid-preflight" {
				preflight["screenCapture"] = false
			}
			if name == "host-refused" {
				preflight["hosted"] = false
			}
			if name == "listen-refused" {
				preflight["listenEvent"] = false
			}
			if name == "post-refused" {
				preflight["postEvent"] = false
			}
			transcript := []map[string]any{preflight}
			if name == "surface-unavailable" {
				transcript = append(transcript, map[string]any{"stage": "surface-unavailable", "label": "inventory", "reason": "unresolved-owner"})
			}
			if name == "prior-unavailable-then-valid-preflight" {
				transcript = append(transcript, map[string]any{"stage": "runner-preflight", "screenCapture": true, "listenEvent": true, "postEvent": true, "hosted": true, "osMajor": 27, "architecture": "arm64"})
			}
			transcript = append(transcript, map[string]any{"stage": "terminal", "outcome": "complete", "reason": "complete"})
			for i, fields := range transcript {
				fields["schema"] = 6
				fields["case"] = selected
				fields["capture"] = true
				fields["elapsedMs"] = i + 1
				fields["eventElapsedMs"] = i + 1
				raw, err := json.Marshal(fields)
				if err != nil {
					t.Fatal(err)
				}
				row, err := decodeRunnerCaptureRow(raw)
				if err != nil {
					t.Fatal(err)
				}
				runnerObserveCaseAvailability(&result, row)
				if row.Stage == "terminal" {
					_ = runnerFinalizeCasePass(&result)
				}
			}
			if name == "valid" {
				if result.Result != "PASS" || result.EvidenceUnavailable {
					t.Fatal("valid availability control refused")
				}
			} else if result.Result == "PASS" || !result.EvidenceUnavailable || len(result.UnavailableReasons) == 0 {
				t.Fatalf("ASSERTION:unavailable-complete-refused-%s", name)
			}
		})
	}
}
