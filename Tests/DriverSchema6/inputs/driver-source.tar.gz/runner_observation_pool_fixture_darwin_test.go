package integration

import (
	"context"
	"sync/atomic"
	"testing"
	"time"
)

func TestRunnerObservationPoolDoesNotInferSettlementFromDeadline(t *testing.T){
	pool:=newRunnerObservationPool[int](context.Background(),time.Now().Add(time.Second))
	entered,release:=make(chan struct{}),make(chan struct{})
	defer close(release)
	if e:=pool.Submit("held",func(context.Context)(int,error){close(entered);<-release;return 1,nil});e!=nil{t.Fatal(e)}
	select{case<-entered:case<-time.After(time.Second):t.Fatal("worker did not enter")}
	start:=time.Now();results,e:=pool.Wait([]string{"held"},start.Add(20*time.Millisecond))
	if e==nil||len(results)!=0||time.Since(start)>time.Second{t.Fatal("ASSERTION:native-worker-deadline")}
	pool.Close()
	if pool.Settled(){t.Fatal("ASSERTION:native-worker-unsettled")}
	if _,settled:=pool.Result("held");settled{t.Fatal("ASSERTION:native-worker-no-inferred-result")}
	if e:=pool.Submit("late",func(context.Context)(int,error){t.Error("late query executed");return 0,nil});e==nil{t.Fatal("ASSERTION:native-worker-admission-retired")}
}

func TestRunnerObservationPoolBoundsConcurrencyAndReportsEveryResult(t *testing.T){
	pool:=newRunnerObservationPool[int](context.Background(),time.Now().Add(2*time.Second))
	var active,maximum atomic.Int32
	gate:=make(chan struct{})
	for _,key:=range []string{"a","b","c","d","e","f","g","h"}{
		if e:=pool.Submit(key,func(context.Context)(int,error){n:=active.Add(1);for old:=maximum.Load();n>old;old=maximum.Load(){if maximum.CompareAndSwap(old,n){break}};<-gate;active.Add(-1);return 7,nil});e!=nil{t.Fatal(e)}
	}
	if e:=pool.Submit("a",func(context.Context)(int,error){return 0,nil});e==nil{t.Fatal("ASSERTION:native-worker-duplicate")}
	close(gate)
	results,e:=pool.Wait([]string{"a","b","c","d","e","f","g","h"},time.Now().Add(time.Second))
	if e!=nil||len(results)!=8||maximum.Load()>4{t.Fatalf("ASSERTION:native-worker-completeness %v",e)}
	for _,r:=range results{if r.Value!=7||r.CancelledBeforeStart||r.Started.IsZero()||r.Finished.Before(r.Started){t.Fatal("ASSERTION:native-worker-result")}}
	pool.Close()
	select{case<-pool.done:case<-time.After(time.Second):t.Fatal("workers did not stop")}
	if !pool.Settled(){t.Fatal("ASSERTION:native-worker-complete-settlement")}
	if _,e:=pool.Wait([]string{"unknown"},time.Now().Add(time.Second));e==nil{t.Fatal("unknown dependency accepted")}
	if _,e:=pool.Wait([]string{"a","a"},time.Now().Add(time.Second));e==nil{t.Fatal("duplicate dependency accepted")}
}
