package integration

import (
	"encoding/binary"
	"fmt"
	"os"
	"os/exec"
	"testing"

	"github.com/ebitengine/purego"
)

type ownedIncarnation struct {
	PID           int
	Parent        int
	UID           uint32
	Unique        uint64
	ParentUnique  uint64
	Version       uint32
	ParentVersion uint32
}

func inspectOwnedIncarnation(pid, expectedParent int) (result ownedIncarnation, err error) {
	result, err = inspectRunnerIncarnation(pid)
	if err != nil {
		return result, err
	}
	if expectedParent <= 0 || result.Parent != expectedParent || result.UID != uint32(os.Getuid()) {
		return ownedIncarnation{}, fmt.Errorf("owned incarnation mismatch")
	}
	return result, nil
}
func inspectRunnerIncarnation(pid int) (result ownedIncarnation, err error) {
	if pid <= 0 {
		return result, fmt.Errorf("invalid owned identity")
	}
	defer func() {
		if recover() != nil {
			err = fmt.Errorf("incarnation query unavailable")
		}
	}()
	lib, e := purego.Dlopen("/usr/lib/libproc.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if e != nil {
		return result, e
	}
	defer purego.Dlclose(lib)
	var info func(int32, int32, uint64, *byte, int32) int32
	purego.RegisterLibFunc(&info, lib, "proc_pidinfo")
	var first, last [56]byte
	var bsd [64]byte
	if info(int32(pid), 17, 0, &first[0], 56) != 56 || info(int32(pid), 13, 0, &bsd[0], 64) != 64 || info(int32(pid), 17, 0, &last[0], 56) != 56 {
		return result, fmt.Errorf("incarnation query failed")
	}
	state := binary.LittleEndian.Uint32(bsd[12:16])
	if state != 2 && state != 3 && state != 4 {
		return result, fmt.Errorf("owned process is not live")
	}
	if first != last {
		return result, fmt.Errorf("incarnation changed while sampled")
	}
	result = ownedIncarnation{PID: int(binary.LittleEndian.Uint32(bsd[:4])), Parent: int(binary.LittleEndian.Uint32(bsd[4:8])), UID: binary.LittleEndian.Uint32(bsd[36:40]), Unique: binary.LittleEndian.Uint64(first[16:24]), ParentUnique: binary.LittleEndian.Uint64(first[24:32]), Version: binary.LittleEndian.Uint32(first[32:36]), ParentVersion: binary.LittleEndian.Uint32(first[36:40])}
	if result.PID != pid || result.Parent <= 0 || result.Unique == 0 {
		return ownedIncarnation{}, fmt.Errorf("owned incarnation mismatch")
	}
	return result, nil
}
func TestOwnedIncarnationObserver(t *testing.T) {
	before, e := inspectOwnedIncarnation(os.Getpid(), os.Getppid())
	if e != nil {
		t.Fatal(e)
	}
	child := exec.Command("/bin/sleep", "2")
	if child.Start() != nil {
		t.Fatal("owned child launch failed")
	}
	defer func() { _ = child.Process.Kill(); _ = child.Wait() }()
	observed, e := inspectOwnedIncarnation(child.Process.Pid, os.Getpid())
	if e != nil {
		t.Fatal(e)
	}
	after, e := inspectOwnedIncarnation(os.Getpid(), os.Getppid())
	if e != nil || before != after {
		t.Fatal("self identity changed unexpectedly")
	}
	if observed.Unique == before.Unique || observed.ParentUnique != before.Unique || observed.ParentVersion != before.Version {
		t.Fatal("independent parent/incarnation query disagreed")
	}
	if _, e := inspectOwnedIncarnation(child.Process.Pid, os.Getppid()); e == nil {
		t.Fatal("wrong parent accepted")
	}
	if _, e := inspectOwnedIncarnation(0, os.Getpid()); e == nil {
		t.Fatal("invalid PID accepted")
	}
}
