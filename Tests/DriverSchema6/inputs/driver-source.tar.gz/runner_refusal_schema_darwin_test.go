package integration

import (
 "encoding/json"
 "fmt"
 "math"
 "strings"
)

const runnerInventoryRefusalSite = "initial refresh monitor authorization-baseline"
const runnerInventoryRefusalIssue = "permission surface-identity browser-identity shareable-content display-geometry cg-inventory owner-attribution completeness surface-geometry browser-window-count window-identity app-windows authorization-requester authorization-missing authorization-ambiguous authorization-identity source-changed unclassified-owner unknown"
const runnerInventoryRefusalBranch = "operation host permission surface-role browser-count shareable-content main-display cg-list cg-fields sck-owner owner-identifier owner-role owner-verification requester owned-verification display context window-ids owner-pids owner-fields surface-identity app-identity browser-identity windowserver owner-class completeness geometry-pair pid-pair bundle-pair geometry duplicate-geometry allowed app-window browser-window authorization-request authorization-window allowed-lookup"
const runnerInventoryRefusalComparison = "operation present count pid parent effective-uid real-uid saved-uid verified start-seconds start-microseconds identifier absolute-path hash-length sysctl-bound apple-anchor unique nonzero rect layer cg-pid sck-pid bundle finite positive-size cg-presence sck-presence requester baseline requested-at"

type runnerDiagnosticIdentifier struct {
 Status string `json:"status"`
 Value *string `json:"value"`
 Bytes *int64 `json:"bytes"`
}

type runnerDiagnosticOwnerClaim struct {
 PID int32 `json:"pid"`
 Parent int32 `json:"parent"`
 EffectiveUID uint32 `json:"effectiveUID"`
 RealUID *uint32 `json:"realUID"`
 SavedUID *uint32 `json:"savedUID"`
 StartSeconds uint64 `json:"startSeconds"`
 StartMicroseconds uint64 `json:"startMicroseconds"`
 Verified bool `json:"verified"`
 AppleAnchored bool `json:"appleAnchored"`
 SysctlBound bool `json:"sysctlBound"`
 HashBytes int64 `json:"hashBytes"`
}

type runnerDiagnosticRect struct {
 X *float64 `json:"x"`
 Y *float64 `json:"y"`
 Width *float64 `json:"width"`
 Height *float64 `json:"height"`
}

type runnerDiagnosticWindow struct {
 ID uint32 `json:"windowID"`
 PID *int32 `json:"pid"`
 Layer int64 `json:"layer"`
 Rect runnerDiagnosticRect `json:"rect"`
 OwnerPresent *bool `json:"ownerPresent,omitempty"`
 Bundle *runnerDiagnosticIdentifier `json:"bundle,omitempty"`
}

type runnerInventoryRefusal struct {
 Attempt int64
 Site,Issue,Branch,Comparison string
 PID *int32
 WindowID *uint32
 SigningIdentifier runnerDiagnosticIdentifier
 SigningIdentifierSource string
 Owner *runnerDiagnosticOwnerClaim
 CGCount,SCKCount int64
 CG,SCK []runnerDiagnosticWindow
}

func runnerDiagnosticObject(raw json.RawMessage,keys,nullable string)(map[string]json.RawMessage,error) {
 var object map[string]json.RawMessage
 if string(raw)=="null"||json.Unmarshal(raw,&object)!=nil||runnerExactNullableFields(object,strings.Fields(keys),nullable)!=nil{return nil,fmt.Errorf("invalid diagnostic object fields")}
 return object,nil
}

func runnerDiagnosticInteger(raw json.RawMessage,low,high int64)error {
 var n int64
 if string(raw)=="null"||json.Unmarshal(raw,&n)!=nil||n<low||n>high{return fmt.Errorf("invalid diagnostic integer")}
 return nil
}

func runnerDiagnosticIdentifierValue(raw json.RawMessage)(value runnerDiagnosticIdentifier,err error) {
 f,err:=runnerDiagnosticObject(raw,"status value bytes","value bytes");if err!=nil{return value,err}
 if json.Unmarshal(raw,&value)!=nil{return value,fmt.Errorf("invalid diagnostic identifier types")}
 switch value.Status {
 case "unavailable":
  if value.Value!=nil||value.Bytes!=nil{return value,fmt.Errorf("unavailable identifier has value")}
 case "invalid-identifier":
  if value.Value!=nil||value.Bytes==nil||*value.Bytes<0{return value,fmt.Errorf("invalid identifier envelope")}
 case "present":
  if value.Value==nil||value.Bytes==nil||*value.Bytes!=int64(len(*value.Value))||*value.Bytes<1||*value.Bytes>255{return value,fmt.Errorf("identifier byte count mismatch")}
  text:=*value.Value
  for _,b:=range []byte(text){if !(b>='A'&&b<='Z'||b>='a'&&b<='z'||b>='0'&&b<='9'||b=='-'||b=='.'){return value,fmt.Errorf("identifier grammar refused")}}
  labels:=strings.Split(text,".");if len(labels)<2{return value,fmt.Errorf("identifier labels missing")}
  for _,label:=range labels {if label==""||strings.HasPrefix(label,"-")||strings.HasSuffix(label,"-"){return value,fmt.Errorf("identifier label refused")}}
 default:return value,fmt.Errorf("identifier status unknown")
 }
 _=f;return value,nil
}

func runnerDiagnosticRectangle(raw json.RawMessage)(value runnerDiagnosticRect,err error) {
 f,err:=runnerDiagnosticObject(raw,"x y width height","x y width height");if err!=nil{return value,err}
 if json.Unmarshal(raw,&value)!=nil{return value,fmt.Errorf("diagnostic rect types")}
 for _,key:=range []string{"x","y","width","height"}{if string(f[key])=="null"{continue};var n float64;if json.Unmarshal(f[key],&n)!=nil||math.IsNaN(n)||math.IsInf(n,0){return value,fmt.Errorf("diagnostic rect number invalid")}}
 return value,nil
}

func runnerDiagnosticWindowRows(raw json.RawMessage,count int64,sck bool)(rows []runnerDiagnosticWindow,err error) {
 var items []json.RawMessage
 if string(raw)=="null"||json.Unmarshal(raw,&items)!=nil||len(items)>2||int64(len(items))!=min(count,2){return nil,fmt.Errorf("diagnostic row count mismatch")}
 for _,item:=range items {
  keys,nullable:="windowID pid layer rect",""
  if sck {keys+=" ownerPresent bundle";nullable="pid"}
  f,e:=runnerDiagnosticObject(item,keys,nullable);if e!=nil{return nil,e}
  var row runnerDiagnosticWindow
  if json.Unmarshal(item,&row)!=nil||runnerDiagnosticInteger(f["windowID"],0,math.MaxUint32)!=nil||runnerDiagnosticInteger(f["layer"],math.MinInt64,math.MaxInt64)!=nil{return nil,fmt.Errorf("diagnostic window types")}
  if string(f["pid"])!="null"&&runnerDiagnosticInteger(f["pid"],math.MinInt32,math.MaxInt32)!=nil{return nil,fmt.Errorf("diagnostic window pid type")}
  row.Rect,e=runnerDiagnosticRectangle(f["rect"]);if e!=nil{return nil,e}
  if sck {
   if row.OwnerPresent==nil||*row.OwnerPresent!=(row.PID!=nil){return nil,fmt.Errorf("diagnostic owner presence mismatch")}
   bundle,e:=runnerDiagnosticIdentifierValue(f["bundle"]);if e!=nil{return nil,e};row.Bundle=&bundle
  }
  rows=append(rows,row)
 }
 return rows,nil
}

func decodeRunnerInventoryRefusal(row runnerCaptureRow)(value runnerInventoryRefusal,err error) {
 f:=row.Fields
 keys:="schema case capture stage elapsedMs eventElapsedMs attempt site issue branch comparison pid windowID signingIdentifier signingIdentifierSource owner cgCount sckCount cg sck"
 if runnerExactNullableFields(f,strings.Fields(keys),"pid windowID owner")!=nil{return value,fmt.Errorf("inventory refusal field set")}
 if value.Attempt,err=runnerInt(f,"attempt",1,math.MaxInt64);err!=nil{return value,err}
 enums:=[]struct{key,allowed string;target *string}{{"site",runnerInventoryRefusalSite,&value.Site},{"issue",runnerInventoryRefusalIssue,&value.Issue},{"branch",runnerInventoryRefusalBranch,&value.Branch},{"comparison",runnerInventoryRefusalComparison,&value.Comparison}}
 for _,entry:=range enums {text,e:=runnerText(f,entry.key);if e!=nil||!runnerOneOf(text,entry.allowed){return value,fmt.Errorf("inventory refusal enum invalid")};*entry.target=text}
 if json.Unmarshal(f["pid"],&value.PID)!=nil||json.Unmarshal(f["windowID"],&value.WindowID)!=nil{return value,fmt.Errorf("inventory refusal nullable pid/window invalid")}
 value.SigningIdentifier,err=runnerDiagnosticIdentifierValue(f["signingIdentifier"]);if err!=nil{return value,err}
 value.SigningIdentifierSource,err=runnerText(f,"signingIdentifierSource");if err!=nil||!runnerOneOf(value.SigningIdentifierSource,"unavailable tentative verified"){return value,fmt.Errorf("identifier provenance invalid")}
 if (value.SigningIdentifier.Status=="unavailable")!=(value.SigningIdentifierSource=="unavailable"){return value,fmt.Errorf("identifier provenance availability mismatch")}
 if string(f["owner"])!="null" {
  ownerFields,e:=runnerDiagnosticObject(f["owner"],"pid parent effectiveUID realUID savedUID startSeconds startMicroseconds verified appleAnchored sysctlBound hashBytes","realUID savedUID");if e!=nil{return value,e}
  var owner runnerDiagnosticOwnerClaim
  if json.Unmarshal(f["owner"],&owner)!=nil||owner.HashBytes<0{return value,fmt.Errorf("inventory refusal owner types")}
  for _,key:=range []string{"verified","appleAnchored","sysctlBound"}{if _,e:=runnerBool(ownerFields,key);e!=nil{return value,e}}
  for _,key:=range []string{"pid","parent"}{if runnerDiagnosticInteger(ownerFields[key],math.MinInt32,math.MaxInt32)!=nil{return value,fmt.Errorf("inventory refusal owner integer")}}
  value.Owner=&owner
 }
 if value.SigningIdentifierSource=="verified"&&(value.Owner==nil||!value.Owner.Verified){return value,fmt.Errorf("verified provenance lacks verified owner claim")}
 if value.CGCount,err=runnerInt(f,"cgCount",0,math.MaxInt64);err!=nil{return value,err}
 if value.SCKCount,err=runnerInt(f,"sckCount",0,math.MaxInt64);err!=nil{return value,err}
 value.CG,err=runnerDiagnosticWindowRows(f["cg"],value.CGCount,false);if err!=nil{return value,err}
 value.SCK,err=runnerDiagnosticWindowRows(f["sck"],value.SCKCount,true);if err!=nil{return value,err}
 return value,nil
}
