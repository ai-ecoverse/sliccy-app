package integration

import (
	"fmt"
	"testing"
	"time"
)

type frameBaselineController struct {
	opened    bool
	first     time.Time
	attempts  uint64
	confirmed bool
}

func (b *frameBaselineController) next(now time.Time) (uint64, error) {
	if !b.opened || b.confirmed || b.attempts >= 5 || (!b.first.IsZero() && !now.Before(b.first.Add(5*time.Second))) {
		return 0, fmt.Errorf("baseline request outside fixed budget")
	}
	if b.first.IsZero() {
		b.first = now
	}
	b.attempts++
	return b.attempts, nil
}
func (b *frameBaselineController) observe(seq uint64, now time.Time) (bool, error) {
	if seq == 0 || seq > b.attempts || b.attempts == 0 || b.confirmed || !now.Before(b.first.Add(5*time.Second)) {
		return false, fmt.Errorf("unexpected baseline sequence/lifetime")
	}
	if seq < b.attempts {
		return false, nil
	}
	b.confirmed = true
	return true, nil
}
func TestFrameBaselineBudgetAndLateFrames(t *testing.T) {
	start := time.Unix(1, 0)
	var b frameBaselineController
	if _, e := b.next(start); e == nil {
		t.Fatal("request before OPENED")
	}
	b.opened = true
	if n, e := b.next(start); e != nil || n != 1 {
		t.Fatal("first request failed")
	}
	if n, e := b.next(start.Add(time.Second)); e != nil || n != 2 {
		t.Fatal("second request failed")
	}
	if accepted, e := b.observe(1, start.Add(2*time.Second)); e != nil || accepted {
		t.Fatal("late frame acknowledged")
	}
	if accepted, e := b.observe(2, start.Add(2*time.Second)); e != nil || !accepted {
		t.Fatal("current frame not acknowledged")
	}
	if _, e := b.next(start.Add(3 * time.Second)); e == nil {
		t.Fatal("request after acknowledgement")
	}
	if _, e := b.observe(3, start.Add(3*time.Second)); e == nil {
		t.Fatal("transferred next frame admitted")
	}
	limit := frameBaselineController{opened: true}
	for n := uint64(1); n <= 5; n++ {
		if got, e := limit.next(start); e != nil || got != n {
			t.Fatal("bounded request rejected")
		}
	}
	if _, e := limit.next(start); e == nil {
		t.Fatal("sixth request accepted")
	}
	expired := frameBaselineController{opened: true}
	if _, e := expired.next(start); e != nil {
		t.Fatal(e)
	}
	if _, e := expired.next(start.Add(5 * time.Second)); e == nil {
		t.Fatal("request beyond deadline")
	}
	if _, e := expired.observe(1, start.Add(5*time.Second)); e == nil {
		t.Fatal("late baseline accepted")
	}
}
