package integration

import (
 "strings"
 "testing"
 "unsafe"
)

func TestRunnerNativeKernelAdapterRetainsActualReturnsErrnoAndCallOrder(t *testing.T){
 for _,failure:=range []string{"none","path","hash","flags"}{t.Run(failure,func(t *testing.T){
  trace:=newRunnerNativeTrace();var errno int32
  c:=&runnerSecurityContext{pid:42,trace:trace,errorPointer:func()*int32{return &errno}}
  assertEntered:=func(operation string){rows,_,_:=trace.Snapshot();if len(rows)==0||rows[len(rows)-1].Operation!=operation||rows[len(rows)-1].Phase!="entered"{t.Fatal("ASSERTION:kernel-entered-before-call")}}
  c.pidpath=func(pid int32,out *byte,size uint32)int32{
   assertEntered("proc_pidpath")
   if pid!=42||size!=4096{t.Fatal("fixed pidpath arguments")}
   if failure=="path"{errno=1;return 0}
   path:=[]byte("/System/Library/Fixture/Executable\x00");copy(unsafe.Slice(out,4096),path);return int32(len(path)-1)
  }
  c.csops=func(pid int32,operation uint32,out *byte,size uint64)int32{
   if pid!=42{t.Fatal("fixed csops PID")}
   if operation==5{
    assertEntered("csops-CDHASH");if size!=20{t.Fatal("fixed hash size")}
    if failure=="hash"{errno=1;return -1}
    for i:=range unsafe.Slice(out,20){unsafe.Slice(out,20)[i]=1};return 0
   }
   assertEntered("csops-STATUS");if operation!=0||size!=4{t.Fatal("fixed status arguments")}
   if failure=="flags"{errno=1;return -1}
   copy(unsafe.Slice(out,4),[]byte{0,0,0,4});return 0
  }
  value,err:=c.kernel()
  rows,lost,pending:=trace.Snapshot()
  if lost||pending!=0{t.Fatal("ASSERTION:kernel-phase-completeness")}
  if failure=="none"{if err!=nil||value.Path!="/System/Library/Fixture/Executable"||value.Flags!=0x04000000||value.Hash[0]!=1||len(c.calls)!=3{t.Fatal("ASSERTION:kernel-actual-values",err)}}else{
   if err==nil{t.Fatal("ASSERTION:kernel-refuse-"+failure)}
   last:=rows[len(rows)-1]
   if last.ReturnValue==nil||last.Errno==nil||*last.Errno!=1||last.ValuePresent==nil||*last.ValuePresent{t.Fatal("ASSERTION:kernel-exact-errno")}
   expected:=int32(-1);if failure=="path"{expected=0}
   if *last.ReturnValue!=expected||c.calls[len(c.calls)-1].Errno==nil||*c.calls[len(c.calls)-1].Errno!=1{t.Fatal("ASSERTION:kernel-exact-return")}
   if !strings.Contains(err.Error(),"errno=1"){t.Fatal("kernel diagnostic reason lost")}
  }
 })}
}
