package integration

import (
	"context"
	"io"
	"os/exec"
	"sort"
	"strconv"
	"strings"
	"time"
)

type nullFDInventory struct {
	fds       []int
	at        time.Time
	available bool
}

func inspectOwnedNullFDs(pid int) nullFDInventory {
	ctx, cancel := context.WithTimeout(context.Background(), 300*time.Millisecond)
	defer cancel()
	cmd := exec.CommandContext(ctx, "/usr/sbin/lsof", "-a", "-p", strconv.Itoa(pid), "-n", "-P", "-Ffn")
	out := &proofRows{}
	cmd.Stdout = out
	cmd.Stderr = io.Discard
	err := cmd.Run()
	result := nullFDInventory{at: time.Now(), available: err == nil && !out.overflow}
	current := -1
	for _, line := range strings.Split(string(out.data), "\n") {
		if strings.HasPrefix(line, "f") {
			current = -1
			number, e := strconv.Atoi(strings.TrimRight(line[1:], "rwu"))
			if e == nil {
				current = number
			}
		}
		if current >= 0 && line == "n/dev/null" {
			result.fds = append(result.fds, current)
		}
	}
	sort.Ints(result.fds)
	return result
}
