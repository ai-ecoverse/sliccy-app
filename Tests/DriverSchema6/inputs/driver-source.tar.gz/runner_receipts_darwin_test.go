package integration

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sort"
	"strings"
	"testing"
)

type runnerReceipt struct {
	Stage, Key  string
	Fields      map[string]json.RawMessage
	Canonical   []byte
	Count       int64
	First, Last float64
	Aggregate   bool
	BSD         *runnerBSDReceipt
	Code        *runnerCodeReceipt
}

type runnerReceiptEntry struct {
	Receipt runnerReceipt
	Count   uint64
}

type runnerReceiptBook struct {
	Entries map[string]runnerReceiptEntry
	Rows    int
}

func runnerExactNullableFields(fields map[string]json.RawMessage, keys []string, nullable string) error {
	if len(fields) != len(keys) {
		return fmt.Errorf("wrong nullable field set")
	}
	for _, key := range keys {
		value, ok := fields[key]
		if !ok || len(value) == 0 || string(value) == "null" && !runnerOneOf(key, nullable) {
			return fmt.Errorf("missing/nonnullable receipt field")
		}
	}
	return nil
}

func runnerReceiptCanonical(fields map[string]json.RawMessage) ([]byte, error) {
	keys := make([]string, 0, len(fields))
	for key := range fields {
		for _, c := range key {
			if c < 'A' || c > 'Z' && c < 'a' || c > 'z' {
				return nil, fmt.Errorf("nonfixed receipt key")
			}
		}
		keys = append(keys, key)
	}
	sort.Strings(keys)
	var out bytes.Buffer
	out.WriteByte('{')
	for i, key := range keys {
		if i != 0 {
			out.WriteByte(',')
		}
		out.WriteByte('"')
		out.WriteString(key)
		out.WriteString(`":`)
		out.Write(fields[key])
	}
	out.WriteByte('}')
	if out.Len() > 3584 {
		return nil, fmt.Errorf("canonical receipt exceeded bound")
	}
	return out.Bytes(), nil
}

func decodeRunnerReceipt(row runnerCaptureRow) (runnerReceipt, error) {
	r := runnerReceipt{Stage: row.Stage}
	if !runnerOneOf(row.Stage, "bsd-identity code-binding") {
		return r, fmt.Errorf("unknown receipt stage")
	}
	f := row.Fields
	var e error
	if r.Key, e = runnerText(f, "receiptKey"); e != nil || len(r.Key) != 64 {
		return r, fmt.Errorf("invalid receipt key")
	}
	if decoded, err := hex.DecodeString(r.Key); err != nil || len(decoded) != 32 || strings.ToLower(r.Key) != r.Key {
		return r, fmt.Errorf("invalid receipt digest")
	}
	if r.Aggregate, e = runnerBool(f, "receiptAggregate"); e != nil {
		return r, e
	}
	if r.Count, e = runnerInt(f, "receiptCount", 1, 100000); e != nil {
		return r, e
	}
	if json.Unmarshal(f["firstEventElapsedMs"], &r.First) != nil || string(f["firstEventElapsedMs"]) == "null" || !finiteNonnegative(r.First) {
		return r, fmt.Errorf("invalid first receipt time")
	}
	if json.Unmarshal(f["lastEventElapsedMs"], &r.Last) != nil || string(f["lastEventElapsedMs"]) == "null" || !finiteNonnegative(r.Last) || r.First > r.Last || r.Last > row.Elapsed || row.Event != r.Last {
		return r, fmt.Errorf("invalid receipt interval")
	}
	keys := strings.Fields("schema case capture stage elapsedMs eventElapsedMs receiptKey receiptAggregate receiptCount firstEventElapsedMs lastEventElapsedMs")
	if r.Aggregate {
		if e := runnerExactFields(f, keys); e != nil {
			return r, e
		}
		return r, nil
	}
	if r.Count != 1 || r.First != r.Last {
		return r, fmt.Errorf("full receipt is not one actual observation")
	}
	var core []string
	nullable := ""
	if row.Stage == "bsd-identity" {
		core = strings.Fields("role phase pid status selfPID parentPID controls target accepted usedSysctl controlsAgreed")
		nullable = "usedSysctl controlsAgreed"
	} else {
		core = strings.Fields("role site passed step statuses selected compared")
		nullable = "selected"
	}
	keys = append(keys, core...)
	if e := runnerExactNullableFields(f, keys, nullable); e != nil {
		return r, e
	}
	r.Fields = make(map[string]json.RawMessage, len(core))
	for _, key := range core {
		r.Fields[key] = append(json.RawMessage(nil), f[key]...)
	}
	if r.Canonical, e = runnerReceiptCanonical(r.Fields); e != nil {
		return r, e
	}
	digest := sha256.Sum256(r.Canonical)
	if hex.EncodeToString(digest[:]) != r.Key {
		return r, fmt.Errorf("receipt digest does not bind complete fields")
	}
	if row.Stage == "bsd-identity" {
		bsd, e := decodeRunnerBSDReceipt(r.Fields)
		if e != nil {
			return r, e
		}
		r.BSD = &bsd
	} else {
		code, e := decodeRunnerCodeReceipt(r.Fields)
		if e != nil {
			return r, e
		}
		r.Code = &code
	}
	return r, nil
}

func (b *runnerReceiptBook) Add(r runnerReceipt) error {
	if b.Rows >= 16384 {
		return fmt.Errorf("receipt row bound exceeded")
	}
	if b.Entries == nil {
		b.Entries = map[string]runnerReceiptEntry{}
	}
	previous, known := b.Entries[r.Key]
	if r.Aggregate {
		if !known || previous.Receipt.Stage != r.Stage {
			return fmt.Errorf("aggregate has no preceding complete same-stage receipt")
		}
		if previous.Receipt.BSD != nil && !previous.Receipt.BSD.Accepted || previous.Receipt.Code != nil && !previous.Receipt.Code.Passed {
			return fmt.Errorf("refused BSD receipt was aggregated")
		}
	} else {
		if known && (previous.Receipt.Stage != r.Stage || !bytes.Equal(previous.Receipt.Canonical, r.Canonical)) {
			return fmt.Errorf("receipt key reused for different complete evidence")
		}
		if !known && len(b.Entries) >= 4096 {
			return fmt.Errorf("receipt history bound exceeded")
		}
	}
	if !known {
		previous.Receipt = r
	}
	if previous.Count > ^uint64(0)-uint64(r.Count) {
		return fmt.Errorf("receipt count overflow")
	}
	previous.Count += uint64(r.Count)
	b.Entries[r.Key] = previous
	b.Rows++
	return nil
}

func TestRunnerReceiptBookRequiresCompleteEvidenceAndKeepsCounts(t *testing.T) {
	fields := map[string]json.RawMessage{"role": json.RawMessage(`"com.apple.WindowServer"`), "phase": json.RawMessage(`"before"`), "compared": json.RawMessage(`{"nested":[true,null,"/fixed/path"]}`)}
	canonical, e := runnerReceiptCanonical(fields)
	if e != nil || string(canonical) != `{"compared":{"nested":[true,null,"/fixed/path"]},"phase":"before","role":"com.apple.WindowServer"}` {
		t.Fatal("complete raw canonical field ordering changed", e)
	}
	digest := sha256.Sum256(canonical)
	full := runnerReceipt{Stage: "bsd-identity", Key: hex.EncodeToString(digest[:]), Fields: fields, Canonical: canonical, Count: 1, First: 1, Last: 1}
	aggregate := runnerReceipt{Stage: full.Stage, Key: full.Key, Aggregate: true, Count: 2, First: 2, Last: 3}
	var b runnerReceiptBook
	if b.Add(aggregate) == nil {
		t.Fatal("unknown aggregate accepted")
	}
	if b.Add(full) != nil || b.Add(aggregate) != nil || b.Entries[full.Key].Count != 3 {
		t.Fatal("complete/count correlation failed")
	}
	changed := full
	changed.Canonical = []byte(`{"role":"changed"}`)
	if b.Add(changed) == nil {
		t.Fatal("hash key reused for different bytes")
	}
	wrongStage := aggregate
	wrongStage.Stage = "code-binding"
	if b.Add(wrongStage) == nil {
		t.Fatal("cross-stage aggregate accepted")
	}
	tooEarly := aggregate
	tooEarly.First = 0
	if b.Add(tooEarly) != nil {
		t.Fatal("actual observation clocks may precede an earlier emitted receipt")
	}
}

func TestRunnerReceiptFoundationEncoderInteroperability(t *testing.T) {
	path := os.Getenv("SLICCY_RECEIPT_FIXTURE")
	if path == "" {
		t.Skip("hosted actual Foundation ledger/journal fixture required")
	}
	data, e := os.ReadFile(path)
	if e != nil || len(data) == 0 || len(data) > 32768 {
		t.Fatal("fixture unavailable/outside bound", e)
	}
	var book runnerReceiptBook
	scanner := bufio.NewScanner(bytes.NewReader(data))
	scanner.Buffer(make([]byte, 4096), 4096)
	last := 0.0
	for scanner.Scan() {
		row, e := decodeRunnerCaptureRow(scanner.Bytes())
		if e != nil || row.Receipt == nil || row.Elapsed < last {
			t.Fatal("actual ledger/encoder receipt rejected", e)
		}
		last = row.Elapsed
		if e := book.Add(*row.Receipt); e != nil {
			t.Fatal("actual receipt aggregation rejected", e)
		}
	}
	if scanner.Err() != nil || book.Rows != 9 || len(book.Entries) != 7 {
		t.Fatal("fixture lost a typed receipt/aggregate", scanner.Err(), book.Rows, len(book.Entries))
	}
	var count uint64
	var bsd, child, preflight, live bool
	for _, entry := range book.Entries {
		count += entry.Count
		if entry.Receipt.BSD != nil {
			bsd = entry.Count == 3
		}
		if code := entry.Receipt.Code; code != nil {
			switch code.Site {
			case "child-initial":
				child = entry.Count == 2
			case "preflight":
				preflight = code.Passed
			case "initial-live":
				live = code.Passed && code.Selected != nil
			}
		}
	}
	if count != 10 || !bsd || !child || !preflight || !live {
		t.Fatal("typed fixture completeness/count mismatch")
	}
}
