package integration

import (
	"context"
	"io"
	"os"
	"os/exec"
	"testing"
	"time"

	"golang.org/x/sys/unix"
)

func TestNativeExecObserverBoundary(t *testing.T) {
	if os.Getenv("SLICC_NATIVE_WATCHER_SELFEXEC") == "1" {
		var one [1]byte
		if _, err := io.ReadFull(os.Stdin, one[:]); err != nil {
			os.Exit(2)
		}
		if unix.Exec("/bin/sleep", []string{"sleep", "1"}, []string{"PATH=/usr/bin:/bin"}) != nil {
			os.Exit(3)
		}
		return
	}
	executable, err := os.Executable()
	if err != nil {
		t.Fatal("test locator unavailable")
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, executable, "-test.run=^TestNativeExecObserverBoundary$")
	cmd.Env = []string{"PATH=/usr/bin:/bin", "SLICC_NATIVE_WATCHER_SELFEXEC=1"}
	pipe, err := cmd.StdinPipe()
	if err != nil {
		t.Fatal("test pipe unavailable")
	}
	if cmd.Start() != nil {
		t.Fatal("observer fixture launch failed")
	}
	defer func() { cancel(); _ = cmd.Wait() }()
	events, stop, err := watchProofExec(cmd.Process.Pid)
	if err != nil {
		t.Fatal("native observer registration failed")
	}
	defer stop()
	if _, err = pipe.Write([]byte{1}); err != nil {
		t.Fatal("observer fixture release failed")
	}
	_ = pipe.Close()
	select {
	case event := <-events:
		if event.Err != nil || !event.Exec || event.Exit {
			t.Fatal("native exec event not established")
		}
	case <-ctx.Done():
		t.Fatal("native exec observer timed out")
	}
	if _, err = inspectProofHelper(cmd.Process.Pid, "/bin/sleep", "0000000000000000000000000000000000000000"); err == nil {
		t.Fatal("Apple sleep accepted as signed app helper")
	}
	t.Log("native watcher observed actual same-PID exec; wrong-role helper refused; this is driver validation, not a signed CLI identity proof")
}
