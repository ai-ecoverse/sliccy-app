package integration

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"strconv"
	"testing"
	"time"
	"unicode/utf8"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
)

func runnerStrict(raw []byte, value any, limit int) error {
	if len(raw) > limit || !utf8.Valid(raw) {
		return fmt.Errorf("JSON admission limit")
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	tokens := 0
	var walk func(int) error
	walk = func(depth int) error {
		tokens++
		if depth > 8 || tokens > 512 {
			return fmt.Errorf("JSON parser budget")
		}
		token, e := decoder.Token()
		if e != nil {
			return e
		}
		delim, container := token.(json.Delim)
		if !container {
			return nil
		}
		if delim != '{' && delim != '[' {
			return fmt.Errorf("unexpected delimiter")
		}
		names := map[string]bool{}
		for decoder.More() {
			if delim == '{' {
				key, e := decoder.Token()
				if e != nil {
					return e
				}
				name, ok := key.(string)
				if !ok || names[name] {
					return fmt.Errorf("duplicate JSON key")
				}
				names[name] = true
			}
			if e := walk(depth + 1); e != nil {
				return e
			}
		}
		end, e := decoder.Token()
		if e != nil || delim == '{' && end != json.Delim('}') || delim == '[' && end != json.Delim(']') {
			return fmt.Errorf("unclosed JSON")
		}
		return nil
	}
	if walk(0) != nil {
		return fmt.Errorf("ambiguous JSON")
	}
	if _, e := decoder.Token(); e != io.EOF {
		return fmt.Errorf("trailing JSON")
	}
	decoder = json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	return decoder.Decode(value)
}
func runnerCounter(value screen.Counter) (uint64, error) {
	if !captureCanonical(string(value)) {
		return 0, fmt.Errorf("noncanonical counter")
	}
	return strconv.ParseUint(string(value), 10, 64)
}
func runnerBindingValid(b screen.Binding) bool {
	if !runnerWireID(b.Link) || !runnerWireID(b.Source) || !runnerWireID(b.Session) {
		return false
	}
	for _, v := range []screen.Counter{b.GrantEpoch, b.SourceEpoch, b.ProtectionEpoch} {
		if n, e := runnerCounter(v); e != nil || n == 0 {
			return false
		}
	}
	return true
}
func runnerLimitsValid(l screen.Limits) bool {
	return l.HeaderBytes > 0 && l.HeaderBytes <= 4096 && l.FrameBytes >= 4 && l.FrameBytes <= 2097152 && l.LongEdge > 0 && l.LongEdge <= 2560 && l.Pixels > 0 && l.Pixels <= 4000000 && l.DefaultFPS > 0 && l.DefaultFPS <= l.MaxFPS && l.MaxFPS <= 10 && l.BytesPerSecond > 0 && l.BytesPerSecond <= 8388608
}
func readRunnerRecord(c net.Conn, wire *runnerWireFrame, maxBody int) ([]byte, error) {
	if !runnerLimitsValid(wire.Limits) || maxBody < 4 || maxBody > 2097152 {
		return nil, fmt.Errorf("invalid record budget")
	}
	if e := c.SetReadDeadline(time.Time{}); e != nil {
		return nil, e
	}
	var size [4]byte
	if _, e := io.ReadFull(c, size[:1]); e != nil {
		return nil, e
	}
	if e := c.SetReadDeadline(time.Now().Add(2 * time.Second)); e != nil {
		return nil, e
	}
	if _, e := io.ReadFull(c, size[1:]); e != nil {
		return nil, e
	}
	n := binary.BigEndian.Uint32(size[:])
	if n == 0 || n > 4096 || n > uint32(wire.Limits.HeaderBytes) {
		return nil, fmt.Errorf("header allocation limit")
	}
	header := make([]byte, int(n))
	if _, e := io.ReadFull(c, header); e != nil {
		return nil, e
	}
	if e := runnerStrict(header, wire, 4096); e != nil {
		return nil, e
	}
	if _, e := io.ReadFull(c, size[:]); e != nil {
		return nil, e
	}
	n = binary.BigEndian.Uint32(size[:])
	if n < 4 || uint64(n) > uint64(maxBody) {
		return nil, fmt.Errorf("JPEG allocation limit")
	}
	body := make([]byte, int(n))
	if _, e := io.ReadFull(c, body); e != nil {
		return nil, e
	}
	return body, nil
}

func TestRunnerIndependentRecordBoundsApplyBeforePayloadRead(t *testing.T) {
	binding := screen.Binding{Link: screen.ID(16), Session: screen.ID(16), Source: screen.ID(16), GrantEpoch: "1", SourceEpoch: "1", ProtectionEpoch: "1"}
	frame := screen.Frame{Type: "frame", V: 1, Binding: binding, Seq: "1", Captured: "1", Width: 16, Height: 16, Codec: "jpeg"}
	header, _ := json.Marshal(frame)
	for _, which := range []string{"header", "body"} {
		reader, writer := net.Pipe()
		sent := make(chan struct{})
		go func() {
			defer close(sent)
			defer writer.Close()
			var prefix [4]byte
			if which == "header" {
				binary.BigEndian.PutUint32(prefix[:], 4097)
				_, _ = writer.Write(prefix[:])
				return
			}
			binary.BigEndian.PutUint32(prefix[:], uint32(len(header)))
			_, _ = writer.Write(prefix[:])
			_, _ = writer.Write(header)
			binary.BigEndian.PutUint32(prefix[:], 2097153)
			_, _ = writer.Write(prefix[:])
		}()
		wire := runnerWireFrame{WidthCap: 16, HeightCap: 16, Limits: screen.DefaultLimits()}
		_, e := readRunnerRecord(reader, &wire, 2097152)
		_ = reader.Close()
		<-sent
		expected := "header allocation limit"
		if which == "body" {
			expected = "JPEG allocation limit"
		}
		if e == nil || e.Error() != expected {
			t.Fatal("limit was deferred until payload read", which, e)
		}
	}
	var fields map[string]json.RawMessage
	raw := []byte(`{"x":{"x":{"x":{"x":{"x":{"x":{"x":{"x":{"x":1}}}}}}}}}`)
	if runnerStrict(raw, &fields, 4096) == nil {
		t.Fatal("nested parser budget bypassed")
	}
}
