package integration

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/ai-ecoverse/slicc-cli/internal/caps/screen"
)

type universalManifest struct {
	Schema         int    `json:"schema"`
	Source         string `json:"sourceCommit"`
	Identifier     string `json:"identifier"`
	Team           string `json:"team"`
	Version        string `json:"version"`
	Build          string `json:"build"`
	ExecutableHash string `json:"executableSHA256"`
	PlistHash      string `json:"infoPlistSHA256"`
	Slices         []struct {
		Architecture      string `json:"architecture"`
		CPU               uint32 `json:"cpuType"`
		Subtype           uint32 `json:"cpuSubtype"`
		Offset            uint64 `json:"offset"`
		Size              uint64 `json:"size"`
		Alignment         uint32 `json:"alignmentExponent"`
		CDHash            string `json:"CDHash"`
		Full              string `json:"codeDirectorySHA256"`
		EmptyEntitlements bool   `json:"emptyEntitlements"`
	} `json:"slices"`
	CLI struct {
		Version      string `json:"version"`
		Architecture string `json:"architecture"`
		SHA256       string `json:"sha256"`
		CDHash       string `json:"CDHash"`
	} `json:"bundledCLI"`
	Production bool `json:"productionEnabled"`
	Trials     bool `json:"nativeTrialsPerformed"`
}
type universalRow struct {
	identityRow
	ReportedArchitecture string          `json:"reportedArchitecture,omitempty"`
	SelectedCDHash       string          `json:"selectedCDHash,omitempty"`
	Resource             string          `json:"resource,omitempty"`
	Verification         json.RawMessage `json:"verification,omitempty"`
}

func decodeUniversalRow(line []byte) (universalRow, error) {
	var row universalRow
	if screen.Strict(line, &row, 4096) != nil {
		return row, fmt.Errorf("strict universal row invalid")
	}
	required := []string{"schema", "case", "capture", "stage", "elapsedMs"}
	switch row.Stage {
	case "universal-started":
		required = append(required, "pid", "reportedArchitecture")
	case "self-verification-accepted":
		required = append(required, "selectedCDHash")
	case "child-started":
		required = append(required, "pid", "resource")
	case "cli-verification":
		required = append(required, "verification")
	case "child-gate-invalidated", "terminal":
		required = append(required, "reason")
	case "child-exit-reaped":
		required = append(required, "pid")
	case "self-verification-refused", "app-observation-confirmed", "lanes-authenticated", "heartbeat-ready", "native-pair-observed", "cli-refusal-observed", "result-observation-confirmed":
	default:
		return row, fmt.Errorf("unknown universal stage")
	}
	var fields map[string]json.RawMessage
	if json.Unmarshal(line, &fields) != nil || len(fields) != len(required) {
		return row, fmt.Errorf("wrong universal stage field set")
	}
	for _, key := range required {
		value, ok := fields[key]
		if !ok || bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			return row, fmt.Errorf("missing/null universal field")
		}
	}
	return row, nil
}

func TestSignedUniversalNative(t *testing.T)     { runSignedUniversal(t, "universal-native") }
func TestSignedUniversalTranslated(t *testing.T) { runSignedUniversal(t, "universal-translated") }
func runSignedUniversal(t *testing.T, which string) {
	executable := os.Getenv("SLICCY_SIGNED_PROOF_APP")
	if executable == "" {
		t.Skip("CI-signed universal fixture required")
	}
	evidence := os.Getenv("SLICCY_PROOF_EVIDENCE")
	manifestPath := os.Getenv("SLICCY_UNIVERSAL_MANIFEST")
	if evidence == "" || manifestPath == "" {
		t.Fatal("immutable universal manifest/evidence required")
	}
	if which == "universal-translated" {
		receipt := exec.Command("/usr/sbin/pkgutil", "--pkg-info", "com.apple.pkg.RosettaUpdateAuto")
		receipt.Stdout = io.Discard
		receipt.Stderr = io.Discard
		_, e := os.Stat("/Library/Apple/usr/libexec/oah/libRosettaRuntime")
		if receipt.Run() != nil || e != nil {
			_ = os.WriteFile(filepath.Join(evidence, "driver-observations.json"), []byte("{\"result\":\"FAILED_TO_DEMONSTRATE\",\"reason\":\"Mac-app Rosetta installation not independently established; no translated launch or installer attempted\"}\n"), 0600)
			t.Fatal("FAILED TO DEMONSTRATE: Mac-app translation installation unconfirmed")
		}
	}
	manifestRaw, e := os.ReadFile(manifestPath)
	if e != nil {
		t.Fatal("manifest unavailable")
	}
	var manifest universalManifest
	if screen.Strict(manifestRaw, &manifest, 65536) != nil || manifest.Schema != 1 || manifest.Identifier != "ai.sliccy.mac" || manifest.Team != "S8LB56P782" || manifest.Version != "0.1.0" || manifest.Build != "7" || manifest.Production || manifest.Trials || len(manifest.Source) != 40 || len(manifest.Slices) != 2 || manifest.CLI.Version != "1.59.0" || manifest.CLI.Architecture != "arm64" || manifest.CLI.SHA256 != "0055c051f48364dbf6d3744c637a06353305a392d06edbedd96bd6764adb5a73" || manifest.CLI.CDHash != "5da1a3199bd3f895bce2e53023c28ca1c33d249e" {
		t.Fatal("invalid fixed universal manifest")
	}
	raw, e := os.ReadFile(executable)
	if e != nil {
		t.Fatal("snapshot unavailable")
	}
	digest := sha256.Sum256(raw)
	if hex.EncodeToString(digest[:]) != manifest.ExecutableHash {
		t.Fatal("snapshot hash mismatch")
	}
	slices, e := signedSnapshotSlices(raw)
	if e != nil || len(slices) != 2 {
		t.Fatal("genuine two-slice snapshot required", e)
	}
	for _, slice := range slices {
		found := 0
		for _, m := range manifest.Slices {
			if m.CPU == slice.CPU && m.Subtype == slice.Subtype && m.Offset == slice.Offset && m.Size == slice.Size && m.CDHash == slice.CDHash && m.Full == slice.FullCDHash && m.Alignment == slice.Alignment && ((m.CPU == 0x0100000c && m.Architecture == "arm64") || (m.CPU == 0x01000007 && m.Architecture == "x86_64")) && m.EmptyEntitlements {
				found++
			}
		}
		if found != 1 || validateStaticSlice(executable, "ai.sliccy.mac", slice) != nil {
			t.Fatal("per-slice validated snapshot mismatch")
		}
	}
	plistPath := filepath.Join(filepath.Dir(filepath.Dir(executable)), "Info.plist")
	plistRaw, e := os.ReadFile(plistPath)
	if e != nil {
		t.Fatal("sealed plist missing")
	}
	plistHash := sha256.Sum256(plistRaw)
	if hex.EncodeToString(plistHash[:]) != manifest.PlistHash {
		t.Fatal("sealed plist hash mismatch")
	}
	cliPath := filepath.Join(filepath.Dir(filepath.Dir(executable)), "Resources", "slicc")
	cliRaw, e := os.ReadFile(cliPath)
	if e != nil {
		t.Fatal("bundled release missing")
	}
	cliHash := sha256.Sum256(cliRaw)
	if hex.EncodeToString(cliHash[:]) != manifest.CLI.SHA256 {
		t.Fatal("bundled release changed")
	}
	gate := make(chan struct{})
	_, join, _ := proofPageControlled(t, gate)
	t.Cleanup(func() { close(gate) })
	arch := "-arm64"
	wantCPU := int32(0x0100000c)
	if which == "universal-translated" {
		arch = "-x86_64"
		wantCPU = 0x01000007
	}
	ctx, cancel := context.WithTimeout(context.Background(), 40*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, "/usr/bin/arch", arch, executable, "--screen-proof", "--case", which)
	cmd.Env = proofEnvironment(t)
	input, e := cmd.StdinPipe()
	if e != nil {
		t.Fatal("marker input unavailable")
	}
	defer input.Close()
	stdout, e := cmd.StdoutPipe()
	if e != nil {
		t.Fatal("metadata pipe unavailable")
	}
	stderr := &proofRows{}
	cmd.Stderr = stderr
	start := time.Now()
	if cmd.Start() != nil {
		t.Fatal("fixed universal invocation failed")
	}
	if _, e = io.WriteString(input, join+"\n"); e != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("synthetic join input failed")
	}
	parentEvents, stopParent, e := watchProofExec(cmd.Process.Pid)
	if e != nil {
		cancel()
		_ = cmd.Wait()
		t.Fatal("owned app monitor unavailable")
	}
	defer stopParent()
	incoming := make(chan universalRow, 64)
	done := make(chan struct{})
	output := &proofRows{}
	var readErr, runErr error
	go func() {
		scanner := bufio.NewScanner(stdout)
		scanner.Buffer(make([]byte, 4096), 4096)
		for scanner.Scan() {
			line := append([]byte(nil), scanner.Bytes()...)
			_, _ = output.Write(append(line, '\n'))
			row, err := decodeUniversalRow(line)
			if err != nil {
				readErr = fmt.Errorf("invalid universal metadata")
				continue
			}
			row.At = time.Now()
			select {
			case incoming <- row:
			default:
				readErr = fmt.Errorf("universal metadata queue exceeded")
			}
		}
		if scanner.Err() != nil {
			readErr = fmt.Errorf("universal metadata read failed")
		}
		close(incoming)
		runErr = cmd.Wait()
		close(done)
	}()
	var failures []string
	fail := func(reason string) { failures = append(failures, reason) }
	rows := map[string]universalRow{}
	allowed := map[string]bool{}
	for _, s := range strings.Fields("universal-started self-verification-accepted self-verification-refused app-observation-confirmed child-started cli-verification lanes-authenticated heartbeat-ready native-pair-observed cli-refusal-observed result-observation-confirmed child-gate-invalidated child-exit-reaped terminal") {
		allowed[s] = true
	}
	var initial, final kernelImageObservation
	var appObservedAt time.Time
	var selected snapshotSlice
	var reports handoffReports
	acceptedSafety, acceptedFrames, refusedSafety := false, false, false
	var childPID int
	var childEvents <-chan proofExecEvent
	var stopChild func()
	childKernelExit := false
	markerSent, resultMarkerSent := false, false
	observe := func() (kernelImageObservation, error) {
		current, e := inspectOwnedKernelImage(cmd.Process.Pid, os.Getpid())
		if e != nil {
			return current, e
		}
		if current.CPU != wantCPU {
			return current, fmt.Errorf("wrong actual running CPU")
		}
		matched := 0
		for _, slice := range slices {
			if slice.CPU == uint32(current.CPU) && slice.Subtype == uint32(current.Subtype) && slice.Offset == current.Offset && slice.CDHash == current.CDHash {
				selected = slice
				matched++
			}
		}
		if matched != 1 {
			return current, fmt.Errorf("kernel image doesn't select exactly one signed snapshot")
		}
		hash, e := inspectProofImageCPU(cmd.Process.Pid, executable, current.CDHash, "ai.sliccy.mac", "ai.sliccy.proof-helper", wantCPU)
		if e != nil || hash != current.CDHash {
			return current, fmt.Errorf("live role/snapshot identity mismatch")
		}
		again, e := inspectOwnedKernelImage(cmd.Process.Pid, os.Getpid())
		if e != nil || again != current {
			return current, fmt.Errorf("app image changed during static comparison")
		}
		return current, nil
	}
	process := func(row universalRow) {
		if row.Schema != 2 || row.Case != which || row.Capture == nil || *row.Capture || !allowed[row.Stage] || math.IsNaN(row.Elapsed) || math.IsInf(row.Elapsed, 0) || row.Elapsed < 0 || row.Elapsed > row.At.Sub(start).Seconds()*1000 || row.Duration != nil {
			fail("universal schema/timing invalid")
			return
		}
		if row.Stage == "cli-verification" {
			if reports.accept(row.Verification) != nil {
				fail("CLI observer loss/malformed evidence")
				return
			}
			var report screen.ProofReport
			_ = json.Unmarshal(row.Verification, &report)
			if report.Stage == "check" && report.Outcome == "accepted" {
				yes := func(p *bool) bool { return p != nil && *p }
				if !yes(report.TokenMatched) || !yes(report.PIDAgreed) || !yes(report.UIDAgreed) {
					fail("accepted verifier row lacks executed agreement")
				}
				if which == "universal-translated" {
					fail("translated parent unexpectedly accepted")
				}
				if report.Lane == "safety" {
					acceptedSafety = true
				} else {
					acceptedFrames = true
				}
			}
			if report.Stage == "check" && report.Outcome == "refused" && report.Lane == "safety" {
				refusedSafety = true
			}
			return
		}
		if len(row.Verification) != 0 {
			fail("unexpected observer payload")
		}
		if _, exists := rows[row.Stage]; exists {
			fail("duplicate universal stage")
		}
		rows[row.Stage] = row
		switch row.Stage {
		case "universal-started":
			want := "arm64"
			if which == "universal-translated" {
				want = "x86_64"
			}
			if row.PID == nil || *row.PID != cmd.Process.Pid || row.ReportedArchitecture != want {
				fail("owned app PID/architecture claim mismatch")
			}
		case "self-verification-accepted":
			var err error
			initial, err = observe()
			if err != nil {
				fail(err.Error())
				return
			}
			appObservedAt = time.Now()
			if row.SelectedCDHash != initial.CDHash {
				fail("production self-verifier chose wrong snapshot slice")
				return
			}
			markerSent = true
			if _, e := io.WriteString(input, "slice-app-observed\n"); e != nil {
				fail("app observation marker failed")
			}
		case "self-verification-refused":
			fail("self verifier refused before running-slice observation")
		case "child-started":
			if !markerSent || row.PID == nil || row.Resource != "bundled-arm64-v1.59.0" || *row.PID == cmd.Process.Pid {
				fail("unexpected native child launch")
				return
			}
			childPID = *row.PID
			var err error
			childEvents, stopChild, err = watchProofExec(childPID)
			if err != nil && which == "universal-native" {
				fail("native child observation unavailable")
			}
		case "native-pair-observed", "cli-refusal-observed":
			if which == "universal-native" && (row.Stage != "native-pair-observed" || !acceptedSafety || !acceptedFrames || refusedSafety) {
				fail("real native pair evidence incomplete")
			}
			if which == "universal-translated" && (row.Stage != "cli-refusal-observed" || acceptedSafety || acceptedFrames || !refusedSafety || !reports.complete) {
				fail("real translated-parent receiver refusal incomplete")
			}
			var err error
			final, err = observe()
			if err != nil || final != initial {
				fail("after-observation kernel/snapshot binding changed")
				return
			}
			resultMarkerSent = true
			if _, e := io.WriteString(input, "slice-result-observed\n"); e != nil {
				fail("result marker failed")
			}
		case "child-gate-invalidated":
			if row.Reason != "invalidated" && row.Reason != "no-transport" {
				fail("unknown child gate outcome")
			}
		case "child-exit-reaped":
			if row.PID == nil || *row.PID != childPID {
				fail("actual child reap metadata mismatched")
			}
		}
	}
	readRows := incoming
	finished := false
	for !finished {
		select {
		case row, ok := <-readRows:
			if ok {
				process(row)
			} else {
				readRows = nil
			}
		case event := <-parentEvents:
			if event.Err != nil {
				fail("app kernel monitor failed")
			}
			if event.Exec && !appObservedAt.IsZero() {
				fail("app exec after live snapshot observation")
			}
			if event.Exit {
				parentEvents = nil
			}
		case event := <-childEvents:
			if event.Err != nil || event.Exec {
				fail("unexpected child exec/monitor error")
			}
			if event.Exit {
				childKernelExit = true
				childEvents = nil
			}
		case <-done:
			for row := range incoming {
				process(row)
			}
			finished = true
		}
	}
	if childEvents != nil {
		select {
		case event := <-childEvents:
			childKernelExit = event.Exit && event.Err == nil && !event.Exec
		case <-time.After(time.Second):
		}
	}
	if stopChild != nil {
		stopChild()
	}
	if readErr != nil || output.overflow || stderr.overflow || runErr != nil {
		fail("universal metadata/process failure")
	}
	if strings.Contains(string(output.data), join) {
		fail("synthetic join disclosed")
	}
	expected := "native-observation-complete"
	if which == "universal-translated" {
		expected = "translated-refusal-observed"
	}
	if rows["terminal"].Reason != expected || !markerSent || !resultMarkerSent || !reports.complete || rows["child-exit-reaped"].PID == nil || rows["app-observation-confirmed"].Stage == "" || rows["result-observation-confirmed"].Stage == "" {
		fail("universal observation/cleanup incomplete")
	}
	if which == "universal-native" && !childKernelExit {
		fail("native child kernel exit not observed")
	}
	afterRaw, e := os.ReadFile(executable)
	if e != nil || sha256.Sum256(afterRaw) != digest {
		fail("immutable signed snapshot changed")
	}
	afterPlist, e := os.ReadFile(plistPath)
	if e != nil || sha256.Sum256(afterPlist) != plistHash {
		fail("sealed app metadata changed")
	}
	afterCLI, e := os.ReadFile(cliPath)
	if e != nil || sha256.Sum256(afterCLI) != cliHash {
		fail("immutable released CLI changed")
	}
	result := "PASS"
	if len(failures) > 0 {
		result = "FAIL"
	}
	facts := map[string]any{"result": result, "case": which, "capture": false, "failures": failures, "kernelBefore": initial, "kernelAfter": final, "validatedSelectedSlice": selected, "cliAcceptedSafety": acceptedSafety, "cliAcceptedFrames": acceptedFrames, "cliRefusedSafety": refusedSafety, "observerCompleteLostFalse": reports.complete, "childKernelExitObserved": childKernelExit, "cliInternalArchitectureBranchClaimed": false, "snapshotUnchanged": sha256.Sum256(afterRaw) == digest, "sourceCommit": manifest.Source}
	data, _ := json.MarshalIndent(facts, "", "  ")
	for name, raw := range map[string][]byte{"milestones.ndjson": output.data, "driver-observations.json": append(data, '\n'), "stderr.txt": stderr.data} {
		if os.WriteFile(filepath.Join(evidence, name), raw, 0600) != nil {
			t.Fatal("universal evidence unavailable")
		}
	}
	if len(failures) > 0 {
		t.Fatal(failures)
	}
	t.Log(which + " running-slice observation PASS; internal refusal branch not claimed")
}
