package integration

import (
	"strings"
	"testing"
)

func TestHandoffObserverEvidenceParser(t *testing.T) {
	accepted := `{"schema":1,"event":"native-screen-verification","seq":1,"stage":"check","lane":"safety","outcome":"accepted","tokenMatched":true,"pidAgreed":true,"uidAgreed":true,"lost":false}`
	refused := `{"schema":1,"event":"native-screen-verification","seq":2,"stage":"check","lane":"safety","outcome":"refused","tokenMatched":false,"pidAgreed":null,"uidAgreed":null,"lost":false}`
	complete := `{"schema":1,"event":"native-screen-verification","seq":3,"stage":"complete","tokenMatched":null,"pidAgreed":null,"uidAgreed":null,"lost":false}`
	var frames handoffReports
	frames.lane = "frames"
	for _, raw := range []string{accepted, refused, complete} {
		if frames.accept([]byte(raw)) != nil {
			t.Fatal("well-formed other lane refused")
		}
	}
	if frames.baseline || frames.refused {
		t.Fatal("safety witness substituted for frame lane")
	}
	var actualFrames handoffReports
	actualFrames.lane = "frames"
	for _, raw := range []string{accepted, refused, complete} {
		if actualFrames.accept([]byte(strings.ReplaceAll(raw, `"lane":"safety"`, `"lane":"frames"`))) != nil {
			t.Fatal("frame witness refused")
		}
	}
	if !actualFrames.baseline || !actualFrames.refused || !actualFrames.complete {
		t.Fatal("frame witnesses not established")
	}
	var good handoffReports
	for _, raw := range []string{accepted, refused, complete} {
		if good.accept([]byte(raw)) != nil {
			t.Fatal("valid evidence rejected")
		}
	}
	if !good.baseline || !good.refused || !good.complete {
		t.Fatal("valid evidence did not establish comparisons")
	}
	if good.accept([]byte(complete)) == nil {
		t.Fatal("post-complete row accepted")
	}
	for _, raw := range []string{
		strings.Replace(accepted, `"lost":false`, `"lost":null`, 1),
		strings.Replace(accepted, `"lost":false`, `"lost":true`, 1),
		strings.Replace(accepted, `"seq":1`, `"seq":2`, 1),
		strings.Replace(accepted, `"schema":1`, `"schema":1,"schema":1`, 1),
		strings.Replace(accepted, `"schema":1`, `"schema":1,"unknown":false`, 1),
		strings.Replace(accepted, `"uidAgreed":true,`, "", 1),
		accepted + " {}",
	} {
		var bad handoffReports
		if bad.accept([]byte(raw)) == nil {
			t.Fatal("invalid evidence accepted")
		}
	}
	var unknown handoffReports
	if unknown.accept([]byte(strings.Replace(accepted, `"tokenMatched":true`, `"tokenMatched":null`, 1))) != nil || unknown.baseline {
		t.Fatal("null inferred as agreement")
	}
	var wrong handoffReports
	if wrong.accept([]byte(accepted)) != nil || wrong.accept([]byte(strings.Replace(refused, `"tokenMatched":false`, `"tokenMatched":null`, 1))) != nil || wrong.refused {
		t.Fatal("missing mismatch inferred as refusal witness")
	}
}
