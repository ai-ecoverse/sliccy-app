package integration

import (
 "bytes"
 "errors"
 "fmt"
 "regexp"
 "os"
 "syscall"
 "strings"
 "sync"
 "time"
 "unicode/utf8"
)

type runnerDiagnosticRecord struct {
 Step string `json:"step"`
 Order uint64 `json:"order"`
 MonotonicMS float64 `json:"monotonicMs"`
 First bool `json:"first"`
 ErrorType string `json:"errorType"`
 Tail string `json:"tail"`
}
type runnerDiagnosticPath struct {
 Records []runnerDiagnosticRecord `json:"records"`
 Total uint64 `json:"total"`
 Omitted uint64 `json:"omitted"`
 Bytes int `json:"bytes"`
}
type runnerDiagnostics struct {
 mu sync.Mutex
 began time.Time
 order uint64
 secrets []string
 paths map[string]runnerDiagnosticPath
}
var runnerDiagnosticSteps = strings.Fields("fixture.answer fixture.candidate-marshal fixture.candidate-decode fixture.candidate-add fixture.setup controller.refusal metadata.decoder metadata.envelope metadata.queue metadata.pipe metadata.problem metadata.terminal metadata.wait protocol.worker page.problem link.lost app.stdout app.stderr app.exit child.spawn child.settlement")
var runnerDiagnosticURL = regexp.MustCompile(`(?i)(?:https?|wss?)://[^\s]+`)
var runnerDiagnosticIP = regexp.MustCompile(`(?:[0-9]{1,3}\.){3}[0-9]{1,3}|[0-9a-fA-F]{0,4}:[0-9a-fA-F:]{2,}`)
var runnerDiagnosticQuoted = regexp.MustCompile("\"[^\"]*\"|'[^']*'|`[^`]*`")
var runnerDiagnosticOpaque = regexp.MustCompile(`[A-Za-z0-9_+/=-]{24,}`)
var runnerDiagnosticPathPattern = regexp.MustCompile(`/(?:[^\s:;,]+/)*[^\s:;,]+`)
func newRunnerDiagnostics(began time.Time) *runnerDiagnostics {
 return &runnerDiagnostics{began:began,paths:map[string]runnerDiagnosticPath{}}
}
func (d *runnerDiagnostics) AddSecret(value string) { if d==nil || value=="" {return}; d.mu.Lock(); defer d.mu.Unlock(); if len(d.secrets)<8 {d.secrets=append(d.secrets,value)} }
func runnerSanitizeDiagnostic(value string,secrets []string) string {
 if !utf8.ValidString(value) { value=strings.ToValidUTF8(value,"?") }
 for _,s:=range secrets {if s!="" {value=strings.ReplaceAll(value,s,"<redacted>")}}
 if i:=strings.IndexAny(value,"\r\n");i>=0 {value=value[:i]+" <additional-lines-redacted>"}
 value=runnerDiagnosticURL.ReplaceAllString(value,"<url>")
 value=runnerDiagnosticQuoted.ReplaceAllString(value,"<quoted>")
 value=runnerDiagnosticIP.ReplaceAllString(value,"<address>")
 value=runnerDiagnosticPathPattern.ReplaceAllString(value,"<path>")
 value=runnerDiagnosticOpaque.ReplaceAllString(value,"<opaque>")
 for _,key:=range []string{"candidate:","a=ice-pwd:","a=ice-ufrag:","token=","secret=","password="} {if i:=strings.Index(strings.ToLower(value),key);i>=0 {value=value[:i]+"<sensitive-suffix-redacted>"}}
 value=strings.Map(func(r rune)rune{if r<32 || r==127{return ' '};return r},value)
 if len(value)>4096 {value=string([]byte(value)[len(value)-4096:]);for !utf8.ValidString(value){value=value[1:]}}
 return value
}
func (d *runnerDiagnostics) Record(step string,err error) {
 if d==nil || err==nil{return}
 d.mu.Lock();defer d.mu.Unlock()
 allowed:=false;for _,s:=range runnerDiagnosticSteps {if step==s{allowed=true;break}};if !allowed {step="metadata.problem";err=errors.New("unknown diagnostic step refused")}
 d.order++
 path:=d.paths[step];path.Total++
 text:=runnerSanitizeDiagnostic(err.Error(),d.secrets)
 available:=4096-path.Bytes
 if available<=0 || len(path.Records)>=16 {path.Omitted++;d.paths[step]=path;return}
 if len(text)>available {text=text[:available];for !utf8.ValidString(text){text=text[:len(text)-1]}}
 record:=runnerDiagnosticRecord{Step:step,Order:d.order,MonotonicMS:float64(time.Since(d.began))/float64(time.Millisecond),First:path.Total==1,ErrorType:fmt.Sprintf("%T",err),Tail:text}
 path.Records=append(path.Records,record);path.Bytes+=len(text);d.paths[step]=path
}
func (d *runnerDiagnostics) Snapshot() map[string]runnerDiagnosticPath {
 out:=map[string]runnerDiagnosticPath{};if d==nil{return out};d.mu.Lock();defer d.mu.Unlock()
 for k,v:=range d.paths {v.Records=append([]runnerDiagnosticRecord(nil),v.Records...);out[k]=v};return out
}
type runnerOutputTail struct {mu sync.Mutex;data []byte;total uint64}
func (b *runnerOutputTail) Write(data []byte)(int,error){b.mu.Lock();defer b.mu.Unlock();n:=len(data);b.total+=uint64(n);if n>=8192 {b.data=append(b.data[:0],data[n-8192:]...)} else {b.data=append(b.data,data...);if len(b.data)>8192 {b.data=append([]byte(nil),b.data[len(b.data)-8192:]...)}};return n,nil}
func (b *runnerOutputTail) Snapshot(secrets []string)(string,uint64){b.mu.Lock();defer b.mu.Unlock();data:=bytes.Clone(b.data);text:=runnerSanitizeOutputTail(string(data),secrets);return text,b.total}

func(d *runnerDiagnostics)SecretSnapshot()[]string{if d==nil{return nil};d.mu.Lock();defer d.mu.Unlock();return append([]string(nil),d.secrets...)}
type runnerProcessExit struct {Observed bool `json:"observed"`;Exited bool `json:"exited"`;Code int `json:"code"`;Signaled bool `json:"signaled"`;Signal int `json:"signal"`}
type runnerCaseOutput struct {StdoutTail string `json:"stdoutTail"`;StderrTail string `json:"stderrTail"`;StdoutBytes uint64 `json:"stdoutBytes"`;StderrBytes uint64 `json:"stderrBytes"`;Exit runnerProcessExit `json:"exit"`}
func runnerCaptureProcessExit(state *os.ProcessState)runnerProcessExit{
 r:=runnerProcessExit{Code:-1};if state==nil{return r};status,ok:=state.Sys().(syscall.WaitStatus);if !ok {r.Observed=true;r.Exited=state.Exited();r.Code=state.ExitCode();return r};return runnerCaptureWaitStatus(true,state.Exited(),state.ExitCode(),status)
}

func runnerCaptureWaitStatus(observed,exited bool,code int,status syscall.WaitStatus)runnerProcessExit{r:=runnerProcessExit{Observed:observed,Exited:exited,Code:code};r.Signaled=status.Signaled();if r.Signaled {r.Signal=int(status.Signal())};return r}

func runnerSanitizeOutputTail(value string,secrets []string)string{
 lines:=strings.Split(strings.TrimRight(value,"\r\n"),"\n")
 for i,line:=range lines {lines[i]=runnerSanitizeDiagnostic(line,secrets)}
 result:=strings.Join(lines,"\n")
 if len(result)>4096 {result=result[len(result)-4096:];for !utf8.ValidString(result){result=result[1:]}}
 return result
}
