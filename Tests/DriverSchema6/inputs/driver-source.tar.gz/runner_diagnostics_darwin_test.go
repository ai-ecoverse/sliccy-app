package integration

import (
 "bytes"
 "errors"
 "fmt"
 "regexp"
 "os"
 "syscall"
 "strings"
 "sync"
 "time"
 "unicode/utf8"
)

type runnerDiagnosticRecord struct {
 Step string `json:"step"`
 Order uint64 `json:"order"`
 MonotonicMS float64 `json:"monotonicMs"`
 First bool `json:"first"`
 ErrorType string `json:"errorType"`
 Tail string `json:"tail"`
}
type runnerDiagnosticPath struct {
 Records []runnerDiagnosticRecord `json:"records"`
 Total uint64 `json:"total"`
 Omitted uint64 `json:"omitted"`
 Bytes int `json:"bytes"`
}
type runnerDiagnostics struct {
 mu sync.Mutex
 began time.Time
 order uint64
 secrets []string
 paths map[string]runnerDiagnosticPath
}
var runnerDiagnosticSteps = strings.Fields("fixture.answer fixture.candidate-marshal fixture.candidate-decode fixture.candidate-add fixture.setup controller.refusal metadata.decoder metadata.envelope metadata.queue metadata.pipe metadata.problem metadata.terminal metadata.wait protocol.worker page.problem link.lost app.stdout app.stderr app.exit child.spawn child.settlement")
var runnerDiagnosticURL = regexp.MustCompile(`(?i)(?:https?|wss?)://[^\s]+`)
var runnerDiagnosticIP = regexp.MustCompile(`(?:[0-9]{1,3}\.){3}[0-9]{1,3}|[0-9a-fA-F]{0,4}:[0-9a-fA-F:]{2,}`)
var runnerDiagnosticQuoted = regexp.MustCompile("\"[^\"]*\"|'[^']*'|`[^`]*`")
var runnerDiagnosticOpaque = regexp.MustCompile(`[A-Za-z0-9_+/=-]{24,}`)
var runnerDiagnosticPathPattern = regexp.MustCompile(`/(?:[^\s:;,]+/)*[^\s:;,]+`)
func newRunnerDiagnostics(began time.Time) *runnerDiagnostics {
 return &runnerDiagnostics{began:began,paths:map[string]runnerDiagnosticPath{}}
}
func (d *runnerDiagnostics) AddSecret(value string) { if d==nil || value=="" {return}; d.mu.Lock(); defer d.mu.Unlock(); if len(d.secrets)<8 {d.secrets=append(d.secrets,value)} }
var runnerSensitiveFields = []string{"a=ice-pwd:","a=ice-ufrag:","ice-pwd:","ice-ufrag:","ice_pwd=","ice_ufrag=","candidate:","candidate=","foundation:","foundation=","token=","secret=","password=","password:","authorization:"}
var runnerDiagnosticWords=regexp.MustCompile(`[A-Za-z][A-Za-z0-9_-]*|[0-9]+`)
var runnerDiagnosticSafeWords=strings.Fields("first underlying second fixed-answer-error fixed-candidate-error fixed-reader-fault fixed-wait-fault first-fixed-error last-fixed-error fixed safe error errors failure failed invalid incomplete unsupported unexpected unknown missing duplicate unavailable unobserved retired refused rejected exhausted exceeded changed closed closing ended stopped completed timeout deadline EOF EACCES EPROTO EPERM ESRCH EBUSY JSON SDP ICE SCTP DTLS TLS UDP TCP HTTP unmarshal marshal decode decoder read write pipe stream data record frame header body envelope value field fields type syntax character beginning looking for of into end after before from to at on with without not cannot could no is was the a an and or candidate answer offer local remote peer connection transport channel signalling signaling state stable have-local-offer have-remote-offer have-local-pranswer have-remote-pranswer invalid-state InvalidStateError InvalidAccessError InvalidModificationError OperationError TypeError SyntaxError SetRemoteDescription SetLocalDescription AddICECandidate CreateOffer CreateAnswer signalingState iceGatheringState iceConnectionState pending current description descriptions supplied operation parameter validation bound budget limit source process owned incarnation monitor signal killed terminated interrupt exit code nil reported actual result control metadata caseMatch monotonic afterTerminal row true false fixture setup native observation observer protocol validity capability capabilities support catalog scope screen HELLO OPEN OPENED ACK acknowledgement reset association version reason field-set field-count row-count tag noncanonical ambiguous malformed key order count sequence requirement status pid uid start parent hash role timestamp retained file regular binding mismatch lost loss overflow integrity input output stdout stderr console panic secret redacted url quoted address path opaque number additional-lines-redacted sensitive-field value-redacted")
func runnerStripSensitiveFields(value string)string{
 lower:=strings.ToLower(value);first:=-1
 for _,field:=range runnerSensitiveFields {if at:=strings.Index(lower,field);at>=0 && (first<0||at<first){first=at}}
 if first>=0 {return value[:first]+"<sensitive-field>"};return value
}
func runnerAllowDiagnosticWords(value string)string{
 value=strings.Map(func(r rune)rune{if r>126{return ' '};return r},value)
 return runnerDiagnosticWords.ReplaceAllStringFunc(value,func(word string)string{
  for _,safe:=range runnerDiagnosticSafeWords {if strings.EqualFold(word,safe){return word}}
  return "value-redacted"
 })
}
func runnerSanitizeDiagnostic(value string, secrets []string) string {
 if !utf8.ValidString(value) {value=strings.ToValidUTF8(value,"?")}
 for _,s:=range secrets {if s!="" {value=strings.ReplaceAll(value,s,"<redacted>")}}
 value=runnerStripSensitiveFields(value)
 if i:=strings.IndexAny(value,"\r\n");i>=0 {value=value[:i]+" <additional-lines-redacted>"}
 value=runnerDiagnosticURL.ReplaceAllString(value,"<url>")
 value=runnerDiagnosticQuoted.ReplaceAllString(value,"<quoted>")
 value=runnerDiagnosticIP.ReplaceAllString(value,"<address>")
 value=runnerDiagnosticPathPattern.ReplaceAllString(value,"<path>")
 value=runnerDiagnosticOpaque.ReplaceAllString(value,"<opaque>")
 value=runnerAllowDiagnosticWords(value)
 value=strings.Map(func(r rune)rune{if r<32||r==127{return ' '};return r},value)
 if len(value)>4096 {value=value[len(value)-4096:];for !utf8.ValidString(value){value=value[1:]}}
 return value
}

func (d *runnerDiagnostics) Record(step string,err error) {
 if d==nil || err==nil{return}
 d.mu.Lock();defer d.mu.Unlock()
 allowed:=false;for _,s:=range runnerDiagnosticSteps {if step==s{allowed=true;break}};if !allowed {step="metadata.problem";err=errors.New("unknown diagnostic step refused")}
 d.order++
 path:=d.paths[step];path.Total++
 text:=runnerSanitizeDiagnostic(err.Error(),d.secrets)
 available:=4096-path.Bytes
 if available<=0 || len(path.Records)>=16 {path.Omitted++;d.paths[step]=path;return}
 if len(text)>available {text=text[:available];for !utf8.ValidString(text){text=text[:len(text)-1]}}
 record:=runnerDiagnosticRecord{Step:step,Order:d.order,MonotonicMS:float64(time.Since(d.began))/float64(time.Millisecond),First:path.Total==1,ErrorType:fmt.Sprintf("%T",err),Tail:text}
 path.Records=append(path.Records,record);path.Bytes+=len(text);d.paths[step]=path
}
func (d *runnerDiagnostics) Snapshot() map[string]runnerDiagnosticPath {
 out:=map[string]runnerDiagnosticPath{};if d==nil{return out};d.mu.Lock();defer d.mu.Unlock()
 for k,v:=range d.paths {v.Records=append([]runnerDiagnosticRecord(nil),v.Records...);out[k]=v};return out
}
type runnerOutputTail struct {mu sync.Mutex;data []byte;total uint64}
func (b *runnerOutputTail) Write(data []byte)(int,error){b.mu.Lock();defer b.mu.Unlock();n:=len(data);b.total+=uint64(n);if n>=8192 {b.data=append(b.data[:0],data[n-8192:]...)} else {b.data=append(b.data,data...);if len(b.data)>8192 {b.data=append([]byte(nil),b.data[len(b.data)-8192:]...)}};return n,nil}
func (b *runnerOutputTail) Snapshot(secrets []string)(string,uint64){b.mu.Lock();defer b.mu.Unlock();data:=bytes.Clone(b.data);text:=runnerSanitizeOutputTail(string(data),secrets);return text,b.total}

func(d *runnerDiagnostics)SecretSnapshot()[]string{if d==nil{return nil};d.mu.Lock();defer d.mu.Unlock();return append([]string(nil),d.secrets...)}
type runnerProcessExit struct {Observed bool `json:"observed"`;Exited bool `json:"exited"`;Code int `json:"code"`;Signaled bool `json:"signaled"`;Signal int `json:"signal"`}
type runnerCaseOutput struct {StdoutTail string `json:"stdoutTail"`;StderrTail string `json:"stderrTail"`;StdoutBytes uint64 `json:"stdoutBytes"`;StderrBytes uint64 `json:"stderrBytes"`;Exit runnerProcessExit `json:"exit"`}
func runnerCaptureProcessExit(state *os.ProcessState)runnerProcessExit{
 r:=runnerProcessExit{Code:-1};if state==nil{return r};status,ok:=state.Sys().(syscall.WaitStatus);if !ok {r.Observed=true;r.Exited=state.Exited();r.Code=state.ExitCode();return r};return runnerCaptureWaitStatus(true,state.Exited(),state.ExitCode(),status)
}

func runnerCaptureWaitStatus(observed,exited bool,code int,status syscall.WaitStatus)runnerProcessExit{r:=runnerProcessExit{Observed:observed,Exited:exited,Code:code};r.Signaled=status.Signaled();if r.Signaled {r.Signal=int(status.Signal())};return r}

func runnerSanitizeOutputTail(value string,secrets []string)string{
 lines:=strings.Split(strings.TrimRight(value,"\r\n"),"\n")
 for i,line:=range lines {lines[i]=runnerSanitizeDiagnostic(line,secrets)}
 result:=strings.Join(lines,"\n")
 if len(result)>4096 {result=result[len(result)-4096:];for !utf8.ValidString(result){result=result[1:]}}
 return result
}

func runnerSettledExit(result runnerReadResult,settled bool)runnerProcessExit{
 if !settled {return runnerProcessExit{Code:-1}}
 return result.exit
}
