package cdp

import (
	"strings"

	"github.com/ai-ecoverse/slicc-cli/internal/protect"
)

func redactURL(raw string) string {
	return protect.Redact(raw)
}

func (g *guard) siteProtected(site string) bool {
	return site != "" && (g.o.URL(site) || g.o.CookieDomain(protect.Host(site)))
}

func (g *guard) cookieProtected(c map[string]any) bool {
	if c == nil {
		return false
	}
	if d, _ := c["domain"].(string); g.o.CookieDomain(d) {
		return true
	}
	switch pk := c["partitionKey"].(type) {
	case string:
		return g.siteProtected(pk)
	case map[string]any:
		site, _ := pk["topLevelSite"].(string)
		return g.siteProtected(site)
	}
	return false
}

func (g *guard) filterCookies(v any) any {
	list, ok := v.([]any)
	if !ok {
		return v
	}
	kept := make([]any, 0, len(list))
	for _, item := range list {
		if c, _ := item.(map[string]any); g.cookieProtected(c) {
			continue
		}
		kept = append(kept, item)
	}
	return kept
}

func socketURL(raw string) string {
	for from, to := range map[string]string{"ws:": "http:", "wss:": "https:"} {
		if len(raw) >= len(from) && strings.EqualFold(raw[:len(from)], from) {
			return to + raw[len(from):]
		}
	}
	return raw
}

func (g *guard) socketCreatedEvent(m *message, data []byte) browserVerdict {
	return g.withParams(m, data, func(p map[string]any) (bool, bool, [][]byte) {
		id := requestIDIn(p)
		u, _ := p["url"].(string)
		world := g.initiatorLocked(m.SessionID, p)
		if world {
			g.worldRequestLocked(g.worldTargetLocked(m.SessionID), id)
		}
		if g.o.Loaded(socketURL(strings.TrimSpace(u))) || world {
			g.markRequestLocked(m.SessionID, id)
		}
		return true, false, nil
	})
}

func (g *guard) markedDropEvent(m *message, data []byte) browserVerdict {
	return g.withParams(m, data, func(p map[string]any) (bool, bool, [][]byte) {
		id, _ := p["requestId"].(string)
		return !g.requestMarkedLocked(m.SessionID, id), false, nil
	})
}

var requestCredentials = []string{"cookie", "authorization", "proxy-authorization"}

func stripHeaders(v any, names ...string) bool {
	h, ok := v.(map[string]any)
	if !ok {
		return false
	}
	changed := false
	for k := range h {
		for _, n := range names {
			if strings.EqualFold(k, n) {
				delete(h, k)
				changed = true
			}
		}
	}
	return changed
}

func stripHeaderList(p map[string]any, field string, names ...string) bool {
	list, ok := p[field].([]any)
	if !ok {
		return false
	}
	kept := make([]any, 0, len(list))
	for _, item := range list {
		e, _ := item.(map[string]any)
		n, _ := e["name"].(string)
		drop := false
		for _, want := range names {
			drop = drop || strings.EqualFold(n, want)
		}
		if !drop {
			kept = append(kept, item)
		}
	}
	p[field] = kept
	return len(kept) != len(list)
}

func stripResponse(r map[string]any) bool {
	if r == nil {
		return false
	}
	changed := stripHeaders(r["headers"], "set-cookie", "set-cookie2")
	changed = stripHeaders(r["requestHeaders"], requestCredentials...) || changed
	changed = stripHeaderLines(r, "headersText", "set-cookie", "set-cookie2") || changed
	return stripHeaderLines(r, "requestHeadersText", requestCredentials...) || changed
}

func stripHeaderLines(p map[string]any, field string, names ...string) bool {
	text, ok := p[field].(string)
	if !ok {
		return false
	}
	lines := strings.Split(text, "\r\n")
	kept := make([]string, 0, len(lines))
	for _, line := range lines {
		name, _, found := strings.Cut(line, ":")
		drop := false
		for _, n := range names {
			drop = drop || found && strings.EqualFold(strings.TrimSpace(name), n)
		}
		if !drop {
			kept = append(kept, line)
		}
	}
	if len(kept) == len(lines) {
		return false
	}
	p[field] = strings.Join(kept, "\r\n")
	return true
}

func (g *guard) requestEvent(m *message, data []byte) browserVerdict {
	return g.withParams(m, data, func(p map[string]any) (bool, bool, [][]byte) {
		id, _ := p["requestId"].(string)
		req, _ := p["request"].(map[string]any)
		u, _ := req["url"].(string)
		redirect, _ := p["redirectResponse"].(map[string]any)
		ru, _ := redirect["url"].(string)
		world := g.initiatorLocked(m.SessionID, p)
		if world {
			g.worldRequestLocked(g.worldTargetLocked(m.SessionID), id)
		}
		if g.o.Loaded(u) || g.o.Loaded(ru) || world {
			g.markRequestLocked(m.SessionID, id)
		}
		if !g.requestMarkedLocked(m.SessionID, id) {
			return true, world, nil
		}
		changed := stripHeaders(req["headers"], requestCredentials...) || world
		return true, stripResponse(redirect) || changed, nil
	})
}

func (g *guard) requestExtra(p map[string]any, marked bool) bool {
	changed := g.filterAssociated(p, "associatedCookies")
	if changed || marked {
		changed = stripHeaders(p["headers"], requestCredentials...) || changed
	}
	return changed
}

func (g *guard) filterAssociated(p map[string]any, field string) bool {
	list, ok := p[field].([]any)
	if !ok {
		return false
	}
	kept := make([]any, 0, len(list))
	for _, item := range list {
		e, _ := item.(map[string]any)
		if c, _ := e["cookie"].(map[string]any); g.cookieProtected(c) {
			continue
		}
		kept = append(kept, item)
	}
	p[field] = kept
	return len(kept) != len(list)
}

func (g *guard) responseEvent(m *message, data []byte) browserVerdict {
	return g.withParams(m, data, func(p map[string]any) (bool, bool, [][]byte) {
		id, _ := p["requestId"].(string)
		r, _ := p["response"].(map[string]any)
		u, _ := r["url"].(string)
		if g.o.Loaded(u) {
			g.markRequestLocked(m.SessionID, id)
		}
		if !g.requestMarkedLocked(m.SessionID, id) {
			return true, false, nil
		}
		return true, stripResponse(r), nil
	})
}

func (g *guard) responseExtra(p map[string]any, marked bool) bool {
	changed := g.filterAssociated(p, "blockedCookies")
	changed = g.filterAssociated(p, "exemptedCookies") || changed
	if !marked {
		return changed
	}
	changed = stripHeaders(p["headers"], "set-cookie", "set-cookie2") || changed
	changed = stripHeaderLines(p, "headersText", "set-cookie", "set-cookie2") || changed
	for _, k := range []string{"blockedCookies", "exemptedCookies"} {
		if _, ok := p[k]; ok {
			delete(p, k)
			changed = true
		}
	}
	return changed
}

func pausedIDs(method string, p map[string]any) (string, string) {
	rid, _ := p["requestId"].(string)
	if method == "Network.requestIntercepted" {
		iid, _ := p["interceptionId"].(string)
		return iid, rid
	}
	nid, _ := p["networkId"].(string)
	return rid, nid
}

func (g *guard) pausedEvent(m *message, data []byte) browserVerdict {
	return g.withParams(m, data, func(p map[string]any) (bool, bool, [][]byte) {
		id, other := pausedIDs(m.Method, p)
		g.linkPauseLocked(m.SessionID, id, other)
		req, _ := p["request"].(map[string]any)
		u, _ := req["url"].(string)
		if msg, ok := g.worldPauseLocked(m, p); ok {
			return false, false, [][]byte{msg}
		}
		if g.o.Loaded(u) {
			delete(g.handed, requestKey{m.SessionID, id})
			g.markRequestLocked(m.SessionID, id)
			g.markRequestLocked(m.SessionID, other)
			return false, false, g.settlePausedLocked(m, p, id)
		}
		g.handOutLocked(requestKey{m.SessionID, id})
		if g.requestMarkedLocked(m.SessionID, other) || g.namesProtectedLocked(p["responseHeaders"]) {
			g.markRequestLocked(m.SessionID, id)
			g.markRequestLocked(m.SessionID, other)
		}
		if !g.requestMarkedLocked(m.SessionID, id) {
			return true, false, nil
		}
		changed := stripHeaderList(p, "responseHeaders", "set-cookie", "set-cookie2")
		changed = stripHeaders(p["responseHeaders"], "set-cookie", "set-cookie2") || changed
		changed = stripHeaders(req["headers"], requestCredentials...) || changed
		return true, changed, nil
	})
}

func (g *guard) noteContinueLocked(k callKey, c *command) {
	if !continueOK[c.method] {
		return
	}
	for key := range requestKeys {
		if id := c.str(key); id != "" {
			req := requestKey{c.session, id}
			g.continues[k] = handedPause{req, g.handed[req]}
		}
	}
}

func (g *guard) continuedLocked(k callKey, failed bool) {
	h, ok := g.continues[k]
	if !ok {
		return
	}
	delete(g.continues, k)
	if !failed && g.handed[h.req] == h.pause {
		delete(g.handed, h.req)
	}
}

func (g *guard) settlePausedLocked(m *message, p map[string]any, id string) [][]byte {
	defaultAuth := map[string]any{"response": "Default"}
	document := p["resourceType"] == "Document"
	idKey := g.pauseLinks[requestKey{m.SessionID, id}]
	owned := g.clientOwnedLocked(idKey.session, idKey.request)
	if owned {
		defaultAuth = map[string]any{"response": "CancelAuth"}
	}
	var method string
	frameID, _ := p["frameId"].(string)
	targetID := g.worldTargetLocked(m.SessionID)
	params := map[string]any{"requestId": id}
	switch m.Method {
	case "Network.requestIntercepted":
		g.logf("cdp: settled an intercepted request into a protected origin without showing it to the page target=%s session=%s frame=%s", targetID, m.SessionID, frameID)
		method = "Network.continueInterceptedRequest"
		params = map[string]any{"interceptionId": id}
		if _, ok := p["authChallenge"]; ok {
			params["authChallengeResponse"] = defaultAuth
		} else if document || owned {
			params["errorReason"] = "BlockedByClient"
		}
	case "Fetch.authRequired":
		g.logf("cdp: answered an auth challenge from a protected origin without showing it to the page target=%s session=%s frame=%s", targetID, m.SessionID, frameID)
		method = "Fetch.continueWithAuth"
		params["authChallengeResponse"] = defaultAuth
	default:
		if document || owned {
			g.logf("cdp: failed a document request into a protected origin that a page session paused target=%s session=%s frame=%s", targetID, m.SessionID, frameID)
			method = "Fetch.failRequest"
			params["errorReason"] = "BlockedByClient"
		} else {
			g.logf("cdp: continued a request into a protected origin without showing it to the page target=%s session=%s frame=%s", targetID, m.SessionID, frameID)
			method = "Fetch.continueRequest"
		}
	}
	var send [][]byte
	if document && params["errorReason"] == "BlockedByClient" {
		send = g.blockChildLocked(targetID, frameID)
	}
	msg, _ := g.newCallLocked(m.SessionID, method, params, false)
	return append(send, msg)
}

type handedPause struct {
	req   requestKey
	pause int
}

func (g *guard) handOutLocked(k requestKey) {
	if k.request == "" {
		return
	}
	g.pauses++
	g.handed[k] = g.pauses
	g.handedOrder = append(g.handedOrder, handedPause{k, g.pauses})
	for len(g.handedOrder) > maxSettled {
		if old := g.handedOrder[0]; g.handed[old.req] == old.pause {
			delete(g.handed, old.req)
		}
		g.handedOrder = g.handedOrder[1:]
	}
}

func (g *guard) namesProtectedLocked(headers any) bool {
	var values []string
	switch h := headers.(type) {
	case []any:
		for _, item := range h {
			e, _ := item.(map[string]any)
			if v, ok := e["value"].(string); ok {
				values = append(values, v)
			}
		}
	case map[string]any:
		for _, v := range h {
			if s, ok := v.(string); ok {
				values = append(values, s)
			}
		}
	}
	for _, v := range values {
		if _, cut := g.cutEmbedded(v); cut || g.cutWhole(v) {
			return true
		}
	}
	return false
}

func (g *guard) cutWhole(v string) bool {
	_, ok := g.cut(v)
	return ok
}
