#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { readdirSync, readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { parseArgs } from 'node:util';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const { values } = parseArgs({
  options: {
    dir: { type: 'string', default: join(root, 'dist', 'npm') },
    tag: { type: 'string', default: 'latest' },
    'dry-run': { type: 'boolean', default: false },
    'require-registry': { type: 'boolean', default: false },
  },
});
const dryRun = values['dry-run'];
const tag = values.tag;

const guarded = {
  sliccy: { tag: 'next', version: /^7\.0\.0-next\./ },
};
const companions = new Set(['@ai-ecoverse/slicc-jerk']);

function fail(message, code = 1) {
  process.stderr.write(`npm-publish: ${message}\n`);
  process.exit(code);
}

function npm(args, options = {}) {
  return spawnSync('npm', args, { encoding: 'utf8', shell: process.platform === 'win32', ...options });
}

function minimumNpm() {
  const [major, minor, patch] = npm(['--version']).stdout.trim().split('.').map(Number);
  const ok = major > 11 || (major === 11 && (minor > 5 || (minor === 5 && patch >= 1)));
  if (!ok) fail('npm trusted publishing needs npm 11.5.1 or newer');
}

function published(name, version) {
  const res = npm(['view', `${name}@${version}`, 'version']);
  return res.status === 0 && res.stdout.trim() === version;
}

async function publishPackage(pkg, args) {
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    const res = npm(args);
    if (res.stdout) process.stdout.write(res.stdout);
    if (res.stderr) process.stderr.write(res.stderr);
    if (res.status === 0) return;
    if (dryRun) fail(`npm publish ${pkg.name}@${pkg.version} failed`);
    if (published(pkg.name, pkg.version)) {
      process.stdout.write(`${pkg.name}@${pkg.version} is published after the publish error\n`);
      return;
    }
    const output = `${res.stdout ?? ''}\n${res.stderr ?? ''}`;
    const conflict = /TLOG_CREATE_ENTRY_ERROR/i.test(output)
      || (/\b409\b/.test(output) && /transparency\s+log|sigstore|rekor/i.test(output));
    if (!conflict) fail(`npm publish ${pkg.name}@${pkg.version} failed`);
    if (attempt === 3) fail(`npm publish ${pkg.name}@${pkg.version} failed after ${attempt} attempts`);
    const delay = 5000 * 2 ** (attempt - 1);
    process.stdout.write(`retrying npm publish ${pkg.name}@${pkg.version} in ${delay / 1000} s after the transparency log conflict\n`);
    await new Promise((resolve) => setTimeout(resolve, delay));
  }
}

function registry() {
  const configured = process.env.npm_config_registry || npm(['config', 'get', 'registry']).stdout.trim();
  return (configured || 'https://registry.npmjs.org/').replace(/\/+$/, '');
}

async function onRegistry(base, name, version, timeoutMs) {
  try {
    const res = await fetch(`${base}/${name.replace('/', '%2f')}/${version}`, {
      headers: { accept: 'application/json', 'cache-control': 'no-cache' },
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (!res.ok) return `HTTP ${res.status}`;
    const got = (await res.json()).version;
    return got === version ? '' : `answers ${got ?? 'no version'}`;
  } catch (error) {
    return error.name === 'TimeoutError' ? `no answer in ${Math.round(timeoutMs / 1000)} s` : error.cause?.code ?? error.cause?.message ?? error.message;
  }
}

async function requireDependencies(pkg) {
  const deps = Object.entries(pkg.optionalDependencies || {}).filter(([name]) => !companions.has(name));
  if (!guarded[pkg.name]?.tag || !deps.length) return;
  const base = registry();
  const waitMs = Number(process.env.SLICC_REGISTRY_WAIT_SECONDS ?? 900) * 1000;
  const deadline = Date.now() + waitMs;
  for (;;) {
    const missing = [];
    for (const [name, version] of deps) {
      const timeoutMs = Math.min(30000, Math.max(5000, deadline - Date.now()));
      const why = await onRegistry(base, name, version, timeoutMs);
      if (why) missing.push(`${name}@${version} (${why})`);
    }
    if (!missing.length) break;
    if (Date.now() >= deadline) fail(`refusing to publish ${pkg.name}@${pkg.version}; not on the registry: ${missing.join(', ')}`, 3);
    process.stdout.write(`waiting for ${missing.join(', ')} to appear on the registry\n`);
    await new Promise((resolve) => setTimeout(resolve, Math.min(30000, Math.max(1000, deadline - Date.now()))));
  }
  process.stdout.write(`every optional dependency of ${pkg.name}@${pkg.version} is on the registry\n`);
}

function check(pkg) {
  const rule = guarded[pkg.name];
  if (!rule?.tag) return;
  if (tag !== rule.tag) fail(`refusing to publish ${pkg.name} with the tag ${tag}; it only goes to ${rule.tag}`);
  if (!rule.version.test(pkg.version)) fail(`refusing to publish ${pkg.name}@${pkg.version}; its version must match ${rule.version}`);
}

function npmTag(pkg) {
  if (dryRun && !guarded[pkg.name]?.tag && tag === 'latest' && pkg.version.includes('-')) return 'dry-run';
  return tag;
}

const packages = readdirSync(values.dir)
  .map((entry) => join(values.dir, entry))
  .map((dir) => ({ dir, pkg: JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) }))
  .sort((a, b) => Number(Boolean(a.pkg.optionalDependencies)) - Number(Boolean(b.pkg.optionalDependencies)));

if (packages.length === 0) fail(`no packages in ${values.dir}`);
for (const { pkg } of packages) check(pkg);

if (!dryRun) minimumNpm();
let already = 0;
for (const { dir, pkg } of packages) {
  if (!dryRun && published(pkg.name, pkg.version)) {
    process.stdout.write(`${pkg.name}@${pkg.version} is already published\n`);
    already += 1;
    continue;
  }
  if (!dryRun || values['require-registry']) await requireDependencies(pkg);
  const args = ['publish', dir, '--access', 'public', '--tag', npmTag(pkg)];
  args.push(dryRun ? '--dry-run' : '--provenance');
  await publishPackage(pkg, args);
}
process.stdout.write(
  `npm-publish: PASS ${tag}: ${dryRun ? `checked ${packages.length}` : `published ${packages.length - already}, ${already} already published`} of ${packages.length} packages\n`,
);
