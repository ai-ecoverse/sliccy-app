//go:build !wasip1

package main

import (
	"fmt"
	"io"
	"os"
)

var version = "dev"

const usage = `slicc: SLICC's command line for seven

usage:
  slicc [flags]             find browsers, open seven in the best one and link
                            it; flags below
  slicc attach --cdp <url>  link a seven open in a running CDP browser
  slicc open                link seven in your everyday browser, without CDP:
                            open a pairing URL in the default browser
                            (also slicc --default-browser)
  slicc pair                the same, but only print the pairing URL
  slicc unpair [--all]      list or forget sevens paired with open or pair
  slicc <join-url> follow   follow a seven's tray from this machine
                            (- or @<file> in place of <join-url> reads it
                            from stdin or a file, out of sight of ps)
  slicc tray [-a] [-q]      list the slicc processes here that hold a link
  slicc <join-url> prompt [--allsettled <quiet>] <text>
                            send a prompt to seven's agent and stream the
                            answer (--allsettled: until seven has settled)
  slicc <join-url> watch    follow seven's agent as it works
  slicc <join-url> wait [--allsettled <quiet>] [--timeout <limit>]
                            wait until seven's agent has nothing left to do
  slicc <join-url> abort    abort the agent's run
  slicc <join-url> agents [--watch]
                            list seven's agents, their status and model
                            (prompt, watch, wait, abort and agents also take
                            --cdp <url> instead of a join URL)
  slicc browsers            list CDP endpoints and installed browsers, ranked
  slicc launch              launch a browser with CDP in a separate SLICC profile
  slicc update [--check]    replace this binary with the latest release
  slicc install jerk        install slicc-jerk into slicc's data folder
  slicc capabilities --json what this slicc offers a program that drives it
  slicc --version           print the version
  slicc --help              print this help
` + defaultHelp

func run(args []string, stdout, stderr io.Writer) int {
	if len(args) > 0 && args[0] == "capabilities" {
		return runCapabilities(args[1:], stdout, stderr)
	}
	companionsOnPath()
	defer startup(args, stderr)()
	if isDefault(args) {
		return runDefault(args, stdout, stderr)
	}
	switch args[0] {
	case "--version", "-V", "version":
		fmt.Fprintf(stdout, "slicc %s\n", version)
		return 0
	case "browsers":
		return runBrowsers(args[1:], stdout, stderr)
	case "launch":
		return runLaunch(args[1:], stdout, stderr)
	case "--help", "-h", "help":
		fmt.Fprint(stdout, usage)
		return 0
	case "attach":
		return attach(args[1:], os.Stdin, stdout, stderr)
	case "update":
		return runUpdate(args[1:], stdout, stderr)
	case "install":
		return runInstall(args[1:], stdout, stderr)
	case "open", "pair":
		return runOpen(args[0], args[1:], os.Stdin, stdout, stderr)
	case "unpair":
		return runUnpair(args[1:], stdout, stderr)
	case "tray":
		return runTray(args[1:], stdout, stderr)
	case "prompt", "watch", "wait", "abort", "agents":
		return runAgent(args[0], "", args[1:], agentIO{stdin: os.Stdin, stdout: stdout, stderr: stderr})
	default:
		if isJoinRef(args[0]) {
			join, err := readJoinRef(args[0], os.Stdin)
			if err != nil {
				fmt.Fprintf(stderr, "slicc: %v\n", err)
				return 2
			}
			return joinCommand(append([]string{join}, args[1:]...), stdout, stderr)
		}
		if looksLikeURL(args[0]) {
			return joinCommand(args, stdout, stderr)
		}
		if six := sixFlagIn(args); six != "" {
			return sixPointer(stderr, six, args)
		}
		fmt.Fprintf(stderr, "slicc: unknown command %q\n\n%s", args[0], usage)
		return 2
	}
}

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, os.Stderr))
}
